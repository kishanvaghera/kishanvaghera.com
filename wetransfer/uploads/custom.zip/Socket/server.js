const express = require('express');
const sha1 = require('sha1');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
var cors = require('cors');
const http = require("http");
const fs = require('fs');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const uuid = require('uuid');
const url = require('url');

const app = express();
const server = http.createServer(app);

// const io = require('socket.io')(server, {
//   maxHttpBufferSize: 1e8
// });

const WebSocket = require('ws');

const io = new WebSocket.Server({ port: 8080, maxPayload: 1e8,perMessageDeflate: false });

const clients = new Map();

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header("Cache-Control", "public, max-age=3600");
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// const corsOptions = {
//   origin: 'http://192.168.1.229',
//   optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
// };

app.use(cors())
app.use(express.json({ limit: '1000mb' }));
app.use(bodyParser.json({ limit: '1000mb', extended: true }));
app.use(bodyParser.urlencoded({ limit: "1000mb", extended: true }));
app.use(bodyParser.text({ limit: '1000mb' }));

const mainUrl = "http://192.168.1.229:9001/";
const MainProjectUrl="http://192.168.1.229/chat-app-dev/";

//Mail Send Function
async function NewSMTPMailSend(toEmail, vSubject, vEmailBody) {
  let transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true, // true for 465, false for other ports
      auth: {
          user: 'kishan.v@enlivendc.com', // SMTP username
          pass: 'separ@462*' // SMTP password
      }
  });

  let mailOptions = {
      from: '"Chat App" <kishan.v@enlivendc.com>', // sender address
      to: Array.isArray(toEmail) ? toEmail.join(',') : toEmail, // list of receivers
      subject: vSubject, // Subject line
      html: vEmailBody // html body
  };

  try {
      let info = await transporter.sendMail(mailOptions);
      console.log('Message sent: %s', info.messageId);
      return 1;
  } catch (error) {
      console.error('Error sending email:', error);
      return 0;
  }
}

//Crypto String
function encryptString(str) {
  const algorithm = 'aes-128-ctr';
  const encryptionKey = crypto.createHash('sha256').update('ChatApp001').digest('base64').substr(0, 16); // Ensure 16 bytes key
  const iv = Buffer.from('1234567891011121'); // Must be 16 bytes for AES-128

  const cipher = crypto.createCipheriv(algorithm, encryptionKey, iv);
  let encrypted = cipher.update(str, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  return encrypted;
}

function decryptString(encryptedStr) {
  const algorithm = 'aes-128-ctr';
  const encryptionKey = crypto.createHash('sha256').update('ChatApp001').digest('base64').substr(0, 16); // Ensure 16 bytes key
  const iv = Buffer.from('1234567891011121'); // Must be 16 bytes for AES-128

  const decipher = crypto.createDecipheriv(algorithm, encryptionKey, iv);
  let decrypted = decipher.update(encryptedStr, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

//Mask Email
function maskEmail(email) {
  return email.replace(/(?<=.{5}).(?=.*@)/g, '*');
}

//Get Current Date in 12_01_2024 format
const currentDate = (dateStr = "") => {
  let date = dateStr == "" ? new Date() : new Date(dateStr);
  let year = date.getFullYear();
  let month = ('0' + (date.getMonth() + 1)).slice(-2);
  let day = ('0' + date.getDate()).slice(-2);

  let formattedDate = day + "_" + month + "_" + year;

  return formattedDate;
}

//Convert Date Time To Date for file only
const ConvertDateForFile = (dateStr) => {
  const newSplitStr = String(dateStr).split(" ");
  const DateSplitStr = String(newSplitStr[0]).split("-");

  let year = DateSplitStr[0];
  let month = DateSplitStr[1];
  let day = DateSplitStr[2];

  let formattedDate = day + "_" + month + "_" + year;

  return formattedDate;
}

//Unique Value Arr
function duplicateRemoveArr(data){
  return data.length?data.filter((value, index, arr) => index === arr.indexOf(""+value)):[]
}

//Get Last file of user conversion
const getLastFileOfUser = (iUserId, iToUserId) => {
  if (fs.existsSync("DB/COMMONDB.json")) {
    var content = fs.readFileSync('DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const filterData = dd.array.filter((curEle, index) => {
      return (curEle.senderId == iUserId && curEle.recieverId == iToUserId) || (curEle.senderId == iToUserId && curEle.recieverId == iUserId)
    })

    return filterData.length > 0 ? filterData[0]['created_at'] : "";
  } else {
    return "";
  }

};

//Get Last file of user group conversion
const getLastFileOfUserGroup = (iGroupId) => {
  const dbFolderPath = "DB/";

  const NewArr = fs.readdirSync(dbFolderPath);

  const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;

  let newDateArr = [];
  const fileExist = dd.length ? dd.filter((curEle, index) => {
    const splitStr = String(curEle).split("_");

    if (splitStr[0] == "GROUP" && splitStr[1] == iGroupId) {
      const day = splitStr[2];
      const month = splitStr[3];
      const year = String(splitStr[4]).split(".")[0];

      const DateString = year + "-" + month + "-" + day;
      newDateArr.push(DateString);
    }

    return splitStr[1] == iGroupId;
  }) : []

  if (fileExist.length > 0) {
    const sortingArr = newDateArr.length ? newDateArr.sort((a, b) => (a ?? '').localeCompare(b ?? '')) : []
    const dateSplit = String(sortingArr[sortingArr.length - 1]).split("-");
    const finalDate = dateSplit[2] + "_" + dateSplit[1] + "_" + dateSplit[0];

    const dateString = "GROUP_" + iGroupId + "_" + finalDate + ".json";

    if (dd.includes(dateString)) {
      var content = fs.readFileSync('./DB/' + dateString, 'utf8');
      const fileDD = typeof content == "string" ? JSON.parse(content) : content;

      const lastDate = fileDD.array ? fileDD.array[Number(fileDD.array.length) - 1]['created_at'] : "";

      return { date: finalDate, time: lastDate };
    } else {
      return { date: "", time: "" };
    }
  } else {
    // return "GROUP_"+iGroupId+"_"+currentDate()+".json";
    return { date: "", time: "" };
  }
};

//Get Before Weak Date
const oneMonthBackDate = (givenDateStr = "") => {
  var givenDate = new Date();
  if (givenDateStr != "") {
    // Split the given date string into day, month, and year
    var parts = givenDateStr.split("_");

    var day = parseInt(parts[1], 10);
    var month = parseInt(parts[2], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[3], 10);
    givenDate = new Date(year, month, day);
  }

  // Calculate the date before by subtracting the number of milliseconds in a day
  var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
  var daysBefore = 7; // Number of days before
  var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

  // Format the target date as dd_mm_yyyy
  var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

  return targetDateString;
}

//Get Before Weak Date
const oneMonthBackDateGroup = (givenDateStr = "") => {
  var givenDate = new Date();
  if (givenDateStr != "") {
    // Split the given date string into day, month, and year
    var parts = givenDateStr.split("_");

    var day = parseInt(parts[2], 10);
    var month = parseInt(parts[3], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[4], 10);
    givenDate = new Date(year, month, day);
  }

  // Calculate the date before by subtracting the number of milliseconds in a day
  var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
  var daysBefore = 7; // Number of days before
  var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

  // Format the target date as dd_mm_yyyy
  var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

  return targetDateString;
}

//get Two Date Array List
const GetMonthArrayDate = (startDateStr, endDateStr, vPrefix = "") => {
  // Given dates in the format dd_mm_yyyy

  // Function to convert date string to Date object
  function stringToDate(dateStr) {
    var parts = dateStr.split("_");
    var day = parseInt(parts[0], 10);
    var month = parseInt(parts[1], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[2], 10);
    return new Date(year, month, day);
  }

  // Convert date strings to Date objects
  var startDate = stringToDate(startDateStr);
  var endDate = stringToDate(endDateStr);

  // Array to store the list of dates
  var dateList = [];

  // Loop to generate the list of dates between startDate and endDate
  var currentDate = new Date(startDate);
  while (currentDate <= endDate) {
    // Format the current date as dd_mm_yyyy
    var dateString = currentDate.getDate().toString().padStart(2, '0') + "_" + (currentDate.getMonth() + 1).toString().padStart(2, '0') + "_" + currentDate.getFullYear();

    // Push the formatted date string into the dateList array
    dateList.push(vPrefix + "_" + dateString + ".json");

    // Move to the next day
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return dateList;
}

const saveBlobFile = (file, uploadFolder) => {
  if(file!=""){
    var base64Data = String(file).split("base64,");
  
    fs.writeFile(uploadFolder, base64Data[1], 'base64', (err) => {
      if (err) throw err;
    })
  }
}

function getUnreadMsg(date, iUserId, receverId) {
  if (fs.existsSync('./DB/' + iUserId + '_' + currentDate(date) + '.json')) {
    var content = fs.readFileSync('./DB/' + iUserId + '_' + currentDate(date) + '.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const totalUnreadMsg = dd.array.filter((curEle, index) => {
      return curEle.iRead == 0 && curEle.iFromUserId == receverId
    })

    return totalUnreadMsg.length
  } else {
    return 0
  }
}

function isCommunicate(iUserId, receverId) {
  if (fs.existsSync('./DB/COMMONDB.json')) {
    var content = fs.readFileSync('./DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const isMsgExist = dd.array.filter((curEle, index) => {
      return curEle.senderId == iUserId && curEle.recieverId == receverId
    })

    return isMsgExist.length
  } else {
    return 0
  }
}

function isStartChatMsg(iUserId, receverId){
  // isStartChat
  if (fs.existsSync('./DB/COMMONDB.json')) {
    var content = fs.readFileSync('./DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const isMsgExist = dd.array.filter((curEle, index) => {
      return curEle.senderId == iUserId && curEle.recieverId == receverId && curEle.isStartChat
    })

    return isMsgExist.length
  } else {
    return 0
  }
}

function getGroupUnreadMsg(date, iGroupId, iUserId) {
  if (fs.existsSync('./DB/GROUP_' + iGroupId + '_' + date + '.json')) {
    var content = fs.readFileSync('./DB/GROUP_' + iGroupId + '_' + date + '.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const totalUnreadMsg = dd.array.filter((curEle, index) => {
      return !String(curEle.tReadUsers).split(",").includes("" + iUserId);
    })
    return totalUnreadMsg.length
  } else {
    return 0
  }
}

const datFunction = () => {
  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1; // Months start at 0!
  let dd = today.getDate();

  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;

  const formattedToday = dd + '_' + mm + '_' + yyyy;

  return formattedToday;
}

const currentDateTime = () => {
  return new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].replace('T', ' ')
}

const lastChatUpdate = (senderChatID, receiverChatID,isStartChat="") => {

  if (fs.existsSync("DB/COMMONDB.json")) {

    const data = fs.readFileSync('DB/COMMONDB.json', 'utf8');

    const db = typeof data == "string" ? JSON.parse(data) : data;

    let ikeyUpdate = "";
    const filterData = db?.array.filter((curEle, index) => {
      const checkCondi = curEle.senderId == senderChatID && curEle.recieverId == receiverChatID;
      if (checkCondi) {
        ikeyUpdate = index;
      }
      return checkCondi
    })

    if (filterData.length) {
      db.array[ikeyUpdate] = {
        senderId: senderChatID,
        recieverId: receiverChatID,
        created_at: currentDateTime(),
        isStartChat:isStartChat==""?db.array[ikeyUpdate]['isStartChat']:isStartChat
      }

      fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));

    } else {
      db.array.push({
        senderId: senderChatID,
        recieverId: receiverChatID,
        created_at: currentDateTime(),
        isStartChat:isStartChat
      })

      fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));
    }
  } else {
    let db = {
      array: [
        {
          senderId: senderChatID,
          recieverId: receiverChatID,
          created_at: currentDateTime(),
          isStartChat:isStartChat
        }
      ]
    }

    fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));
  }
}

const JsonFileGenerate = (senderJsonFile, senderChatID, receiverChatID, content, isSend, vReplyMsg, vReplyMsg_id,id,vReplyFileName,isGroup=0,isThumb="",isGreetingMsg=0,iRequestMsg=0,vMemeberList="",vGroupMessageType="",isForwardMsg=0,isDeleteprofile=0,vDeleteMemberId=0,vNewAdminId="",RequestMemberId="") => {
  if (fs.existsSync('DB/' + senderJsonFile)) {
    const data = fs.readFileSync('DB/' + senderJsonFile, 'utf8');

    const db = data == "" ? { array: [] } : JSON.parse(data);

    let vReplyMsg_idFinal = vReplyMsg_id;
    let vReplyMsgFinal = vReplyMsg;

    if (vReplyMsg_idFinal!="") {
      let explodeId=String(vReplyMsg_idFinal).split("_");
      let readableDate = new Date(Number(explodeId[2])).toLocaleString();

      const dataOld =isGroup==1?fs.readFileSync('DB/' + "GROUP_"+explodeId[1]+"_"+currentDate(Number(explodeId[2]))+".json", 'utf8'):fs.readFileSync('DB/' + explodeId[0]+"_"+currentDate(Number(explodeId[2]))+".json", 'utf8');
      const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);

      if (dbOld.array.length) {
          const filterData=dbOld?.array.filter((curEle,index)=>{
            return curEle.id==vReplyMsg_idFinal
          })
          if(filterData.length>0){
            vReplyMsgFinal = filterData[0]['message'];
          }
      }
    }

    db.array.push({
      id: id,
      iFromUserId: senderChatID,
      iToUserId: receiverChatID,
      iRead: isSend == 1 ? 1 : 0,
      iReadTo: 0,
      message: content,
      created_at: currentDateTime(),
      vReplyMsg: vReplyMsgFinal,
      vReplyMsg_id: vReplyMsg_idFinal,
      tReadUsers: senderChatID,
      vReplyFileName:vReplyFileName,
      iDeleted: 0,
      iEdited:0,
      vImageThumb:isThumb,
      isGreetingMsg:isGreetingMsg,
      iRequestMsg:iRequestMsg,
      vMemeberList:vMemeberList,
      vGroupMessageType:vGroupMessageType,
      isForwardMsg:isForwardMsg,
      isDeleteprofile:isDeleteprofile,
      vDeleteMemberId:vDeleteMemberId,
      vNewAdminId:vNewAdminId,
      RequestMemberId:RequestMemberId
    });

    let jsonData = JSON.stringify(db);

    fs.writeFileSync('DB/' + senderJsonFile, jsonData);
  } else {
    const db = { array: [] }

    db.array.push({
      id: id,
      iFromUserId: senderChatID,
      iToUserId: receiverChatID,
      iRead: 0,
      iReadTo: 0,
      message: content,
      created_at: currentDateTime(),
      vReplyMsg,
      vReplyMsg_id,
      tReadUsers: senderChatID,
      vReplyFileName:vReplyFileName,
      iDeleted: 0,
      iEdited:0,
      vImageThumb:isThumb,
      isGreetingMsg:isGreetingMsg,
      iRequestMsg:iRequestMsg,
      vMemeberList:vMemeberList,
      vGroupMessageType:vGroupMessageType,
      isForwardMsg:isForwardMsg,
      isDeleteprofile:isDeleteprofile,
      vDeleteMemberId:vDeleteMemberId,
      vNewAdminId:vNewAdminId,
      RequestMemberId:RequestMemberId
    });

    let jsonData = JSON.stringify(db);

    fs.writeFileSync('DB/' + senderJsonFile, jsonData);
  }
}



// Sign up Api
app.post('/signup', (req, res) => {
  const { vUsername, vFullName, iEngId,vPassWord,vEmail } = req.body;

  const userFileName="Users.json";

  const vNewPassword=sha1(vPassWord);
  const randProfile=Math.floor(Math.random() * 9) + 1;

  const randomNumber=Math.floor(Math.random() * 900000) + 100000;

  const arrayObj={isLoggedUser:iEngId,vFullName:vFullName,vEmail:vEmail};
  const jsonString = JSON.stringify(arrayObj);
  const encodedString = encodeURIComponent(jsonString);
  const encrptStr=encryptString(encodedString);

  const mailHtml=`<p>User Id:- <b>${iEngId}</b> <br/> User Name:- <b>${vFullName}</b> <br/>OTP Code :- ${randomNumber}</p> <br/> <p>Verify email with link:-</p> <br/> ${MainProjectUrl}check_verify?id=${encrptStr}`;

  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const filterCheckDuplicate=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==iEngId;
      })

      if(filterCheckDuplicate.length){
        res.send({ message: 'User Id  is already exist!', status: 412 });
      }else{
        const newDataUpdateArr = dd.array;
        newDataUpdateArr.push({
          iUserId:Number(dd.array.length)+1,
          iEngId:iEngId,
          vUsername:vUsername,
          vFullName:vFullName,
          vPassword:vNewPassword,
          vProfilePic:"",
          vEmail:vEmail,
          tToken:"",
          vChatId:"",
          eCustStatus:2,
          iColorOption:randProfile,
          tGroupIds:"",
          iStatus:0,
          dLoginDateTime:"",
          iEmailVerified:0,
          vOtp:randomNumber,
          eStatus:"y",
        });

        fs.writeFileSync("DB/"+userFileName, JSON.stringify({ array: newDataUpdateArr }));

        NewSMTPMailSend(vEmail, 'Verify Email', mailHtml)
        .then(result => {
            if (result === 1) {
              res.send({ message: 'User created successfully', status: 200 });
            } else {
                console.log('Failed to send email');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

      }

    }
  }else{
    const db = { array: [] }
    db.array.push({
        iUserId:1,
        iEngId:iEngId,
        vUsername:vUsername,
        vFullName:vFullName,
        vPassword:vNewPassword,
        vProfilePic:"",
        vEmail:vEmail,
        tToken:"",
        vChatId:"",
        eCustStatus:2,
        iColorOption:randProfile,
        tGroupIds:"",
        iStatus:0,
        dLoginDateTime:"",
        iEmailVerified:0,
        vOtp:randomNumber,
        eStatus:"y",
    })

    let jsonData = JSON.stringify(db);

    fs.writeFileSync('DB/'+userFileName, jsonData);

    NewSMTPMailSend(vEmail, 'Verify Email', mailHtml)
    .then(result => {
        if (result === 1) {
          res.send({ message: 'User created successfully', status: 200 });
        } else {
            console.log('Failed to send email');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
  }
});

//Verify Email
app.post('/verify_email', (req, res) => {
  const { urlString } = req.body;

  const decryptedString = decryptString(urlString);
  const decodedString = decodeURIComponent(decryptedString);

  const decryptedObj = JSON.parse(decodedString);

  if(decodedString!="" && decryptedObj?.isLoggedUser){
    const userFileName="Users.json";
  
    if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
    
      if (contentReadFile != "") {
        const dd = JSON.parse(contentReadFile);
        
        const chekcDataExist=dd.array.filter((curEle,index)=>{
          return curEle.eStatus=="y" && curEle.iEngId==decryptedObj?.isLoggedUser;
        })
       
        if(chekcDataExist.length){

          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['iEmailVerified']:curEle2.iUserId==chekcDataExist[0]['iUserId']?1:curEle2.iEmailVerified,
              ['vOtp']:curEle2.iUserId==chekcDataExist[0]['iUserId']?"":curEle2.vOtp
            }
          })

          fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

          res.send({ message: 'Email has been verified successfully.', status: 200 });

        }else{
          res.send({ message: 'User not found.', status: 412});
        }
      }
    }

  }else{
    res.send({ message: 'Link is not found.', status: 412});
  }
})

//Re send verify email
app.post('/resend_verify_email', (req, res) => {
  const { vUsername,vNewEmailAddrs,type } = req.body;

  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const getUserData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==vUsername;
      })

      if(getUserData.length){

        const vEmail=type==1?getUserData[0]['vEmail']:vNewEmailAddrs;

        const randomNumber=Math.floor(Math.random() * 900000) + 100000;

        const arrayObj={isLoggedUser:getUserData[0]['iEngId'],vFullName:getUserData[0]['vFullName'],vEmail:vEmail};
        const jsonString = JSON.stringify(arrayObj);
        const encodedString = encodeURIComponent(jsonString);
        const encrptStr=encryptString(encodedString);

        //Update Otp in User json file
        const mailHtml=`<p>User Id:- <b>${getUserData[0]['iEngId']}</b> <br/> User Name:- <b>${getUserData[0]['vFullName']}</b> <br/>OTP Code :- ${randomNumber}</p> <br/> <p>Verify email with link:-</p> <br/> ${MainProjectUrl}check_verify?id=${encrptStr}`;

        const newDataUpdateArr = dd.array.map((curEle2, index) => {
          return {
            ...curEle2,
            ['vOtp']:curEle2.iUserId==getUserData[0]['iUserId']?randomNumber:curEle2.vOtp,
          }
        })

        fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

        //New otp Mail send
        NewSMTPMailSend(vEmail, 'Verify Email', mailHtml)
        .then(result => {
            if (result === 1) {
              res.send({ message: 'Verify email has been sent successfully.', status: 200 });
            } else {
              res.send({ message: 'Please try again later.', status: 412 });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            res.send({ message: 'Please try again later.', status: 412 });
        });
        
      }else{
        res.send({ message: 'User not found.', status: 412});
      }
    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//Verify Email Code
app.post('/email_code_verify', (req, res) => {
  const { vUsername,vOtp } = req.body;

  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const getUserData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==vUsername;
      })

      if(getUserData.length){
        if(getUserData[0]['vOtp']==vOtp){

          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['iEmailVerified']:curEle2.iUserId==getUserData[0]['iUserId']?1:curEle2.iEmailVerified,
              ['vOtp']:curEle2.iUserId==getUserData[0]['iUserId']?"":curEle2.vOtp
            }
          })
  
          fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));
  
          res.send({ message: "Your email has been verified successfully.", status: 200});

        }else{
          res.send({ message: 'Verification code not valid.', status: 412});
        }
      }else{
        res.send({ message: 'User not found.', status: 412});
      }

    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//Forgot password mail
app.post('/forgot_password', (req, res) => {
  const { vUsername } = req.body;

  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const getUserData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==vUsername;
      })

      if(getUserData.length){

        const arrayObj={isLoggedUser:getUserData[0]['iEngId'],vFullName:getUserData[0]['vFullName']};
        const jsonString = JSON.stringify(arrayObj);
        const encodedString = encodeURIComponent(jsonString);
        const encrptStr=encryptString(encodedString);

        //New password link send mail
        const mailHtml=`<p>User Id:- <b>${getUserData[0]['iEngId']}</b> <br/> User Name:- <b>${getUserData[0]['vFullName']}</b></p> <p>Forgot password link:- </p> ${MainProjectUrl}forgot_password?id=${encrptStr}`;

        NewSMTPMailSend(getUserData[0]['vEmail'], 'Forgot password', mailHtml)
        .then(result => {
            if (result === 1) {
              res.send({ message: 'New password change request link mail has been sent successfully.', status: 200 });
            } else {
              res.send({ message: 'Please try again later.', status: 412 });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            res.send({ message: 'Please try again later.', status: 412 });
        });

      }else{
        res.send({ message: 'User not found.', status: 412});
      }

    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }
})

// Login Api
app.post('/login', (req, res) => {
  const { iUserId, vPassword } = req.body;

  // Find the user in the database
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const filterCheckDuplicate=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==iUserId;
      })

      const vNewPassword=sha1(""+vPassword);

      if(filterCheckDuplicate.length){
        if(filterCheckDuplicate[0]['vPassword']==vNewPassword){

          if(filterCheckDuplicate[0]['iEmailVerified']==0 || filterCheckDuplicate[0]['iEmailVerified']==""){

            res.send({ message: 'Please verify email address',type:"verify_email", status: 411,data:maskEmail(filterCheckDuplicate[0]['vEmail'])});
            
          }else{
            if(filterCheckDuplicate[0]['iStatus']==1){

              res.send({ message: 'You are logged in on another PC. Simultaneous logins are not allowed. If you want to log in on this PC, the other session will be logged out.',type:"already_login", status: 411,tToken:filterCheckDuplicate[0]['tToken']});

            }else{
  
              const currentTimeString = Math.floor(Date.now() / 1000) * 60;
              const token = jwt.sign({ vUsername: filterCheckDuplicate[0]['vUsername'], vFullName: filterCheckDuplicate[0]['vFullName'], LoginTime: currentTimeString }, 'chatApp001');

              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                return {
                  ...curEle2,
                  ['dLoginDateTime']:curEle2.iUserId==filterCheckDuplicate[0]['iUserId']?currentDateTime():curEle2.dLoginDateTime,
                  ['tToken']:curEle2.iUserId==filterCheckDuplicate[0]['iUserId']?token:curEle2.tToken
                }
              })

              fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

              res.send({ message: 'Logged in successfully', status: 200, tToken: token, iUserId: filterCheckDuplicate[0]['iUserId'] });

            }
          }

        }else{
          res.send({ message: 'Please check username or password.', status: 412});
        }
      }else{
        res.send({ message: 'User is not exist.', status: 412});
      }
    }else{
      res.send({ message: 'User is not exist.', status: 412});
    }
  }else{
    res.send({ message: 'User is not exist.', status: 412});
  }
  
});

//Get Username from user id Api
app.post('/getUserName', (req, res) => {
  const { iUserId } = req.body;
  
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const getUserData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iEngId==iUserId;
      })

      if(getUserData.length){
        res.send({ message: getUserData[0]['vFullName'],vEmail:getUserData[0]['vEmail'], status: 200});
      }else{
        res.send({ message: 'User not found.', status: 412});
      }
    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }
})

//Change Password Api
app.post('/change_password', (req, res) => {
  const { urlString,vPassWord } = req.body;

  const decryptedString = decryptString(urlString);
  const decodedString = decodeURIComponent(decryptedString);

  const decryptedObj = JSON.parse(decodedString);

  if(decodedString!="" && decryptedObj?.isLoggedUser){

      const userFileName="Users.json";
      
      if (fs.existsSync("DB/"+userFileName)) {
        const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
      
        if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
          
          const checkUserExist=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.iEngId==decryptedObj?.isLoggedUser;
          })
    
          if(checkUserExist.length){
    
            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              return {
                ...curEle2,
                ['vPassword']:curEle2.iUserId==checkUserExist[0]['iUserId']?sha1(vPassWord):curEle2.vPassword,
              }
            })
    
            fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));
    
            res.send({ message: "Your password has been changed successfully.", status: 200});
    
          }else{
            res.send({ message: 'User not found.', status: 412});
          }
    
        }else{
          res.send({ message: 'User not found.', status: 412});
        }
        
      }else{
        res.send({ message: 'User not found.', status: 412});
      }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//Check password Api
app.post('/checkPassword', (req, res) => {
  const { iUserId,vPassWord } = req.body;

  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iUserId==iUserId;
      })

      if(userExistData.length){
        
        const vOldPassword=sha1(vPassWord);

        if(userExistData[0]['vPassword']==vOldPassword){
            res.send({ message: 'Old Password is correct!', status: 200});
        }else{
            res.send({ message: 'Old Password is not correct!', status: 411});
        }

      }else{
        res.send({ message: 'User not found.', status: 412});
      }

    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//Change Email Address Api
app.post('/change_email', (req, res) => {
  const { iUserId,vEmail } = req.body;
  
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iUserId==iUserId;
      })

      if(userExistData.length){

        const newDataUpdateArr = dd.array.map((curEle2, index) => {
          return {
            ...curEle2,
            ['vEmail']:curEle2.iUserId==iUserId?vEmail:curEle2.vEmail,
          }
        })

        fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

        res.send({ message: "Your email has been changed successfully.", status: 200});
     
      }else{
        res.send({ message: 'User not found.', status: 412});
      }

    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//New Password Change Api
app.post('/new_password', (req, res) => {
  const { iUserId,vPassWord,vOldPassword } = req.body;
  
  const vOldPaswrd=sha1(vOldPassword);

  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.iUserId==iUserId;
      })

      if(userExistData.length){
        if(vOldPaswrd==userExistData[0]['vPassword']){
          
          const vNewPassword=sha1(vPassWord);

          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['vPassword']:curEle2.iUserId==iUserId?vNewPassword:curEle2.vPassword,
            }
          })
  
          fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

          res.send({ message: "Your password has been changed successfully.", status: 200});

        }else{
          res.send({ message: "Password invalid.", status: 411});
        }

      }else{
        res.send({ message: 'User not found.', status: 412});
      }
    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

})

//Get Profile Data Api
app.post('/GetProfileData', (req, res) => {
  const { tToken } = req.body;

  // Find the user in the database
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.tToken==tToken
      })

      if(userExistData.length){

        const UserData={
          iUserId:userExistData[0]['iUserId'],
          vFullName:userExistData[0]['vFullName'],
          vProfilePic:userExistData[0]['vProfilePic'],
          eCustStatus:userExistData[0]['eCustStatus'],
          iStatus:userExistData[0]['iStatus'],
          vStatus:userExistData[0]['iStatus']==1?userExistData[0]['eCustStatus']==2?userExistData[0]['iStatus']:userExistData[0]['eCustStatus']:0,
          iColorOption:userExistData[0]['iColorOption'],
          iEmailVerified:userExistData[0]['iEmailVerified'],
          vEmail:userExistData[0]['vEmail'],
          iEngId:userExistData[0]['iEngId']
        }

        res.send({ data: UserData, status: 200 });

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }  
  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }

});

// Profile Update Api
app.post('/ProfileUpdate', (req, res) => {
  const { tToken, vImage,iColorOption,isDeleteFile,vEditProfileFullName } = req.body;

  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })
      
      if(userExistData.length){

        const uploadFolder = './public/images/uploads/profiles/';

        if (!fs.existsSync(uploadFolder)) {
          fs.mkdirSync(uploadFolder);
        }

        if(isDeleteFile==1){
      
          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['vProfilePic']:curEle2.iUserId==userExistData[0]['iUserId']?"":curEle2.vProfilePic,
              ['iColorOption']:curEle2.iUserId==userExistData[0]['iUserId']?iColorOption:curEle2.iColorOption,
              ['vFullName']:curEle2.iUserId==userExistData[0]['iUserId']?vEditProfileFullName:curEle2.vFullName,
            }
          })
  
          fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

          res.send({ message: 'Profile picture has been updated successfully.', status: 200,data:{ vProfilePic:"",iColorOption:iColorOption } });

        }else{

          if(vImage[0].fileName && vImage[0].fileName!="undefined" && vImage[0].fileName!=""){

            const fileName = `${Date.now()}_${vImage[0].fileName}`;
            const filePath = `${uploadFolder}${fileName}`;
            var base64Data = vImage[0].imageData.split("base64,");
      
            fs.writeFile(filePath, base64Data[1], 'base64', (err) => {
              if (err) throw err;
    
              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                return {
                  ...curEle2,
                  ['vProfilePic']:curEle2.iUserId==userExistData[0]['iUserId']?'images/uploads/profiles/' + fileName:curEle2.vProfilePic,
                  ['iColorOption']:curEle2.iUserId==userExistData[0]['iUserId']?0:curEle2.iColorOption,
                  ['vFullName']:curEle2.iUserId==userExistData[0]['iUserId']?vEditProfileFullName:curEle2.vFullName,
                }
              })
      
              fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

              res.send({ message: 'Profile picture has been updated successfully.', status: 200,data:{ vProfilePic:'images/uploads/profiles/' + fileName,iColorOption:0 } });

            })
          }else{
            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              return {
                ...curEle2,
                ['vFullName']:curEle2.iUserId==userExistData[0]['iUserId']?vEditProfileFullName:curEle2.vFullName,
              }
            })
    
            fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

            res.send({ message: 'Profile picture has been updated successfully.', status: 200 });
          }

        }


      }else{
        res.send({ message: 'User not found.', status: 412});
      }
    }else{
      res.send({ message: 'User not found.', status: 412});
    }
  }else{
    res.send({ message: 'User not found.', status: 412});
  }

});

// Message Delete Api
app.post('/MessageDelete', (req, res) => {
  const { tToken, MultipleSelectDel, vActiveGroupId, vActiveUserId,isAdmin } = req.body;

  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile2 = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile2 != "") {
      const dd2 = JSON.parse(contentReadFile2);
      
      const userExistData=dd2.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      if(userExistData.length){

        const iFileId = vActiveGroupId > 0 ? Number(vActiveGroupId) : Number(userExistData[0]['iUserId']);

        MultipleSelectDel.map((curEle, index) => {
          const msgDate = String(curEle).split("_");
          const dateFormate = currentDate(new Date(Number(msgDate[2])));
  
          const fileName = (vActiveGroupId > 0 ? "GROUP_" : "")+ iFileId + "_" + dateFormate + ".json";
  
          if (fs.existsSync("DB/" + fileName)) {
            const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
            if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
  
              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const iOldDeltedSts = curEle2?.iDeleted ? curEle2.iDeleted : 0;
                const iRequestMsg=curEle2?.iRequestMsg && curEle2?.iRequestMsg>0?1:0;
                
                return {
                  ...curEle2,
                  ['iDeleted']: curEle2.id == curEle && iRequestMsg==0 ? 1 : iOldDeltedSts,
                  ['isAdmin']: curEle2.id == curEle ?isAdmin:curEle2.isAdmin
                }
              })
  
  
              fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
  
              if (vActiveGroupId == 0) {
                const fileNameReciver = vActiveUserId + "_" + dateFormate + ".json";
  
                if (fs.existsSync("DB/" + fileNameReciver)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + fileNameReciver, 'utf8');
  
                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);
  
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const iOldDeltedSts = curEle2?.iDeleted ? curEle2.iDeleted : 0;
                      const iRequestMsg=curEle2?.iRequestMsg && curEle2?.iRequestMsg>0?1:0;
                      return {
                        ...curEle2,
                        ['iDeleted']: curEle2.id == curEle && iRequestMsg==0 ? 1 : iOldDeltedSts,
                        ['isAdmin']: curEle2.id == curEle?isAdmin:curEle2.isAdmin
                      }
                    })
  
                    fs.writeFileSync("DB/" + fileNameReciver, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              }
            }
          }
        })
        
        res.send({ message: 'Message has been deleted successfully.', status: 200 });

      }else{
        res.send({ message: 'User is not exist!', status: 412 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 412 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 412 });
  }

})

//Message Update Api
app.post('/MessageUpdate', (req, res) => {
  const { tToken, msg, msgId, vActiveGroupId, vActiveUserId,id } = req.body;

  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const results=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      if(results.length){

        const iFileId = vActiveGroupId > 0 ? Number(vActiveGroupId) : Number(results[0]['iUserId']);

        const msgDate = String(msgId).split(" ");
        const dateFormate = msgDate[0].split("-");
  
        const fileName = (vActiveGroupId > 0 ? "GROUP_" : "")+ iFileId + "_" + dateFormate[2] + "_" + dateFormate[1] + "_" + dateFormate[0] + ".json";
  
        if (fs.existsSync("DB/" + fileName)) {
          const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
          if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);
  
            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              const isEdited=curEle2?.iEdited === undefined || curEle2?.iEdited === null?0:curEle2?.iEdited;
              
              return {
                ...curEle2,
                ['message']: curEle2.id == id ? msg : curEle2.message,
                ['iEdited']:curEle2.id == id ? 1 : isEdited
              }
            })
  
  
            fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
  
            if (vActiveGroupId == 0) {
              const fileNameReciver = vActiveUserId + "_" + dateFormate[2] + "_" + dateFormate[1] + "_" + dateFormate[0] + ".json";
  
              if (fs.existsSync("DB/" + fileNameReciver)) {
                const contentReadRecFile = fs.readFileSync("DB/" + fileNameReciver, 'utf8');
  
                if (contentReadRecFile != "") {
                  const dd = JSON.parse(contentReadRecFile);
  
                  const newDataUpdateArr = dd.array.map((curEle2, index) => {
                    const isEdited=curEle2?.iEdited === undefined || curEle2?.iEdited === null?0:curEle2?.iEdited;
  
                    return {
                      ...curEle2,
                      ['message']: curEle2.id == id ? msg : curEle2.message,
                      ['iEdited']: curEle2.id == id ? 1 : isEdited
                    }
                  })
  
                  fs.writeFileSync("DB/" + fileNameReciver, JSON.stringify({ array: newDataUpdateArr }));
                }
              }
            }
          }
        }
  
        res.send({ message: 'Message has been updated successfully.', status: 200 });

      }else{
        res.send({ message: 'User is not exist!', status: 412 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 412 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 412 });
  }

})

//Get User List Api
app.post('/GetUserList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const results=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      if(results.length){
        // user list in the database
        const LoginUserId = results[0]['iUserId'];

        const results2=dd.array.filter((curEle,index)=>{
          return curEle.iEmailVerified==1 && curEle.tToken!=tToken
        })

        if(results2.length){

          let newDataArr = results2.map((curEle, index) => {

            const lastDate = getLastFileOfUser(results[0]['iUserId'], curEle.iUserId);

            const totalUnreadMsg = lastDate != "" ? getUnreadMsg(lastDate, LoginUserId, curEle.iUserId) : 0;

            const isMessageExist=isCommunicate(results[0]['iUserId'], curEle.iUserId);

            const isStartChat=isStartChatMsg(results[0]['iUserId'], curEle.iUserId);

            return {
              ['iUserId']:curEle.iUserId,
              ['vFullName']:curEle.vFullName,
              ['iStatus']:curEle.iStatus==1?curEle.eCustStatus==2?curEle.iStatus:curEle.eCustStatus:0,
              ['iColorOption']:curEle.iColorOption,
              ['eStatus']:curEle.eStatus,
              ['isStartChat']:isStartChat,
              ['isMessageExist']:isMessageExist,
              ['iTotalUnReadMsg']: totalUnreadMsg,
              ['lastMessage']: "No Message",
              ['lastTime']: lastDate,
              ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
              ['lastDate']: lastDate != "" ? curEle.iUserId + "_" + ConvertDateForFile(lastDate) + ".json" : curEle.iUserId + "_" + currentDate() + ".json"
            }
          })
          
          const filterData=newDataArr.filter((curEle,index)=>{
            return  curEle.isMessageExist>0
          })

          res.send({ data: filterData, status: 200 });

        }else{
          res.send({ message: 'User is not exist!', status: 401 });
        }

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 412 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 412 });
  }

});

//Get Chat User List Api
app.post('/GetChatUserList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);

      const results=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      if(results.length){

        const results2=dd.array.filter((curEle,index)=>{
          return curEle.iEmailVerified==1 && curEle.iUserId!=results[0]['iUserId']
        })

        if(results2.length){

          let newDataArr = results2.map((curEle, index) => {
            return {
              ['iUserId']:curEle.iUserId,
              ['vFullName']:curEle.vFullName,
              ['iStatus']:curEle.iStatus==1?curEle.eCustStatus==2?curEle.iStatus:curEle.eCustStatus:0,
              ['iColorOption']:curEle.iColorOption,
              ['eStatus']:curEle.eStatus,
              ['iTotalUnReadMsg']: 0,
              ['lastMessage']: "No Message",
              ['lastTime']: "",
              ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
              ['lastDate']: ""
            }
          })

          res.send({ data: newDataArr, status: 200 });

        }else{
          res.send({ data: [], status: 200 });
        }

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }

})

//Get Message List Api
app.post('/GetMessage', (req, res) => {
  const { tToken, iUserId, filterDateStr } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);

      const resultsArr=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      const resultsArr2=dd.array.filter((curEle,index)=>{
        return curEle.iUserId==iUserId
      })

      if(resultsArr.length){

        let ChatUserSts = 0;
        if(resultsArr2.length){
          ChatUserSts=resultsArr2[0]['iStatus']==1?resultsArr2[0]['eCustStatus']==2?resultsArr2[0]['iStatus']:resultsArr2[0]['eCustStatus']:0
        }

        const results=[{ iUserId:resultsArr[0]['iUserId'], ChatUserSts:ChatUserSts }];

        const isMessageExist=isCommunicate(results[0]['iUserId'], iUserId);

        // Function to check if a file exists
        function fileExists(filepath, callback) {
          fs.access(filepath, fs.constants.F_OK, (err) => {
            if (err) {
              callback(false);
            } else {
              callback(true);
            }
          });
        }

        // Function to read files concurrently
        function readFilesConcurrently(filepaths, callback) {
          const existingFiles = [];
          let completed = 0;

          filepaths.forEach((filepath, index) => {
            fileExists(filepath, (exists) => {
              if (exists) {
                existingFiles.push(filepath);
              } else {
                // console.error(`File not found: ${filepath}`);
              }
              completed++;

              if (completed === filepaths.length) {
                let data = [];
                let readCompleted = 0;

                if (existingFiles.length > 0) {
                  existingFiles.forEach((file) => {
                    const content = fs.readFileSync(file, 'utf8');

                    if (content != "") {
                      const dd = JSON.parse(content);

                      let newDataUpdateArr = dd.array.map((curEle, index) => {
                        return {
                          ...curEle,
                          ['iRead']: curEle.iFromUserId == iUserId ? 1 : curEle.iRead
                        }
                      })

                      fs.writeFileSync(file, JSON.stringify({ array: newDataUpdateArr }));

                      const filterDataArr = dd.array.filter((curEle, index) => {
                        const isPermDelete=curEle?.iPermDelete == undefined ? 0 :curEle.iPermDelete;

                        // console.log("isPermDelete=>",isPermDelete)

                        return ((curEle.iFromUserId == results[0]['iUserId'] && curEle.iToUserId == iUserId) || (curEle.iFromUserId == iUserId && curEle.iToUserId == results[0]['iUserId'])) && isPermDelete==0
                      })

                      data = [...data, ...filterDataArr]
                    }

                    const newReadStr = String(file).split("_");
                    const newReadFile = iUserId + "_" + newReadStr[1] + "_" + newReadStr[2] + "_" + newReadStr[3];

                    if (fs.existsSync("DB/" + newReadFile)) {
                      const contentReadFile = fs.readFileSync("DB/" + newReadFile, 'utf8');
                      if (contentReadFile != "") {
                        const dd = JSON.parse(contentReadFile);

                        let newDataUpdateArr = dd.array.map((curEle, index) => {
                          return {
                            ...curEle,
                            ['iReadTo']: curEle.iFromUserId == results[0]['iUserId'] ? 1 : curEle.iReadTo
                          }
                        })

                        fs.writeFileSync("DB/" + newReadFile, JSON.stringify({ array: newDataUpdateArr }));
                      }
                    }

                    readCompleted++;
                    if (readCompleted === existingFiles.length) {
                      callback(data);
                    }
                  });
                } else {
                  callback([]);
                }
              }
            });
          });
        }

        const startDate = oneMonthBackDate(filterDateStr);
        const splitString = String(filterDateStr).split("_");
        let endDateStr = (splitString[1] + "_" + splitString[2] + "_" + splitString[3]);
        const weakArray = GetMonthArrayDate(startDate, endDateStr.split(".")[0], "DB/" + results[0]['iUserId']);

        // Example usage
        const filepaths = weakArray;

        readFilesConcurrently(filepaths, (data) => {
          if (data.length > 0) {

            const sortingArr = data.length ? data.sort((a, b) =>
              (('created_at' in b) - ('created_at' in a))
              || (a.created_at ?? '').localeCompare(b.created_at ?? '')
            ) : []

            res.send({
              data: JSON.stringify(sortingArr), status: 200,
              userStatus: results[0]['ChatUserSts'],
              dLastDate: sortingArr.length ? iUserId + "_" + ConvertDateForFile(sortingArr[0]['created_at']) + ".json" : "",
              isMessageExist
            });
          } else {
            res.send({ data: [], status: 412, userStatus: results[0]['ChatUserSts'],isMessageExist });
          }
        });

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }

    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }

  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }

});

//Get Group Message Api
app.post('/GetGrpMessage', (req, res) => {
  const { tToken, iGroupId, filterDateStr,isAdmin } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);

      const results=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })
      
      if(results.length){

        // Function to check if a file exists
        function fileExists(filepath, callback) {
          fs.access(filepath, fs.constants.F_OK, (err) => {
            if (err) {
              callback(false);
            } else {
              callback(true);
            }
          });
        }

        // Function to read files concurrently
        function readFilesConcurrently(filepaths, callback) {
          const existingFiles = [];
          let completed = 0;

          filepaths.forEach((filepath, index) => {
            fileExists(filepath, (exists) => {
              if (exists) {
                existingFiles.push(filepath);
              } else {
                // console.error(`File not found: ${filepath}`);
              }
              completed++;

              if (completed === filepaths.length) {
                let data = [];
                let readCompleted = 0;

                if (existingFiles.length > 0) {
                  existingFiles.forEach((file) => {
                    const content = fs.readFileSync(file, 'utf8');

                    if (content != "") {
                      const dd = JSON.parse(content);

                      const dataFilterData=dd.array.filter((curEle,index)=>{
                        const vDeleteMsgUser=curEle.vDeleteMsgUser==undefined?"":curEle.vDeleteMsgUser;
                        const vDeleteUserSplit=vDeleteMsgUser!=""?String(vDeleteMsgUser).split(","):[];
                        const vMemeberListMsg=curEle?.vMemeberList!=undefined?String(curEle?.vMemeberList).split(","):[];
                        return !vDeleteUserSplit.includes(""+results[0]['iUserId']) && (vMemeberListMsg.includes(""+results[0]['iUserId']) || curEle.iFromUserId==results[0]['iUserId'])
                      })

                      data = [...data, ...dataFilterData]

                      let newDataUpdateArr = dd.array.map((curEle, index) => {
                        const tReadUsers = curEle.tReadUsers!=""?String(curEle.tReadUsers).split(","):[];

                        return {
                          ...curEle,
                          ['tReadUsers']: tReadUsers.includes("" + results[0]['iUserId']) ? curEle.tReadUsers : curEle.tReadUsers + "," + results[0]['iUserId']
                        }
                      })

                      fs.writeFileSync(file, JSON.stringify({ array: newDataUpdateArr }));
                    }

                    readCompleted++;
                    if (readCompleted === existingFiles.length) {
                      callback(data);
                    }

                  });
                } else {
                  callback([]);
                }
              }
            });
          });
        }

        const startDate = oneMonthBackDateGroup(filterDateStr);
        const splitString = String(filterDateStr).split("_");
        let endDateStr = (splitString[2] + "_" + splitString[3] + "_" + splitString[4]);
        const weakArray = GetMonthArrayDate(startDate, endDateStr.split(".")[0], "DB/GROUP_" + iGroupId);

        // Example usage
        const filepaths = weakArray;

        readFilesConcurrently(filepaths, (data) => {
          if (data.length > 0) {
  
            const sortingArr = data.length ? data.sort((a, b) =>
              (('created_at' in b) - ('created_at' in a))
              || (a.created_at ?? '').localeCompare(b.created_at ?? '')
            ) : []
  
            res.send({
              data: JSON.stringify(sortingArr), status: 200,
              dLastDate: sortingArr.length ? "GROUP_" + iGroupId + "_" + ConvertDateForFile(sortingArr[0]['created_at']) + ".json" : ""
            });
          } else {
            res.send({ data: [], status: 412, userStatus: 0 });
          }
        });

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }

    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }

});

//Add new Group function 
function addNewGroupFun(vGroupName,vGroupImage,tGroupUsers,tGroupJoinMemb,tDescription,iColorOption,tLeftMembers,iCreatedBy,res){
  const vGroupFileName="Groups.json";

  if (fs.existsSync("DB/"+vGroupFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+vGroupFileName, 'utf8');
      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);

          const newDataUpdateArr = dd.array;

          const iGroupId=Number(dd.array.length)+1;

          newDataUpdateArr.push({
              iGroupId:iGroupId,
              vGroupName,
              vGroupImage,
              tGroupUsers,
              tGroupJoinMemb,
              tDescription,
              iColorOption,
              tLeftMembers,
              dCreatedDate:currentDateTime(),
              iCreatedBy,
              eGroupStatus:"y",
          });

          fs.writeFileSync("DB/"+vGroupFileName, JSON.stringify({ array: newDataUpdateArr }));

          //Add Group Id in User data
          const tGroupJoinMembSplitArr=tGroupJoinMemb!=""?String(tGroupJoinMemb).split(","):[];
          const tGroupJoinMembArr=duplicateRemoveArr(tGroupJoinMembSplitArr);

          if(tGroupJoinMembArr.length){
            const vUserFileName="Users.json";

            if (fs.existsSync("DB/"+vUserFileName)) {
              const contentReadFile2 = fs.readFileSync("DB/"+vUserFileName, 'utf8');
              if (contentReadFile2 != "") {
                  const dd2 = JSON.parse(contentReadFile2);

                  const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                    const splitGroupIds=curEle2['tGroupIds']!=""?String(curEle2['tGroupIds']).split(","):[];
                    splitGroupIds.push(iGroupId);

                    return {
                      ...curEle2,
                      ['tGroupIds']:tGroupJoinMembArr.includes(""+curEle2.iUserId)?splitGroupIds.toString():curEle2.tGroupIds,
                    }
                  })
    
                  fs.writeFileSync("DB/" + vUserFileName, JSON.stringify({ array: newDataUpdateArr }));
              }
            }

          }

          res.send({ message: 'Group has been added successfully.', status: 200,id:iGroupId });
      }
  }else{
      const db = { array: [] }

      db.array.push({
          iGroupId:1,
          vGroupName,
          vGroupImage,
          tGroupUsers,
          tGroupJoinMemb,
          tDescription,
          iColorOption,
          tLeftMembers,
          dCreatedDate:currentDateTime(),
          iCreatedBy,
          eGroupStatus:"y",
      })

      let jsonData = JSON.stringify(db);

      fs.writeFileSync('DB/'+vGroupFileName, jsonData);

      //Add Group Id in User data
      const tGroupJoinMembSplitArr=tGroupJoinMemb!=""?String(tGroupJoinMemb).split(","):[];
      const tGroupJoinMembArr=duplicateRemoveArr(tGroupJoinMembSplitArr);

      if(tGroupJoinMembArr.length){
        const vUserFileName="Users.json";

        if (fs.existsSync("DB/"+vUserFileName)) {
          const contentReadFile2 = fs.readFileSync("DB/"+vUserFileName, 'utf8');
          if (contentReadFile2 != "") {
              const dd2 = JSON.parse(contentReadFile2);

              const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                return {
                  ...curEle2,
                  ['tGroupIds']:tGroupJoinMembArr.includes(""+curEle2.iUserId)?1:curEle2.tGroupIds,
                }
              })

              fs.writeFileSync("DB/" + vUserFileName, JSON.stringify({ array: newDataUpdateArr }));
          }
        }
      }

      res.send({ message: 'Group has been added successfully.', status: 200,id:1 });
  }
}

// Add New Group Api / Basic Detail Update Also
app.post('/AddNewGrp', (req, res) => {
  const { vGroupName, vUsers, tToken, vActiveGroupId, vGroupProfile,tDescription,ColorOptionSelect,isDeleteFile,deleteMemeberStr,iUpdateBasic,cancelRequest } = req.body;

  const uploadFolder = './public/images/uploads/GroupProfile/';
  if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
  }

  const groupFileName="Groups.json";
  const userFileName="Users.json";

  // Check Token Exist
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);

      const results=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })

      if(results.length){
        if (fs.existsSync("DB/"+groupFileName)) {
          const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

          if (contentGrpReadFile != "") {
            const dd2 = JSON.parse(contentGrpReadFile);

            const results2=dd2.array.filter((curEle,index)=>{
              return curEle.eGroupStatus=="y" && curEle.vGroupName==vGroupName
            })

            const FilterNameCheck=results2.filter((curEle,index)=>{
                return curEle.iCreatedBy==results[0]['iUserId']
            })

            const results4=dd2.array.filter((curEle,index)=>{
              return curEle.eGroupStatus=="y" && curEle.iGroupId!=vActiveGroupId && curEle.iCreatedBy==results[0]['iUserId'] && curEle.vGroupName==vGroupName
            })

            if(results4.length){
              res.send({ message: 'Group name already exist!', status: 412 });
            }else{
              if(FilterNameCheck.length==0 || vActiveGroupId > 0 || results2.length==0){
                let filePathForDb = "";
                if (vGroupProfile && vGroupProfile?.length && vGroupProfile[0]['fileName'] && vGroupProfile[0]['fileName']!="" && vGroupProfile[0]['fileName']!="undefined") {
                  const fileName = `${Date.now()}_${vGroupProfile[0]['fileName']}`;
                  const filePath = `${uploadFolder}${fileName}`;
      
                  saveBlobFile(vGroupProfile[0]['imageData'], filePath);
              
                  filePathForDb = "images/uploads/GroupProfile/" + fileName;
                }
  
                const vSplitUsrArr=vUsers!=""?String(vUsers).split(","):[];
                const vUsersUniq=duplicateRemoveArr(vSplitUsrArr);
  
                if (vActiveGroupId > 0) {
                    const results3=dd2.array.filter((curEle,index)=>{
                      return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
                    })
  
                    if (results3.length > 0 && results3[0]['iCreatedBy'] == results[0]['iUserId']) {
  
                      if(iUpdateBasic==1){
                        const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                          const vGroupImage=(filePathForDb == "" && isDeleteFile==0) ? results3[0]['vGroupImage'] : filePathForDb

                          return {
                            ...curEle2,
                            ['vGroupName']: curEle2.iGroupId==vActiveGroupId?vGroupName:curEle2.vGroupName,
                            ['vGroupImage']: curEle2.iGroupId==vActiveGroupId?vGroupImage:curEle2.vGroupImage,
                            ['tDescription']: curEle2.iGroupId==vActiveGroupId?tDescription:curEle2.tDescription,
                            ['iColorOption']: curEle2.iGroupId==vActiveGroupId?ColorOptionSelect:curEle2.iColorOption
                          }
                        })
        
                        fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));

                        res.send({ message: 'Group detail has been updated successfully.', status: 200 });
                      }
                    }else{
                      res.send({ message: 'You dont have permission to update detail for this group.', status: 412 });
                    }
  
                }else{
                  //Group insert logic
                  addNewGroupFun(vGroupName,filePathForDb,"",vUsersUniq.toString(),tDescription,ColorOptionSelect,"",results[0]['iUserId'],res);
                }
              }
            }
          }

        }else{
          let filePathForDb = "";
          if (vGroupProfile && vGroupProfile?.length && vGroupProfile[0]['fileName'] && vGroupProfile[0]['fileName']!="" && vGroupProfile[0]['fileName']!="undefined") {
            const fileName = `${Date.now()}_${vGroupProfile[0]['fileName']}`;
            const filePath = `${uploadFolder}${fileName}`;

            saveBlobFile(vGroupProfile[0]['imageData'], filePath);
        
            filePathForDb = "images/uploads/GroupProfile/" + fileName;
          }

          const vSplitUsrArr=vUsers!=""?String(vUsers).split(","):[];
          const vUsersUniq=duplicateRemoveArr(vSplitUsrArr);

          //Group insert logic
          addNewGroupFun(vGroupName,filePathForDb,"",vUsersUniq.toString(),tDescription,ColorOptionSelect,"",results[0]['iUserId'],res);
        }

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }
  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }
});

//Group Member Join Request Accept Api
app.post('/GrpJoinRequestAccept', (req, res) => {
  const { iUserId,iMessageId,vActiveGroupId } = req.body;

  const groupFileName="Groups.json";
  const userFileName="Users.json";

  // Check Token Exist
  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.iUserId==iUserId
          })

          if(results.length){

            //Group Exist or not check
            if (fs.existsSync("DB/"+groupFileName)) {
              const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

              const dd2 = JSON.parse(contentGrpReadFile);

              const results2=dd2.array.filter((curEle,index)=>{
                return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
              })

              if(results2.length){

                const tGroupUsers=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(","):[];
                tGroupUsers.push(iUserId);

                const tGroupJoinMemb=results2[0]['tGroupJoinMemb']!=""?String(results2[0]['tGroupJoinMemb']).split(","):[];
                const filterJoinMember=tGroupJoinMemb.filter((curEle,index)=>{
                  return curEle!=iUserId;
                })

                const tLeftMembers=results2[0]['tLeftMembers']!=""?String(results2[0]['tLeftMembers']).split(",").filter(c=>c):[];
                const filterLeftMemeber=tLeftMembers.filter(cr=>cr!=iUserId);

                const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['tGroupUsers']: curEle2.iGroupId==vActiveGroupId?tGroupUsers.toString():curEle2.tGroupUsers,
                    ['tGroupJoinMemb']: curEle2.iGroupId==vActiveGroupId?filterJoinMember.toString():curEle2.tGroupJoinMemb,
                    ['tLeftMembers']: curEle2.iGroupId==vActiveGroupId?filterLeftMemeber.toString():curEle2.tLeftMembers,
                  }
                })

                //Group original file update
                fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));


                //Group data file Update
                const msgDate = String(iMessageId).split("_");
                const dateFormate = currentDate(Number(msgDate[2]));
                const fileName = "GROUP_"+vActiveGroupId + "_" + dateFormate + ".json";

                if (fs.existsSync("DB/" + fileName)) {
                  const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
                  if (contentReadFile != "") {
                    const dd = JSON.parse(contentReadFile);
        
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";
                      const memberSplitUser=vOldMemebers!=""?String(vOldMemebers).split(",").filter(c=>c):[]
      
                      return {
                        ...curEle2,
                        ['vMemeberList']: memberSplitUser.includes(""+iUserId) && curEle2.iRequestMsg==1 ? results2[0]['iCreatedBy'] : vOldMemebers,
                      }
                    })  
        
                    fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
      
                    res.send({ data: "You are join in the group.", status: 200 });
                  }
                }else{
                  res.send({ data: "You are join in the group.", status: 200 });
                }

              }else{
                res.send({ message: 'Group is not exist!', status: 401 });
              }

            }else{
              res.send({ message: 'Group is not exist!', status: 401 });
            }
          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
})


//Group Member Request Decline Api
app.post('/GrpJoinRequestDecline', (req, res) => {
  const { iUserId,iMessageId,vActiveGroupId } = req.body;

  // Check Token Exist
  const groupFileName="Groups.json";
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.iUserId==iUserId
          })

          if(results.length){

            //Group Exist or not check
            if (fs.existsSync("DB/"+groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

                const dd2 = JSON.parse(contentGrpReadFile);

                const results2=dd2.array.filter((curEle,index)=>{
                  return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
                })

                if(results2.length){

                  const tGroupUsers=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(","):[];
                  const filterGrpUsr=tGroupUsers.filter((curEle,ind)=>{
                    return curEle!=iUserId
                  })

                  const tGroupJoinMemb=results2[0]['tGroupJoinMemb']!=""?String(results2[0]['tGroupJoinMemb']).split(","):[];
                  const filterJoinMember=tGroupJoinMemb.filter((curEle,ind)=>{
                    return curEle!=iUserId
                  })

                  const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                    return {
                      ...curEle2,
                      ['tGroupUsers']: curEle2.iGroupId==vActiveGroupId?filterGrpUsr.toString():curEle2.tGroupUsers,
                      ['tGroupJoinMemb']: curEle2.iGroupId==vActiveGroupId?filterJoinMember.toString():curEle2.tGroupJoinMemb,
                    }
                  })
  
                  //Group original file update
                  fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));


                  //Group Data File Update
                  const msgDate = String(iMessageId).split("_");
                  const dateFormate = currentDate(Number(msgDate[2]));
                  const fileName = "GROUP_"+vActiveGroupId + "_" + dateFormate + ".json";

                  if (fs.existsSync("DB/" + fileName)) {
                    const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
                    if (contentReadFile != "") {
                      const dd = JSON.parse(contentReadFile);
          
                      const newDataUpdateArr = dd.array.map((curEle2, index) => {
                        const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";
                        const memberSplitUser=vOldMemebers!=""?String(vOldMemebers).split(",").filter(c=>c):[]
          
                        return {
                          ...curEle2,
                          ['vMemeberList']: memberSplitUser.includes(""+iUserId) && curEle2.iRequestMsg==1 ? results2[0]['iCreatedBy'] : vOldMemebers,
                        }
                      })  
          
                      fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
          
                      res.send({ data: "You decline the group request.", status: 200 });
                    }
                  }else{
                    res.send({ data: "You decline the group request.", status: 200 });
                  }

                }else{
                  res.send({ message: 'Group is not exist!', status: 401 });
                }
            }else{
              res.send({ message: 'Group is not exist!', status: 401 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

})

//Get Group List Api
app.post('/GetGroupList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  const groupFileName="Groups.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const LoginUserId = results[0]['iUserId'];
            const tGroupIdsList = results[0]['tGroupIds']!=""?String(results[0]['tGroupIds']).split(","):[];
            
            if (fs.existsSync("DB/"+groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

                const dd2 = JSON.parse(contentGrpReadFile);

                const results2=dd2.array.filter((curEle,index)=>{
                  return curEle.eGroupStatus=="y" 
                })

                if(results2.length){

                  const filterUserList=results2.filter((curEle,index)=>{
                    return curEle.iCreatedBy==LoginUserId || tGroupIdsList.includes(""+curEle.iGroupId)
                  })

                  let newDataArr = filterUserList.map((curEle, index) => {
                    const lastDate = getLastFileOfUserGroup(curEle.iGroupId);
        
                    const totalUnreadMsg = lastDate.date != "" ? getGroupUnreadMsg(lastDate.date, curEle.iGroupId, LoginUserId) : 0;
        
                    return {
                      ...curEle,
                      iTotalUnReadMsg: totalUnreadMsg,
                      ['vGroupImage']: curEle['vGroupImage']!=""?mainUrl + curEle['vGroupImage']:"",
                      ['lastTime']: lastDate.time,
                      lastDate: lastDate.date != "" ? "GROUP_" + curEle.iGroupId + "_" + lastDate.date + ".json" : "GROUP_" + curEle.iGroupId + "_" + currentDate() + ".json"
                    }
                  })
                  
                  res.send({ data: newDataArr, status: 200 });

                }else{
                  res.send({ message: 'Group is not exist!', status: 401 });
                }

            }else{
              res.send({ message: 'Group is not exist!', status: 401 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
});

//Delete Group Api
app.post('/DeleteGroup', (req, res) => {
  const { tToken, vActiveGroupId } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  const groupFileName="Groups.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            // Group list
            const LoginUserId = results[0]['iUserId'];

            
            if (fs.existsSync("DB/"+groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

                const dd2 = JSON.parse(contentGrpReadFile);

                const results2=dd2.array.filter((curEle,index)=>{
                  return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
                })

                if(results2.length){
                  if (results2[0]['iCreatedBy'] != LoginUserId) {
                    res.send({ message: 'You are not owner of the group!', status: 412 });
                  } else {
      
                    const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                      return {
                        ...curEle2,
                        ['eGroupStatus']:curEle2.iGroupId==vActiveGroupId?"d":curEle2.eGroupStatus
                      }
                    })  
        
                    fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));

                    res.send({ message: 'Group has been deleted successfully.', status: 200 });
                  }

                }else{
                  res.send({ message: 'Group is not exist!', status: 412 });
                }
            }else{
              res.send({ message: 'Group is not exist!', status: 412 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
});

//Exit Group Api
app.post('/ExitGroup', (req, res) => {
  const { tToken, vActiveGroupId,iNewUserId } = req.body;

  // Check Token Exist
  const userFileName="Users.json";
  const groupFileName="Groups.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            // Group list in the database
            const LoginUserId = results[0]['iUserId'];

            if (fs.existsSync("DB/"+groupFileName)) {
              
              const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');
          
              const dd2 = JSON.parse(contentGrpReadFile);
          
              const results2=dd2.array.filter((curEle,index)=>{
                return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
              })

              if(results2.length){

                const totalMemberAr=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(",").filter(e=>e):[];
                const filterRemoveMember=totalMemberAr.filter((curEle,index)=>{ return curEle!=iNewUserId });

                if (results2[0]['iCreatedBy'] == LoginUserId) {
              
                  const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                    const tLeftMembers=curEle2['tLeftMembers']+","+LoginUserId;
                    const isGroupDelete=totalMemberAr.length==0?'d':curEle2.eGroupStatus;

                    return {
                      ...curEle2,
                      ['tLeftMembers']: curEle2.iGroupId==vActiveGroupId?tLeftMembers:curEle2.tLeftMembers,
                      ['eGroupStatus']: curEle2.iGroupId==vActiveGroupId?isGroupDelete:curEle2.eGroupStatus,
                      ['tGroupUsers']: curEle2.iGroupId==vActiveGroupId?filterRemoveMember.toString():curEle2.tGroupUsers,
                      ['iCreatedBy']: curEle2.iGroupId==vActiveGroupId?iNewUserId:curEle2.iCreatedBy,
                    }
                  })
  
                  //Group original file update
                  fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));

                  const newDataUpdateArr2 = dd.array.map((curEle2, index) => {
                    const tGroupIds=curEle2['tGroupIds']+","+vActiveGroupId;

                    return {
                      ...curEle2,
                      ['tGroupIds']: curEle2.iUserId==LoginUserId?tGroupIds:curEle2.tGroupIds,
                    }
                  })
  
                  //User Original file update
                  fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr2 }));
                  
                  res.send({ message: 'You are exist from group.', status: 200 });

                }else{

                  const totalMemberAr=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(",").filter(e=>e):[];
                  const filterRemoveMember=totalMemberAr.filter((curEle,index)=>{ return curEle!=LoginUserId });
                  const tLeftMembers=results2[0]['tLeftMembers']+","+LoginUserId;

                  const newDataUpdateArr3 = dd2.array.map((curEle2, index) => {
                    return {
                      ...curEle2,
                      ['tGroupUsers']: curEle2.iGroupId==vActiveGroupId?filterRemoveMember.toString():curEle2.tGroupUsers,
                      ['tLeftMembers'] : curEle2.iGroupId==vActiveGroupId?tLeftMembers.toString():curEle2.tLeftMembers,
                    }
                  })
  
                  //Group original file update
                  fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr3 }));

                  res.send({ message: 'You are exist from group.', status: 200 });
                }

              }else{
                res.send({ message: 'Group is not exist!', status: 412 });
              }

            }else{
              res.send({ message: 'Group is not exist!', status: 412 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

});

//Delete Group For Me
app.post('/DeleteGroupForMe', (req, res) => {
  const { tToken, vActiveGroupId } = req.body;
  
  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const dbFolderPath = "DB/";
            const NewArr = fs.readdirSync(dbFolderPath);
            const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
          
            const fileExist = dd.length ? dd.filter((curEle, index) => {
              const splitStr = String(curEle).split("_");
              return splitStr[0] == "GROUP" && splitStr[1] == vActiveGroupId;
            }) : []

            if(fileExist){
              fileExist.map((curEle,index)=>{
                if (fs.existsSync("DB/" + curEle)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');
        
                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);
        
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const isPermDelete=curEle2?.vDeleteMsgUser == undefined ? '' : curEle2.vDeleteMsgUser;
        
                      let splitStr=isPermDelete!=""?String(isPermDelete).split(","):[];
                      const isCheckUserExist=splitStr.includes(Number(results[0]['iUserId']));
                      const vUserDeleteList=isCheckUserExist?isPermDelete:isPermDelete+","+Number(results[0]['iUserId']);
                      
                      return {
                        ...curEle2,
                        ['vDeleteMsgUser']: vUserDeleteList
                      }
                    })
        
                    fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              })
            }

            const tGroupIds=results[0]['tGroupIds']!=""?String(results[0]['tGroupIds']).split(",").filter(c=>c):[];

            const filterGroup=tGroupIds.filter((curEle,index)=>{
              return curEle!=vActiveGroupId
            })

            const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

            if (contentReadFile != "") {
                const dd = JSON.parse(contentReadFile);
                
                const newDataUpdateArr = dd.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['tGroupIds']: curEle2.iUserId==results[0]['iUserId']?[...filterGroup].toString():curEle2.tGroupIds,
                  }
                })
    
                //User original file update
                fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));
            }

            res.send({ message: 'Group is now delete for you.', status: 200 });

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

})

//Edit User Profile Api
app.post('/EditUserProfile', (req, res) => {
  const { tToken, eCustStatus,vEditProfileFullName } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){
            // Group list in the database
            const LoginUserId = results[0]['iUserId'];

            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              return {
                ...curEle2,
                ['eCustStatus']: curEle2.iUserId==LoginUserId?eCustStatus:curEle2.eCustStatus,
                ['vFullName']: curEle2.iUserId==LoginUserId?vEditProfileFullName:curEle2.vFullName,
              }
            })

            //User original file update
            fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));
            
            res.send({ message: 'User profile has been updated successfully.', status: 200 });

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

});

//Request Accept Feature Api
app.post('/RequestAcceptSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const msgDate = String(msgId).split("_");
            const dateFormate = currentDate(Number(msgDate[2]));
            const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

            if (fs.existsSync("DB/" + fileNameSend)) {
              const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');
        
              if (contentReadFile2 != "") {
                const dd2 = JSON.parse(contentReadFile2);
        
                const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2.iPermDelete,
                  }
                })
        
                fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));
        
                lastChatUpdate(results[0]['iUserId'], vActiveUserId,1);
                lastChatUpdate(vActiveUserId, results[0]['iUserId'],1);
                
              }
            }

            res.send({ message: 'Your chat request has been accepted successfully.', status: 200, });

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

})

//Request Decline Feature Api
app.post('/RequestDeclineSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId,isDelete } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const msgDate = String(msgId).split("_");
            const dateFormate = currentDate(Number(msgDate[2]));
            const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

            if (fs.existsSync("DB/" + fileNameSend)) {
              const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');
        
              if (contentReadFile2 != "") {
                const dd2 = JSON.parse(contentReadFile2);
        
                const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2.iPermDelete,
                  }
                })
        
                fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));
        
                if(isDelete==0){
                  lastChatUpdate(results[0]['iUserId'], vActiveUserId,0);
                  lastChatUpdate(vActiveUserId, results[0]['iUserId'],0);
                }
              }
            }

            res.send({ message: 'Your chat request has been accepted successfully.', status: 200, });

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
})

//Request Cancel Feature Api
app.post('/RequestCancelSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const iFileId = Number(vActiveUserId);
            const msgDate = String(msgId).split("_");
            const dateFormate = currentDate(Number(msgDate[2]));
            const fileName = iFileId + "_" + dateFormate + ".json";

            if (fs.existsSync("DB/" + fileName)) {
              const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
        
              if (contentReadFile != "") {
                const dd = JSON.parse(contentReadFile);
        
                const newDataUpdateArr = dd.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2?.iPermDelete,
                  }
                })
        
                fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
        
                lastChatUpdate(results[0]['iUserId'], vActiveUserId);
                lastChatUpdate(vActiveUserId, results[0]['iUserId']);
              }
            }

            res.send({ message: 'Your chat request has been cancelled successfully.', status: 200, });

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
})

//Delete All User Chat Api
app.post('/DeleteAllChatUser', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const dbFolderPath = "DB/";
            const NewArr = fs.readdirSync(dbFolderPath);
            const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;

            const fileExist = dd.length ? dd.filter((curEle, index) => {
              const splitStr = String(curEle).split("_");
              return splitStr[0] == results[0]['iUserId'];
            }) : [];

            const fileExistReceiver = dd.length ? dd.filter((curEle, index) => {
              const splitStr = String(curEle).split("_");
              return splitStr[0] == vActiveUserId;
            }) : [];

            if(fileExist.length){

              fileExist.map((curEle,index)=>{
                
                if (fs.existsSync("DB/" + curEle)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');
        
                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);
        
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const isPermDelete=curEle2?.iPermDelete == undefined ? 0 :curEle2.iPermDelete;
        
                      const isPermDeleteFlag = (curEle2?.iFromUserId==results[0]['iUserId'] && curEle2?.iToUserId==vActiveUserId) || (curEle2?.iFromUserId==vActiveUserId && curEle2?.iToUserId==results[0]['iUserId']) ? 1 : isPermDelete;
        
                      return {
                        ...curEle2,
                        ['iPermDelete']: isPermDeleteFlag
                      }
                    })
        
                    fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              })
        
              fileExistReceiver.map((curEle,index)=>{
                if (fs.existsSync("DB/" + curEle)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');
        
                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);
                    
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const iRequestMsg=curEle2?.iRequestMsg == undefined ? 0 :curEle2.iRequestMsg;
        
                      const isLastMatchRequest=curEle2.iFromUserId==results[0]['iUserId'] && curEle2.iToUserId==vActiveUserId && iRequestMsg==1
        
                      const iPermDelete=curEle2?.iPermDelete && curEle2?.iPermDelete>0?curEle2?.iPermDelete:0;
        
                      return {
                        ...curEle2,
                        ['iPermDelete']: isLastMatchRequest?1:iPermDelete
                      }
                    })
        
                    fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              })
        
              if (fs.existsSync("DB/COMMONDB.json")) {
        
                const data = fs.readFileSync('DB/COMMONDB.json', 'utf8');
            
                const db = typeof data == "string" ? JSON.parse(data) : data;
        
                const filterData = db.array.filter((curEle, index) => {
                  return curEle.senderId != results[0]['iUserId'] || (curEle.senderId == results[0]['iUserId'] && curEle.recieverId != vActiveUserId)
                })
        
                const newMapData=filterData.map((curEle2,index2)=>{
                  const isStartChat=curEle2.isStartChat==undefined?0:curEle2.isStartChat;
        
                  return {
                          ...curEle2,
                          ['isStartChat']:curEle2.senderId == vActiveUserId && curEle2.recieverId == results[0]['iUserId']?0:isStartChat
                        }
                })
        
                fs.writeFileSync('DB/COMMONDB.json', JSON.stringify({array:newMapData}));
              }
        
              const checkMsgConnExist=isCommunicate(vActiveUserId,results[0]['iUserId']);
              
              res.send({ message: 'Your chat history deleted successfully.', status: 200,checkMsgConnExist:checkMsgConnExist});
            }else{
        
              const checkMsgConnExist=isCommunicate(vActiveUserId,results[0]['iUserId']);
              res.send({ message: 'Your chat history deleted successfully.', status: 200,checkMsgConnExist:checkMsgConnExist });
            }
            
          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

})
 
//Delete Group Chat Api
app.post('/DeleteGroupAllChat', (req, res) => {
  const { tToken, vActiveGroupId,isMember } = req.body;

  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const dbFolderPath = "DB/";
            const NewArr = fs.readdirSync(dbFolderPath);
            const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
          
            const fileExist = dd.length ? dd.filter((curEle, index) => {
              const splitStr = String(curEle).split("_");
              return splitStr[0] == "GROUP" && splitStr[1] == vActiveGroupId;
            }) : []


            if(fileExist){
              fileExist.map((curEle,index)=>{
                if (fs.existsSync("DB/" + curEle)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');
        
                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);
        
                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const isPermDelete=curEle2?.vDeleteMsgUser == undefined ? '' : curEle2.vDeleteMsgUser;
        
                      let splitStr=isPermDelete!=""?String(isPermDelete).split(","):[];
                      const isCheckUserExist=splitStr.includes(Number(results[0]['iUserId']));
                      const vUserDeleteList=isCheckUserExist?isPermDelete:isPermDelete+","+Number(results[0]['iUserId']);
                      
                      return {
                        ...curEle2,
                        ['vDeleteMsgUser']: vUserDeleteList
                      }
                    })
        
                    fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              })
      
              res.send({ message: 'Your chat history deleted successfully.', status: 200, });
          }else{
            res.send({ message: 'Your chat history deleted successfully.', status: 200, });
          }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
})

//Delete Profile Api
app.post('/DeleteProfile', (req, res) => {
  const { tToken } = req.body;

  const userFileName="Users.json";
  const groupFileName="Groups.json";
  
  if (fs.existsSync("DB/"+userFileName)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
  
    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);
      
      const userExistData=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==tToken
      })
      
      if(userExistData.length){
        
        if (fs.existsSync("DB/COMMONDB.json")) {
          var content = fs.readFileSync('DB/COMMONDB.json', 'utf8');
      
          const dd3 = typeof content == "string" ? JSON.parse(content) : content;
      
          const filterData = dd3.array.filter((curEle, index) => {
            return !((curEle.senderId == userExistData[0]['iUserId'] && (curEle.isStartChat == "" || curEle.isStartChat == 0)) || (curEle.recieverId == userExistData[0]['iUserId'] && (curEle.isStartChat == "" || curEle.isStartChat == 0)))
          })
  
          fs.writeFileSync('DB/COMMONDB.json', JSON.stringify({array:filterData}));
        }

        if (fs.existsSync("DB/"+groupFileName)) {
          const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');
        
          if (contentGrpReadFile != "") {
            const dd2 = JSON.parse(contentGrpReadFile);

            const newDataUpdateArr = dd2.array.map((curEle2, index) => {
              
              const isGroupMeberExist=curEle2.tGroupUsers!=""?String(curEle2.tGroupUsers).split(",").filter(i => i):[];
              const tGroupJoinMembArr=curEle2.tGroupJoinMemb!=""?String(curEle2.tGroupJoinMemb).split(",").filter(i => i):[];
              const isAdmin= curEle2.iCreatedBy==userExistData[0]['iUserId']?1:0;
              const newAdminId=isAdmin && isGroupMeberExist.length>0?isGroupMeberExist[0]:curEle2.iCreatedBy;
              const tGroupUsers=isGroupMeberExist.filter(curData=>curData!=userExistData[0]['iUserId']);
              const tGroupJoinMemb=tGroupJoinMembArr.filter(curData=>curData!=userExistData[0]['iUserId'])
              const tLeftMembers=isGroupMeberExist.includes(""+userExistData[0]['iUserId']) || isAdmin?curEle2.tLeftMembers+","+userExistData[0]['iUserId']:curEle2.tLeftMembers;
              const NewTGroupUsers=isAdmin?tGroupUsers.filter(curData=>curData!=newAdminId):tGroupUsers;

              return {
                ...curEle2,
                ['iCreatedBy']:newAdminId,
                ['tGroupUsers']:NewTGroupUsers.toString(),
                ['tGroupJoinMemb']:tGroupJoinMemb.toString(),
                ['tLeftMembers']:tLeftMembers,
                ['eGroupStatus']:isAdmin && isGroupMeberExist.length==0?"d":curEle2.eGroupStatus
              }
            })

            fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr })); 
          }
        }

        //Final user delete code 
        const newDataUpdateArr = dd.array.map((curEle2, index) => {
          return {
            ...curEle2,
            ['eStatus']:curEle2.iUserId==userExistData[0]['iUserId']?"d":curEle2.eStatus,
          }
        })

        fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

        //Memeber Delete Mail
        const mailHtml=`<p>Your profile is deleted. Below are the details of your account for your reference:</p><p>Username: ${userExistData[0]['vUsername']}<br/>Email Address: ${userExistData[0]['vEmail']}<br/>Full Name: ${userExistData[0]['vFullName']}</p>`;

        NewSMTPMailSend(userExistData[0]['vEmail'], 'Profile Deletion', mailHtml)
        .then(result => {
        })
        .catch(error => {
            console.error('Error:', error);
            res.send({ message: 'Please try again later.', status: 412 });
        });

        res.send({ message: 'Profile has been deleted succssefull.', status: 200 })

      }else{
        res.send({ message: 'User is not exist!', status: 401 });
      }
    }else{
      res.send({ message: 'User is not exist!', status: 401 });
    }

  }else{
    res.send({ message: 'User is not exist!', status: 401 });
  }

})

//Add New Group Members
app.post('/AddNewGroupMember',(req, res) => {
  const { tToken,vActiveGroupId,vNewMemberIds } = req.body;

  const userFileName="Users.json";

   // Check Token Exist
  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const groupFileName="Groups.json";
            if (fs.existsSync("DB/"+groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

                const dd2 = JSON.parse(contentGrpReadFile);

                const results2=dd2.array.filter((curEle,index)=>{
                  return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
                })

                if(results2.length){

                  if(results2[0]['iCreatedBy']==results[0]['iUserId']){
                    const tGroupJoinMemb=results2[0]['tGroupJoinMemb']+","+vNewMemberIds;
                    let tGroupJoinMembArr=tGroupJoinMemb!=""?String(tGroupJoinMemb).split(","):[];
                    tGroupJoinMembArr=duplicateRemoveArr(tGroupJoinMembArr);
          

                    const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                      return {
                        ...curEle2,
                        ['tGroupJoinMemb']: curEle2.iGroupId==vActiveGroupId?tGroupJoinMembArr.toString():curEle2.tGroupJoinMemb,
                      }
                    })
    
                    fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));

                    const vNewMemberIdsSplit=vNewMemberIds!=""?String(vNewMemberIds).split(","):[]

                    if(vNewMemberIdsSplit.length){
                      const newDataUpdateArr2 = dd.array.map((curEle2, index) => {
                        let tGroupIds=String(curEle2['tGroupIds']+","+vActiveGroupId).split(",");
                        tGroupIds=duplicateRemoveArr(tGroupIds);
                        return {
                          ...curEle2,
                          ['tGroupIds']: vNewMemberIdsSplit.includes(""+curEle2.iUserId)?tGroupIds.toString():curEle2.tGroupIds,
                        }
                      })
      
                      fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr2 }));
                    }
                    

                    res.send({ message: 'New member has been added successfully.', status: 200 });
          
                  }else{
                    res.send({ message: 'You dont have permission to add member.', status: 401 });
                  }

                }else{
                  res.send({ message: 'Group is not exist!', status: 401 });
                }

            }else{
                res.send({ message: 'Group is not exist!', status: 401 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }
})

//Delete Group Memebers
app.post('/DeleteMember',(req, res) => {
  const { tToken,vActiveGroupId,DeleteMemberId } = req.body;
  
  // Check Token Exist
  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results=dd.array.filter((curEle,index)=>{
            return curEle.eStatus=="y" && curEle.tToken==tToken
          })

          if(results.length){

            const groupFileName="Groups.json";

            if (fs.existsSync("DB/"+groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

                const dd2 = JSON.parse(contentGrpReadFile);

                const results2=dd2.array.filter((curEle,index)=>{
                  return curEle.eGroupStatus=="y" && curEle.iGroupId==vActiveGroupId
                })

                if(results2.length){

                  if(results2[0]['iCreatedBy']==results[0]['iUserId']){
                    const tGroupUsers=results2[0]['tGroupUsers'];
                    const tGroupUsersArr=tGroupUsers!=""?String(tGroupUsers).split(","):[];
          
                    let tLeftMembers=results2[0]['tLeftMembers'];
                    if(tGroupUsersArr.includes(""+DeleteMemberId)){
                      tLeftMembers=tLeftMembers+","+DeleteMemberId;
                    }
          
                    const tGroupJoinMemb=results2[0]['tGroupJoinMemb'];
                    const tGroupJoinMembArr=tGroupJoinMemb!=""?String(tGroupJoinMemb).split(","):[];
          
                    const isCancelRequest=tGroupJoinMembArr.includes(""+DeleteMemberId)?1:0;
                    
                    const filterJoin=tGroupJoinMembArr.filter(curEle=>{ return curEle!=DeleteMemberId });
                    const filterJoinArr=duplicateRemoveArr(filterJoin);
                    
                    const filterFinalUsr=tGroupUsersArr.filter(curEle=>{ return curEle!=DeleteMemberId });
                    const filterFinalUsrArr=duplicateRemoveArr(filterFinalUsr);
          
                    if(isCancelRequest==1){
                      const dbFolderPath = "DB/";
                      const NewArr = fs.readdirSync(dbFolderPath);
                      const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
          
                      dd.map((curElee, index) => {
                        const splitStr = String(curElee).split("_");
                        
                        if(splitStr[0]=="GROUP" && splitStr[1]==vActiveGroupId){
                          if (fs.existsSync("DB/" + curElee)) {
          
                            const contentReadFile = fs.readFileSync("DB/" + curElee, 'utf8');
                            if (contentReadFile != "") {
                              const dd = JSON.parse(contentReadFile);
                  
                              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                                const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";
                                const vCancelUserId = curEle2?.vCancelUserId ? curEle2.vCancelUserId : "";
                
                                const UserIds=String(curEle2.vMemeberList).split(",");
          
                                return {
                                  ...curEle2,
                                  ['vMemeberList']: curEle2.iRequestMsg==1 && UserIds[0] == DeleteMemberId ? results2[0]['iCreatedBy'] : vOldMemebers,
                                  ['vCancelUserId']: curEle2.iRequestMsg==1 && UserIds[0] == DeleteMemberId ? vOldMemebers : vCancelUserId,
                                }
                              })  
                  
                              fs.writeFileSync("DB/" + curElee, JSON.stringify({ array: newDataUpdateArr }));
                            }
          
                          }
                        }
          
                      });
                    }
    
                    const newDataUpdateArr = dd2.array.map((curEle2, index) => {
                      return {
                        ...curEle2,
                        ['tGroupJoinMemb']: curEle2.iGroupId==vActiveGroupId?filterJoinArr.toString():curEle2.tGroupJoinMemb,
                        ['tGroupUsers']: curEle2.iGroupId==vActiveGroupId?filterFinalUsrArr.toString():curEle2.tGroupUsers,
                        ['tLeftMembers']: curEle2.iGroupId==vActiveGroupId?tLeftMembers:curEle2.tLeftMembers,
                      }
                    })
    
                    fs.writeFileSync("DB/" + groupFileName, JSON.stringify({ array: newDataUpdateArr }));

                    res.send({ message: 'Member has been deleted successfully.', status: 200 });
          
                  }else{
                    res.send({ message: 'You dont have permission to add member.', status: 401 });
                  }

                }else{
                  res.send({ message: 'Group is not exist!', status: 401 });
                }

            }else{
              res.send({ message: 'Group is not exist!', status: 401 });
            }

          }else{
              res.send({ message: 'User is not exist!', status: 401 });
          }
      }else{
          res.send({ message: 'User is not exist!', status: 401 });
      }
  }else{
      res.send({ message: 'User is not exist!', status: 401 });
  }

})


//Socket Code Start here
io.on('connection', (socket, req) => {
  const parameters = url.parse(req.url, true);
  const token = parameters.query.token;

  // Check Authenticiation for socket connection
  const userFileNameToken="Users.json";
  if (fs.existsSync("DB/"+userFileNameToken)) {
    const contentReadFile = fs.readFileSync("DB/"+userFileNameToken, 'utf8');

    if (contentReadFile != "") {
      const dd = JSON.parse(contentReadFile);

      const results2=dd.array.filter((curEle,index)=>{
        return curEle.eStatus=="y" && curEle.tToken==token
      })

      if(results2.length==0){
        socket.close(1008, 'Invalid token');
        return;
      }
    }
  }else{
    socket.close(1008, 'Invalid token');
    return;
  }

  // Handle incoming messages
  const uploadFolder = './public/images/uploads/';
  if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
  }
  
  socket.on('message', (data,isBinary) => {
    const dataMsg = JSON.parse(isBinary ? data : data.toString());

    if(dataMsg.event=="login"){
      const message=dataMsg.data;

      const { iLoggedId } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results2=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.iEngId==iLoggedId
              })

              if(results2.length){
                if (results2.length > 0) {
                  results2.map((curEle2,index2)=>{
                    const roomClients = clients; 

                    roomClients.forEach(client => {
                        if (client.id == curEle2['vChatId'] && client.readyState === WebSocket.OPEN) {
                            client.send(JSON.stringify({
                                event: 'receive_message',
                                data: {
                                    type: "logout",
                                    isDeleteProfile: 0
                                }
                            }));
                        }
                    });

                    // socket.in('' + curEle2['vChatId']).emit('receive_message', {
                    //   type:"logout",
                    //   isDeleteProfile:0
                    // });
                  })
                }

              }
          }
      }
    }else if(dataMsg.event=="join_msg"){
      const message=dataMsg.data;

      // socket.join(socket.id);
      const socketId = uuid.v4();
      socket.id = socketId;
      clients.set(socketId, socket); // Store the connection in the map
      const targetWs = clients.get(socketId);
    
      const userFileName="Users.json";

      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.tToken==message.token
              })

              if(results.length){
                const newDataUpdateArr = dd.array.map((curEle2, index) => {
                  return {
                    ...curEle2,
                    ['vChatId']: curEle2.tToken==message.token?targetWs.id:curEle2.vChatId,
                    ['iStatus']: curEle2.tToken==message.token?1:curEle2.iStatus,
                  }
                })
                fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));
              }


              const results2=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.iEmailVerified==1
              })

              const newJoinChat=dd.array.filter((curEle,index)=>{
                return curEle.tToken==message.token
              })

              let newDataArr = newJoinChat.map((curEle, index) => {
                return {
                  ['iUserId']:curEle.iUserId,
                  ['vFullName']:curEle.vFullName,
                  ['iStatus']:curEle.eCustStatus==2?1:0,
                  ['iColorOption']:curEle.iColorOption,
                  ['eStatus']:curEle.eStatus,
                  ['iTotalUnReadMsg']: 0,
                  ['lastMessage']: "No Message",
                  ['lastTime']: "",
                  ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
                  ['lastDate']: ""
                }
              })

              results2.map((curEle2,index2)=>{
                const roomClients = clients;
                roomClients.forEach(client => {
                    if (curEle2['vChatId'] == client.id && client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            event: 'receive_message',
                            data: {
                              type:"RefreshUserList",
                              UserData:newDataArr.length?newDataArr[0]:{}
                            }
                        }));
                    }
                });

                // socket.in('' + curEle2['vChatId']).emit('receive_message', {
                //   type:"RefreshUserList",
                //   UserData:newDataArr.length?newDataArr[0]:{}
                // });
              })

          }
      }
    }else if(dataMsg.event=="logout"){
      const message=dataMsg.data;

      const { iLoggedId } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);

              const results2=dd.array.filter((curEle,index)=>{
                return curEle.iUserId==iLoggedId
              })

              if (results2.length > 0) {
                results2.map((curEle2,index2)=>{
                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == curEle2['vChatId'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'receive_message',
                              data: {
                                  type: "logout"
                              }
                          }));
                      }
                  });

                  // socket.in('' + curEle2['vChatId']).emit('receive_message', {
                  //   type:"logout",
                  // });
                })
              }
          }
      }
    }else if(dataMsg.event=="MessageTyping"){
      const message=dataMsg.data;

      const { iFromUserId, iToUserId, msg } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.iUserId==iToUserId
              })

              if(results.length){
                if (msg == "") {

                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == results[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'MessageTypingEnd',
                              data: {
                                iFromUserId: iFromUserId,
                              }
                          }));
                      }
                  });

                  // socket.in(results[0]['vChatId']).emit('MessageTypingEnd', {
                  //   iFromUserId: iFromUserId,
                  // });
                } else {
                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == results[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'MessageTypingStart',
                              data: {
                                iFromUserId: iFromUserId,
                              }
                          }));
                      }
                  });

                  // socket.in(results[0]['vChatId']).emit('MessageTypingStart', {
                  //   iFromUserId: iFromUserId,
                  // });
                }
              }
          }
      }
    }else if(dataMsg.event=="messageReadUpdate"){
      const message=dataMsg.data;

      const { iFromUserId, iToUserId } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.iUserId==iToUserId
              })

              if (results.length > 0) {
                const roomClients = clients;
                roomClients.forEach(client => {
                    if (client.id == results[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            event: 'readSuccessMsg',
                            data: {
                                iFromUserId: iFromUserId,
                            }
                        }));
                    }
                });

                // socket.in(results[0]['vChatId']).emit('readSuccessMsg', {
                //   iFromUserId: iFromUserId,
                // });
        
                const newReadFile = iToUserId + "_" + datFunction() + ".json";
                const MyJsonFile = iFromUserId + "_" + datFunction() + ".json";
        
                if (fs.existsSync("DB/" + newReadFile)) {
                  const contentReadFile = fs.readFileSync("DB/" + newReadFile, 'utf8');
                  if (contentReadFile != "") {
                    const dd = JSON.parse(contentReadFile);
        
                    let newDataUpdateArr = dd.array.map((curEle, index) => {
                      return {
                        ...curEle,
                        ['iRead']: curEle.iToUserId == iFromUserId ? 1 : curEle.iRead,
                        ['iReadTo']: curEle.iToUserId == iFromUserId ? 1 : curEle.iReadTo
                      }
                    })
        
                    fs.writeFileSync("DB/" + newReadFile, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
        
                if (fs.existsSync("DB/" + MyJsonFile)) {
                  const contentReadFile = fs.readFileSync("DB/" + MyJsonFile, 'utf8');
                  if (contentReadFile != "") {
                    const dd = JSON.parse(contentReadFile);
        
                    let newDataUpdateArr = dd.array.map((curEle, index) => {
                      return {
                        ...curEle,
                        ['iRead']: curEle.iFromUserId == iToUserId ? 1 : curEle.iRead,
                      }
                    })
        
                    fs.writeFileSync("DB/" + MyJsonFile, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              }
          }
      }
    }else if(dataMsg.event=="messageGrpReadUpdate"){
      const message=dataMsg.data;

      const { iFromUserId, iToUserId } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.iUserId==iToUserId
              })

              if (results.length > 0) {
                const newReadFile = "GROUP_"+iFromUserId+"_" + datFunction() + ".json";
        
                if (fs.existsSync("DB/" + newReadFile)) {
                  const contentReadFile2 = fs.readFileSync("DB/" + newReadFile, 'utf8');
                  if (contentReadFile2 != "") {
                    const dd2 = JSON.parse(contentReadFile2);
        
                    let newDataUpdateArr = dd2.array.map((curEle, index) => {
                      const tReadUsers = curEle.tReadUsers!=""?String(curEle.tReadUsers).split(","):[];
                      return {
                        ...curEle,
                        ['tReadUsers']: tReadUsers.includes("" + results[0]['iUserId']) ? curEle.tReadUsers : curEle.tReadUsers + "," + results[0]['iUserId']
                      }
                    })
        
                    fs.writeFileSync("DB/" + newReadFile, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }
              }
          }
      }
    }else if(dataMsg.event=="chatRequestAccept"){
      const message=dataMsg.data;

      const { iToUserId,status,tToken,iDelete} = message;

      const userFileName="Users.json";

      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.tToken==tToken
              })

              if(results.length){
                const results2=dd.array.filter((curEle,index)=>{
                  return curEle.iUserId==iToUserId
                })

                if (results2.length > 0) {
                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'receive_message',
                              data: {
                                  type:"ChatRequestAccept",
                                  status:status,
                                  iSenderId: results[0]['iUserId'],
                                  iDelete:iDelete
                              }
                          }));
                      }
                  });

                  // socket.in(results2[0]['vChatId']).emit('receive_message', {
                  //   type:"ChatRequestAccept",
                  //   status:status,
                  //   iSenderId: results[0]['iUserId'],
                  //   iDelete:iDelete
                  // });
                }
              }
          }
      }
    }else if(dataMsg.event=="GroupRefreshUpdate"){
      const message=dataMsg.data;

      const { vActiveGroupId,vUsers,isDelete } = message;

      const groupFileName="Groups.json";

      if (fs.existsSync("DB/"+groupFileName)) {
          const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

          const dd2 = JSON.parse(contentGrpReadFile);

          const results=dd2.array.filter((curEle,index)=>{
            return curEle.iGroupId==vActiveGroupId
          })

          if(results.length){
            const tGroupJoinMembArr=results[0]['tGroupJoinMemb']!=""?results[0]['tGroupJoinMemb'].split(",").filter(c=>c):[];
            const tGroupUsersArr=results[0]['tGroupUsers']!=""?results[0]['tGroupUsers'].split(",").filter(c=>c):[];

            const MergeArr=[...tGroupJoinMembArr,...tGroupUsersArr];
            MergeArr.push(""+results[0]['iCreatedBy']);

            const UniqeUsrArr=duplicateRemoveArr(MergeArr);

            const userFileName="Users.json";

            if (fs.existsSync("DB/"+userFileName)) {
                const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

                if (contentReadFile != "") {
                  const dd = JSON.parse(contentReadFile);
            
                  const results2=dd.array.filter((curEle,index)=>{
                    const tGroupIds=String(curEle.tGroupIds).split(",")
                    return curEle.eStatus=="y" && (UniqeUsrArr.includes(""+curEle.iUserId) || tGroupIds.includes(""+vActiveGroupId))
                  })

                  results2.map((curEle,ind)=>{
                    const roomClients = clients;
                    roomClients.forEach(client => {
                        if (client.id == curEle.vChatId && client.readyState === WebSocket.OPEN) {
                            client.send(JSON.stringify({
                                event: 'receive_grp_message',
                                data: {
                                  type:"refreshGroup",
                                  vActiveGroupId:vActiveGroupId,
                                  vUsers:vUsers,
                                  isDelete:isDelete
                                }
                            }));
                        }
                    });
                  })
                }
            }

          }
      }

    }else if(dataMsg.event=="GroupNewMembRefresh"){
      const message=dataMsg.data;

      const { vUsers } = message;

      const userFileName="Users.json";

      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.iUserId==vUsers
              })

              if (results.length > 0) {
                results.map((curEle,index)=>{

                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == curEle.vChatId && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'receive_message',
                              data: {
                                type:"refreshGroupList",
                              }
                          }));
                      }
                  });

                  // socket.in('' + curEle.vChatId).emit('receive_message', {
                  //   type:"refreshGroupList",
                  // });
                })
              }
          }
      }
    }else if(dataMsg.event=="AllUserGetMyNewSts"){
      const message=dataMsg.data;

      const { tToken,vUsers  } = message;

      const userFileName="Users.json";
      if (fs.existsSync("DB/"+userFileName)) {
          const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');
          if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
        
              const results=dd.array.filter((curEle,index)=>{
                return curEle.eStatus=="y" && curEle.tToken==tToken
              })

              if (results.length > 0) {
                const results2=dd.array.filter((curEle2,index)=>{
                  return curEle2.eStatus=="y" && curEle2.iEmailVerified==1
                })

                let newDataArr = results.map((curEle, index) => {
                  return {
                    ['iUserId']:curEle.iUserId,
                    ['vFullName']:curEle.vFullName,
                    ['iStatus']:curEle.iStatus==1?curEle.eCustStatus==2?curEle.iStatus:curEle.eCustStatus:0,
                    ['iColorOption']:curEle.iColorOption,
                    ['eStatus']:curEle.eStatus,
                    ['iTotalUnReadMsg']: 0,
                    ['lastMessage']: "No Message",
                    ['lastTime']: "",
                    ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
                    ['lastDate']: ""
                  }
                })

                if (results2.length > 0) {
                  results2.map((curEle2,index2)=>{
                    const roomClients = clients;
                    roomClients.forEach(client => {
                        if (client.id == curEle2['vChatId'] && client.readyState === WebSocket.OPEN) {
                            client.send(JSON.stringify({
                                event: 'receive_message',
                                data: {
                                    type:"RefreshUserList",
                                    UserData:newDataArr.length?newDataArr[0]:{}
                                }
                            }));
                        }
                    });
                    // socket.in('' + curEle2['vChatId']).emit('receive_message', {
                    //   type:"RefreshUserList",
                    //   UserData:newDataArr.length?newDataArr[0]:{}
                    // });
                  })
                }
              }
          }
      }
    }else if(dataMsg.event=="send_message"){
      const message=dataMsg.data;

      const { receiverChatID, senderChatID, content, ImageDataArr, vReplyMsg, vReplyMsg_id, id, vReplyFileName, iRequestMsg, isForwardMsg, isDeleteprofile } = message;
  
      if (ImageDataArr.length > 0) {
        ImageDataArr.map((curEle, index) => {
    
          const fileName = `${Date.now()}_${curEle.fileName}`;
          const filePath = `${uploadFolder}${fileName}`;
          const fileType = curEle.type;
    
          // Write the image data to a file
          // var base64Data = curEle.imageData.split("base64,");
    
          var base64Data = curEle.imageData.split("base64,");
    
          const base64DataWithoutHeader = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
          const fileBuffer = Buffer.from(base64DataWithoutHeader, 'base64');
    
          //Image Thumbnail Store
          let fileNameThumb = "";
          if (curEle.imageDataThumb != "") {
            fileNameThumb = `${Date.now()}_thumb_${curEle.fileName}`;
            const filePathThumb = `${uploadFolder}${fileNameThumb}`;
            var base64Data = curEle.imageDataThumb.split("base64,");
            const base64DataWithoutHeaderThumb = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
            const fileBufferThumb = Buffer.from(base64DataWithoutHeaderThumb, 'base64');
    
            fs.writeFile(filePathThumb, fileBufferThumb, (err) => {
              console.log("err", err)
              if (err) throw err;
            })
          }
    
          //Original Image store
          fs.writeFile(filePath, fileBuffer, (err) => {
            console.log("err", err)
            if (err) throw err;
    
            const userFileName = "Users.json";
    
            if (fs.existsSync("DB/" + userFileName)) {
              const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
              if (contentReadFile != "") {
                const dd = JSON.parse(contentReadFile);
    
                const resultsArr = dd.array.filter((curEle, index) => {
                  return curEle.eStatus == "y" && curEle.iUserId == receiverChatID
                })
    
                const resultsArr2 = dd.array.filter((curEle, index) => {
                  return curEle.eStatus == "y" && curEle.iUserId == senderChatID
                })
    
                if (resultsArr.length) {
                  const results = [{ receiverChatID: resultsArr[0]['vChatId'], senderChatID: resultsArr2[0]['vChatId'] }];
    
                  // Send message to only that particular room
                  let ContentData = "vImages => images/uploads/" + fileName;
                  let ContentDataThumb = fileNameThumb != "" ? "vImages => images/uploads/" + fileNameThumb : "";
    
                  const senderJsonFile = senderChatID + '_' + datFunction() + '.json';
                  const receverJsonFile = receiverChatID + '_' + datFunction() + '.json';
    
                  let vReplyMsg_idFinal = vReplyMsg_id;
                  let vReplyMsgFinal = vReplyMsg;
    
                  if (vReplyMsg_id == "LastId") {
                    if (fs.existsSync('DB/' + senderJsonFile)) {
                      const dataOld = fs.readFileSync('DB/' + senderJsonFile, 'utf8');
                      const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);
    
                      if (dbOld.array.length) {
                        vReplyMsg_idFinal = dbOld.array[dbOld.array.length - 1]['id'];
                        vReplyMsgFinal = dbOld.array[dbOld.array.length - 1]['message'];
                      }
                    }
                  }
    
                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == results[0]['receiverChatID'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'receive_message',
                              data: {
                                content: ContentData,
                                senderChatID: results[0]['senderChatID'],
                                receiverChatID: results[0]['receiverChatID'],
                                iSenderId: senderChatID,
                                vReplyMsg: vReplyMsgFinal,
                                vReplyMsg_id: vReplyMsg_idFinal,
                                vReplyFileName: vReplyFileName,
                                id: id,
                                ContentDataThumb: ContentDataThumb,
                                iRequestMsg: iRequestMsg,
                                isForwardMsg: isForwardMsg,
                                isDeleteprofile: isDeleteprofile
                              }
                          }));
                      }
                  });
  
                  // socket.in(results[0]['receiverChatID']).emit('receive_message', {
                  //   content: ContentData,
                  //   senderChatID: results[0]['senderChatID'],
                  //   receiverChatID: results[0]['receiverChatID'],
                  //   iSenderId: senderChatID,
                  //   vReplyMsg: vReplyMsgFinal,
                  //   vReplyMsg_id: vReplyMsg_idFinal,
                  //   vReplyFileName: vReplyFileName,
                  //   id: id,
                  //   ContentDataThumb: ContentDataThumb,
                  //   iRequestMsg: iRequestMsg,
                  //   isForwardMsg: isForwardMsg,
                  //   isDeleteprofile: isDeleteprofile
                  // });
    
                  if (iRequestMsg != 5) {
                    JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 0, ContentDataThumb, 0, iRequestMsg, "", "", isForwardMsg, isDeleteprofile, 0, "", "");
                  }
    
                  JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 0, ContentDataThumb, 0, iRequestMsg, "", "", isForwardMsg, isDeleteprofile, 0, "", "");
    
                  lastChatUpdate(senderChatID, receiverChatID);
                  lastChatUpdate(receiverChatID, senderChatID);
    
                }
              }
            }
    
          })
          // saveBlobFile(curEle.imageData,filePath);
        })
      } else {
    
        const userFileName = "Users.json";
    
        if (fs.existsSync("DB/" + userFileName)) {
          const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
          if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);
    
            const resultsArr = dd.array.filter((curEle, index) => {
              return curEle.eStatus == "y" && curEle.iUserId == receiverChatID
            })
            
            const resultsArr2 = dd.array.filter((curEle, index) => {
              return curEle.eStatus == "y" && curEle.iUserId == senderChatID
            })
  
  
  
            const newDataArr = dd.array.map((curEle, index) => {
              const isStartChat=isStartChatMsg(receiverChatID, curEle.iUserId);
              
              return {
                ['iUserId']:curEle.iUserId,
                ['vFullName']:curEle.vFullName,
                ['iStatus']:curEle.iStatus==1?curEle.eCustStatus==2?curEle.iStatus:curEle.eCustStatus:0,
                ['iColorOption']:curEle.iColorOption,
                ['eStatus']:curEle.eStatus,
                ['isStartChat']:  isStartChat,
                ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic']
              }
            })
  
            const filterUpdateData=newDataArr.filter((curEle,index)=>{
              return curEle.iUserId==senderChatID
            })
    
            if (resultsArr.length) {
  
              const results=[{receiverChatID:resultsArr[0]['vChatId'],senderChatID:resultsArr2[0]['vChatId']}];
    
              // Send message to only that particular room
              let ContentData = content;
              const senderJsonFile = senderChatID + '_' + datFunction() + '.json';
              const receverJsonFile = receiverChatID + '_' + datFunction() + '.json';
    
              let vReplyMsg_idFinal = vReplyMsg_id;
              let vReplyMsgFinal = vReplyMsg;
    
              if (vReplyMsg_id == "LastId") {
                if (fs.existsSync('DB/' + senderJsonFile)) {
                  const dataOld = fs.readFileSync('DB/' + senderJsonFile, 'utf8');
                  const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);
    
                  if (dbOld.array.length) {
                    vReplyMsg_idFinal = dbOld.array[dbOld.array.length - 1]['id'];
                    vReplyMsgFinal = dbOld.array[dbOld.array.length - 1]['message'];
                  }
                }
              }
    
              if (isDeleteprofile == 1) {
                const dbFolderPath = "DB/";
                const NewArr = fs.readdirSync(dbFolderPath);
                const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
    
                const fileExist = dd.length ? dd.filter((curEle, index) => {
                  const splitStr = String(curEle).split("_");
                  return splitStr[0] == receiverChatID;
                }) : [];
    
                if (fileExist.length) {
                  fileExist.map((curEle, index) => {
    
                    if (fs.existsSync("DB/" + curEle)) {
                      const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');
    
                      if (contentReadRecFile != "") {
                        const dd = JSON.parse(contentReadRecFile);
    
                        const newDataUpdateArr = dd.array.map((curEle2, index) => {
                          const isPermDelete = curEle2?.iPermDelete == undefined ? 0 : curEle2.iPermDelete;
                          const iRequestMsg = curEle2?.iRequestMsg == undefined ? 0 : curEle2.iRequestMsg;
                          const isPermDeleteFlag = iRequestMsg == 1 ? 1 : isPermDelete;
    
                          return {
                            ...curEle2,
                            ['iPermDelete']: isPermDeleteFlag
                          }
                        })
    
                        fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                      }
                    }
    
                  })
                }
              }
    
              if (iRequestMsg == 5) {
                const isMessageExist = isCommunicate(receiverChatID, senderChatID);
                if (isMessageExist > 0) {
                  const roomClients = clients;
                  roomClients.forEach(client => {
                      if (client.id == results[0]['receiverChatID'] && client.readyState === WebSocket.OPEN) {
                          client.send(JSON.stringify({
                              event: 'receive_message',
                              data: {
                                content: ContentData,
                                senderChatID: results[0]['senderChatID'],
                                receiverChatID: results[0]['receiverChatID'],
                                iSenderId: senderChatID,
                                vReplyMsg: vReplyMsgFinal,
                                vReplyMsg_id: vReplyMsg_idFinal,
                                vReplyFileName: vReplyFileName,
                                id: id,
                                iRequestMsg: iRequestMsg,
                                isForwardMsg: isForwardMsg,
                                isDeleteprofile: isDeleteprofile,
                                UserData:filterUpdateData.length?filterUpdateData[0]:{}
                              }
                          }));
                      }
                  });
  
                  // socket.in(results[0]['receiverChatID']).emit('receive_message', {
                  //   content: ContentData,
                  //   senderChatID: results[0]['senderChatID'],
                  //   receiverChatID: results[0]['receiverChatID'],
                  //   iSenderId: senderChatID,
                  //   vReplyMsg: vReplyMsgFinal,
                  //   vReplyMsg_id: vReplyMsg_idFinal,
                  //   vReplyFileName: vReplyFileName,
                  //   id: id,
                  //   iRequestMsg: iRequestMsg,
                  //   isForwardMsg: isForwardMsg,
                  //   isDeleteprofile: isDeleteprofile,
                  //   UserData:filterUpdateData.length?filterUpdateData[0]:{}
                  // });
    
                  JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 0, "", 0, iRequestMsg, "", "", isForwardMsg, isDeleteprofile, 0, "", "");
    
                  lastChatUpdate(receiverChatID, senderChatID);
                }
              } else {
  
                const roomClients = clients;
                roomClients.forEach(client => {
                  if (client.id == results[0]['receiverChatID'] && client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            event: 'receive_message',
                            data: {
                              content: ContentData,
                              senderChatID: results[0]['senderChatID'],
                              receiverChatID: results[0]['receiverChatID'],
                              iSenderId: senderChatID,
                              vReplyMsg: vReplyMsgFinal,
                              vReplyMsg_id: vReplyMsg_idFinal,
                              vReplyFileName: vReplyFileName,
                              id: id,
                              iRequestMsg: iRequestMsg,
                              isForwardMsg: isForwardMsg,
                              isDeleteprofile: isDeleteprofile,
                              UserData:filterUpdateData.length?filterUpdateData[0]:{}
                            }
                        }));
                    }
                });
  
                // socket.in(results[0]['receiverChatID']).emit('receive_message', {
                //   content: ContentData,
                //   senderChatID: results[0]['senderChatID'],
                //   receiverChatID: results[0]['receiverChatID'],
                //   iSenderId: senderChatID,
                //   vReplyMsg: vReplyMsgFinal,
                //   vReplyMsg_id: vReplyMsg_idFinal,
                //   vReplyFileName: vReplyFileName,
                //   id: id,
                //   iRequestMsg: iRequestMsg,
                //   isForwardMsg: isForwardMsg,
                //   isDeleteprofile: isDeleteprofile,
                //   UserData:filterUpdateData.length?filterUpdateData[0]:{}
                // });
    
                JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 0, "", 0, iRequestMsg, "", "", isForwardMsg, isDeleteprofile, 0, "", "");
    
                JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 0, "", 0, iRequestMsg, "", "", isForwardMsg, isDeleteprofile, 0, "", "");
    
                lastChatUpdate(senderChatID, receiverChatID);
                lastChatUpdate(receiverChatID, senderChatID);
              }
    
            }
          }
        }
  
      }
    }else if(dataMsg.event=="send_grp_message"){
      const message=dataMsg.data;

      const { receiverChatID, senderChatID, content, ImageDataArr, vReplyMsg, vReplyMsg_id,id,vReplyFileName,isGreetingMsg,vMembersList,vGroupMessageType,isForwardMsg,isDeleteprofile,iRequestMsg,vDeleteMemberId,vNewAdminId,RequestMemberId } = message;

      const groupFileName="Groups.json";
      if (fs.existsSync("DB/"+groupFileName)) {
          const contentGrpReadFile = fs.readFileSync("DB/"+groupFileName, 'utf8');

          const dd2 = JSON.parse(contentGrpReadFile);

          const results=dd2.array.filter((curEle,index)=>{
            return curEle.eGroupStatus=="y" && curEle.iGroupId==receiverChatID
          })

          if(results.length){

            let iCreatedBy=results[0]['iCreatedBy'];

            if (ImageDataArr.length > 0) {
              let SplitGroupUsr = results[0]['tGroupUsers'] != "" ? String(results[0]['tGroupUsers']).split(",") : [];
              SplitGroupUsr.push(iCreatedBy);
              
              let storeFileArr = 0;

              SplitGroupUsr.map((curEle, index) => {
                if (curEle != "") {
                  
                  const userFileName="Users.json";

                if (fs.existsSync("DB/"+userFileName)) {
                    const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

                    if (contentReadFile != "") {
                        const dd = JSON.parse(contentReadFile);
                  
                        const results2=dd.array.filter((curEle2,index)=>{
                          return curEle2.eStatus=="y" && curEle2.iUserId==curEle
                        })

                        if (results2.length > 0) {

                          ImageDataArr.map((curEle, index) => {
                            const fileName = `${Date.now()}_${curEle.fileName}`;
                            const filePath = `${uploadFolder}${fileName}`;
                            const fileType = curEle.type;
              
                            // Write the image data to a file
                            // var base64Data = curEle.imageData.split("base64,");
              
                            saveBlobFile(curEle.imageData, filePath);
              
                            let ContentData = "vImages => images/uploads/" + fileName;
              
                            let fileNameThumb = "";
                            if (curEle.imageDataThumb != "") {
                              fileNameThumb = `${Date.now()}_thumb_${curEle.fileName}`;
                              const filePathThumb = `${uploadFolder}${fileNameThumb}`;
                              var base64Data = curEle.imageDataThumb.split("base64,");
                              const base64DataWithoutHeaderThumb = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
                              const fileBufferThumb = Buffer.from(base64DataWithoutHeaderThumb, 'base64');
              
                              fs.writeFile(filePathThumb, fileBufferThumb, (err) => {
                                console.log("err", err)
                                if (err) throw err;
                              })
                            }
              
                            let ContentDataThumb = fileNameThumb != "" ? "vImages => images/uploads/" + fileNameThumb : "";
              
                            const roomClients = clients;
                            roomClients.forEach(client => {
                                if (client.id == results2[0]['vChatId'] && senderChatID!=results2[0]['iUserId'] && client.readyState === WebSocket.OPEN) {
                                    client.send(JSON.stringify({
                                        event: 'receive_grp_message',
                                        data: {
                                          content: ContentData,
                                          iGroupSenderId: receiverChatID,
                                          senderChatID: senderChatID,
                                          vReplyMsg,
                                          vReplyMsg_id,
                                          ContentDataThumb: ContentDataThumb,
                                          isGreetingMsg: isGreetingMsg,
                                          vGroupMessageType: vGroupMessageType,
                                          isForwardMsg: isForwardMsg,
                                          isDeleteprofile: isDeleteprofile,
                                          iRequestMsg: iRequestMsg,
                                          vMembersList: vMembersList,
                                          vDeleteMemberId: vDeleteMemberId,
                                          id: id
                                        }
                                    }));
                                }
                            });

                            // socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                            //   content: ContentData,
                            //   iGroupSenderId: receiverChatID,
                            //   senderChatID: senderChatID,
                            //   vReplyMsg,
                            //   vReplyMsg_id,
                            //   ContentDataThumb: ContentDataThumb,
                            //   isGreetingMsg: isGreetingMsg,
                            //   vGroupMessageType: vGroupMessageType,
                            //   isForwardMsg: isForwardMsg,
                            //   isDeleteprofile: isDeleteprofile,
                            //   iRequestMsg: iRequestMsg,
                            //   vMembersList: vMembersList,
                            //   vDeleteMemberId: vDeleteMemberId,
                            //   id: id
                            // });
              
                            const senderJsonFile = 'GROUP_' + receiverChatID + '_' + datFunction() + '.json';
              
                            // vDeleteMemberId
                            let vMembersStoreList = vMembersList + "," + results[0]['iCreatedBy'];
                            let vMembersListNew = vDeleteMemberId != "" ? vMembersStoreList + "," + vDeleteMemberId : vMembersStoreList;
                            
                            if (storeFileArr==0) {
                              storeFileArr=1;
                              JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id, id, vReplyFileName, 1, ContentDataThumb, isGreetingMsg, iRequestMsg, vMembersListNew, vGroupMessageType, isForwardMsg, isDeleteprofile, vDeleteMemberId, "", RequestMemberId);
                            }
                          })
              
                        }
                    }
                }

                }
              })
            }else {
              let ContentData = content;

              let SplitGroupUsr = results[0]['tGroupUsers']!=""?String(results[0]['tGroupUsers']).split(","):[];
              if(iRequestMsg==1 || iRequestMsg==3 || iRequestMsg==4){
                const splitMemeberListArr=vMembersList!=""?String(vMembersList).split(","):[];
                SplitGroupUsr = [...splitMemeberListArr];
              }
              let tGroupJoinMembArr = results[0]['tGroupJoinMemb'] != "" ? String(results[0]['tGroupJoinMemb']).split(",") : [];
              if(isDeleteprofile==1 && tGroupJoinMembArr.includes(""+senderChatID)){
                SplitGroupUsr=[results[0]['iCreatedBy']];
              }else{
                if (results[0]['iCreatedBy'] != senderChatID && vGroupMessageType!="NewAdmin") {
                  SplitGroupUsr.push(results[0]['iCreatedBy']);
                }
              }

              SplitGroupUsr.map((curEle, index) => {
                if (curEle != "") {
                  
                  const userFileName="Users.json";

                  if (fs.existsSync("DB/"+userFileName)) {
                      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

                      if (contentReadFile != "") {
                          const dd = JSON.parse(contentReadFile);
                    
                          const results2=dd.array.filter((curEle2,index)=>{
                            return curEle2.eStatus=="y" && curEle2.iUserId==curEle && senderChatID!=curEle2.iUserId
                          })

                          if (results2.length > 0) {
                            const roomClients = clients;
                            roomClients.forEach(client => {
                                if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                                    client.send(JSON.stringify({
                                        event: 'receive_grp_message',
                                        data: {
                                          content: ContentData,
                                          iGroupSenderId: receiverChatID,
                                          senderChatID: senderChatID,
                                          vReplyMsg,
                                          vReplyMsg_id,
                                          isGreetingMsg:isGreetingMsg,
                                          vGroupMessageType:vGroupMessageType,
                                          isForwardMsg:isForwardMsg,
                                          isDeleteprofile:isDeleteprofile,
                                          iRequestMsg:iRequestMsg,
                                          vMembersList:vMembersList,
                                          vDeleteMemberId:vDeleteMemberId,
                                          id:id,
                                          vNewAdminId:vNewAdminId
                                        }
                                    }));
                                }
                            });

                            // socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                            //   content: ContentData,
                            //   iGroupSenderId: receiverChatID,
                            //   senderChatID: senderChatID,
                            //   vReplyMsg,
                            //   vReplyMsg_id,
                            //   isGreetingMsg:isGreetingMsg,
                            //   vGroupMessageType:vGroupMessageType,
                            //   isForwardMsg:isForwardMsg,
                            //   isDeleteprofile:isDeleteprofile,
                            //   iRequestMsg:iRequestMsg,
                            //   vMembersList:vMembersList,
                            //   vDeleteMemberId:vDeleteMemberId,
                            //   id:id,
                            //   vNewAdminId:vNewAdminId
                            // });
                          }
                      }
                  }

                }
              })

              const senderJsonFile = 'GROUP_' + receiverChatID + '_' + datFunction() + '.json';

              let vMembersStoreList=vMembersList;
              if(vGroupMessageType!="NewAdmin"){
                vMembersStoreList+=","+iCreatedBy;
              }
              let vMembersListNew=vDeleteMemberId!=""?vMembersStoreList+","+vDeleteMemberId:vMembersStoreList;

              JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id,id,vReplyFileName,1,"",isGreetingMsg,iRequestMsg,vMembersListNew,vGroupMessageType,isForwardMsg,isDeleteprofile,vDeleteMemberId,vNewAdminId,RequestMemberId);

            }
          }else{
            res.send({ message: 'Group is not exist', status: 412 });
          }
      }
    }else if(dataMsg.event=="delete_message"){
      const message=dataMsg.data;

      const { content, vActiveGroupId, vActiveUserId, tToken, isAdmin } = message;
  
      const userFileName = "Users.json";
    
      if (fs.existsSync("DB/" + userFileName)) {
        const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
        if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results = dd.array.filter((curEle, index) => {
            return curEle.eStatus == "y" && curEle.tToken == tToken
          })
    
          if (results.length) {
            if (vActiveGroupId > 0) {
    
              const groupFileName = "Groups.json";
              if (fs.existsSync("DB/" + groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/" + groupFileName, 'utf8');
    
                const dd2 = JSON.parse(contentGrpReadFile);
    
                const results3 = dd2.array.filter((curEle, index) => {
                  return curEle.eGroupStatus == "y" && curEle.iGroupId == vActiveGroupId
                })
    
                if (results3.length > 0) {
                  let SplitGroupUsr = results3[0]['tGroupUsers'] != "" ? String(results3[0]['tGroupUsers']).split(",") : [];
                  const tLeftMembers = results3[0]['tLeftMembers'] != "" ? String(results3[0]['tLeftMembers']).split(",") : [];
                  SplitGroupUsr = [...SplitGroupUsr, ...tLeftMembers];
    
                  if (SplitGroupUsr.length) {
    
                    if (results3[0]['iCreatedBy'] != results[0]['iUserId']) {
                      SplitGroupUsr.push(results3[0]['iCreatedBy']);
                    }
    
                    SplitGroupUsr.map((curEle, index) => {
                      if (curEle != "" && curEle != results[0]['iUserId']) {
    
                        const results2 = dd.array.filter((curEle2, index) => {
                          return curEle2.eStatus == "y" && curEle2.iUserId == curEle
                        })

                        if (results2.length > 0) {
                          const roomClients = clients;
                          roomClients.forEach(client => {
                              if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                                  client.send(JSON.stringify({
                                      event: 'receive_grp_message',
                                      data: {
                                          content: content,
                                          type: "DeleteMessage",
                                          iGroupId: vActiveGroupId,
                                          isAdmin: isAdmin
                                      }
                                  }));
                              }
                          });

                          // socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                          //   content: content,
                          //   type: "DeleteMessage",
                          //   iGroupId: vActiveGroupId,
                          //   isAdmin: isAdmin
                          // });
                        }
    
                      }
                    })
                  }
                }
    
              }
    
    
            } else {
    
              const userFileName = "Users.json";
    
              if (fs.existsSync("DB/" + userFileName)) {
                const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
                if (contentReadFile != "") {
                  const dd = JSON.parse(contentReadFile);
    
                  const results2 = dd.array.filter((curEle, index) => {
                    return curEle.eStatus == "y" && curEle.iUserId == vActiveUserId
                  })
    
                  if (results2.length > 0) {
                    const roomClients = clients;
                    roomClients.forEach(client => {
                        if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                            client.send(JSON.stringify({
                                event: 'receive_message',
                                data: {
                                    content: content,
                                    type: "DeleteMessage",
                                    iSenderId: results[0]['iUserId']
                                }
                            }));
                        }
                    });

                    // socket.in(results2[0]['vChatId']).emit('receive_message', {
                    //   content: content,
                    //   type: "DeleteMessage",
                    //   iSenderId: results[0]['iUserId']
                    // });
                  }
                }
              }
            }
          }
        }
      }
    }else if(dataMsg.event=="update_message"){
      const message=dataMsg.data;

      const { content, iMessageId, vActiveGroupId, vActiveUserId, tToken } = message;
  
      const userFileName = "Users.json";
    
      if (fs.existsSync("DB/" + userFileName)) {
        const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
        if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const results = dd.array.filter((curEle, index) => {
            return curEle.eStatus == "y" && curEle.tToken == tToken
          })
    
          if (results.length > 0) {
            if (Number(vActiveGroupId) > 0) {
    
              const groupFileName = "Groups.json";
              if (fs.existsSync("DB/" + groupFileName)) {
                const contentGrpReadFile = fs.readFileSync("DB/" + groupFileName, 'utf8');
    
                const dd2 = JSON.parse(contentGrpReadFile);
    
                const results3 = dd2.array.filter((curEle, index) => {
                  return curEle.eGroupStatus == "y" && curEle.iGroupId == vActiveGroupId
                })
    
                if (results3.length > 0) {
                  let SplitGroupUsr = results3[0]['tGroupUsers'] != "" ? String(results3[0]['tGroupUsers']).split(",") : [];
                  const tLeftMembers = results3[0]['tLeftMembers'] != "" ? String(results3[0]['tLeftMembers']).split(",") : [];
                  SplitGroupUsr = [...SplitGroupUsr, ...tLeftMembers];
    
                  if (SplitGroupUsr.length) {
    
                    if (results3[0]['iCreatedBy'] != results[0]['iUserId']) {
                      SplitGroupUsr.push(results3[0]['iCreatedBy']);
                    }
    
                    SplitGroupUsr.map((curEle, index) => {
                      if (curEle != "" && curEle != results[0]['iUserId']) {
    
                        const userFileName = "Users.json";
    
                        if (fs.existsSync("DB/" + userFileName)) {
                          const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
                          if (contentReadFile != "") {
                            const dd = JSON.parse(contentReadFile);
    
                            const results2 = dd.array.filter((curEle2, index) => {
                              return curEle2.eStatus == "y" && curEle2.iUserId == curEle
                            })
    
                            if (results2.length > 0) {
                              const roomClients = clients;
                              roomClients.forEach(client => {
                                  if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                                      client.send(JSON.stringify({
                                          event: 'receive_grp_message',
                                          data: {
                                            content: content,
                                            type: "UpdateMessage",
                                            iMessageId: iMessageId,
                                            iGroupId: vActiveGroupId
                                          }
                                      }));
                                  }
                              });

                              // socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                              //   content: content,
                              //   type: "UpdateMessage",
                              //   iMessageId: iMessageId,
                              //   iGroupId: vActiveGroupId
                              // });
                            }
                          }
                        }
    
                      }
                    })
                  }
                }
    
              }
    
            } else {
    
    
              const userFileName = "Users.json";
    
              if (fs.existsSync("DB/" + userFileName)) {
                const contentReadFile = fs.readFileSync("DB/" + userFileName, 'utf8');
    
                if (contentReadFile != "") {
                  const dd = JSON.parse(contentReadFile);
    
                  const results2 = dd.array.filter((curEle, index) => {
                    return curEle.eStatus == "y" && curEle.iUserId == vActiveUserId
                  })
    
                  if (results2.length > 0) {
                    const roomClients = clients;
                    roomClients.forEach(client => {
                        if (client.id == results2[0]['vChatId'] && client.readyState === WebSocket.OPEN) {
                            client.send(JSON.stringify({
                                event: 'receive_message',
                                data: {
                                  content: content,
                                  type: "UpdateMessage",
                                  iMessageId: iMessageId,
                                  iSenderId: results[0]['iUserId']
                                }
                            }));
                        }
                    });

                    // socket.in(results2[0]['vChatId']).emit('receive_message', {
                    //   content: content,
                    //   type: "UpdateMessage",
                    //   iMessageId: iMessageId,
                    //   iSenderId: results[0]['iUserId']
                    // });
                  }
                }
              }
            }
          }
        }
      }
    }
  });
  
  socket.on('close', function close() {
    const userFileName="Users.json";

    if (fs.existsSync("DB/"+userFileName)) {
        const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

        if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);
      
            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              return {
                ...curEle2,
                ['iStatus']: curEle2.vChatId==socket.id?0:curEle2.iStatus,
              }
            })
          
            fs.writeFileSync("DB/" + userFileName, JSON.stringify({ array: newDataUpdateArr }));

            const results2=dd.array.filter((curEle,index)=>{
              return curEle.eStatus=="y" && curEle.iEmailVerified==1
            })

            const OfflineUser = dd.array.filter((curEle2, index) => {
              return curEle2.vChatId==socket.id
            })

            let newDataArr = OfflineUser.map((curEle, index) => {
              return {
                ['iUserId']:curEle.iUserId,
                ['vFullName']:curEle.vFullName,
                ['iStatus']:0,
                ['iColorOption']:curEle.iColorOption,
                ['eStatus']:curEle.eStatus,
                ['iTotalUnReadMsg']: 0,
                ['lastMessage']: "No Message",
                ['lastTime']: "",
                ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
                ['lastDate']: ""
              }
            })

            if (results2.length > 0) {
              results2.map((curEle2,index2)=>{
                const roomClients = clients;
                roomClients.forEach(client => {
                    if (client.id == curEle2['vChatId'] && client.readyState === WebSocket.OPEN) {
                        client.send(JSON.stringify({
                            event: 'receive_message',
                            data: {
                              type:"RefreshUserList",
                                UserData:newDataArr.length?newDataArr[0]:{}
                            }
                        }));
                    }
                });

                // socket.in('' + curEle2['vChatId']).emit('receive_message', {
                //   type:"RefreshUserList",
                //   UserData:newDataArr.length?newDataArr[0]:{}
                // });
              })
            }
        }
    }

      console.log("user disconnected==>",currentDateTime());
  });
});

app.use(express.static('public'));
app.use('/images/uploads', express.static('images'));
app.use(express.static('DB'))

server.listen(9001, '192.168.1.229', () => {
  console.log('Server started on port 9001');

  const userFileName="Users.json";

  if (fs.existsSync("DB/"+userFileName)) {
      const contentReadFile = fs.readFileSync("DB/"+userFileName, 'utf8');

      if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);
    
          const newDataUpdateArr=dd.array.map((curEle,index)=>{
            return {
              ...curEle,
              ['iStatus']:0
            }
          })

          if(newDataUpdateArr.length){
            fs.writeFileSync("DB/"+userFileName, JSON.stringify({ array: newDataUpdateArr }));
          }
      }
  }
});

server.on('close', function() {
  console.log("server close");
});