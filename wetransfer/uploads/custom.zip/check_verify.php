<?php
include("config.php");

if(!isset($_GET['id'])){
    header('Location: login');
}

?>
<html>
    <head>
        <title>Chat App</title>
    </head>
    <body>
        <span id="errorMsg" style="display: none;">Link not valid.</span>
    <script src="plugins/jquery/jquery.min.js"></script>
    <script>

        $(document).ready(()=>{
            const url=window.location.href;
            const urlObj = new URL(url);
            let idValue = urlObj.searchParams.get('id');

            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: "<?=$API_URL?>verify_email",
                data: {urlString:idValue},
                success: function(data2, status2, xhr) {
                    if(data2.status==200){
                        localStorage.setItem("msg-chat", "Your email is verified; now you can log in.");
                        localStorage.removeItem("verified_email_detail");
                        
                        location.href = 'login';
                    }else{
                        $("#errorMsg").css("display","block");
                    }
                }
            });
        })
    </script>
    </body>
</html>
