<?php
include("config.php");
if(!isset($_GET['id'])){
    header('Location: login');
}

?>
<html>
    <head>
        <title>Chat App - Forgot Password</title>
        <link rel="stylesheet" href="./custom.css">
    </head>
<body>
    <span id="errorMsg" style="display: none;"></span><br/>
    <label>New Password</label>
    <input type="password" id="vPassWord" minlength="8" maxlength="15" />
    <button id="ViewPassword">View</button>
    
    <div id="passwordErrSuggest" class="d-none mt-3">
        <h6 class="validationTitle mb-2">Password requirements</h6>
        <ul id="passwordErrorList">
        </ul>
    </div>

    <br /><br />

    <button id="submit">Submit</button>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="./js/CustomFun.js"></script>
    <script>

        $("#vPassWord").on("input", (e) => {
            const vPassWordStr = String(e.target.value).trim();
            addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
        })

        $("#submit").click(()=>{
            const vPassWord=String($("#vPassWord").val()).trim();
            
            if(vPassWord==""){
                alert("Please fill all field!");
            }else{
                if(addErrorPaswordCust(vPassWord,"passwordErrSuggest","passwordErrorList")){
                    const url=window.location.href;
                    const urlObj = new URL(url);
                    let idValue = urlObj.searchParams.get('id');

                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        url: "<?=$API_URL?>change_password",
                        data: {urlString:idValue,vPassWord:vPassWord},
                        success: function(data2, status2, xhr) {
                            if(data2.status==200){
                                localStorage.setItem("msg-chat", "Your password has been changed, now you can log in.");
                                location.href = 'login';
                            }else{
                                $("#errorMsg").css("display","block");
                                $("#errorMsg").text(data2.message);
                            }
                        }
                    });
                }
            }
        })

        $("#ViewPassword").on("click",(e)=>{
            const vPassWordtype=$("#vPassWord").attr("type");
            if(vPassWordtype=="password"){
                $("#vPassWord").attr("type","text");
            }else{
                $("#vPassWord").attr("type","password");
            }
        })


    </script>
</body>

</html>