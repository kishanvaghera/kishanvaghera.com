<?php
include("config.php");
?>

<html>

<head>
    <title>Chat App - Email Verification</title>
    <link rel="stylesheet" href="./custom.css">
</head>

<body>
    <form method="post">

        <span id="error-msg" style='display: none; margin-bottom:20px; color:red;'></span>

        <label>Verification Code</label>
        <input type="text" id="vOtp" name="vOtp" />
        <br /><br />
        <input type="button" id="submit" name="submit" value="Submit" />
        <input type="button" id="resend" name="resend" value="Resend" />
        <div id="loader" class="d-none"></div>
        <br /><br />
        <span id="msg" style='display: none; margin-bottom:20px; color:green;'></span>
        <br />
        <br />
        <span>Or Link</span>
        <p>If you want to confirm via link, please check your email address. We have sent you a link, click it to confirm.</p>
        <a href="login">Back To Login</a>
    </form>
    <script src="plugins/jquery/jquery.min.js"></script>
    <script>
        function maskEmail(email) {
            return email.replace(/(?<=.{5}).(?=.*@)/g, '*');
        }

        $(document).ready(() => {
            const getLocalData = localStorage.getItem("verified_email_detail");

            if (getLocalData != null) {
                const getLocalDataArr = JSON.parse(getLocalData);

                if (getLocalDataArr?.vUsername != "" && getLocalDataArr?.vEmail) {
                    $("#msg").css("display", "block");
                    $("#msg").text(`We have sent you a verification code to this email ${maskEmail(getLocalDataArr?.vEmail)} please check.`);
                }
            }

        })

        $(document).on("click", "#resend", () => {
            const getLocalData = localStorage.getItem("verified_email_detail");

            if (getLocalData != null) {
                const getLocalDataArr = JSON.parse(getLocalData);

                if (getLocalDataArr?.iEngId && getLocalDataArr?.iEngId != "") {
                    const isLoggedUser = getLocalDataArr?.iEngId;

                    if (isLoggedUser != "") {
                        $("#resend").addClass("d-none");
                        $("#loader").removeClass("d-none");

                        $.ajax({
                            type: 'POST',
                            dataType: "JSON",
                            url: '<?= $API_URL ?>resend_verify_email',
                            data: {
                                vUsername: isLoggedUser,
                                vNewEmailAddrs:"",
                                type:1
                            },
                            success: function(data, status, xhr) {
                                $("#resend").removeClass("d-none");
                                $("#loader").addClass("d-none");

                                if (data.status == 412) {
                                    $("#error-msg").css("display","block");
                                    $("#error-msg").text(data.message);
                                }
                            }
                        });

                    }
                }
            }
        })


        $(document).on("click", "#submit", (e) => {
            e.preventDefault();

            const vOtp = $("#vOtp").val();

            const getLocalData = localStorage.getItem("verified_email_detail");

            if (getLocalData != null) {
                const getLocalDataArr = JSON.parse(getLocalData);

                if (getLocalDataArr?.iEngId && getLocalDataArr?.iEngId != "") {
                    const isLoggedUser = getLocalDataArr?.iEngId;

                    if (isLoggedUser != "") {
                        $("#resend").addClass("d-none");
                        $("#loader").removeClass("d-none");

                        $.ajax({
                            type: 'POST',
                            dataType: "JSON",
                            url: '<?= $API_URL ?>email_code_verify',
                            data: {
                                vUsername: isLoggedUser,
                                vOtp: vOtp
                            },
                            success: function(data, status, xhr) {
                                $("#resend").removeClass("d-none");
                                $("#loader").addClass("d-none");

                                if (data.status == 200) {
                                    localStorage.setItem("msg-chat", "Your email is verified; now you can log in.");
                                    localStorage.removeItem("verified_email_detail");

                                    location.href = 'login';
                                } else {
                                    $("#error-msg").css("display","block");
                                    $("#error-msg").text(data.message);
                                }
                            }
                        });

                    }
                }
            }

        })
    </script>
</body>

</html>