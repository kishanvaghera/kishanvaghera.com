function donwloadBase64File(thefilename, someb64data) {
    var link = document.createElement("a");
    link.download = thefilename;
    var uri = someb64data
    link.href = uri;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function download(url, filename) {
    fetch(url)
        .then(response => response.blob())
        .then(blob => {
            const link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            link.click();
        })
        .catch(console.error);
}

function get_url_extension(url) {
    return url.split(/[#?]/)[0].split('.').pop().trim();
}

const TimeDispFormat = (NewDateStr) => {
    const date = new Date(NewDateStr);
    const hours = date.getHours() + 3; // add 3 hours to get to 11:49
    const minutes = 49;
    const time = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return time;
}

function timestampToAMPM(timestamp = "") {
    const date = timestamp == "" ? new Date() : new Date(timestamp);
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // Handle midnight (0 hours)

    const hoursStr = hours < 10 ? '0' + hours : hours; // Add leading zero if needed
    const minutesStr = minutes < 10 ? '0' + minutes : minutes; // Add leading zero if needed

    const timeString = hoursStr + ':' + minutesStr + ' ' + ampm;
    return timeString;
}

function dateDispl(inputDate = "") {
    var parsedDate;
    if (!inputDate) {
        parsedDate = new Date();
    } else {
        if(typeof inputDate=="string" && inputDate.includes("-")){
            const splitStr=inputDate.split(' ');
            var parts = splitStr[0].split('-');
            parsedDate = new Date(parts[0], parts[1] - 1, parts[2]);
        }else{
            parsedDate=inputDate;
        }
    }

    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];

    var day = parsedDate.getDate();
    var monthIndex = parsedDate.getMonth();
    var year = parsedDate.getFullYear();

    var formattedDate = day + ' ' + monthNames[monthIndex] + ' ' + year;

    return formattedDate;
}

function getCurrentDate() {
    var currentDate = new Date();

    var year = currentDate.getFullYear();
    var month = currentDate.getMonth() + 1;
    var day = currentDate.getDate();
    var monthStr = month < 10 ? '0' + month : '' + month;
    var dayStr = day < 10 ? '0' + day : '' + day;
    var formattedDate = year + '-' + monthStr + '-' + dayStr;

    return formattedDate;
}

//Get Before Weak Date
const oneMonthBackDate=(givenDateStr="")=>{
    var givenDate = new Date();
    if(givenDateStr!=""){
        // Split the given date string into day, month, and year
        var parts = givenDateStr.split("_");
    
        var day = parseInt(parts[1], 10);
        var month = parseInt(parts[2], 10) - 1; // Month is zero-indexed
        var year = parseInt(parts[3], 10);
        givenDate = new Date(year, month, day);
    }

    // Calculate the date before by subtracting the number of milliseconds in a day
    var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
    var daysBefore = 7; // Number of days before
    var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

    // Format the target date as dd_mm_yyyy
    var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

    return targetDateString;
}

//Get Before Weak Date
const oneMonthBackDateGroup=(givenDateStr="")=>{
    var givenDate = new Date();
    if(givenDateStr!=""){
        // Split the given date string into day, month, and year
        var parts = givenDateStr.split("_");

        var day = parseInt(parts[2], 10);
        var month = parseInt(parts[3], 10) - 1; // Month is zero-indexed
        var year = parseInt(parts[4], 10);
        givenDate = new Date(year, month, day);
    }

    // Calculate the date before by subtracting the number of milliseconds in a day
    var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
    var daysBefore = 7; // Number of days before
    var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

    // Format the target date as dd_mm_yyyy
    var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

    return targetDateString;
}

function getCurrentDateTime(isStr=""){
    var date = isStr!=""?new Date(Number(isStr)):new Date();

    // Get the individual components of the date and time
    var year = date.getFullYear();
    var month = ('0' + (date.getMonth() + 1)).slice(-2); // Adding 1 because months are zero-indexed
    var day = ('0' + date.getDate()).slice(-2);
    var hours = ('0' + date.getHours()).slice(-2);
    var minutes = ('0' + date.getMinutes()).slice(-2);
    var seconds = ('0' + date.getSeconds()).slice(-2);

    // Concatenate the components into the desired format
    var formattedDate = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
    
    return formattedDate;
}

function dynamicWithlabel(){
    $('.message-droper-name').each(function () {
        if ($(this).text().length < 8) {
            $(this).css('width', 'auto');
        }
    });
}

$(document).on("click", ".vFileDownload", function(e) {
    const path = $(this).data('id');

    var filename = path.split('/').pop()

    download(path, filename);
})

$(document).on("click", ".base64FileDownload", function(e) {
    const someb64data = $(this).data('id');
    const filename = $(this).data('filename');
    donwloadBase64File(filename, someb64data);
})

function getFileName(url){
    var filename = url.substring(url.lastIndexOf('/')+1);
    return filename
}

const dateToInt = () => {
    return Date.parse(new Date());
}

//2024-05-13T04:41:29.000Z  => 13 May 2024 12:52PM
function formatDateTime(dateTimeStr) {
    
    const utcDate = new Date(dateTimeStr);
    const utcTimeInMs = utcDate.getTime();
    const istOffsetInMs = 5.5 * 60 * 60 * 1000;
    const istTimeInMs = utcTimeInMs + istOffsetInMs;
    const istDate = new Date(istTimeInMs);
    const yearOrg = istDate.getFullYear();
    const monthOrg = String(istDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based in JS
    const dayOrg = String(istDate.getDate()).padStart(2, '0');
    const hoursOrg = String(istDate.getHours()).padStart(2, '0');
    const minutesOrg = String(istDate.getMinutes()).padStart(2, '0');
    const secondsOrg = String(istDate.getSeconds()).padStart(2, '0');
    const istDateStr = `${yearOrg}-${monthOrg}-${dayOrg} ${hoursOrg}:${minutesOrg}:${secondsOrg}`;

    const date = new Date(istDateStr);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const day = date.getUTCDate();
    const month = months[date.getUTCMonth()];
    const year = date.getUTCFullYear();

    let hours = date.getUTCHours();
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'

    const formattedDateTime = `${day} ${month} ${year} ${hours}:${minutes} ${ampm}`;

    return formattedDateTime;
}

function getRandomInt(max) {
    return Number(Math.floor(Math.random() * max))+1;
}

function removeFirstSpaceTxt(htmlString) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');

    // Remove the first &nbsp; or space character from the text nodes
    const walker = document.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null, false);

    let currentNode;
    let nbspRemoved = false;

    let isFirstText=0;
    while (currentNode = walker.nextNode()) {
        isFirstText++
        if(isFirstText==1){
            while (currentNode.nodeValue.startsWith('\u00A0') || currentNode.nodeValue.startsWith(' ')) {
                currentNode.nodeValue = currentNode.nodeValue.substring(1);
                nbspRemoved = true;
            }
            if (nbspRemoved) break;
        }
    }

    // Remove starting <br> elements
    let firstNonBrElementFound = false;
    const childNodes = Array.from(doc.body.childNodes);

    for (let node of childNodes) {
        if(node.tagName=="DIV"){
            node.remove();
        }else{
            if (node.tagName === 'BR' && !firstNonBrElementFound) {
                node.remove();
            } else {
                firstNonBrElementFound = true;
            }
        }
    }

    return doc.body.innerHTML;
}


function splitStringKeepDelimiter(str, delimiter) {
    // Create a regular expression with a positive lookahead to include the delimiter in the split parts
    const regex = new RegExp(`(?=${delimiter})`, 'g');
    // Split the string using the regular expression
    const parts = str.split(regex);
    return parts;
}

//Remove Space if image first or last exist
function removeSpaceImg(htmlString,isFirst=0,isLast=0) {
    if(htmlString!=""){
        let finalHtml="";
        let htmlStringNew=String(htmlString).split("<img");
        const imageStrToArr=splitStringKeepDelimiter(htmlString,"<img");
        if(isFirst || isLast){
            imageStrToArr.map((curEle,index)=>{
                if(index==0 && isFirst){
                    //First Remove br
                    curEle=String(curEle).replace(/<br\s*\/?>/gi, '');
                    finalHtml+=String(curEle.replace(/&nbsp;/g, '')).trim();
                }else if(imageStrToArr.length==Number(index)+1 && isLast){
                    curEle=String(curEle).replace(/<br\s*\/?>/gi, '');
                    // finalHtml += String(curEle.replace(/&nbsp;/g, '').replace(/(<br\s*\/?>|\s)+$/, '')).trim();
                    finalHtml += String(curEle.replace(/&nbsp;\s+/g, '&nbsp;').replace(/&nbsp;/g, '').replace(/(<br\s*\/?>|\s)+$/, '')).trim();
                }else{
                    finalHtml+=curEle;
                }
            })
        }else{
            imageStrToArr.map((curEle,index)=>{
                if(index==0){
                    curEle=String(curEle).replace(/<br\s*\/?>/gi, '');
                  finalHtml+=String(curEle.replace(/&nbsp;/g, '')).trim();
                }else if(htmlStringNew.length==Number(index)+1){
                    curEle=String(curEle).replace(/<br\s*\/?>/gi, '');
                    finalHtml += String(curEle.replace(/&nbsp;\s+/g, '&nbsp;').replace(/&nbsp;/g, '').replace(/(<br\s*\/?>|\s)+$/, '')).trim();
                } else{
                  finalHtml+=curEle;
                }
            })
        }
      
        return finalHtml;
    }else{
        return "";
    }
}

//Check html Code Last Node is image or text 
function isLastNodeImage(node) {
    if (!node) return null;

    for (let i = node.childNodes.length - 1; i >= 0; i--) {
        const child = node.childNodes[i];
        if (child.nodeType === Node.ELEMENT_NODE) {
            if (child.tagName.toLowerCase() === 'img') {
                return 'image';
            }
            const result = isLastNodeImage(child);
            if (result) {
                return result;
            }
        }

        if (child.nodeType === Node.TEXT_NODE && child.textContent.trim().length > 0) {
            return 'text';
        }
    }
    return null;
}

//Check Html First Is Image Or Text
function checkFirstSignificantNode(node) {
    if (!node) return null;

    for (let i = 0; i < node.childNodes.length; i++) {
        const child = node.childNodes[i];
        if (child.nodeType === Node.ELEMENT_NODE) {
            if (child.tagName.toLowerCase() === 'img') {
                return 'image';
            }
            const result = checkFirstSignificantNode(child);
            if (result) {
                return result;
            }
        }
        if (child.nodeType === Node.TEXT_NODE && child.textContent.trim().length > 0) {
            return 'text';
        }
    }
    return null;
}

function removeLastSpaceTxt(htmlString) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, 'text/html');

    // Remove the last &nbsp; or space character from the last text node
    const textWalker = document.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null, false);
    let lastTextNode = null;
    
    while (textWalker.nextNode()) {
        lastTextNode = textWalker.currentNode;
    }

    // console.log("lastTextNode=>",lastTextNode)

    if (lastTextNode) {
        lastTextNode.nodeValue = lastTextNode.nodeValue.replace(/[\u00A0 ]+$/, '');
    }

    // Remove the last <br> element
    if (lastTextNode) {
        let currentNode = lastTextNode.nextSibling;
        // const lastTagName=lastTextNode?.parentNode?.tagName;

        const divElement = document.getElementById('vMessage');
        const children = divElement.children;
        
        let lastTagNameCheck = null;
        
        // Iterate through the children in reverse order
        for (let i = children.length - 1; i >= 0; i--) {
            if (children[i].tagName !== 'BR') {
                lastTagNameCheck = children[i].tagName;
                break;
            }
        }

        if(lastTagNameCheck==='UL' && lastTextNode?.parentNode?.tagName!="BODY"){
            function recursiveFunRemoveBr(){
                const body = doc.body;
                const lastChild = body.lastElementChild;
                
                if (lastChild && lastChild.tagName === 'BR') {
                    body.removeChild(lastChild);

                    const lastChildNext = body.lastElementChild;
                    if (lastChildNext && lastChildNext.tagName === 'BR') {
                        recursiveFunRemoveBr();
                    }
                }
            }

            recursiveFunRemoveBr();
        }else{
            while (currentNode) {
                if (currentNode.nodeType === Node.ELEMENT_NODE && currentNode.tagName === 'BR') {
                    let nextNode = currentNode.nextSibling;
                    currentNode.remove();
                    currentNode = nextNode;
                } else {
                    currentNode = currentNode.nextSibling;
                }
            }
        }

    }

    return doc.body.innerHTML;
}


function removeAllSpaceFrom(){
    var htmlContent = $(".editor").html();

    let NewhtmlContent="";
    let finalHtmlContent="";
    const node = document.getElementById('vMessage');
    const lastChildCheck=isLastNodeImage(node);
    const firstImgOrText=checkFirstSignificantNode(node);

    if(lastChildCheck=="image" && firstImgOrText=="image"){
        finalHtmlContent=removeSpaceImg(htmlContent);
    }else if(lastChildCheck=="text" && firstImgOrText=="text"){
        NewhtmlContent=removeFirstSpaceTxt(String(htmlContent).trim());
        finalHtmlContent=removeLastSpaceTxt(NewhtmlContent);
    }else if(firstImgOrText=="image" && lastChildCheck=="text"){
        NewhtmlContent=removeLastSpaceTxt(String(htmlContent).trim());
        finalHtmlContent=removeSpaceImg(NewhtmlContent,1,0);
    }else if(firstImgOrText=="text" && lastChildCheck=="image"){
        NewhtmlContent=removeFirstSpaceTxt(String(htmlContent).trim());
        finalHtmlContent=removeSpaceImg(NewhtmlContent,0,1);
    }

    // console.log("finalHtmlContent=>",finalHtmlContent)
    // var encodedContent = $("<div>").text(finalHtmlContent).html();
    return finalHtmlContent;
}


// Function to encode HTML entities
function htmlEncode(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/¢/g, '&cent;')
        .replace(/£/g, '&pound;')
        .replace(/¥/g, '&yen;')
        .replace(/€/g, '&euro;')
        .replace(/©/g, '&copy;')
        .replace(/®/g, '&reg;')
        // Add more entities as needed
        ;
}

//Html To plain text
function htmlToPlainText(html) {
    const div = document.createElement('div');
    div.innerHTML = html;
  
    let text = '';
    let currentText = '';
  
    const walker = document.createTreeWalker(
      div,
      NodeFilter.SHOW_ALL,
      { acceptNode: (node) => NodeFilter.FILTER_ACCEPT },
      null
    );
  
    let isEmojiBeforeUl=false;
    let isEmojiAdded=false;
    while (walker.nextNode()) {
      const node = walker.currentNode;
      
      if (node.nodeType === Node.TEXT_NODE) {
        currentText += node.textContent;
      } else if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'IMG') {
        const isBeforeBr=isEmojiBeforeUl?"\n":"";
        text += currentText.trim() + isBeforeBr+ ' <img src="'+node.getAttribute('src')+'" alt="😁" style="width: 25px;">';
        currentText = '';
        isEmojiBeforeUl=false;
        isEmojiAdded=true;
      }else if(node.tagName === 'UL'){
        isEmojiBeforeUl=true;
      }else if (node.tagName === 'BR' || node.tagName === 'LI') {
        text += String(currentText.trim() + '\n').trimStart();
        currentText = '';
        if(node.parentNode.tagName === 'LI'){
            isEmojiBeforeUl=true;
        }else{
            if(node.tagName === 'BR' && isEmojiAdded){
                text += '\n';
                isEmojiAdded=false;
            }
        }
      }
    }
  
    text += currentText.trim();
    
    return String(text).trimStart();
}

function checkString(str) {
    const chars = Array.from(str);

    const hasUppercase = chars.some(char => /[A-Z]/.test(char));
    const hasLowercase = chars.some(char => /[a-z]/.test(char));
    const hasNumeric = chars.some(char => !isNaN(char) && char !== ' ');
    const hasSpecial = chars.some(char => /[!@#$%^&*(),.?":{}|<>]/.test(char));

    return {
        hasUppercase,
        hasLowercase,
        hasNumeric,
        hasSpecial
    };
}

const validateEmail = (email) => {
    return email.match(
        /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

function addErrorPasword(str,idErr){
    const strPaswrd=String(str).trim();
    if(strPaswrd.length>=6){
        const checkPasWord=checkString(strPaswrd);
        if(!checkPasWord['hasUppercase'] || !checkPasWord['hasLowercase'] || !checkPasWord['hasNumeric'] || !checkPasWord['hasSpecial']){
            $("#"+idErr).removeClass("d-none");
            if(!checkPasWord['hasUppercase']){
                $("#"+idErr).text("please add one uppercase.");
            }else if(!checkPasWord['hasLowercase']){
                $("#"+idErr).text("please add one lowercase.");
            }else if(!checkPasWord['hasNumeric']){
                $("#"+idErr).text("please add one number.");
            }else if(!checkPasWord['hasSpecial']){
                $("#"+idErr).text("please add one special character.");
            }
            return 0;
        }else{
            $("#"+idErr).addClass("d-none");
            return 1;
        }
    }else{
        $("#"+idErr).removeClass("d-none");
        $("#"+idErr).text("password must be six character.");
        return 0;
    }
}

function addErrorPaswordCustNew(str,idErrDiv,idErrorList,isSubmit=0){
    const strPaswrd=String(str).trim();
    let htmlCode='';
    let erroList={
        iUpperCase:{isError:1,msg:"Password must include at least one uppercase letter."},
        iLowerCase:{isError:1,msg:"Password must include at least one lowercase letter."},
        iOneNumber:{isError:1,msg:"Password must include at least one number."},
        iOneSpecialCar:{isError:1,msg:"Password must include at least one special character."},
        iPasswordLength:{isError:1,msg:"Password must be at least eight characters long."},
    };
    const checkPasWord=checkString(strPaswrd);

    if(!checkPasWord['hasUppercase'] || !checkPasWord['hasLowercase'] || !checkPasWord['hasNumeric'] || !checkPasWord['hasSpecial'] || strPaswrd.length<8){
        if(!checkPasWord['hasUppercase']){
            erroList['iUpperCase']['isError']=1;
        }else{
            erroList['iUpperCase']['isError']=0;
        }
        
        if(!checkPasWord['hasLowercase']){
            erroList['iLowerCase']['isError']=1;
        }else{
            erroList['iLowerCase']['isError']=0;
        }
        
        if(!checkPasWord['hasNumeric']){
            erroList['iOneNumber']['isError']=1;
        }else{
            erroList['iOneNumber']['isError']=0;
        }
        
        if(!checkPasWord['hasSpecial']){
            erroList['iOneSpecialCar']['isError']=1;
        }else{
            erroList['iOneSpecialCar']['isError']=0;
        }

        if(strPaswrd.length<8){
            erroList['iPasswordLength']['isError']=1;
        }else{
            erroList['iPasswordLength']['isError']=0;
        }


        Object.keys(erroList).map((keys,index)=>{
            if(erroList[keys]['isError']==1){
                $("#"+idErrorList+"_"+keys).removeClass("validation-complete");
                $("#"+idErrorList+"_"+keys).addClass("validation-pending");

                $("#"+idErrorList+"_"+keys+" img").attr("src","./images/svgs/validation-cross.svg");
            }else{
                $("#"+idErrorList+"_"+keys).removeClass("validation-pending");
                $("#"+idErrorList+"_"+keys).addClass("validation-complete");

                $("#"+idErrorList+"_"+keys+" img").attr("src","./images/svgs/validation-check.svg");
            }
        })

        if(isSubmit==1){
            $("#"+idErrDiv).addClass("error");
            $("#"+idErrorList).addClass("d-none");
        }else{
            $("#"+idErrorList).removeClass("d-none");
        }
        return 0;
    }else{
        Object.keys(erroList).map((keys,index)=>{
            $("#"+idErrorList+"_"+keys).removeClass("validation-pending");
            $("#"+idErrorList+"_"+keys).addClass("validation-complete");

            $("#"+idErrorList+"_"+keys+" img").attr("src","./images/svgs/validation-check.svg");
        })

        if(isSubmit==1){
            $("#"+idErrorList).addClass("d-none");
        }else{
            $("#"+idErrorList).removeClass("d-none");
        }

        $("#"+idErrDiv).removeClass("error");
        
        return 1;
    }
}

function duplicateRemoveArr(data){
    return data.length?data.filter((value, index, arr) => index === arr.indexOf(""+value)):[]
}