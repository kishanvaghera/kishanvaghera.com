<?php
    include("config.php");
    @session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Cache-Control" content="no-cache" />
        <meta http-equiv="Pragma" content="no-cache" />
        <meta http-equiv="Expires" content="0" />
        <link rel="shortcut icon" href="./images/favicon.png"
            type="image/x-icon">
        <title>Login | SPOT</title>
        <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
        <link rel="stylesheet" href="./css/style.css">
    </head>
    <body class="login">
        <div class="login-wrapper">
            <div class="position-relative">
                <div style="position: fixed; top: 50%; left: 24%; transform: translateY(-50%); z-index: -1;">
                    <div class="position-absolute top-50 start-50 translate-middle auth-shape1">
                        <img src="./images/svgs/auth-shape1.svg" alt="SPOT">
                    </div>
                    <div class="position-absolute top-50 start-50 translate-middle auth-shape2">
                        <img src="./images/svgs/auth-shape2.svg" alt="SPOT">
                    </div>
                    <div class="position-absolute top-50 start-50 translate-middle auth-shape3">
                        <img src="./images/svgs/auth-shape3.svg" alt="SPOT">
                    </div>
                    <div class="position-absolute top-50 start-50 translate-middle auth-shape4">
                        <img src="./images/svgs/auth-shape4.svg" alt="SPOT">
                    </div>
                    <div class="position-absolute top-50 start-50 translate-middle auth-shape5">
                        <img src="./images/svgs/auth-shape5.svg" alt="SPOT">
                    </div>
                </div>

                <div class="login-header d-flex align-items-center justify-content-between">
                    <a href="javascript:;">
                        <img src="./images/logo.svg" height="64" alt="SPOT" id="logo">
                    </a>
                    <a href="javascript:;">
                        <img src="./images/spot-logo.svg" height="28" alt="SPOT" id="logoTitle">
                    </a>
                </div>

                <div class="login-body d-flex align-items-center justify-content-center" id="bodyContainer">
                    <div class="container-fluid max-width-base">
                        <div class="row">
                            <div class="col-lg-7"></div>
                            <div class="col-lg-4">
                                <h1 class="login-title">Login</h1>
                                <p class="login-subtitle">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                <p class="mb-3 text-danger d-none" id="vErrorMsg"></p>
                                <p class="mb-3 text-success d-none" id="vSucessMsg"></p>

                                <form>
                                    <div class="mb-3">
                                        <label class="form-label">User ID<span>*</span></label>
                                        <input type="text" id="isLoggedUser" class="form-control form-new">
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">User Name</label>
                                        <div class="d-flex gap-3 position-relative">
                                            <input type="text" class="form-control form-new" id="Cur_Fname" disabled="">
                                            <div class="disable-lock"><i class="feather feather-16" data-feather="lock"></i></div>
                                        </div>
                                    </div>

                                    <div class="mb-4">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="form-label">Password<span>*</span></label>
                                            <a href="forgot_password" class="form-label forgot-password-btn">Forgot password?</a>
                                        </div>

                                        <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                            <input type="password" class="form-control form-new" id="vPassword">
                                            <div class="passwordView" id="ViewPassword">
                                                <span><i class="feather feather-18" data-feather="eye"></i></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-4 pb-2">
                                        <button type="button" id="submit" class="btn btn-primary primary-shadow w-100 btn-lg">Login</button>
                                        <div class="loaderContainer d-none" id="loaderSubmit">
                                            <div class="btn-loader-container2">
                                                <div data-loader="circle-side"></div>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <div class="doted-divider mb-4"></div>

                                <div class="pt-2">
                                    <p class="mb-3">Don’t have an account? </p>
                                    <a href="signup" class="btn btn-white white-shadow w-100 btn-lg">Create Now</a>
                                </div>
                            </div>
                            <div class="col-lg-1"></div>
                        </div>
                    </div>
                </div>

                <div class="login-footer d-flex align-items-center justify-content-between">
                    <p class="mb-0">© 2024</p>
                    <div class="enlivenLogo">
                        <a href="https://enlivendc.com/" target="_blank" class="withoutColor">
                            <img src="./images/enliven-logo.svg" height="28" alt="SPOT">
                        </a>
                        <a href="https://enlivendc.com/" target="_blank" class="withColor">
                            <img src="./images/enliven-logo-color.svg" height="28" alt="SPOT">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </body>
    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="plugins/feather-icon/feather.min.js"></script>
    <script>
    
    $(document).ready(()=>{
        feather.replace();
        $("#logo,#logoTitle").click(()=>{
            location.reload();
        })
        
        document.addEventListener('DOMContentLoaded', function () {
            const myDiv = document.getElementById('bodyContainer');
            function updateClasses() {
                const contentHeight = myDiv.scrollHeight;
                const containerHeight = myDiv.clientHeight;

                if (contentHeight <= containerHeight) {
                    myDiv.classList.add('align-items-center');
                } else {
                    myDiv.classList.remove('align-items-center');
                }
            }

            updateClasses();

            window.addEventListener('resize', updateClasses);
        });

        //Email verify Sucess Message
        const successmsg=localStorage.getItem("msg-chat");
        if(successmsg!=null && successmsg!=""){
            $("#vSucessMsg").removeClass("d-none");
            $("#vSucessMsg").text(successmsg);

            localStorage.removeItem("msg-chat");
        }

        //Submit login form
        $("#submit").click(() => {
            submitData();
        })

        //Get Username from User Id
        let vEmailAdr="";
        $("#isLoggedUser").on("input", (e) => {
            vEmailAdr="";
            const iUserId = e.target.value;
            if (iUserId != "") {
                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    url: '<?=$API_URL?>getUserName',
                    data: {
                        iUserId
                    },
                    success: function(data, status, xhr) {
                        if (data.status == 200) {
                            $("#Cur_Fname").val(data.message);
                            if(data?.vEmail){
                                vEmailAdr=data?.vEmail;
                            }
                        } else {
                            $("#Cur_Fname").val("");
                        }
                    }
                });
            } else {
                $("#Cur_Fname").val("");
            }
        })

        $("#ViewPassword").on("click",()=>{
            const vPassWordtype=$("#vPassword").attr("type");
            if(vPassWordtype=="password"){
                $("#vPassword").attr("type","text");
                $("#ViewPassword").html(`<span><i class="feather feather-18" data-feather="eye-off"></i></span>`);
                feather.replace();
            }else{
                $("#vPassword").attr("type","password");
                $("#ViewPassword").html(`<span><i class="feather feather-18" data-feather="eye"></i></span>`);
                feather.replace();
            }
            
        })

        const checkLogin = localStorage.getItem("whatsAppClone");

        if(checkLogin!=null){
            window.location = "./index";
        }
    })

    function submitData(){
        const isLoggedUser = $("#isLoggedUser").val();
        const Cur_Fname = $("#Cur_Fname").val();
        const vPassword = $("#vPassword").val();

        if (isLoggedUser == "" || Cur_Fname == "" || vPassword == "") {
            if(isLoggedUser == ""){
                $("#isLoggedUser").addClass("error");
            }else{
                $("#isLoggedUser").removeClass("error");
            }

            if(vPassword==""){
                $("#vPassword").addClass("error");
            }else{
                $("#vPassword").removeClass("error");
            }
        } else {
            localStorage.removeItem("whatsAppClone");

            $("#loaderSubmit").removeClass("d-none");
            $("#submit").addClass("d-none");

            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: '<?=$API_URL?>login',
                data: {
                    iUserId: isLoggedUser,
                    Cur_Fname: Cur_Fname,
                    vPassword: vPassword
                },
                success: function(data, status, xhr) {
                    $("#vErrorMsg").addClass("d-none");
                    if (data.status == 200) {
                        localStorage.setItem("whatsAppClone", JSON.stringify({
                            tToken: data.tToken,
                            iLoginId: data.iUserId
                        }));
                        localStorage.removeItem("verified_email_detail");
                        
                        window.location = "./index";
                    }else if(data.status == 411){
                        if(data.type=="already_login"){
                            let text = data.message;
                            if (confirm(text) == true) {
                                var socket = new WebSocket('ws://192.168.1.229:8080?token='+data.tToken);

                                socket.onopen = () => {
                                    const loginMessage = JSON.stringify({
                                        event: 'login',
                                        data: {
                                            iLoggedId:isLoggedUser
                                        }
                                    });
                                    socket.send(loginMessage);
                                };

                                setTimeout(() => {
                                    submitData();
                                }, 500);
                            }else{
                                $("#loaderSubmit").addClass("d-none");
                                $("#submit").removeClass("d-none");
                            }
                        }else{
                            localStorage.setItem("verified_email_detail", JSON.stringify({vUsername:Cur_Fname, iEngId:isLoggedUser,vEmail:data.data}));

                            window.location = "./verify_mail";
                        }
                    }else {
                        $("#vErrorMsg").removeClass("d-none");
                        $("#vErrorMsg").text(data.message);
                        $("#loaderSubmit").addClass("d-none");
                        $("#submit").removeClass("d-none");
                    }
                }
            });
        }
    }

    $(document).on("keypress","#vPassword",(e)=>{
        if (e.keyCode == 13) {
            submitData();
        }
    })

    $(document).on("input","#isLoggedUser",(e)=>{
        if (e.target.value!="") {
            $("#isLoggedUser").removeClass("error");
        }
    })

    $(document).on("input","#vPassword",(e)=>{
        if (e.target.value!="") {
            $("#vPassword").removeClass("error");
        }
    })
    </script>
</html>