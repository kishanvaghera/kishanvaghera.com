<?php
include("config.php");
@session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="shortcut icon" href="./images/favicon.png" type="image/x-icon">
    <title>Forgot Password | SPOT</title>
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="login">
    <div class="login-wrapper">
        <div class="position-relative">
            <div style="position: fixed; top: 50%; left: 24%; transform: translateY(-50%); z-index: -1;">
                <div class="position-absolute top-50 start-50 translate-middle auth-shape1">
                    <img src="./images/svgs/auth-shape1.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape2">
                    <img src="./images/svgs/auth-shape2.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape3">
                    <img src="./images/svgs/auth-shape3.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape4">
                    <img src="./images/svgs/auth-shape4.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape5">
                    <img src="./images/svgs/auth-shape5.svg" alt="SPOT">
                </div>
            </div>

            <div class="login-header d-flex align-items-center justify-content-between">
                <a href="javascript:;">
                    <img src="./images/logo.svg" height="64" alt="SPOT" id="logo">
                </a>
                <a href="javascript:;">
                    <img src="./images/spot-logo.svg" height="28" alt="SPOT" id="logoTitle">
                </a>
            </div>

            <div class="login-body d-flex align-items-center justify-content-center" id="bodyContainer">
                <div class="container-fluid max-width-base">
                    <div class="row">
                        <div class="col-lg-7"></div>
                        <div class="col-lg-4">
                            <h1 class="login-title">Forgot Password</h1>
                            <p class="login-subtitle">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                            <p class="mb-3 text-success d-none" id="vForgotPasswordSend"></p>
                            <p class="mb-3 text-danger d-none" id="vErrorMsg"></p>

                            <form>
                                <div class="mb-3">
                                    <label class="form-label">User ID<span>*</span></label>
                                    <input type="text" class="form-control form-new" id="isLoggedUser">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">User Name</label>
                                    <div class="d-flex gap-3 position-relative">
                                        <input type="text" class="form-control form-new" id="Cur_Fname" disabled="">
                                        <div class="disable-lock"><i class="feather feather-16" data-feather="lock"></i></div>
                                    </div>
                                </div>

                                <p class="mb-3 d-none text-dark-60" id="resend_otp_div">Resend OTP in <span class="text-dark" id="timer">05:00</span></p>
                                <div class="mb-4 pb-2">
                                    <button type="button" id="submit" class="btn btn-primary primary-shadow w-100 btn-lg">Reset Password</button>
                                    <div class="loaderContainer d-none" id="loader">
                                        <div class="btn-loader-container2">
                                            <div data-loader="circle-side"></div>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <div class="doted-divider mb-4"></div>

                            <div class="pt-2">
                                <a href="login" class="btn btn-white backBtn w-100 btn-lg d-flex align-items-center justify-content-center"><i class="feather feather-16" data-feather="arrow-left"></i> <span class="ms-2">Back</span></a>
                            </div>

                        </div>
                        <div class="col-lg-1"></div>
                    </div>
                </div>
            </div>

            <div class="login-footer d-flex align-items-center justify-content-between">
                <p class="mb-0">© 2024</p>
                <div class="enlivenLogo">
                    <a href="https://enlivendc.com/" target="_blank" class="withoutColor">
                        <img src="./images/enliven-logo.svg" height="28" alt="SPOT">
                    </a>
                    <a href="https://enlivendc.com/" target="_blank" class="withColor">
                        <img src="./images/enliven-logo-color.svg" height="28" alt="SPOT">
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="plugins/feather-icon/feather.min.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<script>
    function maskEmail(email) {
        return email.replace(/(?<=.{5}).(?=.*@)/g, '*');
    }

    $(document).ready(() => {
        feather.replace();

        $("#logo,#logoTitle").click(()=>{
            location.reload();
        })

        document.addEventListener('DOMContentLoaded', function () {
            const myDiv = document.getElementById('bodyContainer');
            function updateClasses() {
                const contentHeight = myDiv.scrollHeight;
                const containerHeight = myDiv.clientHeight;

                if (contentHeight <= containerHeight) {
                    myDiv.classList.add('align-items-center');
                } else {
                    myDiv.classList.remove('align-items-center');
                }
            }

            updateClasses();

            window.addEventListener('resize', updateClasses);
        });


        //Get Username from User Id
        let vEmailAdr = "";
        $("#isLoggedUser").on("input", (e) => {
            vEmailAdr = "";
            const iUserId = e.target.value;
            if (iUserId != "") {
                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    url: '<?= $API_URL ?>getUserName',
                    data: {
                        iUserId
                    },
                    success: function(data, status, xhr) {
                        if (data.status == 200) {
                            $("#Cur_Fname").val(data.message);
                            if (data?.vEmail) {
                                vEmailAdr = data?.vEmail;
                            }
                        } else {
                            $("#Cur_Fname").val("");
                        }
                    }
                });
            } else {
                $("#Cur_Fname").val("");
            }
        })

        let totalTime = 5 * 60;

        let timerInterval = "";

        function updateTimer() {
            let minutes = Math.floor(totalTime / 60);
            let seconds = totalTime % 60;

            // Pad single digit seconds with a leading zero
            seconds = seconds < 10 ? '0' + seconds : seconds;

            // Display the remaining time
            document.getElementById('timer').innerHTML = minutes + ':' + seconds;

            // Check if the time is up
            if (totalTime > 0) {
                totalTime--;
            } else {
                clearInterval(timerInterval);
                $("#resend_otp_div").addClass("d-none");
                $("#timer").addClass("d-none");
                $("#submit").prop('disabled', false);
            }
        }

        //Forgot Password
        $("#submit").on("click", (e) => {
            e.preventDefault();

            const isLoggedUser = $("#isLoggedUser").val();
            const Cur_Fname = $("#Cur_Fname").val();

            if (isLoggedUser == "" || Cur_Fname == "") {

                if(isLoggedUser==""){
                    $("#isLoggedUser").addClass("error");
                }else{
                    $("#isLoggedUser").removeClass("error");

                    $("#vErrorMsg").text("User is not exist.");
                    $("#vErrorMsg").removeClass("d-none");
                }
            } else {

                $("#submit").addClass("d-none");
                $("#loader").removeClass("d-none");

                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    url: '<?= $API_URL ?>forgot_password',
                    data: {
                        vUsername: isLoggedUser
                    },
                    success: function(data, status, xhr) {
                        if (data.status == 200) {
                            $("#resend_otp_div").removeClass("d-none");
                            
                            localStorage.setItem("forgotResent", 1);

                            $("#timer").removeClass("d-none");

                            $("#submit").text("Resend");
                            $("#submit").removeClass("d-none");
                            $("#submit").prop('disabled', true);

                            $("#loader").addClass("d-none");

                            $("#vForgotPasswordSend").text("Your forgot password link has been sent to this " + maskEmail(vEmailAdr) + " email address.");
                            $("#vForgotPasswordSend").removeClass("d-none");

                            // Update the timer every second
                            totalTime = 5 * 60;

                            timerInterval = setInterval(updateTimer, 1000);
                            // Initial call to display the timer right away
                            updateTimer();
                        } else {
                            $("#submit").removeClass("d-none");
                            $("#loader").addClass("d-none");
                            // alert("some network issue.");
                        }
                    }
                });
            }
        })


        const checkLogin = localStorage.getItem("whatsAppClone");

        if (checkLogin != null) {
            window.location = "./index";
        }

        $(document).on("input",(e)=>{
            if(e.target.value!=""){
                $("#isLoggedUser").removeClass("error");
            }else{
                $("#isLoggedUser").addClass("error");
                $("#vErrorMsg").addClass("d-none");
            }
        })

    })
</script>

</html>