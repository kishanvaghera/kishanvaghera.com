<?php
include("config.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="shortcut icon" href="./images/favicon.png" type="image/x-icon">
    <title>Verify Code | SPOT</title>
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="login">
    <div class="login-wrapper">
        <div class="position-relative">
            <div style="position: fixed; top: 50%; left: 24%; transform: translateY(-50%); z-index: -1;">
                <div class="position-absolute top-50 start-50 translate-middle auth-shape1">
                    <img src="./images/svgs/auth-shape1.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape2">
                    <img src="./images/svgs/auth-shape2.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape3">
                    <img src="./images/svgs/auth-shape3.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape4">
                    <img src="./images/svgs/auth-shape4.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape5">
                    <img src="./images/svgs/auth-shape5.svg" alt="SPOT">
                </div>
            </div>

            <div class="login-header d-flex align-items-center justify-content-between">
                <a href="javascript:;">
                    <img src="./images/logo.svg" height="64" alt="SPOT" id="logo">
                </a>
                <a href="javascript:;">
                    <img src="./images/spot-logo.svg" height="28" alt="SPOT" id="logoTitle">
                </a>
            </div>

            <div class="login-body d-flex align-items-center justify-content-center" id="bodyContainer">
                <div class="container-fluid max-width-base">
                    <div class="row">
                        <div class="col-lg-7"></div>
                        <div class="col-lg-4">
                            <h1 class="login-title">Authentication</h1>
                            <p class="login-subtitle">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                            <p class="mb-3 text-danger d-none" id="error-msg"></p>
                            <p class="mb-3 text-success" id="msg"></p>

                            <form>
                                <div class="mb-3">
                                    <label class="form-label">Verification Code<span>*</span></label>
                                    <input type="text" class="form-control form-new" id="vOtp" name="vOtp">
                                </div>

                                <div class="mb-3 pb-0">
                                    <button type="button" class="btn btn-primary primary-shadow w-100 btn-lg mb-4" id="submit" name="submit" value="Submit">Submit</button>
                                    <div class="loaderContainer d-none" id="loader">
                                        <div class="btn-loader-container2">
                                            <div data-loader="circle-side"></div>
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-primary primary-shadow w-100 btn-lg" id="resend" name="resend" value="Resend">Resend</button>
                                    <div class="loaderContainer d-none" id="loader2">
                                        <div class="btn-loader-container2">
                                            <div data-loader="circle-side"></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="or-line mb-3">
                                    <p>OR</p>
                                </div>

                                <p>Please check your email for a verification link and click on it to verify your account.</p>
                            </form>

                            <div class="doted-divider mb-4"></div>

                            <div class="pt-2">
                                <a href="login" class="btn btn-white backBtn w-100 btn-lg d-flex align-items-center justify-content-center"><i class="feather feather-16" data-feather="arrow-left"></i> <span class="ms-2">Back</span></a>
                            </div>
                        </div>
                        <div class="col-lg-1"></div>
                    </div>
                </div>
            </div>

            <div class="login-footer d-flex align-items-center justify-content-between">
                <p class="mb-0">© 2024</p>
                <div class="enlivenLogo">
                    <a href="https://enlivendc.com/" target="_blank" class="withoutColor">
                        <img src="./images/enliven-logo.svg" height="28" alt="SPOT">
                    </a>
                    <a href="https://enlivendc.com/" target="_blank" class="withColor">
                        <img src="./images/enliven-logo-color.svg" height="28" alt="SPOT">
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>


<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="plugins/feather-icon/feather.min.js"></script>

<script>
    function maskEmail(email) {
        return email.replace(/(?<=.{5}).(?=.*@)/g, '*');
    }

    $(document).ready(() => {
        $("#logo,#logoTitle").click(()=>{
            location.reload();
        })

        feather.replace();
        document.addEventListener('DOMContentLoaded', function() {
            const myDiv = document.getElementById('bodyContainer');

            function updateClasses() {
                const contentHeight = myDiv.scrollHeight;
                const containerHeight = myDiv.clientHeight;

                if (contentHeight <= containerHeight) {
                    myDiv.classList.add('align-items-center');
                } else {
                    myDiv.classList.remove('align-items-center');
                }
            }

            updateClasses();

            window.addEventListener('resize', updateClasses);
        });

        const getLocalData = localStorage.getItem("verified_email_detail");

        if (getLocalData != null) {
            const getLocalDataArr = JSON.parse(getLocalData);

            if (getLocalDataArr?.vUsername != "" && getLocalDataArr?.vEmail) {
                $("#msg").text(`We have sent you a verification code to this email ${maskEmail(getLocalDataArr?.vEmail)} please check.`);
            }
        }

    })

    $(document).on("click", "#resend", () => {
        const getLocalData = localStorage.getItem("verified_email_detail");

        if (getLocalData != null) {
            const getLocalDataArr = JSON.parse(getLocalData);

            if (getLocalDataArr?.iEngId && getLocalDataArr?.iEngId != "") {
                const isLoggedUser = getLocalDataArr?.iEngId;

                if (isLoggedUser != "") {
                    $("#resend").addClass("d-none");
                    $("#loader2").removeClass("d-none");

                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        url: '<?= $API_URL ?>resend_verify_email',
                        data: {
                            vUsername: isLoggedUser,
                            vNewEmailAddrs: "",
                            type: 1
                        },
                        success: function(data, status, xhr) {
                            $("#resend").removeClass("d-none");
                            $("#loader2").addClass("d-none");

                            if (data.status == 412) {
                                $("#error-msg").removeClass("d-none");
                                $("#error-msg").text(data.message);
                            }
                        }
                    });

                }
            }
        }
    })


    $(document).on("click", "#submit", (e) => {
        e.preventDefault();

        const vOtp = $("#vOtp").val();

        const getLocalData = localStorage.getItem("verified_email_detail");

        if (getLocalData != null) {
            const getLocalDataArr = JSON.parse(getLocalData);

            if (getLocalDataArr?.iEngId && getLocalDataArr?.iEngId != "") {
                const isLoggedUser = getLocalDataArr?.iEngId;

                if (isLoggedUser != "") {
                    if(vOtp!=""){
                        $("#submit").addClass("d-none");
                        $("#resend").addClass("d-none");
                        $("#loader").removeClass("d-none");
                        $.ajax({
                            type: 'POST',
                            dataType: "JSON",
                            url: '<?= $API_URL ?>email_code_verify',
                            data: {
                                vUsername: isLoggedUser,
                                vOtp: vOtp
                            },
                            success: function(data, status, xhr) {
                                $("#submit").removeClass("d-none");
                                $("#resend").removeClass("d-none");
                                $("#loader").addClass("d-none");
    
                                if (data.status == 200) {
                                    localStorage.setItem("msg-chat", "Your email is verified, now you can log in.");
                                    localStorage.removeItem("verified_email_detail");
    
                                    location.href = 'login';
                                } else {
                                    $("#error-msg").removeClass("d-none");
                                    $("#error-msg").text(data.message);
                                }
                            }
                        });
                    }else{
                        $("#error-msg").removeClass("d-none");
                        $("#error-msg").text("Please enter verification code.");
                    }

                }
            }
        }

    })
</script>

</html>