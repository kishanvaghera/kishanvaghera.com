<?php
include("config.php");
if (!isset($_GET['id'])) {
    header('Location: login');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="shortcut icon" href="./images/favicon.png" type="image/x-icon">
    <title>Set New Password | SPOT</title>
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body class="login">
    <div class="login-wrapper">
        <div class="position-relative">
            <div style="position: fixed; top: 50%; left: 24%; transform: translateY(-50%); z-index: -1;">
                <div class="position-absolute top-50 start-50 translate-middle auth-shape1">
                    <img src="./images/svgs/auth-shape1.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape2">
                    <img src="./images/svgs/auth-shape2.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape3">
                    <img src="./images/svgs/auth-shape3.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape4">
                    <img src="./images/svgs/auth-shape4.svg" alt="SPOT">
                </div>
                <div class="position-absolute top-50 start-50 translate-middle auth-shape5">
                    <img src="./images/svgs/auth-shape5.svg" alt="SPOT">
                </div>
            </div>

            <div class="login-header d-flex align-items-center justify-content-between">
                <a href="javascript:;">
                    <img src="./images/logo.svg" height="64" alt="SPOT" id="logo">
                </a>
                <a href="javascript:;">
                    <img src="./images/spot-logo.svg" height="28" alt="SPOT" id="logoTitle">
                </a>
            </div>

            <div class="login-body d-flex align-items-center justify-content-center" id="bodyContainer">
                <div class="container-fluid max-width-base">
                    <div class="row">
                        <div class="col-lg-7"></div>
                        <div class="col-lg-4">
                            <h1 class="login-title">Set New Password</h1>
                            <p class="login-subtitle">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                            <p class="mb-3 text-danger d-none" id="vErrorMsg"></p>

                            <form>
                                <div class="mb-4">
                                    <label class="form-label">New Password<span>*</span></label>
                                    <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                        <input type="password" class="form-control form-new" id="vPassWord" minlength="8" maxlength="15">
                                        <div class="passwordView" id="ViewPassword">
                                            <span><i class="feather feather-18" data-feather="eye"></i></span>
                                        </div>

                                        <div class="position-absolute top-100 start-0 w-100 password-require-container d-none" id="passwordErrorList">
                                            <ul class="mb-0">
                                                <li class="validation validation-pending" id="passwordErrorList_iUpperCase">
                                                    <div class="d-flex align-items-center">
                                                        <img src="./images/svgs/validation-cross.svg" alt="">
                                                        <p class="mb-0">Password must include at least one uppercase letter.</p>
                                                    </div>
                                                </li>
                                                <li class="validation validation-pending" id="passwordErrorList_iLowerCase">
                                                    <div class="d-flex align-items-center">
                                                        <img src="./images/svgs/validation-cross.svg" alt="">
                                                        <p class="mb-0">Password must include at least one lowercase letter.</p>
                                                    </div>
                                                </li>
                                                <li class="validation validation-pending" id="passwordErrorList_iOneNumber">
                                                    <div class="d-flex align-items-center">
                                                        <img src="./images/svgs/validation-cross.svg" alt="">
                                                        <p class="mb-0">Password must include at least one number.</p>
                                                    </div>
                                                </li>
                                                <li class="validation validation-pending" id="passwordErrorList_iOneSpecialCar">
                                                    <div class="d-flex align-items-center">
                                                        <img src="./images/svgs/validation-cross.svg" alt="">
                                                        <p class="mb-0">Password must include at least one special character.</p>
                                                    </div>
                                                </li>
                                                <li class="validation validation-pending" id="passwordErrorList_iPasswordLength">
                                                    <div class="d-flex align-items-center">
                                                        <img src="./images/svgs/validation-cross.svg" alt="">
                                                        <p class="mb-0">Password must be at least eight characters long.</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-0 pb-0">
                                    <button type="button" id="submit" class="btn btn-primary primary-shadow w-100 btn-lg">Submit</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-1"></div>
                    </div>
                </div>
            </div>

            <div class="login-footer d-flex align-items-center justify-content-between">
                <p class="mb-0">© 2024</p>
                <div class="enlivenLogo">
                    <a href="https://enlivendc.com/" target="_blank" class="withoutColor">
                        <img src="./images/enliven-logo.svg" height="28" alt="SPOT">
                    </a>
                    <a href="https://enlivendc.com/" target="_blank" class="withColor">
                        <img src="./images/enliven-logo-color.svg" height="28" alt="SPOT">
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
<script src="plugins/feather-icon/feather.min.js"></script>
<script src="./js/CustomFun.js"></script>

<script>
    $(document).ready(()=>{
        feather.replace();

        $("#logo,#logoTitle").click(()=>{
            location.reload();
        })
        
        document.addEventListener('DOMContentLoaded', function () {
            const myDiv = document.getElementById('bodyContainer');
            function updateClasses() {
                const contentHeight = myDiv.scrollHeight;
                const containerHeight = myDiv.clientHeight;

                if (contentHeight <= containerHeight) {
                    myDiv.classList.add('align-items-center');
                } else {
                    myDiv.classList.remove('align-items-center');
                }
            }

            updateClasses();

            window.addEventListener('resize', updateClasses);
        });
    })
    
    $("#vPassWord").on("input", (e) => {
        const vPassWordStr = String(e.target.value).trim();
        addErrorPaswordCustNew(vPassWordStr, "vPassWord", "passwordErrorList");

        if(vPassWordStr!=""){
            $("#vErrorMsg").addClass("d-none");
            $("#vErrorMsg").text("");
        }
    })

    $("#submit").click(() => {
        const vPassWord = String($("#vPassWord").val()).trim();

        if (vPassWord == "") {
            $("#vPassWord").addClass("error");
        } else {
            
            if (addErrorPaswordCustNew(vPassWord, "vPassWord", "passwordErrorList",1)) {
                $("#vPassWord").removeClass("error");

                const url = window.location.href;
                const urlObj = new URL(url);
                let idValue = urlObj.searchParams.get('id');

                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    url: "<?= $API_URL ?>change_password",
                    data: {
                        urlString: idValue,
                        vPassWord: vPassWord
                    },
                    success: function(data2, status2, xhr) {
                        if (data2.status == 200) {
                            localStorage.setItem("msg-chat", "Your password has been changed, now you can log in.");
                            location.href = 'login';
                        } else {
                            $("#errorMsg").css("display", "block");
                            $("#errorMsg").text(data2.message);
                        }
                    }
                });
            }
        }
    })

    $("#ViewPassword").on("click", (e) => {
        const vPassWordtype = $("#vPassWord").attr("type");
        if (vPassWordtype == "password") {
            $("#vPassWord").attr("type", "text");
            $("#ViewPassword").html(`<span><i class="feather feather-18" data-feather="eye-off"></i></span>`);
            feather.replace();
        } else {
            $("#vPassWord").attr("type", "password");
            $("#ViewPassword").html(`<span><i class="feather feather-18" data-feather="eye"></i></span>`);
            feather.replace();
        }
    })

    $("#vPassWord").on("click", (e) => {
        const vPassWordStr = String($("#vPassWord").val()).trim();
        addErrorPaswordCustNew(vPassWordStr, "vPassWord", "passwordErrorList");
    })

    $("#vPassWord").blur(()=>{
        $("#passwordErrorList").addClass("d-none");
    })


</script>

</html>