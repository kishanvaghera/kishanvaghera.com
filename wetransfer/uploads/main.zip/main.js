const { app, BrowserWindow } = require('electron')

process.env.APIPATH = 'http://192.168.1.35/file_manager/api/';
process.env.FTPHOST = '217.21.92.68';
process.env.FTPUSERNAME = 'u560104897.beta_test';
process.env.FTPPASSWORD = '#*1bCJR.ZYjw';

const createWindow = () => {
    const win = new BrowserWindow({
        width: 2000,
        height: 1100,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        }
    })

    win.loadFile('login.html');
}

app.whenReady().then(() => {
    createWindow()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
})
