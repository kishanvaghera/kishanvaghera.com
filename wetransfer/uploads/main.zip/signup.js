const axios = require('axios');

window.addEventListener('DOMContentLoaded', () => { 
    
    const loginApi=async()=>{
        const vUserName=document.getElementById("vUserName").value;
        const vPassword=document.getElementById("vPassword").value;

        if(vUserName=="" || vPassword==""){
            document.getElementById('error-msg').classList.remove("d-none");
            document.getElementById('error-msg').innerHTML="Please enter username & password!";
        }else{
            axios.post(process.env.APIPATH+'auth.php', {action:'register_user',vUserName,vPassword})
              .then(function (response) {
                if(response.data.status==201){
                    document.getElementById('error-msg').classList.add("d-none");
                    document.getElementById('error-msg').innerHTML="";
                    
                    window.location="./login.html";
    
                }else if(response.data.status==412){
                    document.getElementById('error-msg').classList.remove("d-none");
                    document.getElementById('error-msg').innerHTML=response.data.msg;
                }
                console.log(response);
              })
              .catch(function (error) {
                console.log(error);
            });
        }

    }

    document.getElementById('submit').addEventListener('click', function(){
        loginApi();
    });
})