<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE');

$data = json_decode(file_get_contents('php://input'), true);
if ($data != "") {
    $_POST =  $data;
}

if ($_POST['action'] == "login") {
    $vUserName = $_POST['vUserName'];
    $vPassword = $_POST['vPassword'];
    
    $jsonFile = './DB/users.json';

    // Check if the JSON file exists and read its contents
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $users = json_decode($jsonData, true);
    } else {
        $users = array();
    }

    // Check if the user exists and validate the password
    $userFound = 0;
    $index=0;
    foreach ($users as $user) {
        if ($user['vUserName'] == $vUserName && $user['eStatus'] == 'y') {
            if ($user['vPassword'] == sha1($vPassword)) {
                $userFound = 1;
                $data = json_encode(array("iUserId" => $user['iUserId'], "vUserName" => $vUserName));
    
                $encryptionMethod = "AES-256-CBC";
                $secretKey = "FileManageMentSystem";
                $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($encryptionMethod));
                $encryptedData = openssl_encrypt($data, $encryptionMethod, $secretKey, 0, $iv);
    
                // Update the user's auth token
                $users[$index]['vAuthtoken'] = $encryptedData;
    
                // Save the updated users array to the JSON file
                file_put_contents($jsonFile, json_encode($users));
    
                echo json_encode(array("status" => 201, "data" => array("iUserId" => $user['iUserId'], "vAuthtoken" => $encryptedData,"vUserName"=>$vUserName)));
                exit;
            }
        }
        $index++;
    }

    if(!$userFound){
        echo json_encode(array("status" => 412, "msg" => "Please check username or password!"));
        exit;
    }
}else if ($_POST['action'] == "register_user") {
    $vUserName=$_POST['vUserName'];
    $vPassword=$_POST['vPassword'];

    $jsonFile = './DB/users.json';
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $users = json_decode($jsonData, true);
    } else {
        $users = array();
    }

    $userExists = false;
    foreach ($users as $user) {
        if ($user['vUserName'] == $vUserName) {
            $userExists = true;
            break;
        }
    }

    if ($userExists) {
        echo json_encode(array("status" => 412, "msg" => "Username is already registered!"));
    }else{
        // Create a new user
        $newUser = array(
            'iUserId'=>count($users)+1,
            'vUserName' => $vUserName,
            'vPassword' => sha1($vPassword),
            'dCreatedDate' => date('Y-m-d H:i:s'),
            'eStatus' => "y",
            "vAuthtoken" => ""
        );

        // Add the new user to the users array
        $users[] = $newUser;

        // Save the updated users array to the JSON file
        file_put_contents($jsonFile, json_encode($users));
        
        echo json_encode(array("status" => 201, "msg" => "Username has been registered successfully."));
        exit;
    }
}
