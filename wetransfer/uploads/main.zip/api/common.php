<?php

function mf_LoginCheck(){
    $vAuthtoken = $_POST['vAuthtoken'];

    $jsonFile = './DB/users.json';

    // Check if the JSON file exists and read its contents
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $users = json_decode($jsonData, true);

        foreach ($users as $value) {
           if($value['vAuthtoken']==$vAuthtoken){
                $dataArr=array("vUserName"=>$value['vUserName'],"iUserId"=>$value['iUserId'],"vAuthtoken"=>$vAuthtoken);
                return $dataArr;
           }
        }
    }

    $res = array('status' => 411, "message" => "Please login to continue!");
    echo json_encode($res);
    exit();
}