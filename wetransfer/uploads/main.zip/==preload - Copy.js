"use strict";

var jsftp = require("jsftp");
const axios = require('axios');
const fs = require("fs");
const path = require('path');
const { Client } = require("basic-ftp") 

window.addEventListener('DOMContentLoaded', () => {

    let apiBaseUrl="http://192.168.1.35/file_manager/api/";

    const loggedData=localStorage.getItem("fileManagerData");

    //Credential List
    var Ftp = new jsftp({ 
        host: "217.21.92.68",
        port: 21,
        user: "u560104897.beta_test",
        pass: "#*1bCJR.ZYjw"
    });

    Ftp.useList = true;

    Ftp.keepAlive(1000);

    let parentDirPath="./";

    const fileDeleteApi=(fileName)=>{
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'DeleteFolderFile',vAuthtoken,tFolderPath:fileName})
                    .then(function (response) {
        })
    }

    const changePath=()=>{
        document.getElementById("bread-crumb").innerHTML=parentDirPath;
    }

    changePath();

    const basicFtpCheck=async()=>{
        const client = new Client()
        client.ftp.verbose = true
        try {
            await client.access({
                host: "217.21.92.68",
                user: "u560104897.beta_test",
                password: "#*1bCJR.ZYjw",
                secure: true,
                secureOptions: {
                    rejectUnauthorized: false // Disable strict certificate checking
                },
                port:21
            })
            const fileList=await client.list();
            console.log("fileList=>",fileList)
            // await client.uploadFrom("README.md", "README_FTP.md")
            // await client.downloadTo("README_COPY.md", "README_FTP.md")
        }
        catch(err) {
            console.log(err)
        }
        client.close();
    }

    // console.log("parentDirPath",parentDirPath)
    const folderList=document.getElementById("folderList");

    function isFile(pathname) {
        return pathname.split('/').pop().indexOf('.') > -1;
    }
    
    function isDir(pathname) { return !isFile(pathname); }

    function removeDirectory(path, callback) {
        Ftp.ls(path, (err, files) => {
            if (err) {
                return callback(err);
            }

            let pending = files.length;
            if (!pending) {
                fileDeleteApi(path);
                dbTextUpdate(path,"delete");
                return Ftp.raw("RMD", path, callback);
            }

            files.forEach(file => {
                const filePath = `${path}/${file.name}`;
                if (isDir(filePath)) {
                    removeDirectory(filePath, (err) => {
                    
                        if (!--pending) {
                            fileDeleteApi(path);
                            dbTextUpdate(path,"delete");
                            Ftp.raw("RMD", path, callback);
                        }
                    });
                } else {
                    dbTextUpdate(filePath,"delete");
                    Ftp.raw("DELE", filePath, (err) => {
                        if (!--pending) {
                            fileDeleteApi(path);
                            if (isDir(path)) {
                                dbTextUpdate(path,"delete");
                                Ftp.raw("RMD", path, callback);
                            }
                        }
                    });
                }
            });
        });
    }

    const filterFolderPath=(fileListArr,checkPath)=>{
        const dataFilter=fileListArr.filter((curEle,indx)=>{
            return curEle.tFolderPath==checkPath
        })
        return dataFilter.length>0?dataFilter:[];
    }

    //get File Directory List
    function getFolderList(parentDir="."){
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'getFolderList',vAuthtoken})
              .then(function (response) {
                if(response.data.status==201){
                     const dFolderList = response.data.data;
                     changePath();
                     
                     Ftp.ls(parentDir, (err, res) => {
                         let fileHtml="";
                         res.forEach(file => {
                            
                            const filterPermision=filterFolderPath(dFolderList,parentDirPath+file.name);

                            if(filterPermision.length>0){
                                if(filterPermision[0]['isPermission']==1){
                                    if(file.type==0){
                                        fileHtml+="<li>"+file.name+"</li>";
                                    }else{
                                        fileHtml+="<li class='folderList' data-id='"+file.name+"' >"+file.name+"</li>";
                                    }
                                }
                            }else{
                                if(file.type==0){
                                    fileHtml+="<li>"+file.name+"</li>";
                                }else{
                                    fileHtml+="<li class='folderList' data-id='"+file.name+"' >"+file.name+"</li>";
                                }
                            }
                        });
                        
                        folderList.innerHTML="<ul>"+fileHtml+"</ul>";
            
                        var folderListLink = document.querySelectorAll('.folderList');
                        for (var i = 0; i < folderListLink.length; i++) {
                            folderListLink[i].addEventListener('click', function(event) {
                                parentDirPath=parentDirPath+this.dataset.id+"/";
                                getFolderList(parentDirPath);
                            });
                        }
                    });
                }
            })
            .catch(function (error) {
            // console.log(error);
        });
    }

    getFolderList(parentDirPath);

    let isCheckUser=[];
    const getUserList=(isId="userList")=>{
        document.getElementById(isId).innerHTML = "";
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'GetUserList',vAuthtoken})
              .then(function (response) {
            if(response.data.status==201){
                let userHtml="";
                response.data.data.map((curEle,index)=>{
                    userHtml+=` <div class="userListRow">
                                    <div><input type="checkbox" class="checkbox chkUser" name="iUserId_${curEle.iUserId}" id="iUserId_${curEle.iUserId}" value="${curEle.iUserId}" ${isCheckUser.includes(""+curEle.iUserId)?"checked":""}/></div>
                                    <div class="checkbox-label">${curEle.vUserName}</div>
                                </div>`;
                })
                document.getElementById(isId).innerHTML=userHtml;
            }
        })
    }

    //New Folder
    document.getElementById('addcBtn').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "flex";
        getUserList();
    });
    
    document.querySelector('#AddFolderModalClose').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "none";
    });

    function getCheckedBoxes(chkboxName) {
        var checkboxes = document.getElementsByClassName(chkboxName);
        var checkboxesChecked = [];
        // loop over them all
        for (var i=0; i<checkboxes.length; i++) {
           // And stick the checked ones onto an array...
           if (checkboxes[i].checked) {
              checkboxesChecked.push(checkboxes[i].value);
           }
        }
        // Return the array if it is non-empty, or null
        return checkboxesChecked.length > 0 ? checkboxesChecked : [];
    }


    document.getElementById('submitFolder').addEventListener('click', function(e){
        e.preventDefault();
        const folderName=document.getElementById('vFolderName');
        const getUsrList=getCheckedBoxes("chkUser");
        const vUsers=getUsrList.toString();

        if(folderName.value==""){
            alert("please enter folder name!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'addFolder',vAuthtoken,vFolderName:folderName.value,vUsers,tFolderPath:parentDirPath+folderName.value})
                  .then(function (response) {
                if(response.data.status==201){
    
                    dbTextUpdate(parentDirPath+folderName.value,"Add");

                    Ftp.raw("mkd", parentDirPath+folderName.value, (err, data) => {
                        if (err) {
                            return console.error(err);
                        }
                        // console.log(data.text); // Show the FTP response text to the user
                        // console.log(data.code); // Show the FTP response code to the user
                        document.querySelector("#AddFolderModal").style.display = "none";
                        getFolderList(parentDirPath);
                    });
    
                }
            })
        }
    })

    //File Upload Code Start
    const fileInput = document.getElementById('file-input');
    const dropArea = document.getElementById('drop-area');

    // Handle file selection
    fileInput.addEventListener('change', handleFileSelect);

    // Handle drag and drop
    dropArea.addEventListener('dragover', handleDragOver);
    dropArea.addEventListener('drop', handleDrop);

    function handleFileSelect(event) {
        const files = event.target.files;
        handleFiles(files);
    }

    function handleDragOver(event) {
        event.stopPropagation();
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
    }

    function handleDrop(event) {
        event.stopPropagation();
        event.preventDefault();
        const files = event.dataTransfer.files;
        handleFiles(files);
    }
      
    function handleFiles(files) {
        // Process each file
        for (const file of files) {
            const reader = new FileReader();
            reader.onload = () => {
            const fileBuffer = Buffer.from(reader.result);
                document.getElementById("loaderMain").classList.remove("d-none");
                Ftp.put(fileBuffer, parentDirPath+file.name, err => {
                    // console.log("err",err)
                    if (!err) {
                        console.log("File transferred successfully!");
                        getFolderList(parentDirPath);
                        document.getElementById("loaderMain").classList.add("d-none");
                    }
                });
            };
            reader.readAsArrayBuffer(file);
        }
    }



    //Logout Code Start
    document.getElementById('logout').addEventListener('click', function(e){
        localStorage.removeItem("fileManagerData");
        window.location="./login.html";
    })


    //Back Page
    document.getElementById('backButton').addEventListener('click', function(e){
        let newArr = String(parentDirPath).split("/").filter(e => e);
        newArr.pop();
        let text = newArr.join("/");

        if(String(text+"/")!="/"){
            parentDirPath=text+"/";
            getFolderList(parentDirPath);
        }
    })


    //Right Click File & Folder
    let isFileEditActive="";
    let isNewFileName="";
    document.body.addEventListener("mousedown", event => {
        if (event.button == 2){ 
            if(event?.target.closest("li")!=null){
                const fileName=parentDirPath+event?.target?.textContent;
        
                let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
                let iUserId=JSON.parse(loggedData).iUserId;

                isFileEditActive=fileName;
                isNewFileName=event?.target?.textContent;

                axios.post(apiBaseUrl+'fileAction.php', {action:'GetFolderPermission',vAuthtoken,tFolderPath:fileName})
                    .then(function (response) {
                    if(response.data.status==201){
                        if(response.data.iCreatedBy==iUserId){
                            let newArr = String(response.data.data).split(",").filter(e => e);
                            isCheckUser=newArr;

                            document.querySelector("#FolderMoreModal").style.display = "flex";
                        }else{
                            isCheckUser=[];
                        }
                    }else{
                        isCheckUser=[];
                    }
                })
            }
        }
    });


    //More Modal Code Start
    document.querySelector('#FolderMoreModalClose').addEventListener('click', function(){
        document.querySelector("#FolderMoreModal").style.display = "none";
        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
    });
    
    document.querySelector('#PermissionFolderFile').addEventListener('click', function(){
        document.querySelector("#AddFilePermission").style.display = "flex";
        getUserList("userListFile");
    });

    document.querySelector('#RenameFolderFile').addEventListener('click', function(){
        document.querySelector("#RenameFolderFileModal").style.display = "flex";

        document.getElementById("vNewFolderName").value=isNewFileName;
    });

    // SubmitRenameFolderFile
    document.querySelector('#SubmitRenameFolderFile').addEventListener('click', function(e){
        e.preventDefault();

        const vNewFolderName=document.getElementById("vNewFolderName").value;

        Ftp.rename(parentDirPath+isNewFileName,parentDirPath+vNewFolderName, (err, res) => {
            if (!err) {
              console.log("Renaming successful!");
            }

            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'EditFolder',vAuthtoken,vFolderName:parentDirPath+vNewFolderName,vOldFolderName:parentDirPath+isNewFileName})
                    .then(function (response) {
                if(response.data.status==201){
                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#RenameFolderFileModal").style.display = "none";

                    document.querySelector("#FolderMoreModal").style.display = "none";
                    getFolderList(parentDirPath);
                }
            })
        });
    });

    // RenameFolderFileClose
    document.querySelector('#RenameFolderFileClose').addEventListener('click', function(e){
        e.preventDefault();

        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
        document.querySelector("#RenameFolderFileModal").style.display = "none";

        document.querySelector("#FolderMoreModal").style.display = "none";
    })


    function dbTextUpdate(filePath,isType){
        const vDownloadFolderPath=document.getElementById("vDownloadFolderPath").value;
        Ftp.ls("./", (err, files) => {
            const filterData=files.filter((curEle,index)=>{
                return curEle.name=="db.txt" && curEle.size>0
            })

            if(filterData.length>0){
                Ftp.get("./db.txt", (err, socket) => {
                    if (err) {
                        console.error("Error retrieving file:", err);
                        return;
                    }
            
                    socket.on("data", data => {
                        const dataDB=data.toString();
                        if(dataDB!=""){
                            const deletedFileArr=dataDB==""?[]:String(dataDB).split(",");

                            if(isType=="delete"){
                                deletedFileArr.push(filePath);
                                
                                let deleteFoldertext = deletedFileArr.join(",");

                                fs.writeFileSync(vDownloadFolderPath+"/db.txt", deleteFoldertext);
                                const data= fs.readFileSync(vDownloadFolderPath+"/db.txt");

                                Ftp.put(data, "./db.txt", err => {
                                    if (err) {
                                        console.log(err);
                                    }
            
                                    fs.unlink(vDownloadFolderPath+"/db.txt", (err) => {});
                                });

                            }else{
                                const filterFolder=deletedFileArr.filter((curEle,index)=>{
                                    return curEle!=filePath
                                })
                                let deleteFoldertext = filterFolder.join(",");
                                
                                fs.writeFileSync(vDownloadFolderPath+"/db.txt", deleteFoldertext);
                                const data= fs.readFileSync(vDownloadFolderPath+"/db.txt");

                                Ftp.put(data, "./db.txt", err => {
                                    if (err) {
                                        console.log(err);
                                    }
            
                                    fs.unlink(vDownloadFolderPath+"/db.txt", (err) => {});
                                });
                            }
                        }
                    });
        
                    socket.resume(); // Resume reading from the socket
                });
            }else{
                const deletedFileArr=[filePath];

                if(isType=="delete"){
                    let deleteFoldertext = deletedFileArr.join(",");
                   
                    fs.writeFileSync(vDownloadFolderPath+"/db.txt", deleteFoldertext);
                    const data= fs.readFileSync(vDownloadFolderPath+"/db.txt");

                    Ftp.put(data, "./db.txt", err => {
                        if (err) {
                            console.log(err);
                        }

                        fs.unlink(vDownloadFolderPath+"/db.txt", (err) => {});
                    });
                }
            }
        })

    }

    //Delete Folder Or File
    document.querySelector('#DeleteFolderFile').addEventListener('click', function(){
        if (isDir(isFileEditActive)) {
            
            removeDirectory(isFileEditActive, (err, data) => {
                
                if (err) {
                    return console.error(err);
                }
                
                dbTextUpdate(isFileEditActive,"delete");

                document.querySelector("#FolderMoreModal").style.display = "none";
                getFolderList(parentDirPath);
            });
        }else{
            
            Ftp.raw("DELE", isFileEditActive, (err) => {
                dbTextUpdate(isFileEditActive,"delete");
                
                fileDeleteApi(isFileEditActive);
                document.querySelector("#FolderMoreModal").style.display = "none";
                getFolderList(parentDirPath);
            });
        }
    });
    
    // AddFilePermissionClose
    document.querySelector('#AddFilePermissionClose').addEventListener('click', function(){
        isCheckUser=[];
        isFileEditActive="";
        document.querySelector("#AddFilePermission").style.display = "none";
    });

    document.getElementById('submitAddFilePerm').addEventListener('click', function(e){
        e.preventDefault();
        const folderName=isFileEditActive;
        const getUsrList=getCheckedBoxes("chkUser");
        const vUsers=getUsrList.toString();

        if(folderName==""){
            alert("Please select file or folder only!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'UpdatePermission',vAuthtoken,vFolderName:folderName,vUsers:vUsers})
                  .then(function (response) {
                if(response.data.status==201){
                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#AddFilePermission").style.display = "none";
                }
            })
        }
    })

    function getFilesRecursively(directory) {
        let files = [];
        const contents = fs.readdirSync(directory);
        contents.forEach(item => {
            const fullPath = path.join(directory, item);
            const stats = fs.statSync(fullPath);
    
            if (stats.isFile()) {
                files.push(fullPath);
            } else if (stats.isDirectory()) {
                files.push(fullPath);
                files = files.concat(getFilesRecursively(fullPath));
            }
        });
        return files;
    }

    function getFileSize(filePath, callback) {
        let newArr = String(filePath).split("/").filter(e => e);
        newArr.pop();
        let text = newArr.join("/");

        Ftp.ls(text, function(err, files) {
            if (err) {
                callback(err);
                return;
            }
            
            let fileName = String(filePath).split("/").filter(e => e);
            
            var file = files.find(function(file) {
                return file.name === fileName[fileName.length-1];
            });

            if (!file) {
                callback("200");
                return;
            }
    
            callback(null, file.size);
        });
    }

    function uploadFile(localPath, remotePath,lastFolder, callback) {
        fs.readFileSync(localPath, function(err, data) {
            if (err) {
                console.log("err",err)
                callback(err);
                return;
            }
            Ftp.put(data, remotePath, function(err) {
                if(lastFolder){
                    fileDownload("./");
                }
                if (err) {
                    callback(err);
                    return;
                }
                callback(null);
            });
        });
    }

    const asyncForEach = async (array, callback) => {
        for (let index = 0; index < array.length; index++) {
            await callback(array[index], index, array);
        }
    };

    function getDirectoryPath(url) {
        return url.substring(0, url.lastIndexOf('/') + 1);
    }

    document.querySelector('#GetFileData').addEventListener('click', function(){
        basicFtpCheck();
    })

    const downloadFile = (remoteFilePath, localFilePath) => {
        return new Promise((resolve, reject) => {
            const fileStream = fs.createWriteStream(localFilePath);
        
            Ftp.get(remoteFilePath, (err, socket) => {
                if (err) {
                    console.error("Error retrieving file:", err);
                    return reject(err);
                }
    
                socket.on("data", (data) => {
                    console.log("data", data);
                    fileStream.write(data);
                });
    
                socket.on("close", () => {
                    fileStream.end();
                    console.log("File downloaded successfully!");
                    resolve();
                });
    
                socket.resume(); // Resume reading from the socket
            });
        });
    };
      
    const fileDownload = (path, callback) => {
        const vDownloadFolderPath=document.getElementById("vDownloadFolderPath").value;
        if(vDownloadFolderPath==""){
            alert("Please Enter Local Directory Path.");
        }else{
            Ftp.ls(path, async (err, files) => {
                if (err) {
                    return callback(err);
                }
            
                let pending = files.length;
                if (!pending) {
                    return callback(null); // No files to download
                }

                asyncForEach(files, async (file) => {
                    const filePath = `${path}/${file.name}`;
                    const remoteFilePath = String(filePath).replace("./", "");
                    const localFilePath = vDownloadFolderPath + remoteFilePath;

                    if (file.type==1) {
                        if(String(remoteFilePath).split("/").length==2){
                            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
                            axios.post(apiBaseUrl+'fileAction.php', {action:'CheckFolderPermssion',vAuthtoken,vFolderName:path+file.name})
                                .then(function (response) {
                                if(response.data.status==201 && response.data.data==1){
                                    if (!fs.existsSync(localFilePath)) {
                                        fs.mkdirSync(localFilePath, { recursive: true });
                                    }
                                }
                            })
                        }else{
                            const newPath=String(path).replace("./", "");
                            if(fs.existsSync(vDownloadFolderPath+newPath)){
                                if (!fs.existsSync(localFilePath)) {
                                    fs.mkdirSync(localFilePath, { recursive: true });
                                }
                            }
                        }
                        fileDownload(filePath, () => {
                            pending--;
                            if (pending === 0) {
                                callback(null);
                            }
                        });
                    } else {
                        const newPath = String(filePath).replace(".//", "./");
                        
                        if (file.size > 0 && newPath != "./db.txt") {
                            // const getFolderPath = getDirectoryPath(localFilePath);
                            // fs.mkdirSync(getFolderPath, { recursive: true });
    
                            // await new Promise((resolve, reject) => {
                            //     const fileStream = fs.createWriteStream(localFilePath);
                            //     console.log("first1=>", newPath)
    
                            //     Ftp.get(newPath, (err, socket) => {
                            //         if (err) {
                            //             console.error("Error retrieving file:", err);
                            //             return reject(err);
                            //         }
    
                            //         socket.on("data", (data) => {
                            //             console.log("data", data);
                            //             fileStream.write(data);
                            //         });
    
                            //         socket.on("close", () => {
                            //             fileStream.end();
                            //             console.log("File downloaded successfully!");
                            //             resolve();
                            //         });
    
                            //         socket.resume(); // Resume reading from the socket
                            //     });
                            // });

                            const getFolderPath = getDirectoryPath(localFilePath);
                            fs.mkdirSync(getFolderPath, { recursive: true });

                            Ftp.get(newPath, localFilePath, err => {
                                if (err) {
                                  return console.log("err=>",err);
                                }
                                console.log("File copied successfully!");
                            });
                            // await downloadFile(newPath, localFilePath);
                        }
                    }
                    pending--;
                    // if (pending === 0) {
                    //     callback(null);
                    // }
                });
            });
        }
    };

    function syncFolder(){
        const directoryPath=document.getElementById("vDownloadFolderPath").value;
        if(directoryPath==""){
            alert("Please Enter Local Directory Path.");
        }else{
            const fileList = getFilesRecursively(directoryPath);

            const replaceDirePath = String(directoryPath).replace("/", "\\");

            const asyncForEach = async (array, callback) => {
                for (let index = 0; index < array.length; index++) {
                    await callback(array[index], index, array);
                }
            };

            if(fileList.length){
                const uploadAndDownloadFiles = async () => {
                    await asyncForEach(fileList, async (curEle, index) => {
                        const newPath = String(curEle).replace(replaceDirePath, "");
                        const newString = newPath.split("\\").join("/");
    
                        const stats = fs.statSync(curEle);
                        if (!stats.isFile()) {
                            await new Promise((resolve, reject) => {
                
                                if (index === fileList.length - 1) {
                                    fileDownload("./");
                                }
    
                                Ftp.raw("mkd", newString, (err, data) => {
                                    if (err) {
                                        console.error(err);
                                        reject(err);
                                        return;
                                    }
                                    if (newString.split("/").length == 2) {
                                        dbTextUpdate(newString,"Add");
    
                                        let vAuthtoken = JSON.parse(loggedData).vAuthtoken;
                                        axios.post(apiBaseUrl + 'fileAction.php', { action: 'addFolder', vAuthtoken, vFolderName: newString, vUsers: [], tFolderPath: newString })
                                            .then(function (response) {
                                                resolve();
                                            })
                                            .catch(function (error) {
                                                reject(error);
                                            });
                                    } else {
                                        resolve();
                                    }
                                });
                            }).catch((err) => {
                                console.error("Error creating directory:", err);
                            });
                        } else {
                            getFileSize(newString, async (err, size) => {
                                if (err) {
                                    if (err == 200) {
                                        try {
                                            await uploadFile(curEle, newString, index === fileList.length - 1);
                                            console.log("File transferred successfully!");
                                        } catch (error) {
                                            console.error("Error:", error);
                                        }
                                    }
                                } else {
                                    const fileSizeInMegabytes = stats.size / (1024 * 1024);
                                    const ftpFileSize = size / (1024 * 1024);
    
                                    if (ftpFileSize !== fileSizeInMegabytes) {
                                        try {
                                            await uploadFile(curEle, newString, index === fileList.length - 1);
                                            console.log("File transferred successfully!");
                                        } catch (error) {
                                            console.error("Error:", error);
                                        }
                                    } else {
                                        if (index === fileList.length - 1) {
                                            try {
                                                await fileDownload("./");
                                            } catch (error) {
                                                console.error("Error:", error);
                                            }
                                        }
                                    }
                                }
                            });
                        }
                    });
                };
                uploadAndDownloadFiles().catch((error) => {
                    console.error("Error:", error);
                });
            }else{
                fileDownload("./");
            }


        }
    }

    function SyncDeleteFolderLocal(){
        const directoryPath=document.getElementById("vDownloadFolderPath").value;
        if(directoryPath==""){
            alert("Please Enter Local Directory Path.");
        }else{
            Ftp.ls("./", (err, files) => {
                const filterData=files.filter((curEle,index)=>{
                    return curEle.name=="db.txt" && curEle.size>0
                })
                if(filterData.length>0){
                    Ftp.get("./db.txt", (err, socket) => {
                        if (err) {
                            console.error("Error retrieving file:", err);
                            return;
                        }
                
                        socket.on("data", data => {
                            const dataDB=data.toString();
                            if(dataDB!=""){
                                const deletedFileArr=String(dataDB).split(",");
                                deletedFileArr.map((curEle,index)=>{
                                    if(curEle!=""){
                                        const newPath=String(curEle).replace("./", "/");
                                        const filePath=String(directoryPath+newPath).trim();
                                        if(isDir(filePath)){
                                            if(fs.existsSync(filePath)){
                                                fs.rmdirSync(filePath, { recursive: true });  
                                            }
                                            if(Number(deletedFileArr.length)==Number(index+1)){
                                                syncFolder();
                                            }
                                        }else{
                                            if(fs.existsSync(filePath)){
                                                fs.unlinkSync(filePath);
                                            }
                                            if(Number(deletedFileArr.length)==Number(index+1)){
                                                syncFolder();
                                            }
                                        }
                                    }else{
                                        if(Number(deletedFileArr.length)==Number(index+1)){
                                            syncFolder();
                                        }
                                    }
                                })
                            }
                        });
            
                        socket.resume(); // Resume reading from the socket
                    });
                }else{
                    syncFolder();
                }
            })
        }
    }

    document.getElementById('SyncData').addEventListener('click', function(e){
        e.preventDefault();
        SyncDeleteFolderLocal();
    })


})