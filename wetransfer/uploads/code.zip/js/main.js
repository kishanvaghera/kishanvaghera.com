//Soceket Connection Code Start
var socket = io('http://192.168.1.35:9001', {
    transports: ['websocket']
});

let liveIndicationUser=0;
let liveIndicationGroup=0;

const isLocalStorageExist = localStorage.getItem("whatsAppClone");
if (isLocalStorageExist != null) {
    const dd = JSON.parse(isLocalStorageExist);
    socket.emit('join_msg', {
        token: dd.tToken
    });
}

// Default Variable
let timeLineDate = "";
let ImageProfileArr = [];
let filterDateStr = "";
let activeTab = "User";

$(document).ready(function () {
    $("#logo,#logoTitle").click(()=>{
        location.reload();
    })

    const localStorageData = localStorage.getItem("whatsAppClone");
    if (localStorageData != null) {
        const dd = JSON.parse(localStorageData);

        if (dd?.pageType && dd.pageType == "user") {
            setTimeout(() => {
                $("#vUserIdsCls_" + dd.pageTypeId).click();
            }, 100);
        } else if (dd?.pageType && dd.pageType == "group") {
            $("#userGroup").click();
            activeTab = "Group";

            setTimeout(() => {
                let isGroupExist=0;
                $(".vGroupIds").each((e, item) => {
                    const getRowId = $(item).attr("data-id");
                    if (getRowId == dd.pageTypeId) {
                        $(item).click();
                        isGroupExist=1
                    }
                })

                if(isGroupExist==0){
                    let localUpdateData=dd;
                    localUpdateData['pageTypeId']="";
                    localStorage.setItem("whatsAppClone",JSON.stringify(localUpdateData));
                    $("#vActiveGroupId").val("");
                }

            }, 100);
        }
    }

    //Tab Change Code
    $(document).on("click", "#userChat", (e) => {
        activeTab = "User";
        $("#vSearchUser").val("");
        getUserList();
        $("#vSearchText").val("");
        $("#newUserMsgindc").addClass("d-none");
        $("#newUserMsgindc").closest(".sidebar-chat-group-tabs").removeClass("msg-rcv");
    })

    $(document).on("click", "#userGroup", (e) => {
        activeTab = "Group";
        getGroupList();
        $("#vSearchText").val("");
        $("#newGroupMsgindc").addClass("d-none");
        $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").removeClass("msg-rcv");
    })


    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    //Get User List
    function getProfileData(){
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'GetProfileData',
                data: {
                    tToken: dd.tToken
                },
                success: function (data, status, xhr) {
                    if (data.status == 401) {
                        localStorage.removeItem("whatsAppClone");
                        window.location = "./login.php";
                    }else if(data.status==200) {
                        const resData = data.data;
                        let whatsAppCloneData = localStorage.getItem("whatsAppClone");
                        if (whatsAppCloneData != null) {
                            whatsAppCloneData = JSON.parse(whatsAppCloneData);
                            whatsAppCloneData['vEmail'] = resData.vEmail;
                            whatsAppCloneData['iEngId'] = resData.iEngId;
                            whatsAppCloneData['vFullName'] = resData.vFullName;
                            localStorage.setItem("whatsAppClone", JSON.stringify(whatsAppCloneData));
                        }

                        if (resData.vProfilePic == "") {
                            colorOption.map((curEl, index) => {
                                if (curEl.iColorId == resData.iColorOption) {
                                    $("#vProfilePick").attr("xlink:href", curEl.vColorPick);
                                }
                            })
                        } else {
                            $("#vProfilePick").attr("xlink:href", API_URL + resData.vProfilePic);
                        }
    
                        $("#vUserName").text(resData.vFullName);
                        $("#vActiveProfileSts").val(resData.eCustStatus);
                        $("#vLoggedColorOption").val(resData.iColorOption);
    
                        if (resData.eCustStatus == 2) {
                            $("#vUserLoggedSts").text("Online");
                            $("#vLoggedSts").removeClass("offline");
                            $("#vLoggedSts").addClass("online");
                        } else {
                            if (resData.eCustStatus == 1) {
                                $("#vUserLoggedSts").text("Online");
                                $("#vLoggedSts").removeClass("offline");
                                $("#vLoggedSts").addClass("online");
                            } else {
                                $("#vUserLoggedSts").text("Offline");
                                $("#vLoggedSts").addClass("offline");
                                $("#vLoggedSts").removeClass("online");
                            }
                        }
    
                        $(".changeOnlineStst").each((e, item) => {
                            const datId = $(item).attr("data-id");
                            if (datId == resData.eCustStatus) {
                                $(item).addClass("active");
                            } else {
                                $(item).removeClass("active");
                            }
                        })
                    }
                }
            });
        }
    }

    if (isLocalStorageExist != null) {
        getProfileData();

        getGroupList();
        getAllUserList();
    }
})

const chatUserHtmlFun = (filterData, newMessageRecieve = 0) => {
    const vActiveUserId = $("#vActiveUserId").val();

    let htmlUser = "";
    filterData.map((curEle, index) => {
        let profileImage = curEle?.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2, index) => {
                if (curEle2?.iColorId == curEle?.iColorOption) {
                    profileImage = curEle2?.vColorPick;
                }
            })
        }

        const iTotalUnReadMsg = Number(vActiveUserId == curEle?.iUserId ? 0 : curEle?.iTotalUnReadMsg);

        if(vActiveUserId == curEle?.iUserId){
            $("#activeChatProfile").attr("xlink:href",profileImage);
            $("#activeChatName").text(curEle?.vFullName);
            $("#activeChatStsDisp").text(curEle?.iStatus == 1 ? 'Online' : 'Offline');
            if(curEle?.iStatus == 1){
                $("#activeChatSts").removeClass("offline");
                $("#activeChatSts").addClass("online");
            }else{
                $("#activeChatSts").addClass("offline");
                $("#activeChatSts").removeClass("online");
            }


            if(curEle.eStatus=="d"){
                $("#vRequestChatDiv").addClass("d-none");
                $("#TextEditorArea").addClass("d-none");
            }


            $(".receive_chat_profile").attr("src",profileImage);
        }
        
        htmlUser += `
                <li>
                    <a class="cursor-pointer chat-list ${iTotalUnReadMsg > 0 ? 'unread-chat' : ''} ${newMessageRecieve == curEle?.iUserId ? 'message-come' : ''} vUserIdsCls ${vActiveUserId == curEle?.iUserId ? 'chat-active' : ''}" data-id='${curEle?.iUserId}' data-status='${curEle?.iStatus}' id="vUserIdsCls_${curEle?.iUserId}">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <svg role="none" viewBox="0 0 96 96">
                                        <mask id="profile-image">
                                            <circle fill="white" cx="48" cy="48" r="48"></circle>
                                            <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                        </mask>
                                        <g mask="url(#profile-image)">
                                            <image x="0" y="0" height="100%"
                                                preserveAspectRatio="xMidYMid slice" width="100%"
                                                xlink:href="${profileImage}" id="vUserProfileImage_${curEle?.iUserId}"></image>
                                        </g>
                                    </svg>
                                    <div id="vUserProfStatus_${curEle?.iUserId}" class="${curEle?.iStatus == 1 ? 'online' : 'offline'}"></div>
                                </div>
                                <div>
                                    <h5 class="user-profile-name" id="vUserProfName_${curEle?.iUserId}">${curEle?.vFullName}</h5>
                                    <P class="user-profile-activity" id="vUserActSts_${curEle?.iUserId}">${curEle?.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                </div>
                            </div>
                            <div class="unread-message">
                                <span><img src="images/profile/unread-message.svg" alt="unread-message"></span>
                            </div>
                        </div>
                    </a>
                </li>
        `;
    })

    $("#chatUserList").append(htmlUser);

    setTimeout(() => {
        $("#vUserIdsCls_" + newMessageRecieve).removeClass("message-come");
    }, 2000);
}

const chatAllUserHtmlFun = (filterData) => {
    let htmlUser = "";

    filterData.map((curEle, index) => {
        let profileImage = curEle.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2, index) => {
                if (curEle2.iColorId == curEle.iColorOption) {
                    profileImage = curEle2.vColorPick;
                }
            })
        }

        htmlUser += `<li>
                        <a class="cursor-pointer chat-list vNewChatStart" data-id='${curEle.iUserId}' data-status='${curEle.iStatus}'>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="user-profile-image me-3">
                                        <svg role="none" viewBox="0 0 96 96">
                                            <mask id="profile-image">
                                                <circle fill="white" cx="48" cy="48" r="48">
                                                </circle>
                                                <circle fill="black" cx="86%" cy="86%" r="18">
                                                </circle>
                                            </mask>
                                            <g mask="url(#profile-image)">
                                                <image x="0" y="0" height="100%"
                                                    preserveAspectRatio="xMidYMid slice" width="100%"
                                                    xlink:href="${profileImage}">
                                                </image>
                                            </g>
                                        </svg>
                                        <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                    </div>
                                    <div>
                                        <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                        <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                    </div>
                                </div>

                                <div class="unread-message">
                                    <span><img src="images/profile/unread-message.svg"
                                            alt="unread-message"></span>
                                </div>
                            </div>
                        </a>
                    </li>`;

    })

    $("#vChatUserListAll").append(htmlUser);
}

function getUserList(newMessageRecieve = 0) {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    const vActiveUserId=$("#vActiveUserId").val();

    if(activeTab == "User"){
        $("#chatUserList").html("");
    }

    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetUserList',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    const filterData = data.data.sort((a, b) => {
                        var aLastTime = a.lastTime == "" ? 0 : Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime == "" ? 0 : Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime;
                    });

                    // console.log("data",data)
                    if(activeTab == "User"){
                        const vConvertionChatArr=$("#vConvertionChatArr").val();
                        if(vConvertionChatArr!=""){
                            const vConvertionChatList=JSON.parse(vConvertionChatArr);
                            vConvertionChatList.map((curEle,index)=>{
                                if(typeof curEle.isStartChat=="undefined"){
                                    filterData.push(curEle);
                                }
                            })

                            $("#vConvertionChatArr").val(JSON.stringify(filterData));

                            chatUserHtmlFun(filterData, newMessageRecieve);
                        }else{
                            $("#vConvertionChatArr").val(JSON.stringify(filterData));
                            chatUserHtmlFun(filterData, newMessageRecieve);
                        }

                        let vChatUserListJsonArr = $("#vChatUserListJson").val();

                        if (vChatUserListJsonArr != "") {
                            const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

                            if(vActiveUserId>0){
                                const isDeleteMemberReqPend=ChatUserListArr.filter((curEle,index)=>{
                                    return curEle.iUserId==vActiveUserId && curEle.eStatus=="d"
                                })
        
                                if(isDeleteMemberReqPend.length){
                                    // $("#StartChatArea").removeClass("d-none");
                                    // $("#HeaderChatArea").addClass("d-none");
                                    // $("#MainChatArea").addClass("d-none");
                                    $("#vRequestChatDiv").addClass("d-none");
                                    $("#vUserDeleteChat").removeClass("disabled");
                                }
                            }
                        }

                    }else{
                        $("#vConvertionChatArr").val(JSON.stringify(filterData));

                        const unreadMessage=filterData.filter(curEle=>curEle.iTotalUnReadMsg);
                        if(unreadMessage.length>0 && liveIndicationUser==0){
                            liveIndicationUser=1;
                            $("#newUserMsgindc").removeClass("d-none");
                        }
                    }
                }
            }
        });
    }
}

function ifUserDelete(){
    const vActiveUserId=$("#vActiveUserId").val();

    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        if(vActiveUserId>0){
            const isDeleteMemberReqPend=ChatUserListArr.filter((curEle,index)=>{
                return curEle.iUserId==vActiveUserId && curEle.eStatus=="d"
            })

            if(isDeleteMemberReqPend.length){
                $("#StartChatArea").removeClass("d-none");
                $("#HeaderChatArea").addClass("d-none");
                $("#MainChatArea").addClass("d-none");
                
                $(".vUserIdsCls").each((e,item)=>{
                    const iUserId=$(item).attr("data-id");
                    if(iUserId==vActiveUserId){
                        $(item).remove();
                    }
                })
            }
        }
    }
}

function getAllUserList(isNewChat = 0) {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    $("#vChatUserListAll").html("");

    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetChatUserList',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    const filterData = data.data.sort((a, b) => {
                        var aLastTime = a.lastTime == "" ? 0 : Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime == "" ? 0 : Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime;
                    });

                    if (isNewChat) {
                        const filterActiveUSer=filterData.filter((curEle,index)=>{
                            return curEle.eStatus=='y'
                        })
                        chatAllUserHtmlFun(filterActiveUSer);
                        $("#vChatUserListJson").val(JSON.stringify(filterData));
                        ifUserDelete();
                    } else {
                        $("#vChatUserListJson").val(JSON.stringify(filterData));
                        ifUserDelete();
                    }
                }
            }
        });
    }
}

$(document).on("click", "#addNewChatModal", () => {
    $("#SearchUserAllInp").val("");
    getAllUserList(1)
})

//Search Chat User
function searchChatUser(serachText) {
    let vConvertionChatArr = $("#vConvertionChatArr").val();

    if (vConvertionChatArr != "") {
        const ChatUserListArr = JSON.parse(vConvertionChatArr);

        if(activeTab == "User"){
            $("#chatUserList").html("");
        }
        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(serachText).toLocaleLowerCase());
        })

        chatUserHtmlFun(filterData);
    } else {
        if(activeTab == "User"){
            $("#chatUserList").html("");
        }
    }
}

$("#vSearchUser").on('input', (e) => {
    searchChatUser(e.target.value);
})

//Search All User New Chat
function searchChatAllUser(serachText) {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        $("#vChatUserListAll").html("");
        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(serachText).toLocaleLowerCase());
        })

        const filterActiveUser=filterData.filter((curEle,index)=>{
            return curEle.eStatus=='y'
        })

        chatAllUserHtmlFun(filterActiveUser);
    } else {
        $("#vChatUserListAll").html("");
    }
}

$("#SearchUserAllInp").on("input", (e) => {
    searchChatAllUser(e.target.value);
})

//Group List Code
const GroupHtmlFunc = (filterData, iGroupSenderId = 0) => {
    const vActiveGroupId = $("#vActiveGroupId").val();

    filterData.map((curEle, index) => {
        const totalMember = String(curEle.tGroupUsers).split(",");
        const totalMemberCnt = totalMember.filter(curEle => curEle);
        const filterColorOption = GroupColorOption.filter((curEle2, index) => {
            return curEle2.iColorId == curEle.iColorOption
        })

        const vColorOptionImg = filterColorOption.length ? filterColorOption[0]['vColorPick'] : ""

        if (vActiveGroupId == curEle.iGroupId) {
            const totlMemeberCnt=curEle.tGroupUsers==""?0:Number(totalMemberCnt.length)

            $("#activeChatStsDisp").text(Number(totlMemeberCnt)+1 + " Members");
            $("#activeGroupProfile").attr("src", curEle.vGroupImage == "" ? vColorOptionImg : curEle.vGroupImage);
        }

        let html = `<li>
                    <a class="cursor-pointer chat-list vGroupIds ${curEle.iTotalUnReadMsg > 0 && vActiveGroupId != curEle.iGroupId ? 'unread-chat' : ''} ${iGroupSenderId == curEle.iGroupId ? 'message-come' : ''} ${vActiveGroupId == curEle.iGroupId ? 'chat-active' : ''}" data-id='${curEle.iGroupId}'> 
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <img src="${curEle.vGroupImage == "" ? vColorOptionImg : curEle.vGroupImage}" alt="group-profile" class="rounded-2">
                                </div>
                                <div>
                                    <h5 class="user-profile-name">${curEle.vGroupName}</h5>
                                    <P class="user-profile-activity">${Number(totalMemberCnt.length)+1} Members</P>
                                </div>
                            </div>

                            <div class="unread-message">
                                <span><img src="images/profile/unread-message.svg"
                                        alt="unread-message"></span>
                            </div>
                        </div>
                    </a>
                </li>`;

        $("#ChatGroupList").append(html);

        if (iGroupSenderId > 0 && iGroupSenderId == curEle.iGroupId) {
            setTimeout(() => {
                if(activeTab == "Group"){
                    $(".vGroupIds").each((e, item) => {
                        const getRowId = $(item).attr("data-id");
                        if (getRowId == iGroupSenderId) {
                            $(item).removeClass("message-come");
                        }
                    })
                }
            }, 2000)
        }
    })
}

function isGroupDelete(){
    const vActiveGroupId=$("#vActiveGroupId").val();

    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();

    if (vChatGroupListJsonArr != "") {
        const groupListArr = JSON.parse(vChatGroupListJsonArr);

        if(vActiveGroupId>0){
            const isDeleteGroup=groupListArr.filter((curEle,index)=>{
                return curEle.iGroupId==vActiveGroupId && curEle.eStatus=="d"
            })

            if(isDeleteGroup.length){
                $("#StartChatArea").removeClass("d-none");
                $("#HeaderChatArea").addClass("d-none");
                $("#MainChatArea").addClass("d-none");
            }
        }
    }
}




function getGroupList(iGroupSenderId = 0) {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    const vActiveGroupId=$("#vActiveGroupId").val();
    //Get Group List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $(".vGroupIds").remove();
        if (activeTab == "Group") {
            $(".vUserIdsCls").remove();
        }

        $("#ChatGroupList").html("");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetGroupList',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    const filterData = data.data.sort((a, b) => {
                        var aLastTime = a.lastTime == "" ? 0 : Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime == "" ? 0 : Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime;
                    });

                    $("#vChatGroupListJson").val(JSON.stringify(filterData));
                    isGroupDelete();

                    if (activeTab == "Group") {
                        GroupHtmlFunc(filterData, iGroupSenderId);

                        if(vActiveGroupId>0){
                            if(filterData.length>0){
                                filterData.map((curEle,index)=>{
                                    if(curEle.iGroupId==vActiveGroupId || curEle.iGroupId==dd.pageTypeId){
                                        const tGroupUsers=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(","):[];
                                        const tGroupJoinMemb=curEle.tGroupJoinMemb!=""?String(curEle.tGroupJoinMemb).split(","):[];
                                       
                                        $("#activeChatName").text(curEle?.vGroupName);
    
                                        if(tGroupJoinMemb.includes(""+dd.iLoginId) && curEle.iCreatedBy!=dd.iLoginId){
                                            $("#vGroupDeleteChat").addClass("disabled");
                                            $("#vExitGroup").closest("li").addClass("d-none");
                                            $("#vDeleteGroup").closest("li").addClass("d-none");
                                            $("#texAreaEditorDiv").addClass("d-none");
                                        }else{
                                            $("#vGroupDeleteChat").removeClass("disabled");
        
                                            if(tGroupUsers.includes(""+dd.iLoginId) || curEle.iCreatedBy==dd.iLoginId){
                                                $("#vExitGroup").closest("li").removeClass("d-none");
                                                $("#vDeleteGroup").closest("li").addClass("d-none");
                                                $("#texAreaEditorDiv").removeClass("d-none");
                                            }else{
                                                $("#vExitGroup").closest("li").addClass("d-none");
                                                $("#vDeleteGroup").closest("li").removeClass("d-none");
                                                $("#vGroupInfoBtn").closest("li").addClass("d-none");
                                                $("#texAreaEditorDiv").addClass("d-none");
                                            }
                                        }


                                        const filterTotalGrpMemb=tGroupUsers.filter(c=>c);
                                        if(filterTotalGrpMemb.length){
                                            $("#vExitGroup").removeClass("disabled");
                                        }else{
                                            $("#vExitGroup").addClass("disabled");
                                        }
                                    }
                                })
                            }else{
                                if(vActiveGroupId>0){
                                    $("#StartChatArea").removeClass("d-none");
                                    $("#HeaderChatArea").addClass("d-none");
                                    $("#MainChatArea").addClass("d-none");
                                }
                            }
                        }

                    }else{
                        const unreadMessage=filterData.filter(curEle=>curEle.iTotalUnReadMsg);
                        if(unreadMessage.length>0 && liveIndicationGroup==0){
                            liveIndicationGroup=1;
                            $("#newGroupMsgindc").removeClass("d-none");
                        }
                    }
                }
            }
        });
    }
}

function searchGroupName(serachText) {
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();

    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        $("#ChatGroupList").html("");
        const filterData = chatGroupList.filter((curEle, index) => {
            const vGroupName = String(curEle.vGroupName).toLocaleLowerCase();
            return vGroupName.includes(String(serachText).toLocaleLowerCase());
        })

        GroupHtmlFunc(filterData);
    } else {
        $("#ChatGroupList").html("");
    }
}

$("#searchGroupName").on("input", (e) => {
    searchGroupName(e.target.value);
})

function NewGroupUserHtml(dataArr) {
    $("#NewGroupUserList").html("");

    const vNewGrpUserSelect = $("#vNewGrpUserSelect").val();
    const UserSelectListArr = vNewGrpUserSelect != "" ? String(vNewGrpUserSelect).split(",") : [];

    let htmlUser = "";
    dataArr.map((curEle, index) => {
        let profileImage = curEle.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2, index) => {
                if (curEle2.iColorId == curEle.iColorOption) {
                    profileImage = curEle2.vColorPick;
                }
            })
        }

        let isChecked = UserSelectListArr.includes("" + curEle.iUserId);

        htmlUser += `<li>
            <a class="cursor-pointer chat-list">
                <label class="d-flex align-items-center justify-content-between form-check ps-0"
                    for="NewGroupUserChbx_${curEle.iUserId}">
                    <div class="d-flex align-items-center">
                        <div class="user-profile-image me-3">
                            <svg role="none" viewBox="0 0 96 96">
                                <mask id="profile-image">
                                    <circle fill="white" cx="48" cy="48" r="48">
                                    </circle>
                                    <circle fill="black" cx="86%" cy="86%" r="18">
                                    </circle>
                                </mask>
                                <g mask="url(#profile-image)">
                                    <image x="0" y="0" height="100%"
                                        preserveAspectRatio="xMidYMid slice" width="100%"
                                        xlink:href="${profileImage}">
                                    </image>
                                </g>
                            </svg>
                            <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                        </div>
                        <div>
                            <h5 class="user-profile-name">${curEle.vFullName}</h5>
                            <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                        </div>
                    </div>

                    <span>
                        <input class="form-check-input NewGroupUserChbx" type="checkbox" value="${curEle.iUserId}" id="NewGroupUserChbx_${curEle.iUserId}" ${isChecked ? 'checked' : ''}>
                    </span>
                </label>
            </a>
        </li>`;
    })
    $("#NewGroupUserList").html(htmlUser);
}

$("#CreateNewGroup").on("click", () => {
    getAllUserList();
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    // vGroupProfilePick=[];
    tempFilename = "";
    finalProfilePick = "";
    finalColorSelection = "";

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        const filterActveUser=ChatUserListArr.filter((curEle,index)=>{
            return curEle.eStatus=='y'
        })
        NewGroupUserHtml(filterActveUser);
    } else {
        $("#NewGroupUserList").html("");
    }

    $("#SeachNewGroupUser").val("");
})

$("#SeachNewGroupUser").on("input", (e) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(e.target.value).toLocaleLowerCase());
        })

        const filterActiveNewData=filterData.filter((curEle,index)=>{
            return curEle.eStatus=='y'
        })
        NewGroupUserHtml(filterActiveNewData);
    } else {
        $("#NewGroupUserList").html("");
    }
})

$(document).on("change", ".NewGroupUserChbx", (e) => {
    const iUserId = e.target.value;
    const vNewGrpUserSelect = $("#vNewGrpUserSelect").val();
    const UserSelectListArr = vNewGrpUserSelect != "" ? String(vNewGrpUserSelect).split(",") : [];

    if (e.target.checked) {
        UserSelectListArr.push(iUserId);
        $("#vNewGrpUserSelect").val(UserSelectListArr.join(","));

        // if (UserSelectListArr.length > 0) {
        //     $("#vCreateNewGroupNext").removeClass("d-none");
        // } else {
        //     $("#vCreateNewGroupNext").addClass("d-none");
        // }
    } else {
        const filterNewData = UserSelectListArr.filter((curEle, index) => {
            return Number(curEle) != Number(iUserId)
        })

        $("#vNewGrpUserSelect").val(filterNewData.join(","));

        // if (filterNewData.length > 0) {
        //     $("#vCreateNewGroupNext").removeClass("d-none");
        // } else {
        //     $("#vCreateNewGroupNext").addClass("d-none");
        // }
    }
})

$(document).on("click", "#CloseNewGroupUserModal", () => {
    $("#vNewGrpUserSelect").val("");
})

//New Group Create Sidebar Code Start

$(document).on("click", "#vCreateNewGroupNext", () => {
    $("#vNewGroupOwnName").text($("#vUserName").text());
    $("#vNewGrpOwnImg").attr("xlink:href", $("#vProfilePick").attr("xlink:href"));
    // $("#vUserLoggedSts").text();

    getListMemberSelect();

    $("#vGroupName").val("");
    $("#tDescription").val("");

    $("#vGroupName").closest("div").removeClass("error-cust");

    const randNumber = getRandomInt(9);

    if(finalProfilePick!=""){
        $("#vGroupPicSelected").attr("src",finalProfilePick);
    }else{
        finalColorSelection = randNumber
    
        const filterColorOption = GroupColorOption.filter((curEle2, index) => {
            return curEle2.iColorId == randNumber
        })
    
        if (filterColorOption.length > 0) {
            $("#vGroupPicSelected").attr("src", filterColorOption[0]['vColorPick']);
        }
    }
})

function getListMemberSelect() {
    const vNewGrpUserSelect = $("#vNewGrpUserSelect").val();
    const UserSelectListArr = vNewGrpUserSelect != "" ? String(vNewGrpUserSelect).split(",") : [];

    const getAllUsers = $("#vChatUserListJson").val();
    const getAllUsersList = getAllUsers != "" ? JSON.parse(getAllUsers) : [];

    let htmlUser = "";

    getAllUsersList.map((curEle, index) => {
        if (UserSelectListArr.includes("" + curEle.iUserId)) {
            let profileImage = curEle.vProfilePic;
            if (profileImage == "") {
                colorOption.map((curEle2, index) => {
                    if (curEle2.iColorId == curEle.iColorOption) {
                        profileImage = curEle2.vColorPick;
                    }
                })
            }

            htmlUser += `<li id="delGroupNewMemb_${curEle.iUserId}">
                            <a class="cursor-pointer chat-list">
                                <label class="d-flex align-items-center justify-content-between form-check ps-0"
                                    for="flexCheckDefaultMemb${curEle.iUserId}">
                                    <div class="d-flex align-items-center">
                                        <div class="user-profile-image me-3">
                                            <svg role="none" viewBox="0 0 96 96">
                                                <mask id="profile-image-${curEle.iUserId}">
                                                    <circle fill="white" cx="48" cy="48" r="48">
                                                    </circle>
                                                    <circle fill="black" cx="86%" cy="86%" r="18">
                                                    </circle>
                                                </mask>
                                                <g mask="url(#profile-image-${curEle.iUserId})">
                                                    <image x="0" y="0" height="100%"
                                                        preserveAspectRatio="xMidYMid slice" width="100%"
                                                        xlink:href="${profileImage}">
                                                    </image>
                                                </g>
                                            </svg>
                                            <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                        </div>
                                        <div>
                                            <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                            <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                        </div>
                                    </div>
                        
                                    <span><input class="form-check-input form-check-cross delGroupNewMemb" type="checkbox"
                                            value="${curEle.iUserId}" id="flexCheckDefaultMemb${curEle.iUserId}"></span>
                                </label>
                            </a>
                        </li>`;
        }
    })

    $("#newGroupMember").html(htmlUser);
    $("#vGroupUserErr").addClass("d-none");
}

//Delete Member New Group Create Code Start
let isDeleteNewGrpMember=0;
let filterNewDataDelGroupMemb=[];
$(document).on("click", ".delGroupNewMemb", (e) => {
    const iUserId = Number(e.target.value);

    if (iUserId > 0) {
        const vNewGrpUserSelect = $("#vNewGrpUserSelect").val();
        const UserSelectListArr = vNewGrpUserSelect != "" ? String(vNewGrpUserSelect).split(",") : [];

        const filterNewData = UserSelectListArr.filter((curEle, index) => {
            return Number(curEle) != Number(iUserId)
        })

        isDeleteNewGrpMember=iUserId;
        filterNewDataDelGroupMemb=filterNewData;

        $("#newGroupMembDeleteConf").modal("toggle");

        // if (filterNewData.length == 0) {
        //     $("#groupMemberModal").modal("toggle");
        //     // alert("Atleast one memeber required for group.");
        //     e.preventDefault();
        // } else {
        // }
    }
})

$(document).on("click","#newGroupMembDeleteConfSubmit",()=>{
    $("#delGroupNewMemb_" + isDeleteNewGrpMember).remove();
    $("#NewGroupUserChbx_" + isDeleteNewGrpMember).prop("checked", false)
    $("#vNewGrpUserSelect").val(filterNewDataDelGroupMemb.join(","));
    $("#newGroupMembDeleteConf").modal("toggle");
})

$(document).on("click","#newGroupMembDeleteConfCancel,#newGroupMembDeleteConfClose",()=>{
    $("#newGroupMembDeleteConf").modal("toggle");
    $(".delGroupNewMemb").prop("checked",false);
})
//Delete Member New Group Create Code End

$(document).on("click", "#groupMemberModalSubmit,#groupMemberModalClose", () => {
    $("#groupMemberModal").modal("toggle");
})

$(document).on("input", "#tDescription", (e) => {
    const StringLength = String(e.target.value).length;

    if (StringLength <= 350) {
        $("#totalCharDispCrtGrp").text(StringLength + "/350");
    }
})

$(document).on("click", "#AddNewGroup", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    const vGroupName = $("#vGroupName").val();
    const tDescription = $("#tDescription").val();
    
    let vNewGrpUserSelect = $("#vNewGrpUserSelect").val();
    const vNewGrpUserSelectArr=vNewGrpUserSelect!=""?String(vNewGrpUserSelect).split(","):[]
    let uniqueUsers = vNewGrpUserSelectArr.filter((value, index, arr) => index === arr.indexOf(""+value));
    const vUsers=uniqueUsers.length>0?uniqueUsers.toString():"";

    if (isLocalStorageExist != null && vGroupName != "") {
        if(activeTab == "User"){
            activeTab="Group";
            $("#userGroup").click();
        }
        
        const dd = JSON.parse(isLocalStorageExist);
        $("#vGroupName").closest("div").addClass("error-cust");
        $("#vGroupUserErr").addClass("d-none");

        const vGroupProfilePick = [{ fileName: tempFilename, imageData: finalProfilePick }];

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'AddNewGrp',
            data: {
                tToken: dd.tToken,
                vGroupName,
                tDescription,
                vUsers,
                iUpdateBasic:0,
                deleteMemeberStr:"",
                vActiveGroupId: 0,
                vGroupProfile: vGroupProfilePick,
                ColorOptionSelect: finalColorSelection,
                isDeleteFile: 0,
                cancelRequest:""
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    $("#vGroupName").val("");
                    $("#tDescription").val("");
                    $("#vNewGrpUserSelect").val("");

                    $(".add-user-popup").removeClass("active");
                    $(".add-group-popup").removeClass("active");
                    $(".create-group-popup").removeClass("active");

                    getGroupList();

                    if(vUsers!=""){
                        const vUserListArr=vUsers!=""?String(vUsers).split(","):[];

                        vUserListArr.map((curEle,index)=>{
                            socket.emit('GroupNewMembRefresh',{
                                vUsers:curEle
                            });
                        })
                    }

                    $(".vGroupIds").each((e, item) => {
                        const getRowId = $(item).attr("data-id");
                        if (getRowId == data.id) {
                            let newMemberJoinReq=[];

                            let newMemberName="";
                            const newMemberArr=String(vUsers).split(",");
                            const vChatUserListJson = $("#vChatUserListJson").val();
                            if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                                const dataUserList=JSON.parse(vChatUserListJson);

                                newMemberArr.map((curEle,index)=>{
                                    const dataUserListFilter=dataUserList.filter((curEle2,index2)=>{
                                        return curEle2.iUserId==curEle
                                    })
                                    if(dataUserListFilter.length){
                                        if(index==0){
                                            newMemberName=dataUserListFilter[0]['vFullName'];
                                        }else if(newMemberArr.length==Number(index)+1){
                                            newMemberName+=" and "+dataUserListFilter[0]['vFullName'];
                                        }else{
                                            newMemberName+=", "+dataUserListFilter[0]['vFullName'];
                                        }

                                        newMemberJoinReq.push({iUserId:curEle,vFullName:dataUserListFilter[0]['vFullName']});
                                    }
                                })
                            }

                            const vUserName=$("#vUserName").text();

                            let encodedHtmlString = htmlEncode("Greetings!&nbsp;New&nbsp;group&nbsp;is&nbsp;created.&nbsp;<br>"+vUserName+"&nbsp;(group&nbsp;admin)&nbsp;added&nbsp;"+newMemberName+".");
                            if(String(newMemberName).trim()==""){
                                encodedHtmlString = htmlEncode("Greetings!&nbsp;New&nbsp;group&nbsp;is&nbsp;created.");
                            }

                            const finalMsg = JSON.parse(JSON.stringify(encodedHtmlString));

                            socket.emit('send_grp_message', {
                                receiverChatID: data.id,
                                senderChatID: dd['iLoginId'],
                                content: finalMsg,
                                ImageDataArr: [],
                                vReplyFileName: "",
                                vReplyMsg: "text",
                                vReplyMsg_id: "",
                                id: dd['iLoginId'] + "_" + data.id + "_" + Date.parse(new Date()),
                                isGreetingMsg: 1,
                                vMembersList:vUsers,
                                vGroupMessageType:"",
                                isForwardMsg:0,
                                isDeleteprofile:0,
                                iRequestMsg:0,
                                vDeleteMemberId:"",
                                vNewAdminId:"",
                                RequestMemberId:""
                            });

                            if(vUsers==""){
                                $(item).click();
                                getGroupList(); 
                            }

                            setTimeout(() => {
                                if(newMemberJoinReq.length){
                                    async function processArrayWithDelay(array, callback, delayTime) {
                                                    
                                        for (let i = 0; i < array.length; i++) {
                                            //Logic Code
                                            const curEle = array[i];
                                            
                                            const message = "You have sent a group chat request to " + curEle.vFullName + ".";
                                            var encodedHtmlString2 = htmlEncode(message);
                                            const finalMsg2 = JSON.parse(JSON.stringify(encodedHtmlString2));
                                            const MsgId = dd['iLoginId'] + "_" + data.id + "_" + Date.parse(new Date());
                                    
                                            socket.emit('send_grp_message', {
                                                receiverChatID: data.id,
                                                senderChatID: dd['iLoginId'],
                                                content: finalMsg2,
                                                ImageDataArr: [],
                                                vReplyFileName: "",
                                                vReplyMsg: "text",
                                                vReplyMsg_id: "",
                                                id: MsgId,
                                                isGreetingMsg: 0,
                                                vMembersList: curEle.iUserId,
                                                vGroupMessageType: "",
                                                isForwardMsg: 0,
                                                isDeleteprofile: 0,
                                                iRequestMsg: 1,
                                                vDeleteMemberId:"",
                                                vNewAdminId:"",
                                                RequestMemberId:curEle.iUserId
                                            });
            
                                            await delayTimeWait(delayTime);
            
                                            setTimeout(callback, 500);
                                        }
                                    }
                                    
                                    async function processItem(item) {
                                        await delayTimeWait(500);
                                        return item * 1;
                                    }
                                    
                                    processArrayWithDelay(newMemberJoinReq, processItem, 500)
                                    .then(results => {
                                        console.log('All Message sent');
                                        $(item).click();
                                        getGroupList();
                                    });
                                }
                            }, 1000);
                        }
                    })


                    tempFilename = "";
                    finalProfilePick = "";
                    finalColorSelection = "";
                }else if(data.status == 412){
                    $("#vMessgErr").attr("data-error","Duplicate Group Name.")
                }
            }
        });
    } else {
        if (vGroupName == "") {
            $("#vGroupName").closest("div").addClass("error-cust");
        }
    }
})

//New Group Create Sidebar Code End

//User Chat Code Start
$(document).on("click", ".vUserIdsCls", (e) => {
    timeLineDate = "";
    filterDateStr = "";

    $("#vCancelRequest").closest("li").addClass("d-none");
    $("#vUserDeleteChat").removeClass("disabled");

    $("#dispSearchBox").removeClass("show");
    $("#dispSearchBox").addClass("hide");

    $("#vCancelSearch").removeClass("show");
    $("#vCancelSearch").addClass("hide");

    $(".vGroupIds").removeClass("chat-active");

    $("#vSearchNextBtn").removeClass("show");
    $("#vSearchNextBtn").addClass("hide");

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");
    $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
    $(".message-text").closest(".chat-message").removeClass("edit-message-active");
    $(".floating-dd").removeClass("d-none");
    $(".editor-close").addClass("d-none");

    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");

    $(".vUserIdsCls").removeClass("chat-active");
    $(e.currentTarget).addClass("chat-active");
    $("#MessageList").html("");
    $("#vSearchText").val("");
    $(".plc-holder").removeClass("d-none");
    $("#vMessage").html("");
    $(".typing-preview").addClass("d-none");

    updateJson();

    MessageTypingSocket("")

    $("#StartChatArea").addClass("d-none");
    $("#HeaderChatArea").removeClass("d-none");
    $("#MainChatArea").removeClass("d-none");
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

    // console.log("check 4 ==>")
    iEditMsgId = "";
    vEditMsgText = "";
    vEditMsgType = "";
    vEditMessageMainId = "";

    $("#fileUploadDiv").removeClass("show");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");
    ImageDataArr = [];

    const iUserId = $(e.currentTarget).data('id');
    const UserStatus = $(e.currentTarget).data('status') == 1 ? 'Online' : 'Offline';

    // activeChatProfile
    let whatsAppCloneData = localStorage.getItem("whatsAppClone");
    if (whatsAppCloneData != null) {
        whatsAppCloneData = JSON.parse(whatsAppCloneData);
        whatsAppCloneData['pageType'] = "user";
        whatsAppCloneData['pageTypeId'] = iUserId;
        localStorage.setItem("whatsAppClone", JSON.stringify(whatsAppCloneData));
    }

    const vConvertionChatArr = $("#vConvertionChatArr").val();
    const UserList = JSON.parse(vConvertionChatArr);

    UserList.map((curEle, index) => {
        if (curEle.iUserId == iUserId) {
            if (curEle.vProfilePic != "") {
                $("#activeChatProfile").attr("xlink:href", curEle.vProfilePic)
            } else {
                colorOption.map((curEle2, index) => {
                    if (curEle2.iColorId == curEle.iColorOption) {
                        $("#activeChatProfile").attr("xlink:href", curEle2.vColorPick)
                    }
                })
            }

            $("#vActiveUserId").val(iUserId);
            $("#vActiveGroupId").val('');

            if (filterDateStr == "") {
                if (curEle?.lastDate && curEle?.lastDate != "") {
                    filterDateStr = curEle.lastDate;
                }
            }

            $("#vUserIdsCls_" + iUserId).removeClass("unread-chat");
            if (UserStatus == "Online") {
                $("#activeChatSts").removeClass("offline");
                $("#activeChatSts").addClass("online");
            } else {
                $("#activeChatSts").removeClass("online");
                $("#activeChatSts").addClass("offline");
            }
            $("#activeChatName").text(curEle.vFullName);
            $("#activeChatStsDisp").text(UserStatus);

            if(curEle.isStartChat==1){
                $("#vRequestChatDiv").addClass("d-none");
                $("#TextEditorArea").removeClass("d-none");
                $("#texAreaEditorDiv").removeClass("d-none");
            }else{
                $("#vRequestChatDiv").removeClass("d-none");
                $("#TextEditorArea").addClass("d-none");
                $("#texAreaEditorDiv").addClass("d-none");
            }

            getMessageFunc(curEle.iUserId, filterDateStr);
        }
    })
})

//Group Chat Message Start
$(document).on("click", ".vGroupIds", (e) => {
    $(".vGroupIds").removeClass("chat-active");
    $(".vUserIdsCls").removeClass("chat-active");
    $(e.currentTarget).addClass("chat-active");
    $(e.currentTarget).removeClass("unread-chat");

    $("#texAreaEditorDiv").removeClass("d-none");
    $("#TextEditorArea").removeClass("d-none");

    $("#dispSearchBox").addClass("hide");
    $("#dispSearchBox").removeClass("show");

    $("#vCancelSearch").addClass("hide");
    $("#vCancelSearch").removeClass("show");

    $("#vSearchNextBtn").removeClass("show");
    $("#vSearchNextBtn").addClass("hide");

    $(".typing-preview").addClass("d-none");

    $("#vRequestChatDiv").addClass("d-none");

    $("#vCancelRequest").closest("li").addClass("d-none");
    $("#vUserDeleteChat").removeClass("disabled");

    timeLineDate = "";
    filterDateStr = "";

    MessageTypingSocket("");

    // console.log("check 5 ==>")
    iEditMsgId = "";
    vEditMsgText = "";
    vEditMsgType = "";
    vEditMessageMainId = "";

    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");

    $("#fileUploadDiv").removeClass("show");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");
    ImageDataArr = [];

    $(".plc-holder").removeClass("d-none");
    $("#vMessage").html("");

    $("#vGroupTabActive").removeClass("d-none");
    $("#vUseTabActive").addClass("d-none");
    $("#vSearchText").val("");

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");

    $("#StartChatArea").addClass("d-none");
    $("#HeaderChatArea").removeClass("d-none");
    $("#MainChatArea").removeClass("d-none");
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

    const iGroupId = $(e.currentTarget).data('id');

    let whatsAppCloneData = localStorage.getItem("whatsAppClone");
    if (whatsAppCloneData != null) {
        whatsAppCloneData = JSON.parse(whatsAppCloneData);
        whatsAppCloneData['pageType'] = "group";
        whatsAppCloneData['pageTypeId'] = iGroupId;
        localStorage.setItem("whatsAppClone", JSON.stringify(whatsAppCloneData));
    }

    const vChatGroupListJson = $("#vChatGroupListJson").val();
    const GroupList = JSON.parse(vChatGroupListJson);
    $("#MessageList").html("");

    $("#vReplyMsg").val("");
    $("#vReplyMsg_id").val("");
    $("#vReplyMsg_type").val("");
    $("#vReplyFileName").val("");

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        GroupList.map((curEle, index) => {
            if (curEle.iGroupId == iGroupId) {
                const totalMember = String(curEle.tGroupUsers).split(",");
                $("#activeChatName").text(curEle.vGroupName);

                // $("#activeChatUsrDetail").html(curEle.vGroupName + "<br><span id='mainUserStats'>Online</span><span class='typingIndicator d-none' id='typingIndicator'>Typing...</span>");
                const filterColorOption = GroupColorOption.filter((curEle2, index) => {
                    return curEle2.iColorId == curEle.iColorOption
                })

                if (curEle.vGroupImage != "") {
                    $("#activeGroupProfile").attr("src", curEle.vGroupImage)
                } else {
                    $("#activeGroupProfile").attr("src", filterColorOption[0]['vColorPick'])
                }

                $("#activeGroupProfile").removeClass("rounded-circle");
                $("#activeGroupProfile").addClass("rounded-2");

                const totlMemeberCnt=curEle.tGroupUsers==""?0:Number(totalMember.length)
                $("#activeChatStsDisp").text(Number(totlMemeberCnt)+1 + " Members");

                $("#vActiveGroupId").val(iGroupId);
                $("#vActiveUserId").val("");

                socket.emit('join_group', {
                    iGroupId
                });

                if (filterDateStr == "") {
                    if (curEle?.lastDate && curEle?.lastDate != "") {
                        filterDateStr = curEle.lastDate;
                    }
                }

                GetGroupMessage(dd, iGroupId, filterDateStr, 0);

                if(!totalMember.includes(""+dd.iLoginId) && curEle.iCreatedBy!=dd.iLoginId){
                    $("#TextEditorArea").addClass("d-none");
                }else{
                    $("#TextEditorArea").removeClass("d-none");
                }
            }
        })
    }
})


const dateTimeLineAdd = (created_at = "", isSecond = 0) => {
    if (created_at == "") {
        timeLineDate = getCurrentDate();

        // console.log("timeLineDate=>",timeLineDate)

        const NewId = dateDispl(timeLineDate).replaceAll(" ", "_");

        let htmlDate = `<div class="chat-time-line" id="${NewId}">
                            <p>${dateDispl(timeLineDate)}</p>
                        </div>`;
        if (isSecond) {
            $("#MessageList").prepend(htmlDate);
        } else {
            $("#MessageList").append(htmlDate);
        }

    } else {
        if (timeLineDate != String(created_at).split(" ")[0]) {
            timeLineDate = String(created_at).split(" ")[0];
            const NewId = dateDispl(timeLineDate).replaceAll(" ", "_");

            let htmlDate = `<div class="chat-time-line" id="${NewId}">
                                <p>${timeLineDate == getCurrentDate() ? "Today" : dateDispl(timeLineDate)}</p>
                            </div>`;

            if (isSecond) {
                $("#MessageList").prepend(htmlDate);
            } else {
                $("#MessageList").append(htmlDate);
            }
        }
    }
}

const replyHtmlFunc = (vReplyMsg_id, vReplyMsg, vReplyFileName = "", isSend = 0) => {
    let replyHtml = "";
    const vActiveUserId=$("#vActiveUserId").val();
    const vReplyMsgId=String(vReplyMsg_id).split("_");
    let replayUserName="You";
    const vChatUserListJson = $("#vChatUserListJson").val();

    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
        JSON.parse(vChatUserListJson).map((curEle, index) => {
            if(curEle.iUserId==vReplyMsgId[0]){
                replayUserName=curEle['vFullName'];
            }
        })
    }

    if (((vReplyMsg_id && vReplyMsg_id != "") || isSend) && vReplyMsg != "") {

        const newTimeDate=vReplyMsgId[2];

        if (String(vReplyMsg).includes("base64,") || String(vReplyMsg).includes("vImages =>") || String(vReplyMsg).includes("images/uploads")) {
            if (String(vReplyMsg).includes("base64,")) {

                let imagePath = String(vReplyMsg).trim();
                if (String(vReplyMsg).includes("vImages =>")) {
                    imagePath = String(vReplyMsg).split("vImages =>");
                } else if (String(vReplyMsg).includes("images/uploads")) {
                    imagePath = vReplyMsg;
                }

                imagePath = typeof imagePath == "string" ? imagePath : String(imagePath[1]).trim();

                const dotIndex = vReplyFileName.lastIndexOf('.');
                const type = vReplyFileName.substring(dotIndex + 1);

                const imageArr = ["jpg", "png", "jpeg"];

                const fileName = String(vReplyFileName).split(".");

                
                // ${timestampToAMPM(""+vReplyMsgId[3])}

                if (imageArr.includes("" + type)) {
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">${replayUserName} <span>${dateDispl(new Date(Number(newTimeDate)))} ${timestampToAMPM(Number(newTimeDate))}</span></p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-image-preview">
                                            <img src="${imagePath}" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileName[0]).substring(0, 50)}${fileName[0].length > 100 ? '...' : '' + "." + fileName[1]}</p>
                                    </div>
                                </div>`
                } else {
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">${replayUserName} <span>${dateDispl(new Date(Number(newTimeDate)))} ${timestampToAMPM(Number(newTimeDate))}</span></p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-file-preview">
                                            <img src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileName[0]).substring(0, 50)}${fileName[0].length > 100 ? '...' : '' + "." + fileName[1]}</p>
                                    </div>
                                </div>`;
                }

                // replyHtml =`<div class="message-reply-chat">
                //                 <p class="mb-0 name">You</p>
                //                 <div class="d-flex align-items-center">
                //                     <div class="message-image-preview">
                //                         <!-- For Nothing - message-preview -->
                //                         <!-- For Image - message-image-preview -->
                //                         <!-- For File - message-file-preview -->
                //                         <img src="${imagePath}" alt="File">
                //                     </div>
                //                     <p class="mb-0 message">Master_image_preview_updated.png</p>
                //                 </div>
                //             </div>`;
            } else {
                let imagePath = "";
                if (String(vReplyMsg).includes("vImages =>")) {
                    imagePath = String(vReplyMsg).split("vImages =>");
                } else if (String(vReplyMsg).includes("images/uploads")) {
                    imagePath = vReplyMsg;
                }

                imagePath = typeof imagePath == "string" ? imagePath : imagePath[1];

                const dotIndex = imagePath.lastIndexOf('.');
                const type = imagePath.substring(dotIndex + 1);

                const imageArr = ["jpg", "png", "jpeg"];

                const fileName = getFileName(String(imagePath).trim());

                const fileNameNew = String(fileName).split(".");

                if (imageArr.includes("" + type)) {
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">${replayUserName} <span>${dateDispl(new Date(Number(newTimeDate)))} ${timestampToAMPM(Number(newTimeDate))}</span></p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-image-preview">
                                            <img src="${API_URL + String(imagePath).trim()}" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileNameNew[0]).substring(0, 50)}${fileNameNew[0].length > 100 ? '...' : '' + "." + fileNameNew[1]}</p>
                                    </div>
                                </div>`
                } else {
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">${replayUserName} <span>${dateDispl(new Date(Number(newTimeDate)))} ${timestampToAMPM(Number(newTimeDate))}</span></p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-file-preview">
                                            <img src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileNameNew[0]).substring(0, 50)}${fileNameNew[0].length > 100 ? '...' : '' + "." + fileNameNew[1]}</p>
                                    </div>
                                </div>`;
                }
            }
        } else {
            replyHtml = `<div class="message-reply-chat">
                            <p class="mb-0 name">${replayUserName} <span>${dateDispl(new Date(Number(newTimeDate)))} ${timestampToAMPM(Number(newTimeDate))}</span></p>
                            <div class="d-flex align-items-center">
                                <p class="mb-0 message msg-with-emoji-reply">${htmlToPlainText(htmlDecode(vReplyMsg))}</p>
                            </div>
                        </div>`
        }
    }

    return replyHtml;
}

function stripHtmlTags(htmlString) {
    return htmlString.replace(/<\/?[^>]+(>|$)/g, "");
}

const StringDisplLimit = (str, limit) => {
    if (String(str).length > limit) {
        return String(str).substring(0, limit) + "..."
    } else {
        return String(str).trim()
    }
}

const ImageOrFileDipHtml = (filePath, base64Name = "", thumbnail) => {
    let imageHtml = "";

    if (base64Name != "") {
        const trimPath = String(base64Name).trim();
        const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

        const fileNameNew = String(trimPath).split(".");

        if (ImageExtensionArr.includes(get_url_extension(trimPath))) {
            imageHtml = `<div class="d-flex align-items-center">
                            <div class="message-image-preview">
                                <img src="${filePath}" alt="File">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0], 50) + '.' + fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="${filePath}" target="_blank" class="file-action-btn"><i data-feather="eye" class="feather-20"></i></a>
                            </li>
                            <li>
                                <a class="cursor-pointer file-action-btn vFileDownload" data-id="${filePath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        } else {
            imageHtml = `<div class="d-flex align-items-center">
                            <div class="message-file-preview">
                                <img src="./images/svgs/file.svg" alt="File">
                            </div>
                            <p class="mb-0"><p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0], 50) + '.' + fileNameNew[1]}</p>
                            </p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a class="cursor-pointer file-action-btn vFileDownload" data-id="${filePath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        }

    } else {
        const trimPath = String(filePath).trim();

        const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

        const fileNameNew = String(getFileName(trimPath)).split(".");

        const displImage = thumbnail == "" ? trimPath : thumbnail

        if (ImageExtensionArr.includes(get_url_extension(trimPath))) {
            imageHtml = `<div class="d-flex align-items-center">
                            <div class="message-image-preview">
                                <img src="${API_URL + String(displImage).trim()}" alt="File" onerror="this.onerror=null; this.src='./images/imagethumb2.png'">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0], 50) + '.' + fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="${API_URL + trimPath}" target="_blank" class="file-action-btn"><i data-feather="eye" class="feather-20"></i></a>
                            </li>
                            <li>
                                <a class="cursor-pointer file-action-btn vFileDownload" data-id="${API_URL + trimPath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        } else {
            imageHtml = `<div class="d-flex align-items-center">
                            <div class="message-file-preview">
                                <img src="./images/svgs/file.svg" alt="File">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0], 50) + '.' + fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a class="cursor-pointer file-action-btn vFileDownload" data-id="${API_URL + trimPath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        }
    }


    return imageHtml;
}

const floatingDrop = (id, msg, type, dateTime, isSend, fileName = "") => {
    let deleteButton = '';
    let editButton = '';
    let vActiveGroupId=$("#vActiveGroupId").val();
    let isAdmin=0;
    let iLogginId=0;
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLogginId=dd.iLoginId;
    }
    
    let isMember=0;
    const vChatGroupListJson = $("#vChatGroupListJson").val();
    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
        JSON.parse(vChatGroupListJson).map((curEle,index)=>{
            if(curEle.iGroupId==vActiveGroupId && curEle.iCreatedBy==iLogginId){
                isAdmin=1;
            }

            if(curEle.iGroupId==vActiveGroupId){
                const tGroupIds=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(","):[]

                if(tGroupIds.includes(""+iLogginId)){
                    isMember=1;
                }else{
                    isMember=0;
                }
            }
        })
    }

    if(vActiveGroupId=="" || vActiveGroupId==0){
        isMember=1;
    }

    if((isSend==1 && isMember) || isAdmin==1){
        deleteButton = `<li>
                        <a class="dropdown-item deleteMsgSingle cursor-pointer" data-id='${id}' data-msg='${msg}' data-type="${type}" data-time="${dateTime}"><i data-feather="trash-2" class="feather-20 delete"></i> Delete</a>
                    </li>`;
    }

    if (isSend == 1 && (isMember || isAdmin==1)) {
        if (type == "text") {
            editButton = `<li>
                            <a class="dropdown-item EditMessage cursor-pointer" data-id='${id}' data-msg='${msg}' data-type="${type}" data-filename="${fileName}" data-time="${dateTime}"><i data-feather="edit-3" class="feather-20"></i>
                                Edit</a>
                        </li>`;
        }
    }

    let replyBtn=`<li>
                    <a class="dropdown-item replyIcon cursor-pointer" data-id='${id}' data-msg='${msg}' data-type="${type}" data-filename="${fileName}" data-time="${dateTime}"><i data-feather="corner-up-left" class="feather-20"></i> Reply</a>
                </li>`;
    if(isMember==0 && isAdmin==0){
        replyBtn="";
    }

    return `<div class="floating-dd">
                <div class="dropdown dropup">
                    <div class="dropdown-btn" data-bs-toggle="dropdown" class="cursor-pointer">
                        <span>
                            <i data-feather="more-vertical" class="feather-20"></i>
                        </span>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item selectMultiple cursor-pointer" data-id='${id}' data-msg='${msg}' data-type="${type}" data-time="${dateTime}" data-from="${isSend}"><i data-feather="check-circle" class="feather-20"></i>
                                Select</a>
                        </li>
                        <li>
                            <div class="dropdown-line"></div>
                        </li>
                        ${editButton}
                        ${replyBtn}
                        <li>
                            <a class="dropdown-item forwardIcon cursor-pointer" data-bs-toggle="modal" data-bs-target="#forwardModal" data-id='${id}' data-msg='${msg}' data-type="${type}" data-time="${dateTime}"><i data-feather="corner-up-right" class="feather-20"></i> Forward</a>
                        </li>
                        ${deleteButton}
                    </ul>
                </div>
            </div>`;
}

const deleteMessageHtml = (mesgDate, isSend,isDivExist,isAdmin) => {
    let htmlInside=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/delete-message.svg" class="chat-message-profile"
                                alt="chat-message-profile">
                            <div class="main-message message-deleted">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">Message deleted by ${isAdmin==1?'group admin':'its author'}.</p>
                                    <p class="message-drop-time">${timestampToAMPM(mesgDate)}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;

    return isDivExist==1?htmlInside:`<div class="chat-message-outer-container recieve-message unread message-deleted">
                ${htmlInside}
            </div>`
}

const DeleteMeberGroupMsgHtml = (mesgDate,iUserId,isAdmin=0,iSenderId,isDeleteProfile=0) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    let vProfileName="";
    let iLoginId=0;
    let iAdminId=0;
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLoginId=dd.iLoginId;
    }

    const vActiveGroupId=$("#vActiveGroupId").val();
    const vChatGroupListJson = $("#vChatGroupListJson").val();
    const filterGroupDetail=JSON.parse(vChatGroupListJson).filter((curEle,index)=>{
        return curEle.iGroupId==vActiveGroupId;
    });

    if(filterGroupDetail.length>0){
        iAdminId=filterGroupDetail[0]['iCreatedBy'];
    }
    
    let adminName="";
    let memberStatus=1;
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(iUserId==curEle.iUserId){
                vProfileName=curEle?.vFullName;
                if(curEle.eStatus=="d"){
                    memberStatus=0;
                }
            }
            if(iAdminId==curEle.iUserId){
                adminName=curEle?.vFullName;
            }
        })
    }

    let iconDynamic='user-remove';
    let msg=isAdmin==1?`You have removed ${vProfileName}.`:iUserId==iLoginId?`${adminName} (group admin) removed you.`:`${adminName} (group admin) removed ${vProfileName}.`;
    if(iSenderId==iUserId && iLoginId==iUserId){
        msg=`You can't send messages to this group because you're no longer a member.`;
    }else if(iSenderId==iUserId){
        if(isDeleteProfile==1){
            msg=vProfileName+` is no longer a member of the spot chat.`;
        }else{
            msg=vProfileName+` is left.`;
            iconDynamic="user-minus-danger";
        }
    }

    return `<div class="chat-message-outer-container recieve-message unread message-create-group">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/${iconDynamic}.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${msg}</p>
                                    <p class="message-drop-time">${mesgDate}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}

const AddNewMemberGroupMsgHtml =(msg,mesgDate)=>{
    return `<div class="chat-message-outer-container recieve-message unread message-create-group">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/user-add.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${msg}</p>
                                    <p class="message-drop-time">${timestampToAMPM(mesgDate)}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}


const getMessageFunc = (iUserId, filterDateStrVar = "", isSecond = 0) => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        socket.emit('messageReadUpdate', {
            iFromUserId: dd.iLoginId,
            iToUserId: iUserId
        });

        const activeChatName = $("#activeChatName").text();
        const vProfilePick = $("#vProfilePick").attr("xlink:href");
        const activeChatProfile = $("#activeChatProfile").attr("xlink:href");
        $("#vGroupTabActive").addClass("d-none");
        $("#vUseTabActive").removeClass("d-none");

        const vChatUserListJson = $("#vChatUserListJson").val();
        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
            JSON.parse(vChatUserListJson).map((curEle, index) => {
                if(curEle.iUserId==iUserId && curEle.eStatus=="d"){
                    $("#vRequestChatDiv").addClass("d-none");
                    $("#TextEditorArea").addClass("d-none");
                }
            })
        }

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetMessage',
            data: {
                tToken: dd.tToken,
                iUserId: iUserId,
                filterDateStr: filterDateStrVar == "" ? iUserId + "_" + oneMonthBackDate("") + ".json" : filterDateStrVar
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {

                    filterDateStr = data.dLastDate;

                    if (data.userStatus == 1) {
                        $("#activeChatSts").removeClass("offline");
                        $("#activeChatSts").addClass("online");
                    } else {
                        $("#activeChatSts").removeClass("online");
                        $("#activeChatSts").addClass("offline");
                    }

                    $("#activeChatStsDisp").text(data.userStatus == 1 ? 'Online' : 'Offline');

                    // const filterCheckChatStart = JSON.parse(data.data).filter((curEle, index) => {
                    //     return curEle.iRequestMsg == undefined || curEle.iRequestMsg == 0
                    // })

                    // const filterCheckPending = JSON.parse(data.data).filter((curEle, index) => {
                    //     return curEle.iRequestMsg == 1
                    // })
                    
                    const lastData = JSON.parse(data.data).length ? JSON.parse(data.data) : [];
                    const vActiveUserId = $("#vActiveUserId").text();

                    JSON.parse(data.data).map((curEle2, index) => {
                        // console.log("curEle2",curEle2)

                        if(curEle2.iRequestMsg>0){
                            const dataTime = timestampToAMPM(curEle2.created_at);

                            const vUserName = $("#vUserName").text();
                            const vUserNameText = $("#activeChatName").text();

                            if (curEle2.iFromUserId == dd.iLoginId) {
                                if (curEle2.iRequestMsg == 1) {
                                    const html = chatRequestSendHtml(dataTime, vUserNameText,curEle2.id);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                } else {
                                    const html = curEle2.iRequestMsg == 2 ? chatRequestAcceptHtml(dataTime, vUserNameText, 1,0) : curEle2.iRequestMsg == 3 ? chatRequestDeclineHtml(dataTime, vUserNameText,1,0) : curEle2.iRequestMsg == 4 ? chatRequestCancelledHtml(dataTime, vUserNameText,1,0) : curEle2.iRequestMsg == 5 ? chatDeleteConnectHtml(dataTime, vUserNameText,0) : chatRequesHtml(curEle2, 1);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                }
                            } else {
                                if (curEle2.iRequestMsg == 1) {
                                    const html = chatRequesHtml(curEle2, 0);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                } else {
                                    const html = curEle2.iRequestMsg == 2 ? chatRequestAcceptHtml(dataTime, vUserNameText, 0 ,0) : curEle2.iRequestMsg == 3 ? chatRequestDeclineHtml(dataTime, vUserNameText,0,0) : curEle2.iRequestMsg == 4 ? chatRequestCancelledHtml(dataTime, vUserNameText,0,0) : curEle2.iRequestMsg == 5 ? chatDeleteConnectHtml(dataTime, vUserNameText,0) : chatRequesHtml(curEle2, 1);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                }
                            }
                        }else{
                            const vUserNameText = $("#activeChatName").text();

                            let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2?.vReplyMsg, curEle2?.vReplyFileName);

                            // console.log("curEle2",curEle2.id)
                            if (curEle2.iToUserId == dd.iLoginId) {
                                if(curEle2.iRequestMsg==0){
                                    if (curEle2.message.includes('vImages =>')) {
    
                                        let removePrefix = curEle2.message;
                                        const myImageStr = removePrefix.split("vImages =>");
                                        if (myImageStr.length > 0) {
                                            const myImageArr = myImageStr[1].split(",");
                                            if (myImageArr.length > 0) {
                                                myImageArr.map((curEle, index) => {
                                                    const trimPath = String(curEle).trim();
                                                    const trimThumbPath = String(curEle2.vImageThumb).split("=>");
                                                    let isThumnail = "";
                                                    if (trimThumbPath.length > 1) {
                                                        isThumnail = trimThumbPath[1];
                                                    }
    
                                                    const imageHtml = ImageOrFileDipHtml(trimPath, "", isThumnail);
    
                                                    let html = "";
    
                                                    if (curEle2.iDeleted == 1) {
                                                        html = deleteMessageHtml("" + curEle2.created_at, 0,0,0);
                                                    } else {
                                                        // console.log("curEle2.id",curEle2.id)
    
                                                        html = `<div class="chat-message-outer-container recieve-message message-reply read">
                                                                        <div class="selection">
                                                                            <input class="form-check-input forwardChbx d-none" data-from="0" type="checkbox" data-date="${curEle2.created_at}" id="${curEle2.id}" value='${trimPath}' data-type="image">
                                                                        </div>
                                                                        <div class="chat-message-inner-container">
                                                                            <div class="chat-message-container">
                                                                                <div class="main-message">
                                                                                    <img src="${activeChatProfile}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                                                                                    <div>
                                                                                        <div class="chat-message-alignment">
                                                                                            <div class="chat-message">
                                                                                                ${replyHtml}
                                                                                                <div class="d-flex align-items-center justify-content-between">
                                                                                                    <div class="d-flex align-items-center">
                                                                                                        ${imageHtml}
                                                                                                    </div>
                                                                                                    ${floatingDrop(curEle2.id, trimPath, "image", curEle2.created_at, 0, trimPath)}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="d-flex align-items-center message-author">
                                                                                            <p class="message-droper-name">${activeChatName}</p>
                                                                                            <p class="message-drop-time">${timestampToAMPM("" + curEle2.created_at)}</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited == 1 ? '' : 'd-none'} edited_flag" id="edit_${curEle2.id}">Edited</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited == 0 && curEle2?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${curEle2.id}">Forwarded</p>
                                                                                            <div class="message-status"></div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>`;
    
                                                    }

                                                    // let html = `<div class="message-box friend-message">
                                                    //                             <p>${replyHtml} ${imageHtml} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}</span></p>
                                                    //                             ${forwardHtmlFunc(curEle2.id,curEle,"image")}
                                                    //                             ${replyIconHtml(curEle2.id,curEle,"image")}
                                                    //                             <input type="checkbox" data-type="image" class="forwardChbx d-none" data-from="0" value="${trimPath}"  id="${curEle2.id}" />
                                                    //                     </div>`;
    
                                                    if (!isSecond) {
                                                        dateTimeLineAdd(curEle2.created_at, isSecond);
                                                        $("#MessageList").append(html);
                                                        feather.replace();
                                                        scrollToBottom();
                                                        dynamicWithlabel();
                                                    } else {
                                                        dateTimeLineAdd(curEle2.created_at, isSecond);
                                                        const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
    
                                                        $("#" + NewId).after(html);
                                                        feather.replace();
                                                        dynamicWithlabel();
                                                    }
                                                })
                                            }
                                        }
                                    } else {
    
                                        let html = "";
                                        if (curEle2.iDeleted == 1) {
                                            html = deleteMessageHtml("" + curEle2.created_at, 0,0,0);
                                        }else if(curEle2?.isDeleteprofile && curEle2?.isDeleteprofile==1){
                                            html = MemeberLeft(timestampToAMPM(curEle2.created_at), vUserNameText,vActiveUserId);
                                        }else {
                                            const doc = curEle2.message;
                                            // console.log("first==>",curEle2.id)
                                            html = `<div class="chat-message-outer-container recieve-message message-reply read">
                                                            <div class="selection">
                                                                <input class="form-check-input forwardChbx d-none" data-from="0" type="checkbox" data-date="${curEle2.created_at}" id="${curEle2.id}" value='${curEle2.message}' data-type="text">
                                                            </div>
                                                            <div class="chat-message-inner-container">
                                                                <div class="chat-message-container">
                                                                    <div class="main-message">
                                                                        <img src="${activeChatProfile}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                                                                        <div>
                                                                            <div class="chat-message-alignment">
                                                                                <div class="chat-message">
                                                                                    ${replyHtml}
                                                                                    <div class="d-flex align-items-center justify-content-between">
                                                                                        <div class="d-flex align-items-center">
                                                                                            <div class="mb-0 message-text" id="msg_${curEle2.id}">${htmlDecode(curEle2.message)}</div>
                                                                                        </div>
                                                                                        ${floatingDrop(curEle2.id, curEle2.message, "text", curEle2.created_at, 0)}
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-flex align-items-center message-author">
                                                                                <p class="message-droper-name">${activeChatName}</p>
                                                                                <p class="message-drop-time">${timestampToAMPM("" + curEle2.created_at)}</p>
                                                                                <p class="message-drop-time ${curEle2?.iEdited == 1 ? '' : 'd-none'} edited_flag" id="edit_${curEle2.id}">Edited</p>
                                                                                <p class="message-drop-time ${curEle2?.iEdited == 0 && curEle2?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${curEle2.id}">Forwarded</p>
                                                                                <div class="message-status"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>`;
                                        }
                                        // let html = `<div class="message-box friend-message">
                                        //                     <p>${replyHtml}${curEle2.message} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}</span></p>
                                        //                     ${forwardHtmlFunc(curEle2.id,curEle2.message,"text")}
                                        //                     ${replyIconHtml(curEle2.id,curEle2.message,"text")}
                                        //                     <input type="checkbox" class="forwardChbx d-none" data-type="text" data-from="0" value="${curEle2.message}" id="${curEle2.id}" />
                                        //                 </div>`;
    
                                        if (!isSecond) {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);
                                            $("#MessageList").append(html);
                                            feather.replace();
                                            scrollToBottom();
                                            dynamicWithlabel();
                                        } else {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);
                                            const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                            $("#" + NewId).after(html);
                                            feather.replace();
                                            dynamicWithlabel();
                                        }
                                    }
                                }else{
                                    const dataTime = timestampToAMPM(curEle2.created_at);

                                    const vUserNameText = $("#activeChatName").text();

                                    const html = curEle2.iRequestMsg == 2 ? chatRequestAcceptHtml(dataTime, vUserNameText, 0,0) : curEle2.iRequestMsg == 3 ? chatRequestDeclineHtml(dataTime, vUserNameText,0,0) : curEle2.iRequestMsg == 4 ? chatRequestCancelledHtml(dataTime, vUserNameText,0,0) : chatRequesHtml(curEle2, 1);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                }
                            } else if (curEle2.iFromUserId == dd.iLoginId) {
                                if(curEle2.iRequestMsg==0){
                                    if (curEle2.message.includes('vImages =>')) {
                                        let removePrefix = curEle2.message;
                                        const myImageStr = removePrefix.split("vImages =>");
                                        if (myImageStr.length > 0) {
                                            const myImageArr = myImageStr[1].split(",");
                                            if (myImageArr.length > 0) {
                                                myImageArr.map((curEle, index) => {
    
                                                    const trimThumbPath = String(curEle2.vImageThumb).split("=>");
                                                    let isThumnail = "";
                                                    if (trimThumbPath.length > 1) {
                                                        isThumnail = trimThumbPath[1];
                                                    }
    
                                                    const imageHtml = ImageOrFileDipHtml(curEle, "", isThumnail);
    
    
                                                    const blueTick = curEle2.iReadTo == 1 ? 'read' : 'unread';
    
                                                    let html = "";
                                                    if (curEle2.iDeleted == 1) {
                                                        html = deleteMessageHtml("" + curEle2.created_at, 1,0,0);
                                                    }else if(curEle2?.isDeleteprofile && curEle2?.isDeleteprofile==1){
                                                        html = MemeberLeft(curEle2.created_at, vUserNameText,vActiveUserId);
                                                    } else {
                                                        // console.log("first2==>",curEle2.id)
                                                        html = `<div class="chat-message-outer-container send-message message-reply ${blueTick}">
                                                                        <div class="selection">
                                                                            <input class="form-check-input forwardChbx d-none" data-from="1" type="checkbox" data-date="${curEle2.created_at}" id="${curEle2.id}" value='${curEle}' data-type="image" >
                                                                        </div>
                                                                        <div class="chat-message-inner-container">
                                                                            <div class="chat-message-container">
                                                                                <div class="main-message">
                                                                                    <img src="${vProfilePick}" class="chat-message-profile sender_chat_profile" alt="chat-message-profile">
            
                                                                                    <div>
                                                                                        <div class="chat-message-alignment">
                                                                                            <div class="chat-message">
                                                                                                ${replyHtml}
                                                                                                <div class="d-flex align-items-center justify-content-between">
                                                                                                    <div class="d-flex align-items-center">
                                                                                                        ${imageHtml}
                                                                                                    </div>
                                                                                                    ${floatingDrop(curEle2.id, curEle, "image", curEle2.created_at, 1, curEle)}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="d-flex align-items-center message-author">
                                                                                            <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM("" + curEle2.created_at)}</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited == 1 ? '' : 'd-none'} edited_flag" id="edit_${curEle2.id}">Edited</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited == 0 && curEle2?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${curEle2.id}">Forwarded</p>
                                                                                            <div class="message-status"></div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>`;
                                                    }
    
                                                    // let html = `<div class="message-box my-message">
                                                    //                     ${forwardHtmlFunc(curEle2.id,curEle,"image")}
                                                    //                     ${replyIconHtml(curEle2.id,curEle,"image")}
                                                    //                     <p>${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}${blueTick}</span>
                                                    //                     </p>
                                                    //                     <input type="checkbox" data-type="image" class="forwardChbx d-none" data-date="${curEle2.created_at}" data-from="1" value="${curEle}" id="${curEle2.id}" />
                                                    //             </div>`;
    
                                                    if (!isSecond) {
                                                        dateTimeLineAdd(curEle2.created_at, isSecond);
                                                        $("#MessageList").append(html);
                                                        scrollToBottom();
                                                        feather.replace();
                                                        dynamicWithlabel();
                                                    } else {
                                                        dateTimeLineAdd(curEle2.created_at, isSecond);
                                                        const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
    
                                                        $("#" + NewId).after(html);
                                                        feather.replace();
                                                        dynamicWithlabel();
                                                    }
                                                })
                                            }
                                        }
    
                                    } else {
                                        const blueTick = curEle2.iReadTo == 1 ? 'read' : 'unread';
    
                                        let html = "";
                                        if (curEle2.iDeleted == 1) {
                                            html = deleteMessageHtml("" + curEle2.created_at, 1,0,0);
                                        } else {
                                            const doc = curEle2.message;
    
                                            // console.log("first2==>",curEle2.id)
                                            html = `<div class="chat-message-outer-container send-message message-reply ${blueTick}">
                                                                        <div class="selection">
                                                                            <input type="checkbox" data-type="text" data-from="1" class="forwardChbx form-check-input d-none" id="${curEle2.id}" data-date="${curEle2.created_at}" value='${curEle2.message}'  />
                                                                        </div>
                                                                        <div class="chat-message-inner-container">
                                                                            <div class="chat-message-container">
                                                                                <div class="main-message">
                                                                                    <img src="${vProfilePick}" class="chat-message-profile sender_chat_profile" alt="chat-message-profile">
                                                                                    <div>
                                                                                        <div class="chat-message-alignment">
                                                                                            <div class="chat-message">
                                                                                                ${replyHtml}
                                                                                                <div class="d-flex align-items-center justify-content-between">
                                                                                                    <div class="d-flex align-items-center">
                                                                                                        <div class="mb-0 message-text" id="msg_${curEle2.id}">${htmlDecode(doc)}</div>
                                                                                                    </div>
                                                                                                    ${floatingDrop(curEle2.id, curEle2.message, "text", curEle2.created_at, 1)}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="d-flex align-items-center message-author">
                                                                                            <p class="message-droper-name">You</p>
                                                                                            <p class="message-drop-time">${timestampToAMPM("" + curEle2.created_at)}</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited == 1 ? '' : 'd-none'} edited_flag" id="edit_${curEle2.id}">Edited</p>
                                                                                            <p class="message-drop-time ${curEle2?.iEdited==0 && curEle2?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${curEle2.id}">Forwarded</p>
                                                                                            <div class="message-status"></div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>`;
                                        }
    
                                        // let html = `<div class="message-box my-message">
                                        //                     ${forwardHtmlFunc(curEle2.id,curEle2.message,"text")}
                                        //                     ${replyIconHtml(curEle2.id,curEle2.message,"text")}
                                        //                     <p>${replyHtml}${curEle2.message} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}${blueTick}</span></p>
                                        //                     <input type="checkbox" data-type="text" data-from="1" class="forwardChbx d-none" data-date="${curEle2.created_at}" value="${curEle2.message}" id="${curEle2.id}" />
                                        //                 </div>`;
    
                                        if (!isSecond) {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);
                                            $("#MessageList").append(html);
                                            scrollToBottom();
                                            feather.replace();
                                            dynamicWithlabel();
                                        } else {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);
                                            const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
    
                                            $("#" + NewId).after(html);
                                            feather.replace();
                                            dynamicWithlabel();
                                        }
                                    }
                                }else{
                                    const dataTime = timestampToAMPM(curEle2.created_at);

                                    const vUserNameText = $("#activeChatName").text();

                                    const html = curEle2.iRequestMsg == 2 ? chatRequestAcceptHtml(dataTime, vUserNameText, 1,0) : curEle2.iRequestMsg == 3 ? chatRequestDeclineHtml(dataTime, vUserNameText,1,0) : curEle2.iRequestMsg == 4 ? chatRequestCancelledHtml(dataTime, vUserNameText,1,0) : chatRequesHtml(curEle2, 1);

                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();
                                }
                            }
                        }
                    })

                    const scrollableDiv = document.getElementById('MessageList');
                    const scrollPosition = scrollableDiv.scrollTop;

                    if (scrollPosition == 0) {
                        $("#topFilter").removeClass("d-none");
                    } else {
                        $("#topFilter").addClass("d-none");
                    }

                    $("#vUserDeleteChat").removeClass("disabled");
                    if (lastData.length) {
                        if (lastData[Number(lastData.length) - 1]['iRequestMsg'] == 1) {
                            $("#vRequestChatDiv").addClass("d-none");

                            if(lastData[Number(lastData.length) - 1]['iFromUserId'] == dd.iLoginId){
                                $("#vCancelRequest").closest("li").removeClass("d-none");
                                $("#vUserDeleteChat").addClass("disabled");
                            }else{
                                $("#vCancelRequest").closest("li").addClass("d-none");
                                $("#vUserDeleteChat").addClass("disabled");
                            }
                        }


                        if (lastData[Number(lastData.length) - 1]['isDeleteprofile'] == 1) {
                            $("#TextEditorArea").addClass("d-none");
                            $("#vRequestChatDiv").addClass("d-none");
                            $("#vCancelRequest").closest("li").addClass("d-none");
                            $("#vUserDeleteChat").removeClass("disabled");
                        }
                    }


                    
                    const vChatUserListJson = $("#vChatUserListJson").val();
                    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                        const filterIsActiveUsr=JSON.parse(vChatUserListJson).filter((curEle,inde)=>{
                            return curEle.iUserId==iUserId && curEle.eStatus=="y"
                        })

                        if(filterIsActiveUsr.length==0){
                            $("#TextEditorArea").addClass("d-none");
                            $("#vRequestChatDiv").addClass("d-none");
                        }
                    } 
                } else {
                    
                    if (isSecond == 0) {
                        $("#MessageList").html("");
                        timeLineDate = "";
                        $("#topFilter").addClass("d-none");
                    }

                    const vChatUserListJson = $("#vChatUserListJson").val();
                    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                        const filterIsActiveUsr=JSON.parse(vChatUserListJson).filter((curEle,inde)=>{
                            return curEle.iUserId==iUserId && curEle.eStatus=="y"
                        })

                        if(filterIsActiveUsr.length==0){
                            $("#TextEditorArea").addClass("d-none");
                            $("#vRequestChatDiv").addClass("d-none");
                        }
                    }
                }
            }
        });
    }
}


$(document).on("click", ".forwardChbx", () => {
    $('.chat-message-outer-container.select-message .selection .form-check-input').each(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        }
    });

    // Listen for changes in the checkbox state
    $('.chat-message-outer-container.select-message .selection .form-check-input').change(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        } else {
            $(this).closest('.chat-message-outer-container').removeClass('selected');
        }
    });
})


$(document).on("click", ".requestAccept", (e) => {
    const id = $(e.currentTarget).attr("data-id");
    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'RequestAcceptSubmit',
            data: {
                tToken: dd.tToken,
                vActiveUserId,
                msgId: id
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    $("#requestAction_" + id).remove();

                    $("#vUserDeleteChat").removeClass("disabled");

                    const activeChatName = $("#activeChatName").text();
                    const dataTime = timestampToAMPM();
                    const htmlData = chatRequestAcceptHtml(dataTime, activeChatName, 1,0);
                    dateTimeLineAdd(timeLineDate);

                    $("#MessageList").append(htmlData);
                    feather.replace();
                    // socket.emit('chatRequestAccept', {
                    //     iToUserId: vActiveUserId,
                    //     status: 2,
                    //     tToken: dd.tToken,
                    //     iDelete:0
                    // });

                    socket.emit('send_message', {
                        receiverChatID: vActiveUserId,
                        senderChatID: dd['iLoginId'],
                        content: "",
                        ImageDataArr: [],
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        vReplyFileName: "",
                        id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                        iRequestMsg: 2,
                        isForwardMsg:0,
                        isDeleteprofile:0
                    });

                    $("#vRequestChatDiv").addClass("d-none");
                    $("#TextEditorArea").removeClass("d-none");
                    $("#texAreaEditorDiv").removeClass("d-none");
                    dynamicWithlabel();
                    
                    scrollToBottom();
                }
            }
        })
    }
})

$(document).on("click", ".requestDecline", (e) => {
    const id = $(e.currentTarget).attr("data-id");

    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'RequestDeclineSubmit',
            data: {
                tToken: dd.tToken,
                vActiveUserId,
                msgId: id,
                isDelete:0
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    $("#requestAction_" + id).remove();

                    $("#vUserDeleteChat").removeClass("disabled");

                    const activeChatName = $("#activeChatName").text();
                    const dataTime = timestampToAMPM();
                    const htmlData = chatRequestDeclineHtml(dataTime, activeChatName, 1,0);

                    dateTimeLineAdd(timeLineDate);
                    $("#MessageList").append(htmlData);
                    feather.replace();

                    // socket.emit('chatRequestAccept', {
                    //     iToUserId: vActiveUserId,
                    //     status: 3,
                    //     tToken: dd.tToken,
                    //     iDelete:0
                    // });

                    socket.emit('send_message', {
                        receiverChatID: vActiveUserId,
                        senderChatID: dd['iLoginId'],
                        content: "",
                        ImageDataArr: [],
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        vReplyFileName: "",
                        id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                        iRequestMsg: 3,
                        isForwardMsg:0,
                        isDeleteprofile:0
                    });

                    dynamicWithlabel();
                    $("#vRequestChatDiv").removeClass("d-none");
                    scrollToBottom();
                }
            }
        })
    }
})


$(document).on("click","#vCancelRequest",(e)=>{
    const vActiveUserId=$("#vActiveUserId").val();
    let id = "";

    $(".requestSent").each((curEle,item)=>{
        if($(item).data("id")!=""){
            id=$(item).data("id");
        }
    })

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $("#vCancelRequest").closest("li").addClass("d-none");
        $("#vUserDeleteChat").removeClass("disabled");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'RequestCancelSubmit',
            data: {
                tToken: dd.tToken,
                vActiveUserId,
                msgId: id,
                isDelete:0
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {

                    const dataTime = timestampToAMPM();
                    const activeChatName = $("#activeChatName").text();
                    const htmlData = chatRequestCancelledHtml(dataTime, activeChatName, 1,0);

                    $(".requestSent").each((curEle,item)=>{
                        if($(item).data("id")!=""){
                            $(item).removeClass(".requestSent");
                        }
                    })

                    dateTimeLineAdd(timeLineDate);
                    $("#MessageList").append(htmlData);
                    
                    feather.replace();
                    scrollToBottom();
                    dynamicWithlabel();

                    // socket.emit('chatRequestAccept', {
                    //     iToUserId: vActiveUserId,
                    //     status: 4,
                    //     tToken: dd.tToken,
                    //     iDelete:0
                    // });

                    socket.emit('send_message', {
                        receiverChatID: vActiveUserId,
                        senderChatID: dd['iLoginId'],
                        content: "",
                        ImageDataArr: [],
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        vReplyFileName: "",
                        id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                        iRequestMsg: 4,
                        isForwardMsg:0,
                        isDeleteprofile:0
                    });

                    $(".chat-message-outer-container").removeClass("requestSent");
                    $("#vRequestChatDiv").removeClass("d-none");
                }
            }
        })
    }
})
//Chat Request Code End

//read success message
socket.on('readSuccessMsg', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".send-message").removeClass("unread");
        $(".send-message").addClass("read");
    }
})

//Message Typing Start
socket.on('MessageTypingStart', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".typing-preview").removeClass("d-none");
        setTimeout(() => {
            $(".typing-preview").addClass("d-none");
        }, 2000)
    }
})

//Message Typing End
socket.on('MessageTypingEnd', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".typing-preview").addClass("d-none");
    }
})

function replaceUserData(UserData){
    const vActiveUserId=$("#vActiveUserId").val();
    const vActiveGroupId=$("#vActiveGroupId").val();

    const vConvertionChatArr=$("#vConvertionChatArr").val();
    const updateConvertionChat=vConvertionChatArr!=""?JSON.parse(vConvertionChatArr).map((curEle,index)=>{
        const isStartChat=UserData?.isStartChat?UserData.isStartChat:curEle.isStartChat;

        return {
            ...curEle,
            ['vFullName']:curEle.iUserId==UserData.iUserId?UserData.vFullName:curEle.vFullName,
            ['iStatus']:curEle.iUserId==UserData.iUserId?UserData.iStatus:curEle.iStatus,
            ['iColorOption']:curEle.iUserId==UserData.iUserId?UserData.iColorOption:curEle.iColorOption,
            ['eStatus']:curEle.iUserId==UserData.iUserId?UserData.eStatus:curEle.eStatus,
            ['vProfilePic']:curEle.iUserId==UserData.iUserId?UserData.vProfilePic:curEle.vProfilePic,
            ['isStartChat']:curEle.iUserId==UserData.iUserId?isStartChat:curEle.isStartChat,
        }
    }):"";

    $("#vConvertionChatArr").val(JSON.stringify(updateConvertionChat));

    const vChatUserListJsonArr=$("#vChatUserListJson").val();

    const updateUserDataArr=vChatUserListJsonArr!=""?JSON.parse(vChatUserListJsonArr).map((curEle,index)=>{

        if(vActiveUserId==UserData.iUserId){
            let vProfilePic = UserData?.vProfilePic;
            if (vProfilePic == "") {
                colorOption.map((curEle2, index) => {
                    if (curEle2?.iColorId == UserData?.iColorOption) {
                        vProfilePic = curEle2?.vColorPick;
                    }
                })
            }

            $("#activeChatProfile").attr("xlink:href",vProfilePic);
            $("#activeChatName").text(UserData.vFullName);
            $("#activeChatStsDisp").text(UserData.iStatus == 1 ? 'Online' : 'Offline');
            if(UserData.iStatus == 1){
                $("#activeChatSts").removeClass("offline");
                $("#activeChatSts").addClass("online");
            }else{
                $("#activeChatSts").addClass("offline");
                $("#activeChatSts").removeClass("online");
            }


            if(UserData.eStatus=="d"){
                $("#vRequestChatDiv").addClass("d-none");
                $("#TextEditorArea").addClass("d-none");
            }


            $(".receive_chat_profile").attr("src",vProfilePic);
        }

        if(vActiveGroupId>0){
            let vProfilePic = UserData?.vProfilePic;
            if (vProfilePic == "") {
                colorOption.map((curEle2, index) => {
                    if (curEle2?.iColorId == UserData?.iColorOption) {
                        vProfilePic = curEle2?.vColorPick;
                    }
                })
            }

            $(".receive_chat_profile").each((e,item)=>{
                const dataUserId=$(item).attr("data-iuserid");
                if(dataUserId==UserData.iUserId){
                    $(item).attr("src",vProfilePic);
                }
            })
        }

        return {
            ...curEle,
            ['vFullName']:curEle.iUserId==UserData.iUserId?UserData.vFullName:curEle.vFullName,
            ['iStatus']:curEle.iUserId==UserData.iUserId?UserData.iStatus:curEle.iStatus,
            ['iColorOption']:curEle.iUserId==UserData.iUserId?UserData.iColorOption:curEle.iColorOption,
            ['eStatus']:curEle.iUserId==UserData.iUserId?UserData.eStatus:curEle.eStatus,
            ['vProfilePic']:curEle.iUserId==UserData.iUserId?UserData.vProfilePic:curEle.vProfilePic,
        }
    }):"";

    $("#vChatUserListJson").val(JSON.stringify(updateUserDataArr));

    $(".vUserIdsCls").each((e,item)=>{
        const iUserId=$(item).attr("data-id");
        if(iUserId==UserData.iUserId){
            let profileImage = UserData?.vProfilePic;
            if (profileImage == "") {
                colorOption.map((curEle2, index) => {
                    if (curEle2?.iColorId == UserData?.iColorOption) {
                        profileImage = curEle2?.vColorPick;
                    }
                })
            }

            $("#vUserProfileImage_"+UserData.iUserId).attr("xlink:href",profileImage);
            $("#vUserProfName_"+UserData.iUserId).text(UserData?.vFullName);
            $("#vUserActSts_"+UserData.iUserId).text(UserData?.iStatus==1?'Online':'Offline');
            if(UserData?.iStatus==1){
                $("#vUserProfStatus_"+UserData.iUserId).removeClass("offline");
                $("#vUserProfStatus_"+UserData.iUserId).addClass("online");
            }else{
                $("#vUserProfStatus_"+UserData.iUserId).removeClass("online");
                $("#vUserProfStatus_"+UserData.iUserId).addClass("offline");
            }
        }
    })

    ifUserDelete();
}

function changeUserListOrder(iSenderId){
    let isGetIndex=0;
    let indexNum=0;
    $(".vUserIdsCls").each((e,item)=>{
        const dataUserId=$(item).attr("data-id");
        if(dataUserId==iSenderId){
            isGetIndex=indexNum;
        }

        indexNum++;
    })

    $("#chatUserList li:eq(0)").before($("#chatUserList li:eq("+isGetIndex+")"));
}

function changeGroupListOrder(iSenderId){
    let isGetIndex=0;
    let indexNum=0;
    $(".vGroupIds").each((e,item)=>{
        const dataUserId=$(item).attr("data-id");
        if(dataUserId==iSenderId){
            isGetIndex=indexNum;
        }

        indexNum++;
    })

    $("#ChatGroupList li:eq(0)").before($("#ChatGroupList li:eq("+isGetIndex+")"));
}

//Socket Receive Message Single
socket.on('receive_message', data => {
    const vActiveUserId = $("#vActiveUserId").val();
    // console.log("receive_message=>", data)

    if (data?.type && data?.type == "DeleteMessage") {
        if (vActiveUserId == data.iSenderId) {
            let msgTime=$("#"+data.content).attr("data-date");

            let html = deleteMessageHtml(msgTime, 1,1,0);

            $("#" + data.content).closest(".chat-message-outer-container").removeClass("select-message");
            $("#" + data.content).closest(".chat-message-outer-container").html(html);

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageReadUpdate', {
                    iFromUserId: dd.iLoginId,
                    iToUserId: vActiveUserId
                });
            }
        }
    }else if (data?.isDeleteprofile && data?.isDeleteprofile == 1) {
        getUserList(data.iSenderId);
        getAllUserList();

        if (vActiveUserId == data.iSenderId) {
            dateTimeLineAdd(getCurrentDateTime());
            
            const vUsername=$("#activeChatName").text();
            let html = MemeberLeft(timestampToAMPM(), vUsername,vActiveUserId);

            $("#MessageList").append(html);
            scrollToBottom();
            feather.replace();
            
            $("#TextEditorArea").addClass("d-none");
            $("#vRequestChatDiv").addClass("d-none");
            $("#vCancelRequest").closest("li").addClass("d-none");
            $("#vUserDeleteChat").removeClass("disabled");
            $(".requestAccept").closest(".chat-message-outer-container").remove();

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageReadUpdate', {
                    iFromUserId: dd.iLoginId,
                    iToUserId: vActiveUserId
                });
            }

            const vChatUserListJson = $("#vConvertionChatArr").val();

            if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                let isMemeberStatChat=0;
                JSON.parse(vChatUserListJson).map((curEle, index) => {
                    if(curEle.iUserId==data.iSenderId && curEle.isStartChat==1){
                        isMemeberStatChat=1;
                    }
                })

                if(isMemeberStatChat==0){
                    $("#StartChatArea").removeClass("d-none");
                    $("#HeaderChatArea").addClass("d-none");
                    $("#MainChatArea").addClass("d-none");
                }
            }
        }

        if(activeTab == "Group"){
            $("#newUserMsgindc").removeClass("d-none");
            $("#newUserMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }
    }else if (data?.type && data?.type == "refreshGroupList") {
        getGroupList();
    }else if (data?.type && data?.type == "UpdateMessage") {
        if (vActiveUserId == data.iSenderId) {
            $("#msg_" + data.iMessageId).html(htmlDecode(data.content));
            $("#edit_" + data.iMessageId).removeClass("d-none");
            $("#forawrd_" + data.iMessageId).addClass("d-none");
            updateDataInAllHtml(data.iMessageId, data.content);

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageReadUpdate', {
                    iFromUserId: dd.iLoginId,
                    iToUserId: vActiveUserId
                });
            }
        }
    }else if(data?.type && data?.type == "RefreshUserList"){
        const UserData=data.UserData;

        if(UserData){
            replaceUserData(UserData);
        }

        // getUserList();
        // getAllUserList();
    }else if (data?.iRequestMsg && data.iRequestMsg > 0) {
        if (data.iSenderId == vActiveUserId) {
            if(data.iRequestMsg==1){
                dateTimeLineAdd(getCurrentDateTime());
                
                const dataReceve = { ...data, created_at: "" };
                const htmlData = chatRequesHtml(dataReceve, 1);
                $("#MessageList").append(htmlData);
                $("#vRequestChatDiv").addClass("d-none");
                $("#TextEditorArea").addClass("d-none");
                feather.replace();
                scrollToBottom();
                dynamicWithlabel();

                $("#vUserDeleteChat").addClass("disabled");
            }else if(data.iRequestMsg==5){
                dateTimeLineAdd(getCurrentDateTime());
                
                const getRowIdTime = timestampToAMPM();
                const activeChatName = $("#activeChatName").text();

                const htmlData = chatDeleteConnectHtml(getRowIdTime, activeChatName,0);
                $("#MessageList").append(htmlData);
                $("#vRequestChatDiv").removeClass("d-none");
                $("#TextEditorArea").addClass("d-none");
                feather.replace();
                scrollToBottom();
                dynamicWithlabel();

                // getUserList();
                // getAllUserList();
                changeUserListOrder(data.iSenderId);

                const UserData=data.UserData;
                if(UserData){
                    replaceUserData(UserData);
                }


                $("#vUserIdsCls_"+vActiveUserId).click();
                $("#vUserDeleteChat").removeClass("disabled");
                $("#vCancelRequest").closest("li").addClass("d-none");
            }else if(data.iRequestMsg==3){
                dateTimeLineAdd(getCurrentDateTime());
                
                const getRowIdTime = timestampToAMPM();
                const activeChatName = $("#activeChatName").text();

                const htmlData = chatRequestDeclineHtml(getRowIdTime, activeChatName, 0,0);
                $("#MessageList").append(htmlData);
                $("#vRequestChatDiv").removeClass("d-none");
                $("#TextEditorArea").addClass("d-none");
                feather.replace();
                scrollToBottom();
                dynamicWithlabel();

                // getUserList();
                // getAllUserList();
                changeUserListOrder(data.iSenderId);

                const UserData=data.UserData;
                if(UserData){
                    replaceUserData(UserData);
                }

                $("#vUserDeleteChat").removeClass("disabled");
                $("#vCancelRequest").closest("li").addClass("d-none");
            }else if(data.iRequestMsg==2){
                dateTimeLineAdd(getCurrentDateTime());
                
                const getRowIdTime = timestampToAMPM();
                const activeChatName = $("#activeChatName").text();

                const htmlData = chatRequestAcceptHtml(getRowIdTime, activeChatName, 0,0);
                $("#MessageList").append(htmlData);
                $("#vRequestChatDiv").addClass("d-none");
                $("#TextEditorArea").removeClass("d-none");
                $("#texAreaEditorDiv").removeClass("d-none");
                feather.replace();
                scrollToBottom();
                dynamicWithlabel();

                // getUserList();
                // getAllUserList();
                changeUserListOrder(data.iSenderId);

                const UserData=data.UserData;
                if(UserData){
                    replaceUserData(UserData);
                }

                $("#vUserDeleteChat").removeClass("disabled");
                $("#vCancelRequest").closest("li").addClass("d-none");
            }else if(data.iRequestMsg==4){
                dateTimeLineAdd(getCurrentDateTime());
                
                const getRowIdTime = timestampToAMPM();
                const activeChatName = $("#activeChatName").text();

                const htmlData = chatRequestCancelledHtml(getRowIdTime, activeChatName, 0,0);
                $("#MessageList").append(htmlData);
                $("#vRequestChatDiv").removeClass("d-none");
                $("#TextEditorArea").addClass("d-none");
                feather.replace();
                scrollToBottom();
                dynamicWithlabel();

                // getUserList();
                // getAllUserList();
                changeUserListOrder(data.iSenderId);

                const UserData=data.UserData;
                if(UserData){
                    replaceUserData(UserData);
                }

                $(".requestAccept").closest(".chat-message-outer-container").remove();
                $("#vUserDeleteChat").removeClass("disabled");
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageReadUpdate', {
                    iFromUserId: dd.iLoginId,
                    iToUserId: vActiveUserId
                });
            }
        } else {
            getUserList(data.iSenderId);
        }

        if(activeTab == "Group"){
            $("#newUserMsgindc").removeClass("d-none");
            $("#newUserMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }
    }else if (data?.type && data?.type == "logout") {
        localStorage.removeItem("whatsAppClone");
        window.location.href="./login.php";
    } else {
        if (vActiveUserId > 0 || activeTab == "User") {
            // getUserList(data.iSenderId);
            changeUserListOrder(data.iSenderId);
        }

        if (activeTab == "Group") {
            $("#newUserMsgindc").removeClass("d-none");
            $("#newUserMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }

        if (data.iSenderId != vActiveUserId) {
            $(".vUserIdsCls").each((e, item) => {
                const getRowId = $(item).attr("data-id");
                if (getRowId == data.iSenderId) {
                    $(item).addClass("unread-chat");
                }
            })
        }

        let totalForwardCheck=0;
        $(".forwardChbx").each(function () {
            if(this.checked){
                totalForwardCheck++;
            }
        });

        const activeChatName = $("#activeChatName").text();
        const vProfilePick = $("#vProfilePick").attr("xlink:href");
        const activeChatProfile = $("#activeChatProfile").attr("xlink:href");

        const dataContent = data.content;

        const vReplyMsg = data?.vReplyMsg;
        const vReplyMsg_id = data?.vReplyMsg_id;
        const vReplyFileName = data?.vReplyFileName;

        let replyHtml = replyHtmlFunc(vReplyMsg_id, vReplyMsg, vReplyFileName);

        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            socket.emit('messageReadUpdate', {
                iFromUserId: dd.iLoginId,
                iToUserId: vActiveUserId
            });

            if (vActiveUserId == data.iSenderId) {
                if (dataContent.includes('vImages =>')) {
                    let removePrefix = dataContent;
                    const myImageStr = removePrefix.split("vImages =>");
                    if (myImageStr.length > 0) {
                        const myImageArr = myImageStr[1].split(",");
                        if (myImageArr.length > 0) {
                            myImageArr.map((curEle, index) => {

                                const trimThumbPath = String(data.ContentDataThumb).split("=>");
                                let isThumnail = "";
                                if (trimThumbPath.length > 1) {
                                    isThumnail = trimThumbPath[1];
                                }

                                let imageHtml = ImageOrFileDipHtml(curEle, "", isThumnail);

                                if (timeLineDate == "") {
                                    dateTimeLineAdd();
                                }else{
                                    dateTimeLineAdd(getCurrentDateTime());
                                }

                                const id = data.id;

                                let html = `<div class="chat-message-outer-container recieve-message message-reply read ${totalForwardCheck>0?'select-message':''}">
                                        <div class="selection">
                                            <input type="checkbox" data-type="image" data-from="0" class="form-check-input forwardChbx ${totalForwardCheck>0?'':'d-none'}" data-date="${getCurrentDateTime()}" id="${id}" value='${curEle}' />
                                        </div>
                                        <div class="chat-message-inner-container">
                                            <div class="chat-message-container">
                                                <div class="main-message">
                                                    <img src="${activeChatProfile}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                                                    <div>
                                                        <div class="chat-message-alignment">
                                                            <div class="chat-message">
                                                                ${replyHtml}
                                                                <div class="d-flex align-items-center justify-content-between">
                                                                    <div class="d-flex align-items-center">
                                                                        ${imageHtml}
                                                                    </div>
                                                                    ${floatingDrop(id, curEle, "image", "", 0, curEle)}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center message-author">
                                                            <p class="message-droper-name">${activeChatName}</p>
                                                            <p class="message-drop-time">${timestampToAMPM()}</p>
                                                            <p class="message-drop-time d-none edited_flag" id="edit_${id}">Edited</p>
                                                            <p class="message-drop-time ${data?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${id}">Forwarded</p>
                                                            <div class="message-status"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;

                                // let html = `<div class="message-box friend-message">
                                //                 <p>${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM()}</span></p>
                                //                 ${forwardHtmlFunc(0,curEle,"image")}
                                //                 ${replyIconHtml(0,curEle,"image")}
                                //                     <input type="checkbox" data-type="image" data-from="0" class="forwardChbx d-none" value="${curEle}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                //         </div>`;

                                $("#MessageList").append(html);
                                scrollToBottom();
                                feather.replace();
                            })
                        }
                    }
                } else {
                    if (timeLineDate == "") {
                        dateTimeLineAdd();
                    }else{
                        dateTimeLineAdd(getCurrentDateTime());
                    }

                    const id = data.id;

                    let html = `<div class="chat-message-outer-container recieve-message message-reply read ${totalForwardCheck>0?'select-message':''}">
                                <div class="selection">
                                    <input type="checkbox" data-type="text" data-from="0" class="form-check-input forwardChbx ${totalForwardCheck>0?'':'d-none'}" data-date="${getCurrentDateTime()}" id="${id}" value='${data.content}' />
                                </div>
                                <div class="chat-message-inner-container">
                                    <div class="chat-message-container">
                                        <div class="main-message">
                                            <img src="${activeChatProfile}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                                            <div>
                                                <div class="chat-message-alignment">
                                                    <div class="chat-message">
                                                        ${replyHtml}
                                                        <div class="d-flex align-items-center justify-content-between">
                                                            <div class="d-flex align-items-center">
                                                            <div class="mb-0 message-text" id="msg_${id}">${htmlDecode(data.content)}</div>
                                                            </div>
                                                            ${floatingDrop(id, data.content, "text", "", 0)}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center message-author">
                                                    <p class="message-droper-name">${activeChatName}</p>
                                                    <p class="message-drop-time">${timestampToAMPM()}</p>
                                                    <p class="message-drop-time d-none edited_flag" id="edit_${id}">Edited</p>
                                                    <p class="message-drop-time ${data?.isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${id}">Forwarded</p>
                                                    <div class="message-status"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;

                    // let html = `<div class="message-box friend-message">
                    //             <p>${replyHtml}${data.content} <span class="msgTime">${timestampToAMPM()}</span></p>
                    //             ${forwardHtmlFunc(0,data.content,"text")}
                    //             ${replyIconHtml(0,data.content,"text")}
                    //                 <input type="checkbox" data-type="text" data-from="0" class="forwardChbx d-none" value="${data.content}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                    //         </div>`;

                    $("#MessageList").append(html);
                    scrollToBottom();
                    feather.replace();
                }
            }
        }
        // Handle received message
    }
});


window.onload = (event) => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist == null) {
        window.location = "./login.php";
    }
};

function MessageTypingSocket(msg) {
    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        socket.emit('MessageTyping', {
            iFromUserId: dd.iLoginId,
            iToUserId: vActiveUserId,
            msg: msg
        });
    }
}

$(document).ready(function () {

    getUserList();

    $("#vMessage").on("keyup", (e) => {
        if (e.keyCode == 27 && iEditMsgId != "") {
            $("#vMessage").html("");
            $(".plc-holder").removeClass("d-none");
            $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
            $(".message-text").closest(".chat-message").removeClass("edit-message-active");
            $(".editor-close").addClass("d-none");

            $(".floating-dd").removeClass("d-none");
            // console.log("ceheck 1 ==>")
            iEditMsgId = "";
            vEditMsgText = "";
            vEditMsgType = "";
            vEditMessageMainId = "";
            updateJson();
        }

        if (e.keyCode == 13 && e.shiftKey) {
            shiftEnterTag(e);
        }
    })

    $(document).on("click", ".editor-close", () => {
        $("#vMessage").html("");
        $(".plc-holder").removeClass("d-none");
        $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
        $(".message-text").closest(".chat-message").removeClass("edit-message-active");
        $(".editor-close").addClass("d-none");

        $(".floating-dd").removeClass("d-none");
        iEditMsgId = "";
        vEditMsgText = "";
        vEditMsgType = "";
        vEditMessageMainId = "";
        updateJson();
    })

    const shiftEnterTag = (e) => {
        if (e.key === 'Enter' && e.shiftKey) {
            e.preventDefault();

            let selection = window.getSelection();
            let range = selection.getRangeAt(0);
            let container = range.startContainer;

            // Traverse up the DOM to find the closest 'li'
            while (container && container.nodeName !== 'LI') {
                container = container.parentNode;
            }

            if (container && container.nodeName === 'LI') {
                // Check if the <li> is empty
                if (container.textContent.trim() === '') {
                    e.preventDefault();
                    let ul = container.closest('ul');

                    container.textContent = "     ";
                    document.execCommand('insertUnorderedList', false, null);
                    container.textContent = "";
                    // ul.closest("span").textContent="";
                    return;
                }

                // Handle the scenario with <br> in the <li>
                let liContent = container.innerHTML;
                let brIndex = liContent.indexOf('<br>');

                if (brIndex !== -1) {
                    // Get the text content before and after the <br> tag
                    let beforeBr = liContent.substring(0, brIndex);
                    let afterBr = liContent.substring(brIndex + 4); // 4 is the length of '<br>'

                    // Update the current <li> with the text before the <br> tag
                    container.innerHTML = beforeBr;

                    // Create a new <li> element and set its text to the text after the <br> tag
                    let newLi = document.createElement('li');
                    newLi.innerHTML = afterBr;

                    // Insert the new <li> after the current <li>
                    container.parentNode.insertBefore(newLi, container.nextSibling);

                    // Set the cursor position to the beginning of the new <li>
                    let newRange = document.createRange();
                    newRange.setStart(newLi, 0);
                    newRange.setEnd(newLi, 0);
                    let newSelection = window.getSelection();
                    newSelection.removeAllRanges();
                    newSelection.addRange(newRange);
                }
            }
        }
    };

    $("#vMessage").on("keydown", (e) => {
        let vMessage = MsgRemvQuotes(textEditorMsg);
        if (e.keyCode == 13 && !e.shiftKey) {
            e.preventDefault();
            if (vMessage != "&lt;br&gt;") {
                if(sendDate==""){
                    sendDate=new Date();
                    sendMessage();
                }else{
                    var startDate = sendDate;
                    // Do your operations
                    var endDate   = new Date();
                    var seconds = (endDate.getTime() - startDate.getTime()) / 1000;
                    if(seconds>1){
                        sendDate=new Date();
                        sendMessage();
                    }
                    // else{
                    //     setTimeout(() => {
                    //         sendMessage();
                    //     }, 1000);
                    // }
                    
                }
            }
            return false;
        } else if (e.keyCode == 13 && e.shiftKey) {
            if (vMessage == "" || vMessage == "&lt;br&gt;") {
                e.preventDefault();
                return false;
            }
        }
        // shiftEnterTag(e);
    })


    //Remove emoji i have select from window suggestion
    $("#vMessage").on("input", (e) => {
        let text = e.target.innerText;

        // Regex pattern to match emojis
        let emojiPattern = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu;

        // Find the last emoji
        let emojis = text.match(emojiPattern);
        let lastEmoji = emojis ? emojis[emojis.length - 1] : "";

        if (lastEmoji != "") {
            $('#vMessage').html(function (i, o) {
                return o.replace('' + lastEmoji + '', '');
            })
            updateJson();

            var node = document.getElementById('vMessage');
            focusAndPlaceCaretAtEnd(node);
        }
    })

    var keyUpSpaceDisAllow = document.getElementById('vMessage');

    keyUpSpaceDisAllow.addEventListener('keyup', function (event) {
        if (String(keyUpSpaceDisAllow.textContent).trim() == "") {
            if ($("#vMessage").find('img').length == 0) {
                $("#vMessage").html("");
            }
        }
    });

    document.querySelector('#vMessage').addEventListener('input', function (e) {
        if($("#vMessage").text()!=""){
            MessageTypingSocket(textEditorMsg)
        }else{
            MessageTypingSocket("")
        }
    })

    document.querySelector('#vMessage').addEventListener('keyup', function (e) {
        const vMessageText = $("#vMessage").text();
        if (String(vMessageText).trim() == "") {
            if ($("#vMessage:has(img)").length == 0) {
                $("#sendMessage").addClass("disabled");
            } else {
                $("#sendMessage").removeClass("disabled");
            }
        } else {
            $("#sendMessage").removeClass("disabled");
        }
    })
})

$(document).on("click", "#sendMessage", function (e) {
    sendMessage();
})

let ImageDataArr = [];

const MsgRemvQuotes = (msg) => {
    let newMsg = msg.substring(1);
    return newMsg.substring(0, newMsg.length - 1);
}

function removeBackslashes(input) {
    return input.replace(/\\/g, '')
}

function htmlDecode(inputHTML) {
    // Remove unnecessary escape characters and correct the tags
    const correctedHTML = String(inputHTML)
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&cent;/g, '¢')
        .replace(/&pound;/g, '£')
        .replace(/&yen;/g, '¥')
        .replace(/&euro;/g, '€')
        .replace(/&copy;/g, '©')
        .replace(/&reg;/g, '®')
        .replace(/&amp;nbsp;/g, '&nbsp;')
        .replace(/\\n/g, " ")
        ; // Correcting &amp;nbsp;

    return removeBackslashes(correctedHTML);
}

function ReplyhtmlDecode(inputHTML) {
    // Remove unnecessary escape characters and correct the tags
    const correctedHTML = String(inputHTML)
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&cent;/g, '¢')
        .replace(/&pound;/g, '£')
        .replace(/&yen;/g, '¥')
        .replace(/&euro;/g, '€')
        .replace(/&copy;/g, '©')
        .replace(/&reg;/g, '®')
        .replace(/&amp;nbsp;/g, '&nbsp;')
        .replace(/br/g, "/n")
        ; // Correcting &amp;nbsp;

    return removeBackslashes(correctedHTML);
}

function delayTimeWait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const removeDoubleQuotes = (str) => {
    return str = str.replace(/^"(.*)"$/, '$1');
}

function sendMessage() {
    // console.log("iEditMsgId",iEditMsgId)
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const isMesage = $("#vMessage").text();
        $("#fileUploadButtton").removeClass("disabled");

        let totalForwardCheck=0;
        $(".forwardChbx").each(function () {
            if(this.checked){
                totalForwardCheck++;
            }
        });

        if (String(isMesage).trim() != "" || ImageDataArr.length || $("#vMessage:has(img)").length) {
            let vMessage = MsgRemvQuotes(textEditorMsg);
            // let vMessage=$("#vMessage").text();
            const vActiveUserId = $("#vActiveUserId").val();
            const vActiveGroupId = $("#vActiveGroupId").val();

            const vChatGroupListJson = $("#vChatGroupListJson").val();

            let vMembersList="";
            if (vActiveGroupId && vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
                const filterGroupDetail=JSON.parse(vChatGroupListJson).filter((curEle,index)=>{
                    return curEle.iGroupId==vActiveGroupId;
                });

                if(filterGroupDetail.length>0){
                    vMembersList=filterGroupDetail[0]['tGroupUsers'];
                }
            }

            if (iEditMsgId == "") {
                const vReplyMsg = $("#vReplyMsg").val();
                const vReplyMsg_id = $("#vReplyMsg_id").val();
                const vReplyMsg_type = $("#vReplyMsg_type").val();
                const vReplyFileName = $("#vReplyFileName").val();

                const senderImageHtml = $("#vProfilePick").attr("xlink:href");

                let replyHtml = replyHtmlFunc(vReplyMsg_id, vReplyMsg, vReplyFileName, 1);

                let isReadFlag = vActiveGroupId > 0 ? '' : `<div class="message-status"></div>`

                if (vMessage != "" || ImageDataArr.length > 0) {
                    if (ImageDataArr.length == 0) {
                        if (timeLineDate == "" || timeLineDate!=getCurrentDate()) {
                            timeLineDate = getCurrentDate();

                            let htmlDate = `<div class="chat-time-line">
                                <p>Today</p>
                            </div>`;

                            $("#MessageList").append(htmlDate);
                            dynamicWithlabel();
                        }

                        // htmlDecode(vMessage)

                        let id = vActiveUserId > 0 ? dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()) : dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());

                        let html = `<div class="chat-message-outer-container send-message message-reply unread ${totalForwardCheck>0?'select-message':''}">
                                        <div class="selection">
                                            <input type="checkbox" data-type="text" data-from="1" id="${id}" class="form-check-input forwardChbx ${totalForwardCheck>0?'':'d-none'}" data-date="${getCurrentDateTime()}" value='${vMessage}'/>
                                        </div>
                                        <div class="chat-message-inner-container">
                                            <div class="chat-message-container">
                                                <div class="main-message">
                                                    <img src="${senderImageHtml}" class="chat-message-profile sender_chat_profile" alt="chat-message-profile">
                                                    <div>
                                                        <div class="chat-message-alignment">
                                                            <div class="chat-message">
                                                                ${replyHtml}
                                                                <div class="d-flex align-items-center justify-content-between">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="mb-0 message-text" id="msg_${id}">${htmlDecode(vMessage)}</div>
                                                                        </div>
                                                                        ${floatingDrop(id, vMessage, "text", getCurrentDateTime(), 1)}
                                                                    </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center message-author">
                                                            <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM()}</p> <p class="message-drop-time d-none edited_flag" id="edit_${id}">Edited</p>
                                                            ${isReadFlag}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;

                        // let html = `<div class="message-box my-message">
                        //                 ${forwardHtmlFunc("LastId", vMessage, "text")}
                        //                 ${replyIconHtml("LastId", vMessage, "text")}
                        //                 ${senderImageHtml}
                        //                 <p>${vUserName}${replyHtml}${vMessage} <span class="msgTime">${timestampToAMPM()}${blueTick}</span>
                        //                 </p>
                        //                 <input type="checkbox" data-type="text" data-from="1" id="${dataParseStr}" class="forwardChbx d-none" data-date="${getCurrentDateTime()}" value="${vMessage}"/>
                        //             </div>`;

                        $("#MessageList").append(html);
                        $("#vMessage").html("");
                        $("#sendMessage").addClass("disabled");
                        updateJson();
                        scrollToBottom();
                        dynamicWithlabel();
                        feather.replace();
                        $(".textarea-reply-container").removeClass('show');

                        $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
                        $(".message-text").closest(".chat-message").removeClass("edit-message-active");
                        $(".editor-close").addClass("d-none");
                        $(".floating-dd").removeClass("d-none");

                        if (vActiveUserId > 0) {
                            socket.emit('send_message', {
                                receiverChatID: vActiveUserId,
                                senderChatID: dd['iLoginId'],
                                content: vMessage,
                                ImageDataArr: [],
                                vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                vReplyMsg_id: vReplyMsg_id,
                                vReplyFileName: vReplyFileName,
                                id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                                iRequestMsg: 0,
                                isForwardMsg:0,
                                isDeleteprofile:0
                            });

                            MessageTypingSocket("")
                            if (activeTab == "User") {
                                changeUserListOrder(vActiveUserId);
                            }

                            $("#vReplyMsg_id").val("");
                        } else {
                            socket.emit('send_grp_message', {
                                receiverChatID: vActiveGroupId,
                                senderChatID: dd['iLoginId'],
                                content: vMessage,
                                ImageDataArr: [],
                                vReplyFileName: vReplyFileName,
                                vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                vReplyMsg_id: vReplyMsg_id,
                                id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                                isGreetingMsg: 0,
                                vMembersList:vMembersList,
                                vGroupMessageType:"",
                                isForwardMsg:0,
                                isDeleteprofile:0,
                                iRequestMsg:0,
                                vDeleteMemberId:"",
                                vNewAdminId:"",
                                RequestMemberId:""
                            });

                            MessageTypingSocket("");
                            if (activeTab == "Group") {
                                // getGroupList();
                                if(vActiveGroupId>0){
                                    changeGroupListOrder(vActiveGroupId);
                                }
                            }

                            $("#vReplyMsg_id").val("");
                        }
                    } else {
                        let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                    <a class="cursor-pointer close-reply"><i data-feather="x"
                                                            class="feather-16"></i></a>
                                                </div>`;
                        $("#fileUploadDiv").html(fileUploadDummyHtml);
                        
                        async function processArrayWithDelay(array, callback, delayTime) {
                            const results = [];
                            for (let i = 0; i < array.length; i++) {
                                //Logic Code
                                const curEle = array[i];
                                const index = i;

                                const fileName=Date.parse(new Date())+"_"+curEle.fileName;
                                
                                let imageHtml = ImageOrFileDipHtml(curEle.imageDataThumb, fileName);

                                if (timeLineDate == "" || timeLineDate!=getCurrentDate()) {
                                    timeLineDate = getCurrentDate();
            
                                    let htmlDate = `<div class="chat-time-line">
                                        <p>Today</p>
                                    </div>`;
        
                                    $("#MessageList").append(htmlDate);
                                    dynamicWithlabel();


                                    // timeLineDate = getCurrentDate();
                                    // let htmlDate = "<div class='date-timeline'><p>" + dateDispl(timeLineDate) + "</p></div>";
                                    // $("#MessageList").append(htmlDate);
                                    // dynamicWithlabel();
                                }

                                const id = dd.iLoginId + "_" + vActiveUserId + "_" + Date.parse(new Date());

                                let html = `<div class="chat-message-outer-container send-message message-reply unread ${totalForwardCheck>0?'select-message':''}">
                                            <div class="selection">
                                                <input type="checkbox" data-type="image" data-from="1" class="form-check-input forwardChbx ${totalForwardCheck>0?'':'d-none'}" id="${id}" value='${curEle.imageData}' data-date="${getCurrentDateTime()}" />
                                            </div>
                                            <div class="chat-message-inner-container">
                                                <div class="chat-message-container">
                                                    <div class="main-message">
                                                        <img src="${senderImageHtml}" class="chat-message-profile sender_chat_profile" alt="chat-message-profile">
                                                        <div>
                                                            <div class="chat-message-alignment">
                                                                <div class="chat-message">
                                                                    ${replyHtml}
                                                                    <div class="d-flex align-items-center justify-content-between">
                                                                        <div class="d-flex align-items-center">
                                                                            ${imageHtml}
                                                                        </div>
                                                                        ${floatingDrop(id, curEle.imageData, "image", getCurrentDateTime(), 1, curEle.fileName)}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center message-author">
                                                                <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM()}</p> <p class="message-drop-time d-none edited_flag" id="edit_${id}">Edited</p>
                                                                ${isReadFlag}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>`;

                                // let html = `<div class="message-box my-message">
                                //             ${forwardHtmlFunc("LastId", curEle.imageData, "image")}
                                //             ${replyIconHtml("LastId", curEle.imageData, "image")}
                                //             ${senderImageHtml}
                                //         <p>${vUserName}${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM()}${blueTick}</span></p>
                                //         <input type="checkbox" data-type="image" data-from="1" class="forwardChbx d-none" value="${curEle.fileName}" data-date="${getCurrentDateTime()}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                //     </div>`;

                                $("#MessageList").append(html);
                                $("#vMessage").html("");
                                $("#sendMessage").addClass("disabled");
                                updateJson();
                                scrollToBottom();
                                feather.replace();
                                dynamicWithlabel();
                                $(".textarea-reply-container").removeClass('show');

                                if (vActiveUserId > 0) {
                                    socket.emit('send_message', {
                                        receiverChatID: vActiveUserId,
                                        senderChatID: dd['iLoginId'],
                                        content: vMessage,
                                        ImageDataArr: [curEle],
                                        vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                        vReplyMsg_id: vReplyMsg_id,
                                        vReplyFileName: vReplyFileName,
                                        id: dd.iLoginId + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                                        iRequestMsg: 0,
                                        isForwardMsg:0,
                                        isDeleteprofile:0
                                    });
                                    if (Number(ImageDataArr.length) == Number(index + 1)) {
                                        ImageDataArr = [];
                                        if (activeTab == "Group") {
                                            getGroupList();
                                        } else {
                                            getUserList();
                                            MessageTypingSocket("")
                                        }
                                    }
                                } else {
                                    socket.emit('send_grp_message', {
                                        receiverChatID: vActiveGroupId,
                                        senderChatID: dd['iLoginId'],
                                        content: vMessage,
                                        ImageDataArr: [curEle],
                                        vReplyFileName: vReplyFileName,
                                        vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                        vReplyMsg_id: vReplyMsg_id,
                                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                                        isGreetingMsg: 0,
                                        vMembersList:vMembersList,
                                        vGroupMessageType:"",
                                        isForwardMsg:0,
                                        isDeleteprofile:0,
                                        iRequestMsg:0,
                                        vDeleteMemberId:"",
                                        vNewAdminId:"",
                                        RequestMemberId:""
                                    });
                                    if (Number(ImageDataArr.length) == Number(index + 1)) {
                                        ImageDataArr = [];
                                        if (activeTab == "Group") {
                                            getGroupList();
                                        } else {
                                            getUserList();
                                            MessageTypingSocket("")
                                        }
                                    }
                                }

                                await delayTimeWait(delayTime);

                                setTimeout(callback, 1000);
                            }
                            return results;
                        }

                        async function processItem(item) {
                            await delayTimeWait(500);
                            return item * 1;
                        }

                        processArrayWithDelay(ImageDataArr, processItem, 2000)
                            .then(results => {
                                if (vActiveUserId > 0) {
                                    setTimeout(() => {
                                        $("#vUserIdsCls_" + vActiveUserId).click();
                                    }, 100);
                                } else {
                                    if(activeTab == "User"){
                                        activeTab="Group";
                                        $("#userGroup").click();
                                    }
                                    setTimeout(() => {
                                        $(".vGroupIds").each((e, item) => {
                                            const getRowId = $(item).attr("data-id");
                                            if (getRowId == vActiveGroupId) {
                                                $(item).click();
                                            }
                                        })
                                    }, 100)
                                }

                                $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
                                $(".message-text").closest(".chat-message").removeClass("edit-message-active");
                                $(".floating-dd").removeClass("d-none");
                                $(".editor-close").addClass("d-none");

                                $("#vReplyMsg_id").val("");

                                console.log('All image processed');

                            });
                    }

                    $("#replyInputBox").addClass("d-none");
                    $("#vReplyMsg").val("");
                    $("#vReplyMsg_id").val("");
                    $("#vReplyMsg_type").val("");
                    $("#vReplyFileName").val("");

                    $(".teatarea-file-upload").removeClass("show");
                    $("#fileInput").val("");
                    $(".editor").addClass("show");

                    $('.file-preview').text("");
                    $(".type-link").removeClass("d-none");
                    $(".emoji-link").removeClass("d-none");

                    var outerheight = $('.textarea-outer-container').outerHeight() + 32 + 24;
                    $(".chat-area-bottom-space").css("padding-bottom", outerheight + 'px');

                    $("#fileInput").val("");

                    $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
                    $(".message-text").closest(".chat-message").removeClass("edit-message-active");
                    $(".floating-dd").removeClass("d-none");
                    $(".editor-close").addClass("d-none");

                    $("#fileUploadLoader").addClass("d-none");
                    $("#fileUploadButtton").removeClass("disabled");
                    $("#texAreaEditorDiv").removeClass("d-none");
                }
            } else {
                if (vMessage != "") {
                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        async: false,
                        url: API_URL + 'MessageUpdate',
                        data: {
                            tToken: dd.tToken,
                            msg: vMessage,
                            vActiveGroupId,
                            vActiveUserId,
                            msgId: iEditMsgId,
                            id: vEditMessageMainId
                        },
                        success: function (data, status, xhr) {
                            if (data.status == 200) {

                                // const vMessage=$("#vMessage").text();
                                // var htmlContent = $(".editor").html();
                                // const NewhtmlContent=removeLeadingNbsp(htmlContent);
                                // const finalHtmlContent=String(vMessage).trim()==""?removeLeadingNbspImg(htmlContent):removeTrailingNbsp(NewhtmlContent);
                                // var encodedContent = $("<div>").text(finalHtmlContent).html();

                                const encodedContent = removeAllSpaceFrom();

                                var encodedHtmlString = htmlEncode(encodedContent);


                                const finalMsg = JSON.parse(JSON.stringify(encodedHtmlString));

                                // $("#vMessage").html("");
                                $(".plc-holder").removeClass("d-none");
                                $("#msg_" + vEditMessageMainId).html(htmlDecode(removeDoubleQuotes(finalMsg)));
                                $("#edit_" + vEditMessageMainId).removeClass("d-none");
                                $("#forawrd_" + vEditMessageMainId).addClass("d-none");
                                $("#sendMessage").addClass("disabled");

                                updateJson();

                                updateDataInAllHtml(vEditMessageMainId, removeDoubleQuotes(textEditorMsg))

                                socket.emit('update_message', {
                                    content: removeDoubleQuotes(textEditorMsg),
                                    iMessageId: vEditMessageMainId,
                                    vActiveGroupId,
                                    vActiveUserId,
                                    tToken: dd.tToken
                                });

                                // console.log("check 2 ==>")
                                iEditMsgId = "";
                                vEditMsgText = "";
                                vEditMsgType = "";
                                vEditMessageMainId = "";

                                $("#vMessage").html("");

                                $("#vMessage").closest(".textarea-inner-container").removeClass("edit-message-active");
                                $(".message-text").closest(".chat-message").removeClass("edit-message-active");
                                $(".floating-dd").removeClass("d-none");
                                $(".editor-close").addClass("d-none");
                                $("#vReplyMsg_id").val("");
                            }
                        }
                    })
                }
            }
        }
    }
}

function updateDataInAllHtml(id, message) {

    $(".forwardChbx").each((e, item) => {
        const getRowId = $(item).attr("id");
        if (getRowId == id) {
            $(item).val(message);
        }
    })

    $(".EditMessage").each((e, item) => {
        const getRowId = $(item).attr("data-id");
        if (getRowId == id) {
            $(item).attr("data-msg", message);
        }
    })

    $(".replyIcon").each((e, item) => {
        const getRowId = $(item).attr("data-id");
        if (getRowId == id) {
            $(item).attr("data-msg", message);
        }
    })

    $(".forwardIcon").each((e, item) => {
        const getRowId = $(item).attr("data-id");
        if (getRowId == id) {
            $(item).attr("data-msg", message);
        }
    })

    $(".deleteMsgSingle").each((e, item) => {
        const getRowId = $(item).attr("data-id");
        if (getRowId == id) {
            $(item).attr("data-msg", message);
        }
    })
}

//File Select And Delete Code Start
$(".upload-file-input").on('click',()=>{
    let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image" src="./images/imagethumb2.png">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                </div>`;
    $("#fileUploadDiv").html(fileUploadDummyHtml);
    
    $("#fileUploadDiv").addClass("show");
    $("#vMessage").removeClass("show");
    $("#texAreaEditorDiv").addClass("d-none");
    // $("#fileUploadLoader").removeClass("d-none");
})

$(".upload-file-input").on('cancel',()=>{
    $("#vMessage").addClass("show");
    $("#texAreaEditorDiv").removeClass("d-none");
    $("#fileUploadDiv").removeClass("show");
    // $("#fileUploadLoader").addClass("d-none");
})

$(".upload-file-input").on('change', () => {
    ImageDataArr = [];
    $("#vMessage").removeClass("show");
    $("#texAreaEditorDiv").addClass("d-none");

    $("#fileUploadDiv").addClass("show");

    $("#fileUploadLoader").removeClass("d-none");
    
    $("#sendMessage").addClass("disabled");

    const fileInput = document.getElementById('fileInput');
    const files = fileInput.files;

    let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image" src="./images/imagethumb2.png">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                </div>`;
    $("#fileUploadDiv").html(fileUploadDummyHtml);

    $("#fileUploadLoader").removeClass("d-none");
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileNameNew = String(file.name).split(".");

        const reader = new FileReader();
        
        reader.onload = function (event) {
            const imageData = event.target.result;
            const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

            const img = new Image();
            img.src = imageData;

            if (ImageExtensionArr.includes(get_url_extension(file.name))) {
                img.onload = function () {
                    if (ImageExtensionArr.includes(get_url_extension(file.name))) {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        canvas.width = img.width * 1;
                        canvas.height = img.height * 1;
                        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                        const base64ImageData = canvas.toDataURL(file.type);

                        //Thumbnail Code
                        const targetWidth = 48;
                        const targetHeight = 48;
                        canvas.width = targetWidth;
                        canvas.height = targetHeight;
                        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
                        const base64Thumbnail = canvas.toDataURL(file.type);

                        const data = {
                            fileName: file.name,
                            imageData: base64ImageData,
                            imageDataThumb: base64Thumbnail,
                            type: file.type
                        };

                        ImageDataArr.push(data);

                        $(".plc-holder").addClass("d-none");

                        // <div class="d-flex align-items-center">
                        //     <div class="preview-container">
                        //         <img class="preview-image" src="${imageData}">
                        //     </div>
                        //     <div class="file-preview mb-0">${StringDisplLimit(fileNameNew[0],50)+"."+fileNameNew[1]}</div>
                        // </div>
                        
                        const fileHtml = `<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data">
                                            <div class="d-flex align-items-center">
                                                <div class="message-image-preview">
                                                    <img src="${base64Thumbnail}" alt="File">
                                                </div>
                                                <p class="mb-0 message">${StringDisplLimit(fileNameNew[0], 50) + "." + fileNameNew[1]}</p>
                                            </div>

                                            <a class="cursor-pointer close-reply clearImage" data-id="${file.name}"><i data-feather="x" class="feather-16"></i></a>
                                        </div>`;

                        $("#fileUploadDiv").append(fileHtml);
                        $("#demoFileUpload").remove();
                        $("#sendMessage").removeClass("disabled");
                        feather.replace();

                        const divLength=$(".teatarea-file-upload-data").length;
                        if(files.length==divLength){
                            $("#fileUploadLoader").addClass("d-none");
                        }
                    }
                };
            } else {

                const data = {
                    fileName: file.name,
                    imageData: imageData,
                    type: file.type,
                    imageDataThumb: ""
                };
                ImageDataArr.push(data);

                const fileNameNew = String(file.name).split(".");

                // <div class="d-flex align-items-center">
                //     <div class="preview-container">
                //         <img class="preview-image" src="./images/svgs/file.svg" alt="File">
                //     </div>
                //     <div class="file-preview mb-0">${StringDisplLimit(fileNameNew[0],50)+"."+fileNameNew[1]}</div>
                // </div>

                const fileHtml = `<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data">
                                    <div class="d-flex align-items-center">
                                        <div class="message-file-preview me-2">
                                            <img src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <p class="mb-0 message">${StringDisplLimit(fileNameNew[0], 50) + "." + fileNameNew[1]}</p>
                                    </div>
                                    <a class="cursor-pointer close-reply clearImage" data-id="${file.name}"><i data-feather="x" class="feather-16"></i></a>
                                </div>`;

                $("#fileUploadDiv").append(fileHtml);
                $("#demoFileUpload").remove();
                $("#sendMessage").removeClass("disabled");
                feather.replace();
               
                const divLength=$(".teatarea-file-upload-data").length;
                if(files.length==divLength){
                    $("#fileUploadLoader").addClass("d-none");
                }
            }

            $("#fileUploadButtton").addClass("disabled");
        };

        reader.readAsDataURL(file);
    }
        
    
    $(".teatarea-file-upload").addClass("show");
    $(".editor").removeClass("show");
    $(".type-link").addClass("d-none");
    $(".type-functions").removeClass("show");
    $(".emoji-link").addClass("d-none");
    $('.preview-container').css('display', 'block');
});

$(document).on("click", ".clearImage", (e) => {
    const fileName = $(e.currentTarget).attr("data-id");
    const vMessage=$("#vMessage").text();

    const fileListFilter = ImageDataArr.filter((curEle, index) => {
        return curEle.fileName != fileName
    })

    ImageDataArr = fileListFilter;

    $(e.currentTarget).closest(".teatarea-file-upload-data").fadeOut(300).remove();

    if (fileListFilter.length == 0) {
        $(".teatarea-file-upload").removeClass("show");
        $(".editor").addClass("show");

        $('.file-preview').text("");
        $(".type-link").removeClass("d-none");
        $(".emoji-link").removeClass("d-none");
        $("#sendMessage").addClass("disabled");

        $("#fileInput").val("");

        if(vMessage==""){
            $(".plc-holder").removeClass("d-none");
        }else{
            $(".plc-holder").addClass("d-none");
        }
        $("#texAreaEditorDiv").removeClass("d-none");

        $("#fileUploadButtton").removeClass("disabled");

        let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                    <a class="cursor-pointer close-reply"><i data-feather="x"
                                                            class="feather-16"></i></a>
                                                </div>`;
        
        $("#fileUploadDiv").html("");
    }
})
//File Select And Delete Code End


//Reply Message Code Start
$(document).on("click", ".cancelReply", () => {
    $(".textarea-reply-container").removeClass("show");
    if (ImageDataArr.length == 0) {
        $(".editor").addClass("show");
    }
    // $('.file-preview').text("");

    $(".textarea-reply-container").html("");

    $("#vReplyMsg").val("");
    $("#vReplyMsg_id").val("");
    $("#vReplyMsg_type").val("");
    $("#vReplyFileName").val("");
    $(".textarea-inner-container").removeClass("textareaReply");
  
    var node = document.getElementById('vMessage');
    focusAndPlaceCaretAtEnd(node);
    $(".floating-dd").removeClass("d-none");
})

$(document).on("click", ".replyIcon", (e) => {
    $(".textarea-reply-container").addClass("show");
    $(".teatarea-file-upload").removeClass("show");
    $("#fileInput").val("");
    ImageDataArr=[];

    let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                    <a class="cursor-pointer close-reply"><i data-feather="x"
                                                            class="feather-16"></i></a>
                                                </div>`;

    $("#fileUploadDiv").html(fileUploadDummyHtml);
    // $(".editor").removeClass("show");
    $(".textarea-inner-container").addClass("textareaReply");

    $("#texAreaEditorDiv").removeClass("d-none");
    $("#vMessage").addClass("show");
    $("#fileUploadButtton").removeClass("disabled");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");

    const getMainDivClass = $(e.currentTarget).closest(".chat-message-outer-container");
    const MainDivClassList = getMainDivClass[0].classList.value;

    let ReplyAuthName = "You";

    const dataId = $(e.currentTarget).attr('data-id');
    const dataMsg = $(e.currentTarget).attr('data-msg');
    const dataType = $(e.currentTarget).attr('data-type');
    const dataFileName = $(e.currentTarget).attr('data-filename');

    const vActiveGroupId = $("#vActiveGroupId").val();
    if(vActiveGroupId>0){
        const vReplyMsgId=String(dataId).split("_");
        const vChatUserListJson = $("#vChatUserListJson").val();
        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
            JSON.parse(vChatUserListJson).map((curEle, index) => {
                if(curEle.iUserId==vReplyMsgId[0]){
                    ReplyAuthName=curEle['vFullName'];
                }
            })
        } 
    }else{
        if (MainDivClassList.includes("recieve-message")) {
            ReplyAuthName = $("#activeChatName").text();
        }
    }

    $(".textarea-reply-container").html("");

    $("#vReplyMsg").val(String(dataMsg).trim());
    $("#vReplyMsg_id").val(dataId);
    $("#vReplyMsg_type").val(dataType);
    $("#vReplyFileName").val(dataFileName);;

    // vReplyMsg

    if (dataType == "image") {
        const imageArr = ["jpg", "png", "jpeg"];
        const filterExten = dataFileName != "" ? get_url_extension(String(dataFileName).trim()) : get_url_extension(String(dataMsg).trim());

        const type = String(dataMsg).trim().split(';')[0].split('/')[1];

        const fileNameNew = String(getFileName(dataFileName)).split(".")

        if (imageArr.includes("" + filterExten)) {
            if (String(dataMsg).trim().includes("base64,")) {
                let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        class="cursor-pointer close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-image-preview">
                                        <img src="${dataMsg}" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0], 100) + "." + fileNameNew[1]}</p>
                                </div>
                            </div>`;
                // let html = `<p>
                //                 <img src="${String(dataMsg).trim()}" style="width:40px; height:40px;" />
                //                 <i class="fa-solid fa-circle-xmark" id="cancelReply"></i>
                //             </p>`;
                //             $("#replyInputBox").html(html);
                $(".textarea-reply-container").html(html);
                feather.replace();
            } else {
                let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        class="cursor-pointer close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-image-preview">
                                        <img src="${API_URL + String(dataMsg).trim()}" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0], 100) + "." + fileNameNew[1]}</p>
                                </div>
                            </div>`;
                // let html = `<p>
                //                 <img src="<?= $API_URL ?>${String(dataMsg).trim()}" style="width:40px; height:40px;" />
                //                 <i class="fa-solid fa-circle-xmark" id="cancelReply"></i>
                //             </p>`;
                // $("#replyInputBox").html(html);
                $(".textarea-reply-container").html(html);
                feather.replace();
            }
        } else {
            let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        class="cursor-pointer close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-file-preview">
                                        <img src="./images/svgs/file.svg" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0], 100) + "." + fileNameNew[1]}</p>
                                </div>
                            </div>`;
            // let html = `<p><i class="fa-solid fa-file-arrow-down" aria-hidden="true"></i><i class="fa-solid fa-circle-xmark" id="cancelReply"></i></p>`;

            // $("#replyInputBox").html(html);
            $(".textarea-reply-container").html(html);
            feather.replace();
        }
    } else {

        let html = `<div class="textarea-reply-inner-container">
                        <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                class="cursor-pointer close-reply cancelReply"><i data-feather="x"
                                    class="feather-16"></i></a></p>
                        <div class="d-flex align-items-center">
                            <p class="mb-0 message msg-with-emoji">${htmlToPlainText(htmlDecode(dataMsg))}</p>
                        </div>
                    </div>`;
        // let html = `<p>${dataMsg} <i class="fa-solid fa-circle-xmark" id="cancelReply"></i></p>`;
        // $("#replyInputBox").html(html);
        $(".textarea-reply-container").html(html);
        feather.replace();
    }

    var node = document.getElementById('vMessage');
    focusAndPlaceCaretAtEnd(node);

    $(".floating-dd").addClass("d-none");
})

let isMultiSelect = 0;
$(document).on("click", ".selectMultiple", (e) => {
    const dataId = $(e.currentTarget).attr('data-id');
    const dataFrom = $(e.currentTarget).attr("data-from");

    const type = $(e.currentTarget).attr("data-type");
    const values = $(e.currentTarget).attr("data-msg");
    const isMyMessage = Number($(e.currentTarget).attr("data-from"));
    const messageDateTime = $(e.currentTarget).attr("data-time");
    const MsgId = $(e.currentTarget).attr("data-id");

    const vActiveGroupId=$("#vActiveGroupId").val();
    let isAdmin=0;
    let iLogginId=0;
    let isMember=0;
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLogginId=dd.iLoginId;
    }
    
    const vChatGroupListJson = $("#vChatGroupListJson").val();
    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
        JSON.parse(vChatGroupListJson).map((curEle,index)=>{
            if(curEle.iGroupId==vActiveGroupId && curEle.iCreatedBy==iLogginId){
                isAdmin=1;
            }

            if(curEle.iGroupId==vActiveGroupId){
                const tGroupIds=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(","):[]

                if(tGroupIds.includes(""+iLogginId)){
                    isMember=1;
                }else{
                    isMember=0;
                }
            }
        })
    }

    if(vActiveGroupId==0 || vActiveGroupId==""){
        isMember=1;
    }

    console.log("first check",isMember)

    // $(".forwardChbx").prop("checked",false);
    $("#iTotalMessageSelect").text("1 Selected");
    $(".forwardChbx").removeClass("d-none");
    $(".chat-message-outer-container").addClass("select-message");

    $("#" + dataId).prop("checked", true);
    $(".floating-dd").addClass("d-none");

    $("#MultipleSelectDiv").removeClass("d-none");
    $("#topHeaderActiveArea").addClass("d-none");

    if (dataFrom > 0 && isMember) {
        $("#forwardMultiple").removeClass("disabled");
        $("#MultipleMsgDelete").removeClass("disabled");
    } else {
        $("#forwardMultiple").removeClass("disabled");
        $("#MultipleMsgDelete").addClass("disabled");
    }

    MultipleSelectMsg = [];
    MultipleSelectDel = [];
    MultipleMessageDeleIds = [];

    MultipleSelectMsg.push({
        type: type,
        values: values
    });

    if ((isMyMessage > 0 && isMember) || isAdmin==1) {
        MultipleSelectDel.push(MsgId);
        MultipleMessageDeleIds.push(MsgId);
    }

    if (type == "image") {
        $("#downloadFiles").removeClass("disabled");
    } else {
        $("#downloadFiles").addClass("disabled");
    }

    if(isAdmin==1){
        $("#MultipleMsgDelete").removeClass("disabled");
    }
})

let sendDate="";
$(document).keyup(function (e) {

    if (e.keyCode == 13 && !e.shiftKey) {
        const isMesage = $("#vMessage").text();

        if (String(isMesage).trim() != "" || ImageDataArr.length || $("#vMessage:has(img)").length) {
            if(sendDate==""){
                sendDate=new Date();
                sendMessage();
            }else{
                var startDate = sendDate;
                // Do your operations
                var endDate   = new Date();
                var seconds = (endDate.getTime() - startDate.getTime()) / 1000;
                if(seconds>1){
                    sendDate=new Date();
                    sendMessage();
                }
                // else{
                //     setTimeout(() => {
                //         sendMessage();
                //     }, 1000);
                // }
            }
        }
    }

});


//Forward Message Single Code Start 
let MultipleSelectMsg = [];
let MultipleSelectDel = [];
let MultipleMessageDeleIds = [];

$(document).on("change", ".forwardChbx", () => {
    MultipleSelectMsg = [];
    MultipleSelectDel = [];
    MultipleMessageDeleIds = [];

    let isTotalSelectedMsg = 0;
    let isNotMyMessage = 0;
    let isAllImages = 1;

    const vActiveGroupId=$("#vActiveGroupId").val();
    let isAdmin=0;
    let iLogginId=0;
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLogginId=dd.iLoginId;
    }
    let isMember=0;
    const vChatGroupListJson = $("#vChatGroupListJson").val();
    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
        JSON.parse(vChatGroupListJson).map((curEle,index)=>{
            if(curEle.iGroupId==vActiveGroupId && curEle.iCreatedBy==iLogginId){
                isAdmin=1;
            }

            if(curEle.iGroupId==vActiveGroupId){
                const tGroupIds=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(","):[]

                if(tGroupIds.includes(""+iLogginId)){
                    isMember=1;
                }else{
                    isMember=0;
                }
            }
        })
    }

    if(vActiveGroupId=="" || vActiveGroupId==0){
        isMember=1;
    }

    document.querySelectorAll('.forwardChbx').forEach(function (e) {
        const type = $(e).attr("data-type");
        const values = $(e).val();
        const isMyMessage = Number($(e).attr("data-from"));
        const messageDateTime = $(e).attr("data-date");
        const MsgId = $(e).attr("id");

        if (e.checked) {
            if (type == "text") {
                isAllImages = 0;
            }
            MultipleSelectMsg.push({
                type: type,
                values: values
            });
            isTotalSelectedMsg++;

            if ((isMyMessage > 0 && isMember) || isAdmin==1) {
                // if (isMyMessage == 0) {
                MultipleSelectDel.push(MsgId);
                MultipleMessageDeleIds.push(MsgId);
            } else {
                isNotMyMessage = 1;
            }

            // console.log("MultipleSelectMsg",MultipleSelectMsg)
        }
    });

    $("#iTotalMessageSelect").text(isTotalSelectedMsg + " Selected");

    if (isAllImages == 1 && isTotalSelectedMsg > 0) {
        $("#downloadFiles").removeClass("disabled");
    } else {
        $("#downloadFiles").addClass("disabled");
    }
    // if (isTotalSelectedMsg > 0) {
    //     $("#MultipleSelectDiv").removeClass("d-none");
    //     $("#topHeaderActiveArea").addClass("d-none");
    // } else {
    //     $("#MultipleSelectDiv").addClass("d-none");
    //     $("#topHeaderActiveArea").removeClass("d-none");
    // }

    if (isTotalSelectedMsg > 0) {
        $("#forwardMultiple").removeClass("disabled");
        if (isNotMyMessage == 0 || isAdmin==1) {
            $("#MultipleMsgDelete").removeClass("disabled");
        } else {
            $("#MultipleMsgDelete").addClass("disabled");
        }
    } else {
        $("#MultipleMsgDelete").addClass("disabled");
        $("#forwardMultiple").addClass("disabled");
    }

    // console.log("MultipleSelectDel=>",MultipleSelectDel)
    // console.log("MultipleMessageDeleIds=>",MultipleMessageDeleIds)
});


$(document).on("click", "#downloadFiles", () => {
    MultipleSelectMsg.map((curE, eindex) => {
        const path = API_URL + String(curE.values).trim();
        var filename = path.split('/').pop();
        download(path, filename);
    })
})

function forwardHtmlList(vSearchStr="") {
    const vChatUserListJson = $("#vConvertionChatArr").val();
    const vChatGroupListJson = $("#vChatGroupListJson").val();

    const vSearcString=String(vSearchStr).toLocaleLowerCase();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
   
        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
            JSON.parse(vChatUserListJson).map((curEle, index) => {
                let profilePic = curEle.vProfilePic;
                if (curEle.vProfilePic == "") {
                    colorOption.map((curEle2, index) => {
                        if (curEle2.iColorId == curEle.iColorOption) {
                            profilePic = curEle2.vColorPick
                        }
                    })
                }

                const vFullName=String(curEle.vFullName).toLocaleLowerCase();
                const matchStr=vSearcString!=""?vFullName.includes(""+vSearcString):1;

                if(curEle.isStartChat==1 && matchStr && curEle.eStatus=='y'){
                    const htmlRows = `<li>
                                    <a class="cursor-pointer chat-list">
                                        <label class="d-flex align-items-center justify-content-between form-check ps-0" for="vUser_${curEle.iUserId}">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3">
                                                    <svg role="none" viewBox="0 0 96 96">
                                                        <mask id="profile-image">
                                                            <circle fill="white" cx="48" cy="48" r="48">
                                                            </circle>
                                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                                            </circle>
                                                        </mask>
                                                        <g mask="url(#profile-image)">
                                                            <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="${profilePic}">
                                                            </image>
                                                        </g>
                                                    </svg>
                                                    <div class="${curEle.iStatus == 0 ? 'offline' : 'online'}"></div>
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name">${curEle.vFullName} </h5>
                                                    <P class="user-profile-activity">${curEle.iStatus == 0 ? 'Offline' : 'Online'}</P>
                                                </div>
                                            </div>
    
                                            <span><input class="form-check-input vForwardUsers" type="checkbox" value="${curEle.iUserId}" id="vUser_${curEle.iUserId}" ${vUserForwrdSelect.includes(""+curEle.iUserId)?'checked':''} ></span>
                                        </label>
                                    </a>
                                </li>`
    
                    $("#forwrdModalGrpMembList").append(htmlRows);
                }
            })
        }

        if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {

            JSON.parse(vChatGroupListJson).map((curEle, index) => {
                // const vGroupImage=(curEle?.vGroupImage && curEle?.vGroupImage!="")?curEle.vGroupImage:"images/profile/group-profile.svg";

                let vGroupImage = curEle.vGroupImage;
                if (curEle.vGroupImage == "") {
                    GroupColorOption.map((curEle2, index) => {
                        if (curEle2.iColorId == curEle.iColorOption) {
                            vGroupImage = curEle2.vColorPick
                        }
                    })
                }

                const vGroupName=String(curEle.vGroupName).toLocaleLowerCase();
                const vMatchGroupName=vSearcString!=""?vGroupName.includes(""+vSearcString):1;

                const vGroupMember=String(curEle.tGroupUsers).split(",");
                if((vGroupMember.includes(""+dd.iLoginId) || curEle.iCreatedBy==dd.iLoginId) && vMatchGroupName){
                    const htmlRows = `<li>
                                    <a class="cursor-pointer chat-list">
                                        <label class="d-flex align-items-center justify-content-between form-check ps-0" for="vGroup_${curEle.iGroupId}">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3">
                                                    <img class="rounded-2" src="${vGroupImage}" alt="group-profile">
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name">${curEle.vGroupName} </h5>
                                                </div>
                                            </div>
    
                                            <span><input class="form-check-input vForwardUsers" type="checkbox" value="${curEle.iGroupId}" id="vGroup_${curEle.iGroupId}" ${vGroupForwrdSelect.includes(""+curEle.iGroupId)?'checked':''}></span>
                                        </label>
                                    </a>
                                </li>`

                    $("#forwrdModalGrpMembList").append(htmlRows);
                }
            })
        }
    }

}

$(document).on("click", ".forwardIcon", (e) => {
    const dataId = $(e.currentTarget).attr('data-id');
    const dataMsg = $(e.currentTarget).attr('data-msg');
    const dataType = $(e.currentTarget).attr('data-type');

    vUserForwrdSelect = [];
    vGroupForwrdSelect = [];

    $("#forwrdModalGrpMembList").html("");
    $("#ForwardSelTags").html("");
    $("#submitForwardForm").addClass("d-none");

    $("#iActiveMessageId").val(dataId);
    $("#vActiveMessage").val(dataMsg);
    $("#vForwardDataType").val(dataType);

    forwardHtmlList();
});


$(document).on("input","#vSearchUserForward",(e)=>{
    $("#forwrdModalGrpMembList").html("");
    const searchData=String(e.target.value).trim();
    forwardHtmlList(searchData);
})

let vUserForwrdSelect = [];
let vGroupForwrdSelect = [];
$(document).on("click", ".vForwardUsers", (e) => {
    const idName = e.target.id;

    if (idName.includes("vUser_")) {
        if (e.target.checked) {
            $(e.currentTarget).closest(".chat-list").addClass("chat-active");
            vUserForwrdSelect.push(e.target.value);
            ForwardToSelectedData(vUserForwrdSelect, vGroupForwrdSelect);
        } else {
            const filterUser = vUserForwrdSelect.filter((curEle, index) => {
                return Number(curEle) != Number(e.target.value)
            })

            vUserForwrdSelect = filterUser;
            $(e.currentTarget).closest(".chat-list").removeClass("chat-active");
            ForwardToSelectedData(vUserForwrdSelect, vGroupForwrdSelect);
        }
    } else {
        if (e.target.checked) {
            $(e.currentTarget).closest(".chat-list").addClass("chat-active");
            vGroupForwrdSelect.push(e.target.value);
            ForwardToSelectedData(vUserForwrdSelect, vGroupForwrdSelect);
        } else {
            const filterUser = vGroupForwrdSelect.filter((curEle, index) => {
                return Number(curEle) != Number(e.target.value)
            })

            vGroupForwrdSelect = filterUser;
            $(e.currentTarget).closest(".chat-list").removeClass("chat-active");
            ForwardToSelectedData(vUserForwrdSelect, vGroupForwrdSelect);
        }
    }


    if (vUserForwrdSelect.length == 0 && vGroupForwrdSelect.length == 0) {
        $("#submitForwardForm").addClass("d-none");
    } else {
        $("#submitForwardForm").removeClass("d-none");
    }
})

function ForwardToSelectedData(selectedUser, selectedGroup) {
    const vChatUserListJson = $("#vChatUserListJson").val();
    const vChatGroupListJson = $("#vChatGroupListJson").val();

    $("#ForwardSelTags").html("");

    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
        JSON.parse(vChatUserListJson).map((curEle, index) => {
            if (selectedUser.includes("" + curEle.iUserId)) {
                $("#ForwardSelTags").append(
                    `<li id="forward_user_tag_${curEle.iUserId}">
                        <div class="custom-badge">
                            <p class="user-name">${curEle.vFullName}</p>
                            <a class="cursor-pointer remove-user remvForwardTag" data-type="user" data-id="${curEle.iUserId}"><i data-feather="x" class="feather-18"></i></a>
                        </div>
                    </li>`
                );
                feather.replace();
            }
        })
    }

    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
        JSON.parse(vChatGroupListJson).map((curEle, index) => {
            if (selectedGroup.includes("" + curEle.iGroupId)) {
                $("#ForwardSelTags").append(
                    `<li id="forward_user_tag_${curEle.iGroupId}">
                        <div class="custom-badge">
                            <p class="user-name">${curEle.vGroupName}</p>
                            <a class="cursor-pointer remove-user remvForwardTag" data-type="group" data-id="${curEle.iGroupId}"><i data-feather="x" class="feather-18"></i></a>
                        </div>
                    </li>`
                );
                feather.replace();
            }
        })
    }
}

$(document).on("click", ".remvForwardTag", (e) => {
    const iUserId = $(e.currentTarget).attr("data-id");
    const isType = $(e.currentTarget).attr("data-type");

    if (isType == "user") {
        const filterUser = vUserForwrdSelect.filter((curEle, index) => {
            return Number(curEle) != Number(iUserId)
        })

        vUserForwrdSelect = filterUser;

        $("#forward_user_tag_" + iUserId).remove();
        $("#vUser_" + iUserId).prop("checked", false);

        $("#vUser_" + iUserId).closest(".chat-list").removeClass("chat-active");
    } else {
        const filterUser = vGroupForwrdSelect.filter((curEle, index) => {
            return Number(curEle) != Number(iUserId)
        })

        vGroupForwrdSelect = filterUser;

        $("#forward_user_tag_" + iUserId).remove();
        $("#vGroup_" + iUserId).prop("checked", false);

        $("#vGroup_" + iUserId).closest(".chat-list").removeClass("chat-active");
    }

    if (vUserForwrdSelect.length == 0 && vGroupForwrdSelect.length == 0) {
        $("#submitForwardForm").addClass("d-none");
    } else {
        $("#submitForwardForm").removeClass("d-none");
    }
})

$(document).on("click", "#submitForwardForm", (e) => {
    e.preventDefault();
    const iActiveMessageId = $("#iActiveMessageId").val();
    const vActiveMessage = $("#vActiveMessage").val();
    const vForwardDataType = $("#vForwardDataType").val();
    const vActiveGroupId = $("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    const vActiveUserId=$("#vActiveUserId").val();

    $("#fileInput").val("");
    ImageDataArr=[];

    let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                <div class="d-flex align-items-center">
                                    <div class="preview-container position-relative">
                                        <img class="preview-image">
                                    </div>
                                    <div class="file-preview mb-0">No file selected</div>
                                </div>
                                <a class="cursor-pointer close-reply"><i data-feather="x" class="feather-16"></i></a>
                            </div>`;
    $("#fileUploadDiv").html(fileUploadDummyHtml);
    // $(".editor").removeClass("show");
    $(".textarea-inner-container").addClass("textareaReply");

    $("#texAreaEditorDiv").removeClass("d-none");
    $("#vMessage").addClass("show");
    $("#fileUploadButtton").removeClass("disabled");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");
    $(".plc-holder").removeClass("d-none");

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const totalCheckedUser=$('input:checkbox.vForwardUsers').length;
        // console.log("totalCheckedUser=>",totalCheckedUser)
        let iForwrdUserCnt=0;
        $('input:checkbox.vForwardUsers').each(function (e, item) {
            iForwrdUserCnt++;
            const type = $(item).attr("id");
            var sThisVal = (this.checked ? $(this).val() : "");
            const splitStr = String(type).split("_");

            function refreshMessage(){
                getGroupList();
                getUserList();

                if(vActiveGroupId>0){
                    if(activeTab == "User"){
                        activeTab="Group";
                        $("#userGroup").click();
                    }
                    $(".vGroupIds").each((e, item) => {
                        const getRowId = $(item).attr("data-id");
                        if (getRowId == vActiveGroupId) {
                            $(item).click();
                        }
                    })
                }else if(vActiveUserId>0){
                    if(activeTab == "Group"){
                        activeTab="User";
                        $("#userChat").click();
                    }
                    $("#vUserIdsCls_"+vActiveUserId).click();
                }
            }

            if (Number(sThisVal) > 0) {
                if (splitStr[0] == "vGroup") {
                    if (Number(splitStr[1]) > 0) {

                        let vMembersList="";
                        if (vChatGroupListJsonArr != "" && JSON.parse(vChatGroupListJsonArr).length) {
                            const filterGroupDetail=JSON.parse(vChatGroupListJsonArr).filter((curEle,index)=>{
                                return curEle.iGroupId==splitStr[1];
                            });
    
                            if(filterGroupDetail.length>0){
                                vMembersList=filterGroupDetail[0]['tGroupUsers'];
                            }
                        }

                        if (MultipleSelectMsg.length) {
                            
                            async function processArrayWithDelay(array, callback, delayTime) {
                                for (let i = 0; i < array.length; i++) {
                                    //Logic Code
                                    const curEle = array[i];
                                    
                                    socket.emit('send_grp_message', {
                                        receiverChatID: splitStr[1],
                                        senderChatID: dd['iLoginId'],
                                        content: curEle.type == "text" ? curEle.values : "vImages => " + String(curEle.values).trim(),
                                        ImageDataArr: [],
                                        vReplyMsg: "",
                                        vReplyMsg_id: "",
                                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                                        isGreetingMsg: 0,
                                        vMembersList:vMembersList,
                                        vGroupMessageType:"",
                                        isForwardMsg:1,
                                        isDeleteprofile:0,
                                        iRequestMsg:0,
                                        vDeleteMemberId:"",
                                        vNewAdminId:"",
                                        RequestMemberId:""
                                    });

                                    refreshMessage();

                                    await delayTimeWait(delayTime);
                                    setTimeout(callback, 500);
                                }
                            }
                            
                            async function processItem(item) {
                                await delayTimeWait(1000);
                                return item * 1;
                            }
                            
                            processArrayWithDelay(MultipleSelectMsg, processItem, 1000)
                            .then(results => {
                                console.log('All Message sent');
                            });

                        } else {
                            socket.emit('send_grp_message', {
                                receiverChatID: splitStr[1],
                                senderChatID: dd['iLoginId'],
                                content: vForwardDataType == "text" ? vActiveMessage : "vImages => " + String(vActiveMessage).trim(),
                                ImageDataArr: [],
                                vReplyMsg: "",
                                vReplyMsg_id: "",
                                id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                                isGreetingMsg: 0,
                                vMembersList:vMembersList,
                                vGroupMessageType:"",
                                isForwardMsg:1,
                                isDeleteprofile:0,
                                iRequestMsg:0,
                                vDeleteMemberId:"",
                                vNewAdminId:"",
                                RequestMemberId:""
                            });

                            refreshMessage();
                        }
                    }
                } else {
                    if (Number(splitStr[1]) > 0) {
                        if (MultipleSelectMsg.length) {
                            
                            async function processArrayWithDelay(array, callback, delayTime) {
                                for (let i = 0; i < array.length; i++) {
                                    //Logic Code
                                    const curEle = array[i];
                                    
                                    socket.emit('send_message', {
                                        receiverChatID: splitStr[1],
                                        senderChatID: dd['iLoginId'],
                                        content: curEle.type == "text" ? curEle.values : "vImages => " + String(curEle.values).trim(),
                                        ImageDataArr: [],
                                        vReplyMsg: "",
                                        vReplyMsg_id: "",
                                        id: dd['iLoginId'] + "_" + sThisVal + "_" + Date.parse(new Date()),
                                        iRequestMsg: 0,
                                        isForwardMsg:1,
                                        isDeleteprofile:0
                                    });
                            
                                    refreshMessage();
                                    
                                    await delayTimeWait(delayTime);
                                    setTimeout(callback, 500);
                                }
                            }
                            
                            async function processItem(item) {
                                await delayTimeWait(1000);
                                return item * 1;
                            }
                            
                            processArrayWithDelay(MultipleSelectMsg, processItem, 1000)
                            .then(results => {
                                console.log('All Message sent');
                            });

                            // MultipleSelectMsg.map((curEle, index) => {
                                
                            // })
                        } else {
                            socket.emit('send_message', {
                                receiverChatID: splitStr[1],
                                senderChatID: dd['iLoginId'],
                                content: vForwardDataType == "text" ? vActiveMessage : "vImages => " + String(vActiveMessage).trim(),
                                ImageDataArr: [],
                                vReplyMsg: "",
                                vReplyMsg_id: "",
                                id: dd['iLoginId'] + "_" + sThisVal + "_" + Date.parse(new Date()),
                                iRequestMsg: 0,
                                isForwardMsg:1,
                                isDeleteprofile:0
                            });

                            refreshMessage();
                        }

                        
                    }
                }

            }
        });

        isMultiSelect = 0;
        $(".chat-message-outer-container").removeClass("select-message selected");
        MultipleSelectMsg = [];
        MultipleSelectDel = [];
        MultipleMessageDeleIds = [];

        $(".forwardChbx").each((e, item) => {
            $(item).prop("checked", false)
        })
    }

    $('#forwardModal').modal('toggle');
    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");
    clearMultipleSelect();
})
//Forward Message Single Code End


//Forward Multiple Message Code Start 
$(document).on("click", "#forwardMultiple", () => {
    vUserForwrdSelect = [];
    vGroupForwrdSelect = [];

    $("#forwrdModalGrpMembList").html("");
    $("#ForwardSelTags").html("");
    $("#submitForwardForm").addClass("d-none");

    forwardHtmlList();
})
//Forward Multiple Message Code End


// MultipleSelectDel
$(document).on("click", "#msgMultiDelConfirmModalClose,#msgMultiDelConfirmModalCancel", () => {
    $("#msgMultiDelConfirmModal").modal("toggle");
})

$(document).on("click", "#msgMultiDelConfirmModalSubmit", () => {
    multipleMsgDel();
    $("#msgMultiDelConfirmModal").modal("toggle");
})

const multipleMsgDel = () => {
    const vActiveGroupId = $("#vActiveGroupId").val();
    const vActiveUserId = $("#vActiveUserId").val();

    
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        
        let isAdmin=0;
        if(vActiveGroupId>0){
            let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
            if (vChatGroupListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatGroupListJsonArr);
                const filterGroupDat=chatGroupList.filter((curE,index)=>{
                    return curE.iGroupId==vActiveGroupId
                })
        
                if(filterGroupDat.length && filterGroupDat[0]['iCreatedBy']==dd.iLoginId){
                    isAdmin=1;
                }
            }
        }

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'MessageDelete',
            data: {
                tToken: dd.tToken,
                MultipleSelectDel,
                vActiveGroupId,
                vActiveUserId,
                isAdmin:isAdmin
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    // Message deleted by its author
                    MultipleMessageDeleIds.map((curEle, index) => {
                        const mesgDate = $("#" + curEle).attr("data-date");

                        let html = deleteMessageHtml(mesgDate, 1,1,isAdmin);

                        $("#" + curEle).closest(".chat-message-outer-container").removeClass("send-message");
                        $("#" + curEle).closest(".chat-message-outer-container").addClass("recieve-message");
                        $("#" + curEle).closest(".chat-message-outer-container").removeClass("select-message");
                        $("#" + curEle).closest(".chat-message-outer-container").html(html);

                        socket.emit('delete_message', {
                            content: curEle,
                            vActiveGroupId,
                            vActiveUserId,
                            tToken: dd.tToken,
                            isAdmin:isAdmin
                        });
                    })

                    clearMultipleSelect();
                    MultipleSelectDel = [];
                }
            }
        })
    }
}

$(document).on("click", "#MultipleMsgDelete", () => {
    $("#msgMultiDelConfirmModal").modal("toggle");
})

function clearMultipleSelect() {
    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");
    isMultiSelect = 0;
    $(".chat-message-outer-container").removeClass("select-message selected");
    MultipleSelectMsg = [];
    MultipleSelectDel = [];
    MultipleMessageDeleIds = [];

    $(".forwardChbx").each((e, item) => {
        $(item).prop("checked", false)
    })
    $(".floating-dd").removeClass("d-none");
}

$(document).on("click", "#MultipleMsgCancel", () => {
    clearMultipleSelect();
    $(".floating-dd").removeClass("d-none");
})


const SingleMessageDeleteApi = () => {
    MultipleSelectDel.push(deleteMsgId);
    MultipleMessageDeleIds.push(deleteMsgId);

    const vActiveGroupId = $("#vActiveGroupId").val();
    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        
        let isAdmin=0;
        if(vActiveGroupId>0){
            let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
            if (vChatGroupListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatGroupListJsonArr);
                const filterGroupDat=chatGroupList.filter((curE,index)=>{
                    return curE.iGroupId==vActiveGroupId
                })
        
                if(filterGroupDat.length && filterGroupDat[0]['iCreatedBy']==dd.iLoginId){
                    isAdmin=1;
                }
            }
        }

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'MessageDelete',
            data: {
                tToken: dd.tToken,
                MultipleSelectDel,
                vActiveGroupId,
                vActiveUserId,
                MultipleMessageDeleIds,
                isAdmin:isAdmin
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    // Message deleted by its author
                    MultipleMessageDeleIds.map((curEle, index) => {

                        let html = deleteMessageHtml(deleteMsg, 1,1,isAdmin);

                        $("#" + curEle).closest(".chat-message-outer-container").removeClass("send-message");
                        $("#" + curEle).closest(".chat-message-outer-container").addClass("recieve-message");
                        $("#" + curEle).closest(".chat-message-outer-container").removeClass("select-message");
                        $("#" + curEle).closest(".chat-message-outer-container").html(html);

                        socket.emit('delete_message', {
                            content: curEle,
                            vActiveGroupId,
                            vActiveUserId,
                            tToken: dd.tToken,
                            isAdmin:isAdmin
                        });

                        deleteMsg = "";
                        deleteMsgId = "";
                    })

                    clearMultipleSelect();
                    MultipleSelectDel = [];
                }
            }
        })
    }
}

//Single Message Delete Code Start
let deleteMsg = "";
let deleteMsgId = "';"
$(document).on("click", ".deleteMsgSingle", (e) => {
    deleteMsg = "";
    deleteMsgId = "";

    const dateMsg = $(e.currentTarget).attr("data-time");
    const dataId = $(e.currentTarget).attr("data-id");
    deleteMsg = dateMsg;
    deleteMsgId = dataId;

    $("#msgDelConfirmModal").modal("toggle");
})


$(document).on("click", "#msgDelConfirmModalClose,#msgDelConfirmModalCancel", () => {
    $("#msgDelConfirmModal").modal("toggle");
    deleteMsg = "";
    deleteMsgId = "";
})

$(document).on("click", "#msgDelConfirmModalSubmit", () => {
    SingleMessageDeleteApi();
    $("#msgDelConfirmModal").modal("toggle");
})
//Single Message Delete Code End

//Group Chat Start Code
const getGroupChatHtml = (curEle, id, iUserIdSelect, senderImageHtml, replyHtml, imageHtml, created_at, isSend, vUserName, isEdit, isDeleted, isImage = "",isAdmin=0,isForwardMsg=0) => {

    const isImageOrHtml = isImage != "" ? imageHtml : `<div class="mb-0 message-text" id="msg_${id}">${htmlDecode(curEle)}</div>`;
    const floatingDropHtml = isImage != "" ? floatingDrop(id, curEle, "image", created_at, isSend, curEle) : floatingDrop(id, curEle, "text", created_at, isSend);

    let vRecieveHtmlProfile = senderImageHtml;
    if (senderImageHtml == "") {
        // const filterData=
        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

            ChatUserListArr.map((curEl3, index3) => {
                if (curEl3.iUserId == iUserIdSelect) {
                    colorOption.map((curEle2, index) => {
                        if (curEle2.iColorId == curEl3.iColorOption) {
                            vRecieveHtmlProfile = curEle2.vColorPick
                        }
                    })
                }
            })
        }
    }

    let totalForwardCheck=0;
    $(".forwardChbx").each(function () {
        if(this.checked){
            totalForwardCheck++;
        }
    });


    if (isDeleted == 1) {
        return deleteMessageHtml(created_at, isSend,0,isAdmin);
    } else {
        return `<div class="chat-message-outer-container ${isSend == 1 ? 'send-message' : 'recieve-message'} message-reply read  ${totalForwardCheck>0?'select-message':''}">
                    <div class="selection">
                        <input class="form-check-input forwardChbx ${totalForwardCheck==0?'d-none':''}" data-from="${isSend}" type="checkbox" id="${id}" data-date="${created_at}" value='${curEle}' data-type="${isImage != "" ? "image" : "text"}">
                    </div>
                    <div class="chat-message-inner-container">
                        <div class="chat-message-container">
                            <div class="main-message">
                                <img src="${vRecieveHtmlProfile}" class="chat-message-profile ${isSend == 1 ? 'sender_chat_profile' : 'receive_chat_profile'}" data-iuserid="${iUserIdSelect}" alt="chat-message-profile">
                                <div>
                                    <div class="chat-message-alignment">
                                        <div class="chat-message">
                                            ${replyHtml}
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    ${isImageOrHtml}
                                                </div>
                                                ${floatingDropHtml}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center message-author">
                                        <p class="message-droper-name">${vUserName}</p>
                                        <p class="message-drop-time">${timestampToAMPM("" + created_at)}</p>
                                        <p class="message-drop-time ${isEdit == 1 ? '' : 'd-none'} edited_flag" id="edit_${id}">Edited</p>
                                        <p class="message-drop-time ${isEdit == 0 && isForwardMsg == 1 ? '' : 'd-none'} edited_flag" id="forawrd_${id}">Forwarded</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`
    }
}

function GetGroupMessage(dd, iGroupId, filterDateStrVar, isSecond = 0) {
    const vChatUserListJson = JSON.parse($("#vChatUserListJson").val());

    let isAdmin=0;
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);
        const filterGroupDat=chatGroupList.filter((curE,index)=>{
            return curE.iGroupId==iGroupId
        })

        if(filterGroupDat.length && filterGroupDat[0]['iCreatedBy']==dd.iLoginId){
            isAdmin=1;
        }

        if(filterGroupDat.length){
            const MemberListArr=String(filterGroupDat[0]['tGroupUsers']).split(",");
            if(MemberListArr.includes(""+dd.iLoginId) || isAdmin){
                $("#TextEditorArea").removeClass("d-none");
            }else{
                $("#TextEditorArea").addClass("d-none");
            }

            const filterTotalGrpMemb=MemberListArr.filter(c=>c);
            if(filterTotalGrpMemb.length){
                $("#vExitGroup").removeClass("disabled");
            }else{
                $("#vExitGroup").addClass("disabled");
            }
        }
    }

    const vUserName=$("#vUserName").text();
    
    $.ajax({
        type: 'POST',
        dataType: "JSON",
        async: false,
        url: API_URL + 'GetGrpMessage',
        data: {
            tToken: dd.tToken,
            iGroupId: iGroupId,
            filterDateStr: filterDateStrVar,
            isAdmin
        },
        success: function (data, status, xhr) {
            if (data.status == 200) {

                JSON.parse(data.data).map((curEle2, index) => {

                    // console.log("curEle2",curEle2);

                    if (curEle2.isGreetingMsg > 0) {
                        let newMemberName="";
                        let adminName="";
                        
                        const newMemberArr=String(curEle2.vMemeberList).split(",");
                        newMemberArr.pop();
                        const vChatUserListJson = $("#vChatUserListJson").val();
                        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                            const dataUserList=JSON.parse(vChatUserListJson);

                            if(curEle2.iFromUserId==dd.iLoginId){
                                adminName=vUserName;
                            }

                            newMemberArr.map((curEle,index)=>{
                                const dataUserListFilter=dataUserList.filter((curEle3,index2)=>{
                                    if(curEle2.iFromUserId==curEle3.iUserId){
                                        adminName=curEle3.vFullName;
                                    }
                                    return curEle3.iUserId==curEle && curEle2.iFromUserId!=curEle3.iUserId
                                })

                                if(dataUserListFilter.length){
                                    if(index==0){
                                        newMemberName=dataUserListFilter[0]['vFullName'];
                                    }else if(newMemberArr.length==Number(index)+1){
                                        newMemberName+=" and "+dataUserListFilter[0]['vFullName'];
                                    }else{
                                        newMemberName+=", "+dataUserListFilter[0]['vFullName'];
                                    }
                                }
                            })
                        }

                        dateTimeLineAdd(curEle2.created_at);

                        const newMemberArrData=newMemberArr.filter(c=>c);
                        let isAddedNames=`<br/>${adminName} (group admin) added ${newMemberName}.`;
                        if(newMemberArrData.length==0){
                            isAddedNames="";
                        }

                        let html = `<div class="chat-message-outer-container recieve-message unread message-create-group">
                                        <div class="chat-message-inner-container">
                                            <div class="chat-message-container">
                                                <div class="d-flex">
                                                    <img src="images/svgs/message-create-group.svg" class="chat-message-profile"
                                                        alt="chat-message-profile">
                                                    <div class="main-message message-create-group">
                                                        <div class="chat-message-alignment">
                                                            <div class="chat-message">
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center message-author">
                                                            <p class="message-droper-name">Greetings! New group is created. ${isAddedNames}</p>
                                                            <p class="message-drop-time">${timestampToAMPM(curEle2.created_at)}</p>
                                                            <div class="message-status"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;

                        $("#MessageList").append(html);

                        scrollToBottom();
                        feather.replace();
                        dynamicWithlabel();
                    }else if(curEle2?.iRequestMsg && curEle2.iRequestMsg > 0){
                        dateTimeLineAdd(curEle2.created_at);
                        let html = "";

                        if(curEle2?.iRequestMsg==1){
                            if(curEle2.iFromUserId==dd.iLoginId){
                                const vMemeberList=curEle2?.RequestMemberId;
                                // const vMemeberList=curEle2?.vMemeberList==""?curEle2.vCancelUserId:curEle2?.vMemeberList;
                                html=GroupChatRequestSendHtml(timestampToAMPM(curEle2.created_at), curEle2.id,vMemeberList)
                            }else{
                                if(curEle2.vMemeberList!=dd.iLoginId){
                                    html=GrpChatRequesHtml(curEle2);
                                    // console.log("curEle2",curEle2)
                                    // const vMemeberList=curEle2?.RequestMemberId;
                                    // html=GroupChatRequestSendHtml(timestampToAMPM(curEle2.created_at), curEle2.id,vMemeberList)
                                }
                            }
                            // if(isAdmin){
                            // }else{
                            //     const AssignMember=curEle2?.vMemeberList;
                            //     console.log("AssignMember",curEle2)
                            // }
                        }else if(curEle2.iRequestMsg==2){
                            if(isAdmin){
                                if(curEle2.iFromUserId==dd.iLoginId){
                                    html=GroupChatRequestSendHtml(timestampToAMPM(curEle2.created_at), curEle2.id,curEle2.vMemeberList);
                                }
                            }else{
                                html=GroupChatRequestAcceptHtml(timestampToAMPM(curEle2.created_at), curEle2.id,curEle2,dd.iLoginId,isAdmin);
                            }
                        }else if(curEle2.iRequestMsg==3){
                            html=GrpChatRequestDeclineHtml(timestampToAMPM(curEle2.created_at), curEle2.iFromUserId,0,isAdmin);
                        }else if(curEle2.iRequestMsg==4){
                            if(isAdmin){
                                if(curEle2.iFromUserId==dd.iLoginId){
                                    html=GrpChatRequestCancelHtml(timestampToAMPM(curEle2.created_at),curEle2.vMemeberList,0,isAdmin);
                                }
                            }else{
                                html=GrpChatRequestCancelHtml(timestampToAMPM(curEle2.created_at),curEle2.iFromUserId,0,isAdmin);
                            }
                        }

                        $("#MessageList").append(html);

                        scrollToBottom();
                        feather.replace();
                        dynamicWithlabel();
                        
                    }else if(curEle2.vGroupMessageType=="AddMemeber"){

                        dateTimeLineAdd(curEle2.created_at);
                        let html = GroupChatRequestAcceptHtml(timestampToAMPM(curEle2.created_at), curEle2.id,curEle2,dd.iLoginId,isAdmin)
                        // AddNewMemberGroupMsgHtml(JSON.parse(curEle2.message), curEle2.created_at);
                        $("#MessageList").append(htmlDecode(html));
                        feather.replace();
                        dynamicWithlabel();
                        scrollToBottom();

                    }else if(curEle2.vGroupMessageType=="DeleteMemeber"){

                        dateTimeLineAdd(curEle2.created_at);
                        let html = DeleteMeberGroupMsgHtml(timestampToAMPM(curEle2.created_at),curEle2.vDeleteMemberId,isAdmin,curEle2.iFromUserId,curEle2?.isDeleteprofile);
                        $("#MessageList").append(html);
                        feather.replace();
                        dynamicWithlabel();
                        scrollToBottom();

                    }else if(curEle2.vGroupMessageType=="NewAdmin"){

                        if(curEle2.iFromUserId!=dd.iLoginId){
                            dateTimeLineAdd(curEle2.created_at);
                            let html = GroupNewAdminHtml(timestampToAMPM(curEle2.created_at),dd.iLoginId,curEle2?.vNewAdminId);
                            $("#MessageList").append(html);
                            feather.replace();
                            dynamicWithlabel();
                            scrollToBottom();
                        }

                    }else if(curEle2?.isDeleteprofile && curEle2?.isDeleteprofile==1){
                        dateTimeLineAdd(curEle2.created_at);
                        let html = AdminGroupLeft(timestampToAMPM(curEle2.created_at),curEle2.message,curEle2.iFromUserId);
                        $("#MessageList").append(htmlDecode(html));
                        feather.replace();
                        dynamicWithlabel();
                        scrollToBottom();
                    }else if(curEle2.vGroupMessageType=="AdminLeft"){

                        dateTimeLineAdd(curEle2.created_at);
                        let html = AdminGroupLeft(timestampToAMPM(curEle2.created_at),"",curEle2.iFromUserId,"AdminLeft");
                        $("#MessageList").append(htmlDecode(html));
                        feather.replace();
                        dynamicWithlabel();
                        scrollToBottom();

                    }else {
                        if (curEle2.iFromUserId == dd.iLoginId) {

                            let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2.vReplyMsg, curEle2?.vReplyFileName);

                            let senderImageHtml = $("#vProfilePick").attr("xlink:href");

                            if (curEle2.message.includes('vImages =>')) {
                                let removePrefix = curEle2.message;
                                const myImageStr = removePrefix.split("vImages =>");
                                if (myImageStr.length > 0) {
                                    const myImageArr = myImageStr[1].split(",");
                                    if (myImageArr.length > 0) {
                                        myImageArr.map((curEle, index) => {

                                            const trimThumbPath = String(curEle2.vImageThumb).split("=>");
                                            let isThumnail = "";
                                            if (trimThumbPath.length > 1) {
                                                isThumnail = trimThumbPath[1];
                                            }

                                            let imageHtml = ImageOrFileDipHtml(curEle, "", isThumnail);

                                            if (isSecond) {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);

                                                let html = getGroupChatHtml(curEle, curEle2.id, dd.iLoginId, senderImageHtml, replyHtml, imageHtml, curEle2.created_at, 1, "You", curEle2?.iEdited, curEle2.iDeleted, curEle,curEle2.isAdmin,curEle2?.isForwardMsg);

                                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");

                                                $("#" + NewId).after(html);
                                                feather.replace();
                                                dynamicWithlabel();
                                            } else {
                                                dateTimeLineAdd(curEle2.created_at);

                                                let html = getGroupChatHtml(curEle, curEle2.id, dd.iLoginId, senderImageHtml, replyHtml, imageHtml, curEle2.created_at, 1, "You", curEle2?.iEdited, curEle2.iDeleted, curEle,curEle2.isAdmin,curEle2?.isForwardMsg);

                                                $("#MessageList").append(html);
                                                feather.replace();
                                                dynamicWithlabel();
                                                scrollToBottom();
                                            }
                                        })
                                    }
                                }
                            } else {

                                if (isSecond) {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);

                                    let html = getGroupChatHtml(curEle2.message, curEle2.id, dd.iLoginId, senderImageHtml, replyHtml, "", curEle2.created_at, 1, "You", curEle2?.iEdited, curEle2.iDeleted,"",curEle2.isAdmin,curEle2?.isForwardMsg);

                                    const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                    $("#" + NewId).after(html);
                                    feather.replace();
                                    dynamicWithlabel();
                                } else {
                                    dateTimeLineAdd(curEle2.created_at);

                                    let html = getGroupChatHtml(curEle2.message, curEle2.id, dd.iLoginId, senderImageHtml, replyHtml, "", curEle2.created_at, 1, "You", curEle2?.iEdited, curEle2.iDeleted,"",curEle2.isAdmin,curEle2?.isForwardMsg);

                                    $("#MessageList").append(html);

                                    scrollToBottom();
                                    feather.replace();
                                    dynamicWithlabel();
                                }
                            }
                        } else {
                            let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2.vReplyMsg, curEle2?.vReplyFileName);

                            const filterData = vChatUserListJson.filter((curEle, index) => {
                                return curEle.iUserId == curEle2.iFromUserId
                            })

                            let senderImageHtml = "";
                            let vUserName = "";
                            if (filterData.length > 0) {
                                senderImageHtml = filterData[0]['vProfilePic'];
                                vUserName = filterData[0]['vFullName'];
                            }

                            if (curEle2.message.includes('vImages =>')) {
                                let removePrefix = curEle2.message;
                                const myImageStr = removePrefix.split("vImages =>");
                                if (myImageStr.length > 0) {
                                    const myImageArr = myImageStr[1].split(",");
                                    if (myImageArr.length > 0) {
                                        myImageArr.map((curEle, index) => {

                                            const trimThumbPath = String(curEle2.vImageThumb).split("=>");
                                            let isThumnail = "";
                                            if (trimThumbPath.length > 1) {
                                                isThumnail = trimThumbPath[1];
                                            }

                                            let imageHtml = ImageOrFileDipHtml(curEle, "", isThumnail);

                                            if (isSecond) {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);

                                                let html = getGroupChatHtml(curEle, curEle2.id, curEle2.iFromUserId, senderImageHtml, replyHtml, imageHtml, curEle2.created_at, 0, vUserName, curEle2?.iEdited, curEle2.iDeleted, curEle,curEle2.isAdmin,curEle2?.isForwardMsg);

                                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                                $("#" + NewId).after(html);
                                                feather.replace();
                                                dynamicWithlabel();
                                            } else {
                                                dateTimeLineAdd(curEle2.created_at);

                                                let html = getGroupChatHtml(curEle, curEle2.id, curEle2.iFromUserId, senderImageHtml, replyHtml, imageHtml, curEle2.created_at, 0, vUserName, curEle2?.iEdited, curEle2.iDeleted, curEle,curEle2.isAdmin,curEle2?.isForwardMsg);

                                                $("#MessageList").append(html);

                                                scrollToBottom();
                                                feather.replace();
                                                dynamicWithlabel();
                                            }

                                        })
                                    }
                                }
                            } else {

                                if (isSecond) {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);

                                    let html = getGroupChatHtml(curEle2.message, curEle2.id, curEle2.iFromUserId, senderImageHtml, replyHtml, "", curEle2.created_at, 0, vUserName, curEle2?.iEdited, curEle2.iDeleted,"",curEle2.isAdmin,curEle2?.isForwardMsg);

                                    const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                    $("#" + NewId).after(html);
                                    feather.replace();
                                    dynamicWithlabel();
                                } else {
                                    dateTimeLineAdd(curEle2.created_at);

                                    let html = getGroupChatHtml(curEle2.message, curEle2.id, curEle2.iFromUserId, senderImageHtml, replyHtml, "", curEle2.created_at, 0, vUserName, curEle2?.iEdited, curEle2.iDeleted,"",curEle2.isAdmin,curEle2?.isForwardMsg);

                                    $("#MessageList").append(html);

                                    scrollToBottom();
                                    feather.replace();
                                    dynamicWithlabel();
                                }

                            }
                        }
                    }
                })

                const scrollableDiv = document.getElementById('MessageList');
                const scrollPosition = scrollableDiv.scrollTop;

                if (scrollPosition == 0) {
                    $("#topFilter").removeClass("d-none");
                } else {
                    $("#topFilter").addClass("d-none");
                }
            } else {
                if (isSecond == 0) {
                    $("#MessageList").html("");
                    timeLineDate = "";
                    $("#topFilter").addClass("d-none");
                }
            }
        }
    });
}

function realTimeGroupModalUpdate(){
    const vChatGroupListJsonData=$("#vChatGroupListJson").val();
    const vActiveGroupId=$("#vActiveGroupId").val();

    if(vChatGroupListJsonData!=""){
        JSON.parse(vChatGroupListJsonData).map((curEle,inde)=>{
            if(curEle.iGroupId==vActiveGroupId){
                const vChatGroupListJsonArr=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(","):[];
                const tGroupJoinMembArr=curEle.tGroupJoinMemb!=""?String(curEle.tGroupJoinMemb).split(","):[];


                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);

                    const filterData = chatGroupList.filter((curEle, index) => {
                        return vChatGroupListJsonArr.includes('' + curEle.iUserId)
                    })

                    chatGroupList.map((curEle,index)=>{
                        if(tGroupJoinMembArr.includes(""+curEle.iUserId)){
                            curEle['iPending']=1;
                            filterData.push(curEle);
                        }
                    })   
                    editMemberOldData = filterData;
                }
            }
        })
    }
}

socket.on('receive_grp_message', data => {
    const vActiveGroupId = $("#vActiveGroupId").val();    

    // console.log("receive_grp_message=>",data)
    if (data?.type && data?.type == "DeleteMessage") {
        if (vActiveGroupId == data.iGroupId) {
            let html = deleteMessageHtml("", 0,1,data.isAdmin);

            $("#" + data.content).closest(".chat-message-outer-container").removeClass("select-message");
            $("#" + data.content).closest(".chat-message-outer-container").removeClass("send-message");
            $("#" + data.content).closest(".chat-message-outer-container").addClass("recieve-message");
            $("#" + data.content).closest(".chat-message-outer-container").html(html);

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }
        }
    }else if (data?.isDeleteprofile && data?.isDeleteprofile == 1) {
        getGroupList();
        getAllUserList();
        
        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }
        
        if (vActiveGroupId == data.iGroupSenderId) {
            dateTimeLineAdd(getCurrentDateTime());

            if(activeTab == "Group"){
                getGroupList(data.iGroupSenderId);
            }
            
            let html = AdminGroupLeft(timestampToAMPM(),data.content,data.senderChatID);

            $("#MessageList").append(html);
            scrollToBottom();
            feather.replace();

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }

            setTimeout(() => {
                getGroupList();

                realTimeGroupModalUpdate();

                if($("#groupDetailsEdit").hasClass("show") && $("#vGroupEditMemberList").hasClass("active")){
                    $("#vGroupEditMemberList").click();
                }

                if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                    $("#groupMembersTab").click();
                }
            }, 200);
        }
    }else if (data?.iRequestMsg && data?.iRequestMsg>0) {
        getGroupList();
    
        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }

        if (vActiveGroupId == data.iGroupSenderId) {
            dateTimeLineAdd(getCurrentDateTime());

            if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                $("#groupMembersTab").click();
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);

                if(data?.iRequestMsg==1){
                    html=GrpChatRequesHtml({iFromUserId:data.senderChatID,id:data.id,created_at:""});

                    $("#vGroupDeleteChat").addClass("disabled");
                    $("#vDeleteGroup").closest("li").addClass("d-none");
                    $("#vGroupInfoBtn").closest("li").removeClass("d-none");

                }else if(data?.iRequestMsg==2){
                    const dataMsg={iFromUserId:data.senderChatID,id:data.id,created_at:timestampToAMPM()};
                    html=GroupChatRequestAcceptHtml(timestampToAMPM(), data.id,dataMsg,dd.iLoginId,0); 
                    
                    realTimeGroupModalUpdate();

                    if($("#groupDetailsEdit").hasClass("show") && $("#vGroupEditMemberList").hasClass("active")){
                        $("#vGroupEditMemberList").click();
                    }
                }else if(data?.iRequestMsg==3){
                    html=GrpChatRequestDeclineHtml(timestampToAMPM(), data.senderChatID,0,1);

                    realTimeGroupModalUpdate();

                    if($("#groupDetailsEdit").hasClass("show") && $("#vGroupEditMemberList").hasClass("active")){
                        $("#vGroupEditMemberList").click();
                    }
                }else if(data?.iRequestMsg==4){
                    $(".grpRequestAccept").closest(".chat-message-outer-container").remove();

                    html=GrpChatRequestCancelHtml(timestampToAMPM(),data.senderChatID,0,0);

                    $("#vGroupDeleteChat").removeClass("disabled");
                    $("#vDeleteGroup").closest("li").removeClass("d-none");
                    $("#vGroupInfoBtn").closest("li").addClass("d-none");
                }

                $("#MessageList").append(html);
                scrollToBottom();
                feather.replace();
                dynamicWithlabel(); 

                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });

                let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
                if (vChatGroupListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatGroupListJsonArr);

                    const filterData = chatGroupList.filter((curEle, index) => {
                        return curEle.iGroupId == vActiveGroupId
                    })

                    if(filterData.length>0){
                        const vGroupMember=String(filterData[0]['tGroupUsers']).split(",");
                        if(vGroupMember.includes(""+dd.iLoginId) || filterData[0]['iCreatedBy']==dd.iLoginId){
                            $("#TextEditorArea").removeClass("d-none");
                        }else{
                            $("#TextEditorArea").addClass("d-none");
                        }
                    }
                }
            }
        }
    }else if (data?.type && data?.type == "UpdateMessage") {
        if (vActiveGroupId == data.iGroupId) {
            $("#msg_" + data.iMessageId).html(htmlDecode(data.content));
            $("#edit_" + data.iMessageId).removeClass("d-none");
            $("#forawrd_" + data.iMessageId).addClass("d-none");
            updateDataInAllHtml(data.iMessageId, data.content);

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }
        }
    }else if (data?.type && data?.type == "refreshGroup") {
            // console.log("data==>",data)
            if(activeTab == "Group"){
                getGroupList(data.vActiveGroupId);
            }else{
                getGroupList();
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                if (vActiveGroupId == data.vActiveGroupId) {
                    if(data.vUsers!=""){
                        const splitUser=String(data.vUsers).split(",");
                        if(!splitUser.includes(""+dd.iLoginId)){
                            $("#TextEditorArea").addClass("d-none")
                            if(activeTab == "Group"){
                                $(".vGroupIds").each((e, item) => {
                                    const getRowId = $(e.currentTarget).attr("data-id");
                                    if (getRowId == data.vActiveGroupId) {
                                        $(item).click();
                                    }
                                })
                            }
                        }else{
                            $("#TextEditorArea").removeClass("d-none")
                        }
                    }

                    if(data.isDelete==1){
                        $("#StartChatArea").removeClass("d-none");
                        $("#HeaderChatArea").addClass("d-none");
                        $("#MainChatArea").addClass("d-none");
                    }

                    if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                        $("#groupMembersTab").click();
                    }
                }
            }
    }else if(data?.vGroupMessageType && data?.vGroupMessageType == "AddMemeber"){
        getGroupList();

        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }

        if (vActiveGroupId == data.iGroupSenderId) {
            dateTimeLineAdd(getCurrentDateTime());

            if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                $("#groupMembersTab").click();
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);

                let html = GroupChatRequestAcceptHtml(timestampToAMPM(), data.iMessageId,{iFromUserId:data.senderChatID},dd.iLoginId,0)
    
                $("#MessageList").append(htmlDecode(html));
                feather.replace();
                dynamicWithlabel();
                scrollToBottom();

                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });

                realTimeGroupModalUpdate();

                if($("#groupDetailsEdit").hasClass("show") && $("#vGroupEditMemberList").hasClass("active")){
                    $("#vGroupEditMemberList").click();
                }
            }
        }
    }else if(data?.vGroupMessageType && data.vGroupMessageType=="AdminLeft"){
        getGroupList();

        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }
        
        if (vActiveGroupId == data.iGroupSenderId) {
            if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                $("#groupMembersTab").click();
            }

            dateTimeLineAdd(getCurrentDateTime());
            let html = AdminGroupLeft(timestampToAMPM(),"",data.senderChatID,"AdminLeft");
            $("#MessageList").append(htmlDecode(html));
            feather.replace();
            dynamicWithlabel();
            scrollToBottom();

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }
        }

    }else if(data?.vGroupMessageType && data?.vGroupMessageType == "NewAdmin"){
        getGroupList();

        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }

        if (vActiveGroupId == data.iGroupSenderId) {
            dateTimeLineAdd(getCurrentDateTime());

            if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                $("#groupMembersTab").click();
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);

                let html = GroupNewAdminHtml(timestampToAMPM(),dd.iLoginId,data.vNewAdminId)
    
                $("#MessageList").append(htmlDecode(html));
                feather.replace();
                dynamicWithlabel();
                scrollToBottom();

                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });

                setTimeout(() => {
                    getGroupList();
                }, 200);
            }
        }
    }else if(data?.vGroupMessageType && data?.vGroupMessageType == "DeleteMemeber"){
        getGroupList();
        if (activeTab == "User") {
            $("#newGroupMsgindc").removeClass("d-none");
            $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
        }

        if (vActiveGroupId == data.iGroupSenderId) {
            dateTimeLineAdd(getCurrentDateTime());

            let html = DeleteMeberGroupMsgHtml(timestampToAMPM(),data.vDeleteMemberId,0,data.senderChatID,data?.isDeleteprofile);
            $("#MessageList").append(html);
            feather.replace();
            dynamicWithlabel();
            scrollToBottom();

            if($("#groupDetails").hasClass("show") && $("#groupMembersTab").hasClass("active")){
                $("#groupMembersTab").click();
            }

            if($("#groupDetailsEdit").hasClass("show") && $("#vGroupEditMemberList").hasClass("active")){
                $("#vGroupEditMemberList").click();
            }

            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                if(data.vDeleteMemberId==dd.iLoginId){
                    $("#TextEditorArea").addClass("d-none");
                }

                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }
        }

    }else {
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);

            const vActiveGroupId = $("#vActiveGroupId").val();

            // if (vActiveGroupId > 0 && activeTab == "Group") {
            //     getGroupList(data.iGroupSenderId);
            // }else{
            //     getGroupList();
            // }

            if (activeTab == "Group") {
                changeGroupListOrder(data.iGroupSenderId);
            }

            if (activeTab == "User") {
                $("#newGroupMsgindc").removeClass("d-none");
                $("#newGroupMsgindc").closest(".sidebar-chat-group-tabs").addClass("msg-rcv");
            }

            if (activeTab == "Group" && data.iGroupSenderId != vActiveGroupId) {
                $(".vGroupIds").each((e, item) => {
                    const getRowId = $(item).attr("data-id");
                    if (getRowId == data.iGroupSenderId) {
                        $(item).addClass("unread-chat");
                    }
                })
            }
            // EMP => console.log("data",data)

            const dataContent = data.content;

            const vChatUserListJson = JSON.parse($("#vChatUserListJson").val());

            let senderImageHtml = "";
            let senderName = "";
            if (vActiveGroupId > 0) {
                const filterData = vChatUserListJson.filter((curEle, index) => {
                    return curEle.iUserId == data.senderChatID
                })

                if (filterData.length > 0) {
                    senderImageHtml = filterData[0]['vProfilePic'];
                    senderName = filterData[0]['vFullName'];
                }
            }

            let replyHtml = replyHtmlFunc(data?.vReplyMsg_id, data?.vReplyMsg, data?.vReplyFileName);

            if (vActiveGroupId == data.iGroupSenderId) {
                dateTimeLineAdd(getCurrentDateTime());

                if (dataContent.includes('vImages =>')) {
                    let removePrefix = dataContent;
                    const myImageStr = removePrefix.split("vImages =>");
                    if (myImageStr.length > 0) {
                        const myImageArr = myImageStr[1].split(",");
                        if (myImageArr.length > 0) {
                            myImageArr.map((curEle, index) => {

                                const trimThumbPath = String(data.ContentDataThumb).split("=>");
                                let isThumnail = "";
                                if (trimThumbPath.length > 1) {
                                    isThumnail = trimThumbPath[1];
                                }

                                const imageHtml = ImageOrFileDipHtml(curEle, "", isThumnail);

                                if (timeLineDate == "") {
                                    dateTimeLineAdd();
                                }

                                const id = data.senderChatID + "_" + vActiveGroupId + "_" + dateToInt();
                                let html = getGroupChatHtml(curEle, id, data.senderChatID, senderImageHtml, replyHtml, imageHtml, "", 0, senderName, 0, 0, curEle,data?.isAdmin,data?.isForwardMsg);

                                // let html = `<div class="message-box friend-message">
                                //                 <p>${senderName} ${replyHtml} ${imageHtml} <span class="msgTime">${timestampToAMPM()}</span></p>
                                //                 ${senderImageHtml}
                                //                 ${forwardHtmlFunc(0,curEle,"image")}
                                //                 ${replyIconHtml(0,curEle,"image")}
                                //         </div>`;
                                $("#MessageList").append(html);
                                feather.replace();
                                dynamicWithlabel();
                                scrollToBottom();

                            })
                        }
                    }
                } else {
                    if (timeLineDate == "") {
                        dateTimeLineAdd();
                    }

                    const id = data.senderChatID + "_" + vActiveGroupId + "_" + dateToInt();

                    let html = getGroupChatHtml(data.content, id, data.senderChatID, senderImageHtml, replyHtml, "", "", 0, senderName, 0, 0, "",data?.isAdmin,data?.isForwardMsg);

                    // let html = `<div class="message-box friend-message">
                    //             <p>${senderName} ${replyHtml} ${data.content} <span class="msgTime">${timestampToAMPM()}</span></p>
                    //             ${senderImageHtml}
                    //             ${forwardHtmlFunc(0,data.content,"text")}
                    //             ${replyIconHtml(0,data.content,"text")}
                    //         </div>`;
                    $("#MessageList").append(html);
                    feather.replace();
                    dynamicWithlabel();
                    scrollToBottom();
                }

                socket.emit('messageGrpReadUpdate', {
                    iFromUserId: vActiveGroupId,
                    iToUserId: dd.iLoginId
                });
            }
        }
    }
})
//Group Chat End Code

function isHTML(str) {
    var a = document.createElement('div');
    a.innerHTML = str;

    for (var c = a.childNodes, i = c.length; i--;) {
        if (c[i].nodeType == 1) return true;
    }

    return false;
}

//Search Message Code Start 
var delay = (function () {
    var timer = 0;
    return function (callback, ms) {
        clearTimeout(timer);
        timer = setTimeout(callback, ms);
    };
})();


function highlightText(divId, textToHighlight, isOrange = "") {
    var div = document.getElementById(divId);
    var orangeColor = isOrange ? 'orange' : 'yellow';
    var textNodes = getTextNodes(div);
    var lowerTextToHighlight = textToHighlight.toLowerCase();

    for (var i = 0; i < textNodes.length; i++) {
        var node = textNodes[i];
        var lowerNodeValue = node.nodeValue.toLowerCase();
        var index = lowerNodeValue.indexOf(lowerTextToHighlight);

        if (index !== -1) {
            var span = document.createElement('span');
            span.className = 'highlight';
            span.style.setProperty('background-color', orangeColor, 'important');

            var highlightedText = node.splitText(index);
            highlightedText.splitText(textToHighlight.length);
            var highlight = highlightedText.cloneNode(true);

            span.appendChild(highlight);
            highlightedText.parentNode.replaceChild(span, highlightedText);
        }
    }
}

function getTextNodes(node) {
    var textNodes = [];

    function recurse(node) {
        if (node.nodeType === 3) {
            textNodes.push(node);
        } else {
            for (var child = node.firstChild; child; child = child.nextSibling) {
                recurse(child);
            }
        }
    }

    recurse(node);
    return textNodes;
}


function removeHighlight(divId = "") {
    if (divId != "") {
        var div = document.getElementById(divId);
        var spans = div.getElementsByClassName('highlight');
        while (spans.length) {
            var span = spans[0];
            var parent = span.parentNode;
            parent.replaceChild(document.createTextNode(span.textContent), span);
            parent.normalize(); // merge adjacent text nodes
        }
    } else {
        const totalHighlight = document.querySelectorAll('.highlight').length;
        if (totalHighlight > 0) {
            var spans = document.getElementsByClassName('highlight');
            while (spans.length) {
                var span = spans[0];
                var parent = span.parentNode;
                parent.replaceChild(document.createTextNode(span.textContent), span);
                parent.normalize(); // merge adjacent text nodes
            }
        }
    }
}

function searchPosition(searchText) {
    const nodeList = document.querySelectorAll(".message-text");
    // $(".message-text").css("backgroundColor","transparent");
    removeHighlight();
    let totalSearchindex = 0;
    for (let i = 0; i < nodeList.length; i++) {
        const idName = $(nodeList[i]).attr('id');
        const serachString = String(searchText).toLowerCase();

        if (searchText != "") {
            $("#dispSearchBox").removeClass("hide");
            $("#dispSearchBox").addClass("show");

            $("#vCancelSearch").removeClass("hide");
            $("#vCancelSearch").addClass("show");

            $("#vSearchNextBtn").removeClass("hide");
            $("#vSearchNextBtn").addClass("show");

            const TextContainStr = String($(nodeList[i]).text()).toLowerCase();

            if (String(TextContainStr).includes(serachString)) {
                totalSearchindex++;
                if (SerachTextIndex == totalSearchindex) {
                    document.getElementById(idName).scrollIntoView();
                    highlightText(idName, serachString, 1);
                } else {
                    highlightText(idName, serachString);
                }
            }
        } else {
            $("#dispSearchBox").removeClass("show");
            $("#dispSearchBox").addClass("hide");

            $("#vCancelSearch").removeClass("show");
            $("#vCancelSearch").addClass("hide");

            $("#vSearchNextBtn").removeClass("show");
            $("#vSearchNextBtn").addClass("hide");
        }
    }

    const isMatchIndex = Number(SerachTextIndex) > Number(totalSearchindex);
    if (isMatchIndex && Number(totalSearchindex) > 0) {
        SerachTextIndex = 1;
        searchPosition(searchText);
    }

    if (Number(totalSearchindex) == 0) {
        $("#activeSearchIndex").text(0);
        $("#totalSearchRecord").text(0);
    } else {
        $("#activeSearchIndex").text(SerachTextIndex);
        $("#totalSearchRecord").text(totalSearchindex);
    }
}

$(document).on("click","#vCancelSearch",()=>{
    SerachTextIndex = 0;
    $("#vSearchText").val("");

    $("#dispSearchBox").removeClass("show");
    $("#dispSearchBox").addClass("hide");

    $("#vSearchNextBtn").removeClass("show");
    $("#vSearchNextBtn").addClass("hide");

    $("#vCancelSearch").removeClass("show");
    $("#vCancelSearch").addClass("hide");

    removeHighlight();
    scrollToBottom();
})

let SerachTextIndex = 0;
$('#vSearchText').keyup(function (e) {
    if (e.keyCode == 13) {
        e.preventDefault();
        SerachTextIndex++;
        const strSearch = e.target.value;
        if (strSearch == "") {
            $("#dispSearchBox").removeClass("show");
            $("#dispSearchBox").addClass("hide");

            $("#vCancelSearch").removeClass("show");
            $("#vCancelSearch").addClass("hide");

            $("#vSearchNextBtn").removeClass("show");
            $("#vSearchNextBtn").addClass("hide");
            removeHighlight();
            scrollToBottom();
        } else {
            searchPosition(strSearch);
        }
    } else {
        if(e.target.value!=""){
            $("#vSearchNextBtn").addClass("show");
            $("#vSearchNextBtn").removeClass("hide");
        }else{
            $("#vSearchNextBtn").removeClass("show");
            $("#vSearchNextBtn").addClass("hide");

            $("#dispSearchBox").removeClass("show");
            $("#dispSearchBox").addClass("hide");

            $("#vCancelSearch").removeClass("show");
            $("#vCancelSearch").addClass("hide");
            removeHighlight();
            scrollToBottom();
            SerachTextIndex = 0;
        }
        SerachTextIndex = 0;
    }
});

$("#vSearchNextBtn").click(() => {
    const vSearchText = $("#vSearchText").val();
    SerachTextIndex++;
    searchPosition(vSearchText);
})
//Search Message Code End

//Edit Message Code Start
let iEditMsgId = "";
let vEditMsgText = "";
let vEditMsgType = "";
let vEditMessageMainId = "";
$(document).on("click", ".EditMessage", (e) => {
    const id = $(e.currentTarget).attr("data-id");
    const vMessage = $(e.currentTarget).attr("data-msg");
    const Type = $(e.currentTarget).attr("data-type");
    const MsgTime = $(e.currentTarget).attr("data-time");
    const filename = $(e.currentTarget).attr("data-filename");

    iEditMsgId = MsgTime;
    vEditMsgText = vMessage;
    vEditMsgType = Type;
    vEditMessageMainId = id;
    ImageDataArr=[];
    $("#fileInput").val("");
    ImageDataArr=[];

    let fileUploadDummyHtml=`<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data" id="demoFileUpload">
                                                    <div class="d-flex align-items-center">
                                                        <div class="preview-container position-relative">
                                                            <img class="preview-image">
                                                        </div>
                                                        <div class="file-preview mb-0">No file selected</div>
                                                    </div>
                                                    <a class="cursor-pointer close-reply"><i data-feather="x"
                                                            class="feather-16"></i></a>
                                                </div>`;
    $("#fileUploadDiv").html(fileUploadDummyHtml);
    $("#fileUploadButtton").removeClass("disabled");

    $("#texAreaEditorDiv").removeClass("d-none");
    $("#vMessage").addClass("show");

    // console.log("vMessage",vMessage)
    $("#vMessage").closest(".textarea-inner-container").addClass("edit-message-active");
    $("#msg_" + id).closest(".chat-message").addClass("edit-message-active");
    $(".floating-dd").addClass("d-none");
    $(".editor-close").removeClass("d-none");

    $("#sendMessage").removeClass("disabled");

    if (vEditMsgType == "text") {

        // console.log("vMessage",vMessage)
        $(".editor").html(htmlDecode(vMessage));


        $(".teatarea-file-upload").removeClass("show");
        $("#fileInput").val("");
        $(".editor").addClass("show");
        $(".type-link").removeClass("d-none");
        $(".emoji-link").removeClass("d-none");
        $('.preview-container').css('display', 'flex');

        updateJson();

        var node = document.getElementById('vMessage');
        focusAndPlaceCaretAtEnd(node);
        // document.querySelector('.editor').focus();
    }
})

function focusAndPlaceCaretAtEnd(el) {
    el.focus();
    if (typeof window.getSelection != "undefined" && typeof document.createRange != "undefined") {
        var range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);

    } else if (typeof document.body.createTextRange != "undefined") {
        var textRange = document.body.createTextRange();
        textRange.moveToElementText(el);
        textRange.collapse(false);
        textRange.select();
    }
}
//Edit Message Code End

//New Chat Start Code
$(document).on("click", ".vNewChatStart", (e) => {
    const id = $(e.currentTarget).attr("data-id");
    $("#MessageList").html("");

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");
    $("#vMessage").html("");
    $("#vCancelSearch").removeClass("show");
    $("#vCancelSearch").addClass("hide");
    $("#vUserDeleteChat").addClass("disabled");
    
    $("#vActiveGroupId").val("");

    $("#vGroupInfoBtn").closest("li").addClass("d-none");
    $("#vGroupDeleteChat").closest("li").addClass("d-none");
    $("#vGroupEditGroup").closest("li").addClass("d-none");
    $("#vExitGroup").closest("li").addClass("d-none");
    $("#vDeleteGroup").closest("li").addClass("d-none");

    let vChatUserListJsonArr = $("#vChatUserListJson").val();
    $(".add-user-popup").removeClass("active");

    let vConvertionChatArr = $("#vConvertionChatArr").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        const CheckExistAlread = (idUser) => {
            return JSON.parse(vConvertionChatArr).filter((curEle, index) => {
                return curEle.iUserId == idUser
            }).length
        };

        ChatUserListArr.map((curEle, index) => {
            if (curEle.iUserId == id) {
                $("#vUseTabActive").removeClass("d-none");
                $("#vGroupTabActive").addClass("d-none");

                if (CheckExistAlread(id)) {
                    timeLineDate = "";
                    filterDateStr = "";

                    $(".textarea-reply-container").removeClass("show");
                    $(".editor").addClass("show");
                    $('.file-preview').text("");

                    $(".vUserIdsCls").removeClass("chat-active");

                    $(".vUserIdsCls").each((e2, item) => {
                        const iUserId = $(item).attr("data-id");
                        if (iUserId == id) {
                            $(item).addClass("chat-active");

                            $("#MessageList").html("");
                            $("#vSearchText").val("");
                            $(".plc-holder").removeClass("d-none");
                            $("#vMessage").html("");

                            $("#StartChatArea").addClass("d-none");
                            $("#HeaderChatArea").removeClass("d-none");
                            $("#MainChatArea").removeClass("d-none");
                            $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

                            // console.log("check 3 ==>")
                            iEditMsgId = "";
                            vEditMsgText = "";
                            vEditMsgType = "";
                            vEditMessageMainId = "";

                            const iUserId = $(item).data('id');
                            const UserStatus = $(item).data('status') == 1 ? 'Online' : 'Offline';

                            const vConvertionChatArr = $("#vConvertionChatArr").val();
                            const UserList = JSON.parse(vConvertionChatArr);

                            UserList.map((curEle, index) => {
                                if (curEle.iUserId == iUserId) {
                                    if (curEle.vProfilePic != "") {
                                        $("#activeChatProfile").attr("xlink:href", curEle.vProfilePic)
                                    }else{
                                        colorOption.map((curEle2, index) => {
                                            if (curEle2.iColorId == curEle.iColorOption) {
                                                $("#activeChatProfile").attr("xlink:href", curEle2.vColorPick);
                                            }
                                        })
                                    }

                                    $("#vActiveUserId").val(iUserId);
                                    $("#vActiveGroupId").val('');

                                    if (filterDateStr == "") {
                                        if (curEle?.lastDate && curEle?.lastDate != "") {
                                            filterDateStr = curEle.lastDate;
                                        }
                                    }

                                    $("#vUserIdsCls_" + iUserId).removeClass("unread-chat");
                                    if (UserStatus == "Online") {
                                        $("#activeChatSts").removeClass("offline");
                                        $("#activeChatSts").addClass("online");
                                    } else {
                                        $("#activeChatSts").removeClass("online");
                                        $("#activeChatSts").addClass("offline");
                                    }
                                    $("#activeChatName").text(curEle.vFullName);
                                    $("#activeChatStsDisp").text(UserStatus);

                                    getMessageFunc(curEle.iUserId, filterDateStr);
                                }
                            })
                        }
                    })

                } else {
                    $("#vActiveUserId").val(curEle.iUserId);
                    $("#MessageList").html("");
                    $("#activeChatName").text(curEle.vFullName);
                    $("#activeChatStsDisp").text(curEle.iStatus == 0 ? 'Offline' : 'Online');

                    $("#StartChatArea").addClass("d-none");
                    $("#HeaderChatArea").removeClass("d-none");
                    $("#MainChatArea").removeClass("d-none");
                    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

                    if (curEle.iStatus == 0) {
                        $("#activeChatSts").removeClass("online");
                        $("#activeChatSts").addClass("offline");
                    } else {
                        $("#activeChatSts").removeClass("offline");
                        $("#activeChatSts").addClass("online");
                    }

                    let profilePath = "";
                    if (curEle.vProfilePic == "") {
                        colorOption.map((curEle2, index) => {
                            if (curEle2.iColorId == curEle.iColorOption) {
                                $("#activeChatProfile").attr("xlink:href", curEle2.vColorPick);
                                profilePath = curEle2.vColorPick;
                            }
                        })

                    } else {
                        $("#activeChatProfile").attr("xlink:href", curEle.vProfilePic);
                        profilePath = curEle.vProfilePic;
                    }

                    let profileImage = profilePath;
                    if (profileImage == "") {
                        profileImage = "./image/profile/profile.png";
                    }

                    $(".vUserIdsCls").removeClass("chat-active");

                    const htmlUser = `<li>
                                        <a class="cursor-pointer chat-list vUserIdsCls chat-active" data-id='${curEle.iUserId}' data-status='${curEle.iStatus}' id="vUserIdsCls_${curEle.iUserId}">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-profile-image me-3">
                                                        <svg role="none" viewBox="0 0 96 96">
                                                            <mask id="profile-image">
                                                                <circle fill="white" cx="48" cy="48" r="48"></circle>
                                                                <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                                            </mask>
                                                            <g mask="url(#profile-image)">
                                                                <image x="0" y="0" height="100%"
                                                                    preserveAspectRatio="xMidYMid slice" width="100%"
                                                                    xlink:href="${profileImage}"></image>
                                                            </g>
                                                        </svg>
                                                        <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                                    </div>
                                                    <div>
                                                        <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                                        <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                                    </div>
                                                </div>
                                                <div class="unread-message">
                                                    <span><img src="images/profile/unread-message.svg" alt="unread-message"></span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                `;
                    // $("#chatUserList").
                    $("#chatUserList").prepend(htmlUser);

                    if (vConvertionChatArr != "") {
                        const ChatConversionListArr = JSON.parse(vConvertionChatArr);
                        ChatConversionListArr.push(curEle);

                        $("#vConvertionChatArr").val(JSON.stringify(ChatConversionListArr));
                    }

                    $("#vRequestChatDiv").removeClass("d-none");
                    $("#TextEditorArea").addClass("d-none");
                }
            }
        })
    }
})
//New Chat Start Code End

//View Group Modal Code Start
$(document).on("click", "#vGroupInfoBtn", () => {
    $("#groupDetails").modal("toggle");
    $("#group-basic-details").click();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        const vActiveGroupId = $("#vActiveGroupId").val();
        let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatGroupListJsonArr);

            const filterData = chatGroupList.filter((curEle, index) => {
                return curEle.iGroupId == vActiveGroupId
            })

            if (filterData.length > 0) {
                const vGroupName = filterData[0]['vGroupName'];
                const vGroupImage = filterData[0]['vGroupImage'];
                const iCreatedBy = filterData[0]['iCreatedBy'];
                const tDescription = filterData[0]['tDescription'];
                const dCreatedDate = filterData[0]['dCreatedDate'];

                $("#vGroupInforName").text(vGroupName);

                const filterColorOption = GroupColorOption.filter((curEle2, index) => {
                    return curEle2.iColorId == filterData[0]['iColorOption']
                })

                if (vGroupImage != "") {
                    $("#vGroupInforProfile").attr("src", vGroupImage);
                } else {
                    $("#vGroupInforProfile").attr("src", filterColorOption[0]['vColorPick']);
                }

                $("#vGroupInfoDescription").text(tDescription);
                $("#vGroupInfCreateDate").text(formatDateTime(dCreatedDate));

                if (dd.iLoginId == iCreatedBy) {
                    $("#vGroupOwnerProfile").attr("xlink:href", $("#vProfilePick").attr("xlink:href"));
                    $("#vGroupOwnerName").text($("#vUserName").text());
                    $("#vGroupOwnerSts").text($("#vUserLoggedSts").text());
                    if ($("#vUserLoggedSts").text() == "Online") {
                        $("#vGroupOwnerStsCls").removeClass("offline");
                        $("#vGroupOwnerStsCls").addClass("online");
                    } else {
                        $("#vGroupOwnerStsCls").addClass("offline");
                        $("#vGroupOwnerStsCls").removeClass("online");
                    }
                } else {
                    let vChatUserListJsonArr = $("#vChatUserListJson").val();
                    if (vChatUserListJsonArr != "") {
                        const chatGroupList = JSON.parse(vChatUserListJsonArr);

                        const filterUserList = chatGroupList.filter((curEle, index) => {
                            return curEle.iUserId == filterData[0]['iCreatedBy']
                        })

                        if (filterUserList.length) {
                            const UserSts = filterUserList[0]['iStatus'];
                            if (filterUserList[0]['vProfilePic'] != "") {
                                $("#vGroupOwnerProfile").attr("xlink:href", filterUserList[0]['vProfilePic']);
                            } else {
                                colorOption.map((curEle2, index) => {
                                    if (curEle2.iColorId == filterUserList[0]['iColorOption']) {
                                        $("#vGroupOwnerProfile").attr("xlink:href", curEle2.vColorPick);
                                    }
                                })

                            }
                            $("#vGroupOwnerName").text(filterUserList[0]['vFullName']);
                            $("#vGroupOwnerSts").text(UserSts == 0 ? 'Offline' : 'Online');
                            if (UserSts == 1) {
                                $("#vGroupOwnerStsCls").removeClass("offline");
                                $("#vGroupOwnerStsCls").addClass("online");
                            } else {
                                $("#vGroupOwnerStsCls").addClass("offline");
                                $("#vGroupOwnerStsCls").removeClass("online");
                            }
                        }
                    }
                }
            }
        }
    }


})

$(document).on("click", "#groupDetailsClose", () => {
    $("#groupDetails").modal("toggle");
})

const groupMemberHtml = (chatGroupList, isEdit = 0, vGroupMemberHtmlId = "") => {
    // $("#vGroupInfoMemeberList").html("");
    let iLoggedId = 0;
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLoggedId = dd.iLoginId
    }

    $("#" + vGroupMemberHtmlId).html("");
    let isLeftMemeberList="";
    chatGroupList.map((curEle) => {
        const pendingReq=curEle?.iPending && curEle?.iPending==1?1:0;
        const isLeftMember=curEle?.isLeftMember && curEle?.isLeftMember==1?1:0;

        let isCheckBox = "";
        if (isEdit == 2) {
            const filterChecked = NewSelectMemberGrp.filter((curEle2, index) => curEle2.iUserId == curEle.iUserId)
            isCheckBox = `<span><input class="form-check-input vEditGroupMembrCls" type="checkbox" value="${curEle.iUserId}" id="${vGroupMemberHtmlId}chk_${curEle.iUserId}" ${filterChecked.length ? 'checked' : ''}></span>`;
        } else if (isEdit == 1) {
            if(pendingReq==1){
                isCheckBox = `<div class="d-flex align-items-center">
                                <div class="pe-2 me-4">
                                    <div class="badge bg-primary">Pending</div>
                                </div>
                                <span><input class="form-check-input form-check-cross vEditGroupMembrDelCls" type="checkbox" value="${curEle.iUserId}" id="${vGroupMemberHtmlId}chk_${curEle.iUserId}" ></span>
                            </div>`;
            }else{
                isCheckBox = `<span><input class="form-check-input form-check-cross vEditGroupMembrDelCls" type="checkbox" value="${curEle.iUserId}" id="${vGroupMemberHtmlId}chk_${curEle.iUserId}" ></span>`;
            }
        }else{
            if(pendingReq==1 && isLeftMember==0){
                isCheckBox = `<div class="d-flex align-items-center">
                                <div class="pe-2">
                                    <div class="badge bg-primary">Pending</div>
                                </div>
                            </div>`;
            }
        }

        let vProfileImg = curEle.vProfilePic;
        if (curEle.vProfilePic == "") {
            colorOption.map((curEle2, index) => {
                if (curEle2.iColorId == curEle.iColorOption) {
                    vProfileImg = curEle2.vColorPick
                }
            })
        }

        const isAdminFlag=curEle?.isAdmin==1?'admin':'you';

        let isDivCheck=`<div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <svg role="none" viewBox="0 0 96 96">
                                        <mask id="profile-image">
                                            <circle fill="white" cx="48" cy="48" r="48">
                                            </circle>
                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                            </circle>
                                        </mask>
                                        <g mask="url(#profile-image)">
                                            <image x="0" y="0" height="100%"
                                                preserveAspectRatio="xMidYMid slice"
                                                width="100%"
                                                xlink:href="${vProfileImg}">
                                            </image>
                                        </g>
                                    </svg>
                                    <div class="${curEle.iStatus == 0 ? 'offline' : 'online'}"></div>
                                </div>
                                <div>
                                    <h5 class="user-profile-name">${curEle.vFullName} ${(iLoggedId == curEle.iUserId || curEle?.isAdmin==1) ? '<span class="profile-you">('+isAdminFlag+')</span>' : ''}</h5>
                                    <P class="user-profile-activity">${curEle.iStatus == 0 ? 'Offline' : 'Online'}</P>
                                </div>
                            </div>
                            ${isCheckBox}`;

        let html = `<li class="${isLeftMember==1?'d-none vLeftMemeberList':''}" data-id="0">
                    <a class="cursor-pointer chat-list ${isEdit == 0 ? 'hide-checkbox' : ''}">
                    ${isEdit == 2?`<label class="d-flex align-items-center justify-content-between form-check ps-0"
                                        for="${vGroupMemberHtmlId}chk_${curEle.iUserId}">
                                        ${isDivCheck}
                                    </label>`:
                                    `<div class="d-flex align-items-center justify-content-between form-check ps-0"
                                            for="${vGroupMemberHtmlId}chk_${curEle.iUserId}">
                                            ${isDivCheck}
                                    </div>`}
                    </a>
                </li>`;

        if(isLeftMember==1){
            isLeftMemeberList+=html; 
        }else{
            $("#" + vGroupMemberHtmlId).append(html);
        }
        // $("#vGroupInfoMemeberList").append(html);
    })

    if(vGroupMemberHtmlId=="vGroupInfoMemeberList"){
        if(isLeftMemeberList!=""){
            $("#" + vGroupMemberHtmlId).append(`<button id="viewPastMember">Past member</button>`);
        }
    }

    if(isLeftMemeberList!=""){
        $("#" + vGroupMemberHtmlId).append(isLeftMemeberList);
    }
}


$(document).on("click", "#groupMembersTab", () => {
    $("#vGroupInfoSearchMember").val("");

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    let iLoggedId = 0;
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        iLoggedId = dd.iLoginId;
    }
    const vActiveGroupId = $("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        const filterData = chatGroupList.filter((curEle, index) => {
            return curEle.iGroupId == vActiveGroupId
        })

        const iAdminId=filterData[0]['iCreatedBy'];

        const tGroupUsers = filterData[0]['tGroupUsers'];
        const tGroupJoinMemb = filterData[0]['tGroupJoinMemb'];
        const tLeftMembers = filterData[0]['tLeftMembers'];

        let splitGrpUsr = tGroupUsers!=""?String(tGroupUsers).split(","):[];
        const tGroupJoinMembArr = tGroupJoinMemb!=""?String(tGroupJoinMemb).split(",").filter(i=>i):[];
        const tLeftMembersArr = tLeftMembers!=""?String(tLeftMembers).split(",").filter(i=>i):[];
        
        if(tGroupJoinMembArr.length>0){
            splitGrpUsr=[...splitGrpUsr,...tGroupJoinMembArr]
        }

        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatUserListJsonArr);

            if(iAdminId!=iLoggedId){
                splitGrpUsr=[''+iAdminId,...splitGrpUsr];
            }

            if(tLeftMembersArr.length>0){
                splitGrpUsr=[...splitGrpUsr,...tLeftMembersArr]
            }
            
            const filterData = chatGroupList.filter((curEle, index) => {
                return splitGrpUsr.includes('' + curEle.iUserId)
            })

            const vLoggedColorOption = $("#vLoggedColorOption").val();
            const vLoggedSts = $("#vUserLoggedSts").text();
            const vUserName = $("#vUserName").text();
            const vProfilePick = $("#vProfilePick").attr("xlink:href");

            if(iAdminId==iLoggedId){
                filterData.push({
                    iColorOption: vLoggedColorOption,
                    iStatus: vLoggedSts == "Online" ? "1" : "0",
                    iTotalUnReadMsg: 0,
                    iUserId: iLoggedId,
                    lastDate: "",
                    lastMessage: "No Message",
                    lastTime: "",
                    vFullName: vUserName,
                    vProfilePic: vProfilePick,
                    isAdmin:1
                });
            }

            if (splitGrpUsr.includes("" + iLoggedId)) {
                filterData.push({
                    iColorOption: vLoggedColorOption,
                    iStatus: vLoggedSts == "Online" ? "1" : "0",
                    iTotalUnReadMsg: 0,
                    iUserId: iLoggedId,
                    lastDate: "",
                    lastMessage: "No Message",
                    lastTime: "",
                    vFullName: vUserName,
                    vProfilePic: vProfilePick
                });
            }

            const NewData=filterData.map((curEle,index)=>{
                return {
                    ...curEle,
                    ['isAdmin']:iAdminId==curEle.iUserId?1:0,
                    ['iPending']:tGroupJoinMembArr.includes(""+curEle.iUserId)?1:0,
                    ['isLeftMember']:tLeftMembersArr.includes(""+curEle.iUserId)?1:0,
                }
            })

            const filterLeftPendMember=NewData.filter((curEle,index)=>{
                return curEle.iPending==1 && curEle.isLeftMember==1
            })

            if(filterLeftPendMember.length){
                filterLeftPendMember.map((curEle,index)=>{
                    NewData.push({...curEle,isLeftMember:0});
                })
            }

            NewData.sort(function(a,b){
                return b.isAdmin - a.isAdmin;
            })
            
            groupMemberHtml(NewData, 0, "vGroupInfoMemeberList");

            if(tLeftMembersArr.length==0){
                $("#viewPastMember").addClass("d-none");
            }   
        }
        // if (tGroupUsers != "" || tGroupJoinMemb!="" || tLeftMembers!="") {
        // }
    }
})

//Past Memeber List Display
$(document).on("click","#viewPastMember",()=>{
    let isShow=0;
    $(".vLeftMemeberList").each((cur,item)=>{
        const dataId=$(item).attr("data-id");
        isShow=dataId;
    })

    if(isShow==0){
        $(".vLeftMemeberList").attr("data-id",1);
        $(".vLeftMemeberList").removeClass("d-none");
    }else{
        $(".vLeftMemeberList").attr("data-id",0);
        $(".vLeftMemeberList").addClass("d-none");
    }
})

function filterGrpUser(splitGrpUsr,tGroupJoinMembArr,tLeftMembersArr,iAdminId,searchStr=""){
    const memberArr=[...splitGrpUsr,...tGroupJoinMembArr,...tLeftMembersArr];

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const chatUserListArr = JSON.parse(vChatUserListJsonArr);
            
            const filterData = chatUserListArr.filter((curEle, index) => {
                return (memberArr.includes('' + curEle.iUserId)  || iAdminId==curEle.iUserId) && String(curEle.vFullName).toLocaleLowerCase().includes(searchStr)
            })
    
            const vLoggedColorOption = Number($("#vLoggedColorOption").val());
            const vLoggedSts = $("#vUserLoggedSts").text();
            const vUserName = $("#vUserName").text();
            const vProfilePick = $("#vProfilePick").attr("xlink:href");
    
            if((dd.iLoginId==iAdminId || memberArr.includes(""+dd.iLoginId)) && String(dd.vFullName).toLocaleLowerCase().includes(searchStr)){
                filterData.push({
                    iColorOption: vLoggedColorOption,
                    iStatus: vLoggedSts == "Online" ? "1" : "0",
                    iTotalUnReadMsg: 0,
                    iUserId: dd.iLoginId,
                    lastDate: "",
                    lastMessage: "No Message",
                    lastTime: "",
                    vFullName: vUserName,
                    vProfilePic: vProfilePick
                });
            }

            const NewData=filterData.map((curEle,index)=>{
                return {
                    ...curEle,
                    ['isAdmin']:iAdminId==curEle.iUserId?1:0,
                    ['iPending']:tGroupJoinMembArr.includes(""+curEle.iUserId)?1:0,
                    ['isLeftMember']:tLeftMembersArr.includes(""+curEle.iUserId)?1:0,
                }
            })

            NewData.sort(function(a,b){
                return b.isAdmin - a.isAdmin;
            })

            groupMemberHtml(NewData, 0, "vGroupInfoMemeberList");
        }
    
    }
}

$(document).on("input", "#vGroupInfoSearchMember", (e) => {
    const searchStr = String(e.target.value).trim().toLocaleLowerCase();
    const vActiveGroupId = $("#vActiveGroupId").val();

    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        const filterData = chatGroupList.filter((curEle, index) => {
            return curEle.iGroupId == vActiveGroupId
        })

        const tGroupUsers = filterData[0]['tGroupUsers'];
        const tGroupJoinMemb=filterData[0]['tGroupJoinMemb'];
        const tLeftMembers=filterData[0]['tLeftMembers'];
        const iAdminId=filterData[0]['iCreatedBy'];

        const splitGrpUsr = tGroupUsers!=""?String(tGroupUsers).split(","):[];
        const tGroupJoinMembArr = tGroupJoinMemb!=""?String(tGroupJoinMemb).split(","):[];
        const tLeftMembersArr = tLeftMembers!=""?String(tLeftMembers).split(","):[];

        filterGrpUser(splitGrpUsr,tGroupJoinMembArr,tLeftMembersArr,iAdminId,searchStr);
    }
})
//View Group Modal Code End


//Edit Group Detail Modal Code Start
let editMemberOldData = [];
let isNewMemberTab = 0;
let NewSelectMemberGrp = [];

$(document).on("click", "#vGroupEditGroup", () => {
    $("#groupDetailsEdit").modal("toggle");
    isNewMemberTab = 0;
    NewSelectMemberGrp = [];
    editMemberOldData = [];
    ColorOptionSelect = "";
    finalColorSelection = "";
    finalProfilePick = "";
    isDeleteFile = 0;

    $("#vEditGrupBasicDetBtn").click();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        const vActiveGroupId = $("#vActiveGroupId").val();

        let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatGroupListJsonArr);

            const filterData = chatGroupList.filter((curEle, index) => {
                return curEle.iGroupId == vActiveGroupId
            })

            if (filterData.length > 0) {
                const vGroupName = filterData[0]['vGroupName'];
                const vGroupImage = filterData[0]['vGroupImage'];
                const iCreatedBy = filterData[0]['iCreatedBy'];
                const tDescription = filterData[0]['tDescription'];

                const filterColorOption = GroupColorOption.filter((curEle2, index) => {
                    return curEle2.iColorId == filterData[0]['iColorOption']
                })

                if (vGroupImage != "") {
                    $("#vGroupEditProfile").attr("src", vGroupImage);
                } else {
                    $("#vGroupEditProfile").attr("src", filterColorOption[0]['vColorPick']);
                }

                $("#vEditGrupName").val(vGroupName);
                $("#vEditGroupDesc").val(tDescription);

                const stringLength = String(tDescription).length;
                $("#totalCharDisp").text(stringLength + "/350");

                if (dd.iLoginId == iCreatedBy) {
                    $("#vEditGropOwnProfile").attr("xlink:href", $("#vProfilePick").attr("xlink:href"));
                    $("#vEditGroupOwnerName").text($("#vUserName").text());
                    $("#vEditGroupOwnerSts").text($("#vUserLoggedSts").text());
                    if ($("#vUserLoggedSts").text() == "Online") {
                        $("#vEditGroupOwnerStsCls").removeClass("offline");
                        $("#vEditGroupOwnerStsCls").addClass("online");
                    } else {
                        $("#vEditGroupOwnerStsCls").addClass("offline");
                        $("#vEditGroupOwnerStsCls").removeClass("online");
                    }
                } else {
                    let vChatUserListJsonArr = $("#vChatUserListJson").val();
                    if (vChatUserListJsonArr != "") {
                        const chatGroupList = JSON.parse(vChatUserListJsonArr);

                        const filterUserList = chatGroupList.filter((curEle, index) => {
                            return curEle.iUserId == filterData[0]['iCreatedBy']
                        })

                        if (filterUserList.length) {
                            const UserSts = filterUserList[0]['iStatus'];
                            $("#vEditGropOwnProfile").attr("xlink:href", filterUserList[0]['vProfilePic']);
                            $("#vEditGroupOwnerName").text(filterUserList[0]['vFullName']);
                            $("#vEditGroupOwnerSts").text(UserSts == 0 ? 'Offline' : 'Online');
                            if (UserSts == 1) {
                                $("#vEditGroupOwnerStsCls").removeClass("offline");
                                $("#vEditGroupOwnerStsCls").addClass("online");
                            } else {
                                $("#vEditGroupOwnerStsCls").addClass("offline");
                                $("#vEditGroupOwnerStsCls").removeClass("online");
                            }
                        }
                    }
                }
            }
        }
    }
})

$(document).on("click", "#vEditGrupBasicDetBtn", () => {
    isNewMemberTab = 0;
    NewSelectMemberGrp = [];
})

$(document).on("click", "#vGroupEditMemberList", () => {
    $("#vSearchEditMember").val("");

    $("#vEditGrpButtonAdd").addClass("d-none");
    $("#addGroupMembBtnDiv").addClass("d-none");
    // $("#vEditGrpButtonUpd").removeClass("d-none");
    $("#NewUserGrpBtn").removeClass("d-none");

    $("#editGroupModalHeader").addClass("modal-header-custom");
    $("#EditGroupModalBackBtn").addClass("d-none");
    $("#editGroupHeaderTitle").text("Group Members");

    const vActiveGroupId = $("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        const filterData = chatGroupList.filter((curEle, index) => {
            return curEle.iGroupId == vActiveGroupId
        })

        const tGroupUsers = filterData[0]['tGroupUsers'];
        const tGroupJoinMemb = filterData[0]['tGroupJoinMemb'];
        if (tGroupUsers != "" || tGroupJoinMemb!="") {
            const splitGrpUsr = String(tGroupUsers).split(",");
            const tGroupJoinMembSplit = String(tGroupJoinMemb).split(",");

            let vChatUserListJsonArr = $("#vChatUserListJson").val();
            if (vChatUserListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatUserListJsonArr);

                const filterData = chatGroupList.filter((curEle, index) => {
                    return splitGrpUsr.includes('' + curEle.iUserId)
                })

                chatGroupList.map((curEle,index)=>{
                    if(tGroupJoinMembSplit.includes(""+curEle.iUserId)){
                        curEle['iPending']=1;
                        filterData.push(curEle);
                    }
                })
                
                editMemberOldData = filterData;

                groupMemberHtml(filterData, 1, "vEditGrpMemeberOld");
            }
        }else{
            $("#vEditGrpMemeberOld").html("");
        }
    }
})

let deleteMemberId = "";
$(document).on("change", ".vEditGroupMembrDelCls", (e) => {
    const vActiveGroupId = $("#vActiveGroupId").val();

    const iSelectdId = Number(e.target.value);
    deleteMemberId = iSelectdId;

    let vChatGroupListJson=$("#vChatGroupListJson").val();
    if(vChatGroupListJson!=""){
        JSON.parse(vChatGroupListJson).map((curE,inde)=>{
            if(curE.iGroupId==vActiveGroupId){
                const isMember=String(curE.tGroupUsers).split(",");

                if(isMember.includes(""+iSelectdId)){
                    $("#delGroupMemeberModalHeading").text("Delete Confirm");
                    $("#delGroupMemeberModalTitle").text("Are you sure you want to delete member?");
                    $("#delGroupMemeberModalSubmit").text("Delete");
                    $("#delGroupMemeberModalSubmit").removeClass("btn-warning");
                    $("#delGroupMemeberModalSubmit").addClass("btn-danger");
                }else{
                    $("#delGroupMemeberModalHeading").text("Cancel Request Confirm");
                    $("#delGroupMemeberModalTitle").text("Are you sure you want to cancel request?");
                    $("#delGroupMemeberModalSubmit").text("Cancel Request");
                    $("#delGroupMemeberModalSubmit").removeClass("btn-danger");
                    $("#delGroupMemeberModalSubmit").addClass("btn-warning");
                }
            }
        })
    }

    $("#delGroupMemeberModal").modal("toggle");
})

$(document).on("click", "#delGroupMemeberModalSubmit", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        const vActiveGroupId = $("#vActiveGroupId").val();
        
        let vChatGroupListJson=$("#vChatGroupListJson").val();
        if(vChatGroupListJson!=""){
            JSON.parse(vChatGroupListJson).map((curE,inde)=>{
                if(vActiveGroupId==curE.iGroupId){
                    const vChatGroupListJsonArr=curE.tGroupUsers!=""?String(curE.tGroupUsers).split(","):[];
                    const tGroupJoinMembArr=curE.tGroupJoinMemb!=""?String(curE.tGroupJoinMemb).split(","):[];

                    if(vChatGroupListJsonArr.includes(""+deleteMemberId)){
                        let deleteMemberName="";
                        const vChatUserListJson = $("#vChatUserListJson").val();
                        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                            const dataUserList=JSON.parse(vChatUserListJson);
                            
                            const dataUserListFilter=dataUserList.filter((curEle2,index2)=>{
                                return curEle2.iUserId==deleteMemberId
                            })
                            
                            if(dataUserListFilter.length){
                                deleteMemberName=dataUserListFilter[0]['vFullName'];
                            }
                        }

                        const vUserName=$("#vUserName").text();
        
                        var vDeleteMsgUser = htmlEncode(vUserName+"&nbsp;(group&nbsp;admin)&nbsp;removed&nbsp;"+ deleteMemberName +".");
                        
                        const finalMsg = JSON.stringify(vDeleteMsgUser);
        
                        socket.emit('send_grp_message', {
                            receiverChatID: vActiveGroupId,
                            senderChatID: dd['iLoginId'],
                            content: finalMsg,
                            ImageDataArr: [],
                            vReplyFileName: "",
                            vReplyMsg: "text",
                            vReplyMsg_id: "",
                            id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                            isGreetingMsg: 0,
                            vMembersList:vChatGroupListJsonArr.toString(),
                            vGroupMessageType:"DeleteMemeber",
                            isForwardMsg:0,
                            isDeleteprofile:0,
                            iRequestMsg:0,
                            vDeleteMemberId:deleteMemberId,
                            vNewAdminId:"",
                            RequestMemberId:""
                        });
        
                        let html = DeleteMeberGroupMsgHtml(timestampToAMPM(),deleteMemberId,1,dd['iLoginId'],0);
                        $("#MessageList").append(html);
                        feather.replace();
                        dynamicWithlabel();
                        scrollToBottom();
                        
                    }else if(tGroupJoinMembArr.includes(""+deleteMemberId)){

                        const vChatUserListJson = $("#vChatUserListJson").val();
                        if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                            const dataUserList=JSON.parse(vChatUserListJson);

                            dataUserList.map((curE,ind)=>{
                                if(curE.iUserId==deleteMemberId){
                                    const message = "You have cancelled the group chat request of " + curE.vFullName + ".";
                                    var encodedHtmlString2 = htmlEncode(message);
                                    const finalMsg2 = JSON.parse(JSON.stringify(encodedHtmlString2));
                                    const MsgId = dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());
                            
                                    socket.emit('send_grp_message', {
                                        receiverChatID: vActiveGroupId,
                                        senderChatID: dd['iLoginId'],
                                        content: finalMsg2,
                                        ImageDataArr: [],
                                        vReplyFileName: "",
                                        vReplyMsg: "text",
                                        vReplyMsg_id: "",
                                        id: MsgId,
                                        isGreetingMsg: 0,
                                        vMembersList: curE.iUserId,
                                        vGroupMessageType: "",
                                        isForwardMsg: 0,
                                        isDeleteprofile: 0,
                                        iRequestMsg: 4,
                                        vDeleteMemberId:"",
                                        vNewAdminId:"",
                                        RequestMemberId:""
                                    });

                                    socket.emit('GroupRefreshUpdate', {
                                        vActiveGroupId: vActiveGroupId,
                                        vUsers:"",
                                        isDelete:0
                                    });
                                }
                            })
                        }

                    }

                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        async: false,
                        url: API_URL + 'DeleteMember',
                        data: {
                            tToken: dd.tToken,
                            vActiveGroupId,
                            DeleteMemberId:deleteMemberId
                        },
                        success: function (data, status, xhr) {
                            if (data.status == 200) {
                                getGroupList();

                                $(".vGroupIds").each((e, item) => {
                                    const getRowId = $(item).attr("data-id");
                                    if (getRowId == vActiveGroupId) {
                                        $(item).click();
                                    }
                                })
                                
                                $(".vEditGroupMembrDelCls").each((e, item) => {
                                    const id = $(item).val();
                                    if (id == deleteMemberId) {
                                        $(item).closest("li").remove();
                                        $("#delGroupMemeberModal").modal("toggle");
                                        isNewMemberTab = 0;
                                    
                                        realTimeGroupModalUpdate();
                                    }
                                })
                            }
                        }
                    })
                }
            })
        }
    }

    // const filterNewData = editMemberOldData.filter((curEle, index) => {
    //     return curEle.iUserId != deleteMemberId
    // })    

    // editMemberOldData = filterNewData;
    // $(".vEditGroupMembrDelCls").each((e, item) => {
    //     const id = $(item).val();
    //     if (id == deleteMemberId) {
    //         $(item).closest("li").remove();
    //         $("#delGroupMemeberModal").modal("toggle");
    //     }
    // })
})

$(document).on("click", "#delGroupMemeberModalCancel", () => {
    $("#delGroupMemeberModal").modal("toggle");

    $(".vEditGroupMembrDelCls").each((e, item) => {
        $(item).prop("checked", false)
    })
})

$(document).on("click", "#delGroupMemeberModalClose", () => {
    $("#delGroupMemeberModal").modal("toggle");
    $(".vEditGroupMembrDelCls").each((e, item) => {
        $(item).prop("checked", false)
    })
})

$(document).on("input", "#vSearchEditMember", (e) => {
    const searchStr = String(e.target.value).toLocaleLowerCase();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    let iAddedUserArr = [];
    editMemberOldData.map((curEle, index) => {
        iAddedUserArr.push(curEle.iUserId);
    })

    if (isNewMemberTab == 0) {
        if (searchStr != "") {
            const filterData = editMemberOldData.filter((curEle, index) => {
                return String(curEle.vFullName).toLocaleLowerCase().includes('' + searchStr)
            })
            groupMemberHtml(filterData, 1, "vEditGrpMemeberOld");
        } else {
            groupMemberHtml(editMemberOldData, 1, "vEditGrpMemeberOld");
        }
    } else {
        if (searchStr != "") {
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);

                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);

                    const filterUserList = chatGroupList.filter((curEle, index) => {
                        return curEle.iUserId != dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId) && String(curEle.vFullName).toLocaleLowerCase().includes('' + searchStr) && curEle.eStatus=='y'
                    })

                    groupMemberHtml(filterUserList, 2, "vEditGrpMemeberOld");
                }
            }
        } else {
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);

                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);

                    const filterUserList = chatGroupList.filter((curEle, index) => {
                        return curEle.iUserId != dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId) && curEle.eStatus=='y' 
                    })

                    groupMemberHtml(filterUserList, 2, "vEditGrpMemeberOld");
                }
            }
        }
    }
})

$(document).on("click", "#NewUserGrpBtn", () => {
    getAllUserList();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    let iAddedUserArr = [];
    editMemberOldData.map((curEle, index) => {
        iAddedUserArr.push(curEle.iUserId);
    })

    NewSelectMemberGrp=[];

    $("#editGroupModalHeader").removeClass("modal-header-custom");
    $("#EditGroupModalBackBtn").removeClass("d-none");
    $("#editGroupHeaderTitle").text("Add Group Members");

    $("#NewUserGrpBtn").addClass("d-none");
    isNewMemberTab = 1;
    $("#vEditGrpButtonAdd").removeClass("d-none");
    $("#addGroupMembBtnDiv").removeClass("d-none");
    // $("#vEditGrpButtonUpd").addClass("d-none");

    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatUserListJsonArr);

            const filterUserList = chatGroupList.filter((curEle, index) => {
                return curEle.iUserId != dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId) && curEle.eStatus=='y'
            })

            groupMemberHtml(filterUserList, 2, "vEditGrpMemeberOld");
        }
    }
})

$(document).on("click", ".vEditGroupMembrCls", (e) => {
    const iUserIdSelect = Number(e.target.value);
    const vActiveGroupId=$("#vActiveGroupId").val();

    if (e.target.checked) {
        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        let vChatGroupListJson=$("#vChatGroupListJson").val();
        let vChatGroupListJsonArr=[];
        if(vChatGroupListJson!=""){
            JSON.parse(vChatGroupListJson).map((curE,inde)=>{
                if(vActiveGroupId==curE.iGroupId){
                    vChatGroupListJsonArr=String(curE.tGroupUsers).split(",");
                }
            })
        }

        if (vChatUserListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatUserListJsonArr);

            chatGroupList.map((curEle, index) => {
                if (Number(curEle.iUserId) == iUserIdSelect) {
                    if(!vChatGroupListJsonArr.includes(""+curEle.iUserId)){
                        curEle['iPending']=1;
                    }else{
                        curEle['iPending']=0;
                    }
                    
                    NewSelectMemberGrp.push(curEle);
                }
            })
        }
    } else {

        const filterData = NewSelectMemberGrp.filter((curEle, index) => {
            return curEle.iUserId != iUserIdSelect
        })

        NewSelectMemberGrp = filterData;
    }
})

$(document).on("click", "#vEditGrpButtonAdd", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        let newMembersIds=[];
        NewSelectMemberGrp.map(curEle=>{
            newMembersIds.push(""+curEle.iUserId)
        })

        const vActiveGroupId = $("#vActiveGroupId").val();

        const newMemberUniq = duplicateRemoveArr(newMembersIds);

        if (newMemberUniq.length) {
            $("#groupNewMemberAddLoader").removeClass("d-none");
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'AddNewGroupMember',
                data: {
                    tToken: dd.tToken,
                    vActiveGroupId,
                    vNewMemberIds: newMemberUniq.toString(),
                },
                success: function (data, status, xhr) {
                    if (data.status == 200) {
                        setTimeout(() => {

                            async function processArrayWithDelay(array, callback, delayTime) {

                                for (let i = 0; i < array.length; i++) {
                                    //Logic Code
                                    const curEle = array[i];

                                    const vChatUserListJson = $("#vChatUserListJson").val();
                                    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
                                        const dataUserList = JSON.parse(vChatUserListJson);

                                        dataUserList.map((curE, ind) => {
                                            if (curE.iUserId == curEle) {
                                                const message = "You have sent a group chat request to " + curE.vFullName + ".";
                                                var encodedHtmlString2 = htmlEncode(message);
                                                const finalMsg2 = JSON.parse(JSON.stringify(encodedHtmlString2));
                                                const MsgId = dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());

                                                socket.emit('send_grp_message', {
                                                    receiverChatID: vActiveGroupId,
                                                    senderChatID: dd['iLoginId'],
                                                    content: finalMsg2,
                                                    ImageDataArr: [],
                                                    vReplyFileName: "",
                                                    vReplyMsg: "text",
                                                    vReplyMsg_id: "",
                                                    id: MsgId,
                                                    isGreetingMsg: 0,
                                                    vMembersList: curE.iUserId,
                                                    vGroupMessageType: "",
                                                    isForwardMsg: 0,
                                                    isDeleteprofile: 0,
                                                    iRequestMsg: 1,
                                                    vDeleteMemberId: "",
                                                    vNewAdminId: "",
                                                    RequestMemberId: curE.iUserId
                                                });
                                            }
                                        })

                                        await delayTimeWait(delayTime);
                                        setTimeout(callback, 500);
                                    }

                                }
                            }

                            async function processItem(item) {
                                await delayTimeWait(500);
                                return item * 1;
                            }

                            processArrayWithDelay(newMemberUniq, processItem, 500)
                                .then(results => {
                                    console.log('All Message sent');
                                    getGroupList();
                                    
                                    isNewMemberTab = 0;

                                    NewSelectMemberGrp=[];

                                    $(".vGroupIds").each((e, item) => {
                                        const getRowId = $(item).attr("data-id");
                                        if (getRowId == vActiveGroupId) {
                                            $(item).click();
                                        }
                                    })

                                    socket.emit('GroupRefreshUpdate', {
                                        vActiveGroupId: vActiveGroupId,
                                        vUsers:"",
                                        isDelete:0
                                    });

                                    setTimeout(() => {
                                        $("#vGroupEditMemberList").click();
                                        $("#groupNewMemberAddLoader").addClass("d-none");
                                    }, 100);
                                });
                        }, 1000);
                    }
                }
            })
        }
    }
    
})

$(document).on("click", "#EditGroupModalBackBtn", () => {
    NewSelectMemberGrp = [];
    $("#editGroupModalHeader").addClass("modal-header-custom");
    $("#EditGroupModalBackBtn").addClass("d-none");
    $("#editGroupHeaderTitle").text("Group Members");

    // $("#vEditGrpButtonUpd").removeClass("d-none");
    $("#vEditGrpButtonAdd").addClass("d-none");
    $("#addGroupMembBtnDiv").addClass("d-none");

    if (isNewMemberTab == 0) {
        $("#groupDetailsEdit").modal("toggle");
    } else {
        $("#vSearchEditMember").val("");

        groupMemberHtml(editMemberOldData, 1, "vEditGrpMemeberOld");
        isNewMemberTab = 0;
        $("#NewUserGrpBtn").removeClass("d-none");
    }
})

// $(document).on("click", "#vEditGrpButtonUpd", () => {
//     const isLocalStorageExist = localStorage.getItem("whatsAppClone");
//     if (isLocalStorageExist != null) {
//         const dd = JSON.parse(isLocalStorageExist);

//         if(activeTab == "User"){
//             activeTab="Group";
//             $("#userGroup").click();
//         }

//         const memeberList = [];
//         const ActualMemeber=[];
//         editMemberOldData.map((curEle, index) => {
//             const iPending=curEle?.iPending && curEle.iPending==1?1:0
//             if(iPending==0){
//                 ActualMemeber.push(""+curEle.iUserId);
//             }else{
//                 memeberList.push(""+curEle.iUserId);
//             }
//         })

//         const vEditGrupName = $("#vEditGrupName").val();
//         const vEditGroupDesc = $("#vEditGroupDesc").val();
//         const vActiveGroupId = $("#vActiveGroupId").val();

//         const vGroupProfilePick = [{ fileName: tempFilename, imageData: finalProfilePick }];

//         let vOldUserList=[];
//         let pendingReqMemeber=[];
//         const vChatGroupListJson = $("#vChatGroupListJson").val();
//         if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
//             const filterGroupDetail=JSON.parse(vChatGroupListJson).filter((curEle,index)=>{
//                 return curEle.iGroupId==vActiveGroupId
//             })

//             if(filterGroupDetail.length){
//                 vOldUserList=String(filterGroupDetail[0]['tGroupUsers']).split(",");
//                 pendingReqMemeber=String(filterGroupDetail[0]['tGroupJoinMemb']).split(",");
//             }
//         }
        
//         let newMemberArr=[];
//         let deleteMemeberStr=[];
//         let cancelRequest=[];

//         memeberList.map((curEle,index)=>{
//             if(!pendingReqMemeber.includes(""+curEle)){
//                 if(curEle!=""){
//                     newMemberArr.push(curEle);
//                 }
//             }
//         })

//         vOldUserList.map((curEl,index)=>{
//             if(!ActualMemeber.includes(""+curEl)){
//                 if(curEl!=""){
//                     deleteMemeberStr.push(curEl);
//                 }
//             }
//         })

//         pendingReqMemeber.map((curEle,index)=>{
//             if(!memeberList.includes(""+curEle)){
//                 if(curEle!=""){
//                     cancelRequest.push(curEle);
//                 }
//             }
//         })

//         // let deleteMemberName="";
//         // const vChatUserListJson = $("#vChatUserListJson").val();
//         // if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
//         //     const dataUserList=JSON.parse(vChatUserListJson);

//         //     deleteMemeberStr.map((curEle,index)=>{
//         //         const dataUserListFilter=dataUserList.filter((curEle2,index2)=>{
//         //             return curEle2.iUserId==curEle
//         //         })
//         //         if(dataUserListFilter.length){
//         //             if(index==0){
//         //                 deleteMemberName=dataUserListFilter[0]['vFullName'];
//         //             }else if(deleteMemeberStr.length==Number(index)+1){
//         //                 deleteMemberName+=" and "+dataUserListFilter[0]['vFullName'];
//         //             }else{
//         //                 deleteMemberName+=", "+dataUserListFilter[0]['vFullName'];
//         //             }
//         //         }
//         //     })
//         // }

//         const withoutCancelReqMember=memeberList.filter((curEle,index)=>{ return !cancelRequest.includes(""+curEle) });

//         const vUserName=$("#vUserName").text();

//         if(deleteMemeberStr.length){
//             const deleteMemberArr=duplicateRemoveArr(deleteMemeberStr);
//             deleteMemberArr.map((curEle,index)=>{

//                 let deleteMemberName="";
//                 const vChatUserListJson = $("#vChatUserListJson").val();
//                 if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
//                     const dataUserList=JSON.parse(vChatUserListJson);
                    
//                     const dataUserListFilter=dataUserList.filter((curEle2,index2)=>{
//                         return curEle2.iUserId==curEle
//                     })
                    
//                     if(dataUserListFilter.length){
//                         deleteMemberName=dataUserListFilter[0]['vFullName'];
//                     }
//                 }

//                 var vDeleteMsgUser = htmlEncode(vUserName+"&nbsp;(group&nbsp;admin)&nbsp;removed&nbsp;"+ deleteMemberName +".");
                
//                 const finalMsg = JSON.stringify(vDeleteMsgUser);

//                 socket.emit('send_grp_message', {
//                     receiverChatID: vActiveGroupId,
//                     senderChatID: dd['iLoginId'],
//                     content: finalMsg,
//                     ImageDataArr: [],
//                     vReplyFileName: "",
//                     vReplyMsg: "text",
//                     vReplyMsg_id: "",
//                     id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
//                     isGreetingMsg: 0,
//                     vMembersList:ActualMemeber.toString(),
//                     vGroupMessageType:"DeleteMemeber",
//                     isForwardMsg:0,
//                     isDeleteprofile:0,
//                     iRequestMsg:0,
//                     vDeleteMemberId:curEle,
//                     vNewAdminId:"",
//                     RequestMemberId:""
//                 });

//                 let html = DeleteMeberGroupMsgHtml(timestampToAMPM(),curEle,1,dd['iLoginId'],0);
//                 $("#MessageList").append(html);
//                 feather.replace();
//                 dynamicWithlabel();
//                 scrollToBottom();
//             })
//         }

//         const withoutCancReqMemberUniq=duplicateRemoveArr(withoutCancelReqMember);
//         const deleteMemeberStrUniq=duplicateRemoveArr(deleteMemeberStr);
//         const cancelRequestUniq=duplicateRemoveArr(cancelRequest);

//         $.ajax({
//             type: 'POST',
//             dataType: "JSON",
//             async: false,
//             url: API_URL + 'AddNewGrp',
//             data: {
//                 tToken: dd.tToken,
//                 vGroupName: vEditGrupName,
//                 tDescription: vEditGroupDesc,
//                 vUsers: withoutCancReqMemberUniq.toString(),
//                 iUpdateBasic:0,
//                 deleteMemeberStr:deleteMemeberStrUniq.toString(),
//                 vActiveGroupId,
//                 vGroupProfile: vGroupProfilePick,
//                 ColorOptionSelect: finalColorSelection,
//                 isDeleteFile: isDeleteFile,
//                 cancelRequest:cancelRequestUniq.toString()
//             },
//             success: function (data, status, xhr) {
//                 if (data.status == 200) {
//                     editMemberOldData=[];
                    
//                     $("#groupDetailsEdit").modal("toggle");
//                     isNewMemberTab = 0;
//                     $("#NewUserGrpBtn").removeClass("d-none");

//                     NewSelectMemberGrp = [];
//                     $("#editGroupModalHeader").addClass("modal-header-custom");
//                     $("#EditGroupModalBackBtn").addClass("d-none");
//                     $("#editGroupHeaderTitle").text("Group Members");

//                     tempFilename = "";
//                     finalProfilePick = "";
//                     finalColorSelection = "";

//                     socket.emit('GroupRefreshUpdate',{
//                         vActiveGroupId: vActiveGroupId,
//                         vUsers: [...memeberList,...ActualMemeber].toString(),
//                         isDelete:0
//                     });

//                     if(newMemberArr.length){
//                         setTimeout(() => {
//                             async function processArrayWithDelay(array, callback, delayTime) {
                                            
//                                 for (let i = 0; i < array.length; i++) {
//                                     //Logic Code
//                                     const curEle = array[i];

//                                     const vChatUserListJson = $("#vChatUserListJson").val();
//                                     if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
//                                         const dataUserList=JSON.parse(vChatUserListJson);

//                                         dataUserList.map((curE,ind)=>{
//                                             if(curE.iUserId==curEle){
//                                                 const message = "You have sent a group chat request to " + curE.vFullName + ".";
//                                                 var encodedHtmlString2 = htmlEncode(message);
//                                                 const finalMsg2 = JSON.parse(JSON.stringify(encodedHtmlString2));
//                                                 const MsgId = dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());
                                        
//                                                 socket.emit('send_grp_message', {
//                                                     receiverChatID: vActiveGroupId,
//                                                     senderChatID: dd['iLoginId'],
//                                                     content: finalMsg2,
//                                                     ImageDataArr: [],
//                                                     vReplyFileName: "",
//                                                     vReplyMsg: "text",
//                                                     vReplyMsg_id: "",
//                                                     id: MsgId,
//                                                     isGreetingMsg: 0,
//                                                     vMembersList: curE.iUserId,
//                                                     vGroupMessageType: "",
//                                                     isForwardMsg: 0,
//                                                     isDeleteprofile: 0,
//                                                     iRequestMsg: 1,
//                                                     vDeleteMemberId:"",
//                                                     vNewAdminId:"",
//                                                     RequestMemberId:curE.iUserId
//                                                 });
//                                             }
//                                         })

//                                         await delayTimeWait(delayTime);
//                                         setTimeout(callback, 500);
//                                     }
                                    
//                                 }
//                             }
                            
//                             async function processItem(item) {
//                                 await delayTimeWait(500);
//                                 return item * 1;
//                             }
                            
//                             const newMemberUniq=duplicateRemoveArr(newMemberArr);

//                             processArrayWithDelay(newMemberUniq, processItem, 500)
//                             .then(results => {
//                                 console.log('All Message sent');

//                                 $(".vGroupIds").each((e, item) => {
//                                     const getRowId = $(item).attr("data-id");
//                                     if (getRowId == vActiveGroupId) {
//                                         $(item).click();
//                                     }
//                                 })
//                             });
//                         }, 1000);
//                     }

//                     if(cancelRequest.length){
//                         setTimeout(() => {
//                             async function processArrayWithDelay(array, callback, delayTime) {
                                            
//                                 for (let i = 0; i < array.length; i++) {
//                                     //Logic Code
//                                     const curEle = array[i];

//                                     const vChatUserListJson = $("#vChatUserListJson").val();
//                                     if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
//                                         const dataUserList=JSON.parse(vChatUserListJson);

//                                         dataUserList.map((curE,ind)=>{
//                                             if(curE.iUserId==curEle){
//                                                 const message = "You have cancelled the group chat request of " + curE.vFullName + ".";
//                                                 var encodedHtmlString2 = htmlEncode(message);
//                                                 const finalMsg2 = JSON.parse(JSON.stringify(encodedHtmlString2));
//                                                 const MsgId = dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());
                                        
//                                                 socket.emit('send_grp_message', {
//                                                     receiverChatID: vActiveGroupId,
//                                                     senderChatID: dd['iLoginId'],
//                                                     content: finalMsg2,
//                                                     ImageDataArr: [],
//                                                     vReplyFileName: "",
//                                                     vReplyMsg: "text",
//                                                     vReplyMsg_id: "",
//                                                     id: MsgId,
//                                                     isGreetingMsg: 0,
//                                                     vMembersList: curE.iUserId,
//                                                     vGroupMessageType: "",
//                                                     isForwardMsg: 0,
//                                                     isDeleteprofile: 0,
//                                                     iRequestMsg: 4,
//                                                     vDeleteMemberId:"",
//                                                     vNewAdminId:"",
//                                                     RequestMemberId:""
//                                                 });
//                                             }
//                                         })

//                                         await delayTimeWait(delayTime);
//                                         setTimeout(callback, 500);
//                                     }
                                    
//                                 }
//                             }
                            
//                             async function processItem(item) {
//                                 await delayTimeWait(500);
//                                 return item * 1;
//                             }
                            
//                             const cancelRequestUniq=duplicateRemoveArr(cancelRequest);
//                             processArrayWithDelay(cancelRequestUniq, processItem, 500)
//                             .then(results => {
//                                 console.log('All Message sent');

//                                 $(".vGroupIds").each((e, item) => {
//                                     const getRowId = $(item).attr("data-id");
//                                     if (getRowId == vActiveGroupId) {
//                                         $(item).click();
//                                     }
//                                 })
//                             });
//                         }, 1000);
//                     }

//                     getGroupList();
//                 }
//             }
//         });
//     }
// })

$(document).on("input", "#vEditGroupDesc", (e) => {
    const stringLength = String(e.target.value).length;
    if (stringLength <= 350) {
        $("#totalCharDisp").text(stringLength + "/350");
    }
})

$(document).on("click", "#UpdateGroupBasicDetail", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vActiveGroupId = $("#vActiveGroupId").val();

        let memeberList = "";

        const vChatGroupListJson = $("#vChatGroupListJson").val();
        if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
            JSON.parse(vChatGroupListJson).map((curEle, index) => {
                if (curEle.iGroupId == vActiveGroupId) {
                    memeberList = curEle.tGroupUsers
                    if (((tempFilename == "" || tempFilename == undefined) && finalColorSelection == "")) {
                        finalColorSelection = curEle.iColorOption
                    }
                }
            })
        }

        const vEditGrupName = $("#vEditGrupName").val();
        const vEditGroupDesc = $("#vEditGroupDesc").val();

        const vGroupProfilePick = [{ fileName: tempFilename, imageData: finalProfilePick }];

        if(vEditGrupName==""){
            $("#vEditGrupNameErr").addClass("error-cust");
        }else{
            $("#vEditGrupNameErr").removeClass("error-cust");
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'AddNewGrp',
                data: {
                    tToken: dd.tToken,
                    vGroupName: vEditGrupName,
                    tDescription: vEditGroupDesc,
                    vUsers: "",
                    iUpdateBasic:1,
                    deleteMemeberStr:"",
                    vActiveGroupId,
                    vGroupProfile: vGroupProfilePick,
                    ColorOptionSelect: Number(finalColorSelection),
                    isDeleteFile: Number(isDeleteFile),
                    cancelRequest:""
                },
                success: function (data, status, xhr) {
                    if (data.status == 200) {
                        getGroupList();
                        $("#groupDetailsEdit").modal("toggle");
                        isNewMemberTab = 0;
                        $("#NewUserGrpBtn").removeClass("d-none");
                        $("#activeChatName").text(vEditGrupName);
    
                        NewSelectMemberGrp = [];
                        $("#editGroupModalHeader").addClass("modal-header-custom");
                        $("#EditGroupModalBackBtn").addClass("d-none");
                        $("#editGroupHeaderTitle").text("Group Members");
    
                        tempFilename = "";
                        finalProfilePick = "";
                        finalColorSelection = "";
    
                        socket.emit('GroupRefreshUpdate', {
                            vActiveGroupId: vActiveGroupId,
                            vUsers:"",
                            isDelete:0
                        });

                        $("#vEditGrupNameErr").attr("data-error","Required");
                    }else if(data.status == 412){
                        $("#vEditGrupNameErr").addClass("error-cust");
                        $("#vEditGrupNameErr").attr("data-error",data.message);
                    }
                }
            });
        }
    }
})

//Edit Group Detail Modal Code End

//Delete Group Code Start
$(document).on("click", "#vGroupDeleteGroup", () => {
    $("#groupDeleteModal").modal("toggle")
})

$(document).on("click", "#groupDeleteModalClose,#groupDeleteModalCancel", () => {
    $("#groupDeleteModal").modal("toggle");
})

$(document).on("click", "#groupDeleteModalSubmit", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        const vActiveGroupId = $("#vActiveGroupId").val();

        $("#groupDeleteModalLoader").removeClass("d-none");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'DeleteGroup',
            data: {
                tToken: dd.tToken,
                vActiveGroupId
            },
            success: function (data, status, xhr) {
                $("#groupDeleteModalLoader").addClass("d-none");

                if (data.status == 200) {
                    $("#groupDeleteModal").modal("toggle");
                    getGroupList();

                    $("#groupDetailsEdit").modal("toggle");

                    $("#StartChatArea").removeClass("d-none");
                    $("#HeaderChatArea").addClass("d-none");
                    $("#MainChatArea").addClass("d-none");
                    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

                    socket.emit('GroupRefreshUpdate',{
                        vActiveGroupId: vActiveGroupId,
                        vUsers:"",
                        isDelete:1
                    });
                }
            }
        });
    }
})
//Delete Group Code End

//Permission based button display code start
$(document).on("click", "#GroupDropDown", () => {
    const vActiveGroupId = $("#vActiveGroupId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        if(vActiveGroupId>0){
            $("#vGroupDeleteChat").closest("li").removeClass("d-none");

            $("#vUserDeleteChat").closest("li").addClass("d-none");
            const vChatGroupListJson = $("#vChatGroupListJson").val();
            if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
                JSON.parse(vChatGroupListJson).map((curEle, index) => {
                    if (curEle.iGroupId == vActiveGroupId) {
                        if (curEle.iCreatedBy != dd.iLoginId) {
                            $("#vGroupEditGroup").closest("li").addClass("d-none");
                        } else {
                            $("#vGroupEditGroup").closest("li").removeClass("d-none");
                        }

                        const vGroupMemberListArr=String(curEle.tGroupUsers).split(",").filter(c=>c);
                        const tGroupJoinMembArr=String(curEle.tGroupJoinMemb).split(",").filter(c=>c);
                        if(vGroupMemberListArr.includes(""+dd.iLoginId) || curEle.iCreatedBy == dd.iLoginId){
                            $("#vExitGroup").closest("li").removeClass("d-none");
                            $("#vDeleteGroup").closest("li").addClass("d-none");
                            $("#vGroupInfoBtn").closest("li").removeClass("d-none");
                            $("#vGroupDeleteChat").removeClass("disabled");
                        }else{
                            if(tGroupJoinMembArr.includes(""+dd.iLoginId)){
                                $("#vExitGroup").closest("li").addClass("d-none");
                                $("#vDeleteGroup").closest("li").addClass("d-none");
                                $("#vGroupInfoBtn").closest("li").removeClass("d-none");
                                $("#vGroupDeleteChat").addClass("disabled");
                            }else{
                                $("#vExitGroup").closest("li").addClass("d-none");
                                $("#vDeleteGroup").closest("li").removeClass("d-none");
                                $("#vGroupInfoBtn").closest("li").addClass("d-none");
                                $("#vGroupDeleteChat").removeClass("disabled");
                            }
                        } 
                    }
                })
            }
        }else{
            $("#vGroupInfoBtn").closest("li").addClass("d-none");
            $("#vGroupDeleteChat").closest("li").addClass("d-none");
            $("#vGroupEditGroup").closest("li").addClass("d-none");
            $("#vUserDeleteChat").closest("li").removeClass("d-none");
            $("#vExitGroup").closest("li").addClass("d-none");
            $("#vDeleteGroup").closest("li").addClass("d-none");
        }
    }
})
//Permission based button display code End

//Edit Profile Modal Code Start
function updateStatus(statusId) {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vUserName = $("#vUserName").text();

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'EditUserProfile',
            data: {
                tToken: dd.tToken,
                eCustStatus: statusId,
                vEditProfileFullName: vUserName
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    $("#vActiveProfileSts").val(statusId);
                    if (statusId == 2) {
                        $("#vUserLoggedSts").text("Online");
                        $("#vLoggedSts").removeClass("offline");
                        $("#vLoggedSts").addClass("online");
                    } else {
                        if (statusId == 1) {
                            $("#vUserLoggedSts").text("Online");
                            $("#vLoggedSts").removeClass("offline");
                            $("#vLoggedSts").addClass("online");
                        } else {
                            $("#vUserLoggedSts").text("Offline");
                            $("#vLoggedSts").addClass("offline");
                            $("#vLoggedSts").removeClass("online");
                        }
                    }

                    $(".changeOnlineStst").each((e, item) => {
                        const datId = $(item).attr("data-id");
                        if (datId == statusId) {
                            $(item).addClass("active");
                        } else {
                            $(item).removeClass("active");
                        }
                    })

                    let vConvertionChatArr = $("#vChatUserListJson").val();

                    if (vConvertionChatArr != "") {
                        const ChatUserListArr = JSON.parse(vConvertionChatArr);
                        const vUsers=[];

                        ChatUserListArr.map((curEle,index)=>{
                            vUsers.push(curEle.iUserId);
                        })

                        if(vUsers.length){
                            socket.emit('AllUserGetMyNewSts',{
                                tToken:dd.tToken,
                                vUsers:vUsers.toString()
                            });
                        }
                    }
                }
            }
        });
    }
}

$(document).on("click", ".changeOnlineStst", (e) => {
    const dataId = $(e.currentTarget).attr("data-id");
    updateStatus(dataId);
})

$(document).on("click", "#vEditProfilePickBtn", () => {
    ProfileImageType = 3;
    $("#NewGroupProfilePickSubmit").removeClass("d-none");
    $("#EditUserProfileSubmit").addClass("d-none");

    isGroupProfileEdit = true;
    $("#vGroupProfilePickModal").modal("toggle");
    const vActiveGroupId = $("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();

    $("#ImageCropperHeading").text("Create New Group");

    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        const filterData = chatGroupList.filter((curEle, index) => {
            return curEle.iGroupId == vActiveGroupId
        })

        if (filterData.length > 0) {
            if (finalColorSelection == "" && finalProfilePick == "") {
                const iColorOption = filterData[0]['iColorOption'];
                const vGroupImage = filterData[0]['vGroupImage'];

                $("#vColorOptionHtml").html("");
                GroupColorOption.map((curEle, index) => {
                    let html = `<li>
                                <a class="cursor-pointer profile vProfileColorOptions rounded-3 ${vGroupImage == "" && iColorOption == curEle.iColorId ? 'active' : ''}"  data-id="${curEle.iColorId}">
                                    <img src="${curEle.vColorPick}" class="rounded-3" alt="group-profile">
                                </a>
                            </li>`;
                    $("#vColorOptionHtml").append(html);
                })

                $("#item-img-output").removeClass("rounded-circle");
                $("#item-img-output").addClass("rounded-3");

                if (vGroupImage != "") {
                    $("#item-img-output").attr("src", vGroupImage);
                    $("#deletGroupProfile").removeClass("d-none");
                    $("#vChooseProfileBtn").addClass("d-none");
                    vCroppingImageBase64 = vGroupImage;
                } else {
                    $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
                    $("#deletGroupProfile").addClass("d-none");
                    $("#vChooseProfileBtn").removeClass("d-none");
                    vCroppingImageBase64 = "";
                }
            } else {
                const iColorOption = finalColorSelection;
                const vGroupImage = finalProfilePick;

                $("#vColorOptionHtml").html("");
                GroupColorOption.map((curEle, index) => {
                    let html = `<li>
                                <a class="cursor-pointer profile vProfileColorOptions rounded-3 ${vGroupImage == "" && iColorOption == curEle.iColorId ? 'active' : ''}"  data-id="${curEle.iColorId}">
                                    <img src="${curEle.vColorPick}" class="rounded-3" alt="group-profile">
                                </a>
                            </li>`;
                    $("#vColorOptionHtml").append(html);
                })

                $("#item-img-output").removeClass("rounded-circle");
                $("#item-img-output").addClass("rounded-3");

                if (vGroupImage != "") {
                    $("#item-img-output").attr("src", vGroupImage);
                    $("#deletGroupProfile").removeClass("d-none");
                    $("#vChooseProfileBtn").addClass("d-none");
                    vCroppingImageBase64 = vGroupImage;
                } else {
                    $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
                    $("#deletGroupProfile").addClass("d-none");
                    $("#vChooseProfileBtn").removeClass("d-none");
                    vCroppingImageBase64 = "";
                }
            }
        }
    }
})

//Edit Profle Modal Code End

//Edit Profile Pick Of Group Code Start
let colorOption = [
    { iColorId: 1, vColorPick: "./images/profile/user-p-10.svg" },
    { iColorId: 2, vColorPick: "./images/profile/user-p-2.svg" },
    { iColorId: 3, vColorPick: "./images/profile/user-p-3.svg" },
    { iColorId: 4, vColorPick: "./images/profile/user-p-4.svg" },
    { iColorId: 5, vColorPick: "./images/profile/user-p-5.svg" },
    { iColorId: 6, vColorPick: "./images/profile/user-p-6.svg" },
    { iColorId: 7, vColorPick: "./images/profile/user-p-7.svg" },
    { iColorId: 8, vColorPick: "./images/profile/user-p-8.svg" },
    { iColorId: 9, vColorPick: "./images/profile/user-p-9.svg" },
];

let GroupColorOption=[
    { iColorId: 1, vColorPick: "./images/profile/group-p-10.svg" },
    { iColorId: 2, vColorPick: "./images/profile/group-p-2.svg" },
    { iColorId: 3, vColorPick: "./images/profile/group-p-3.svg" },
    { iColorId: 4, vColorPick: "./images/profile/group-p-4.svg" },
    { iColorId: 5, vColorPick: "./images/profile/group-p-5.svg" },
    { iColorId: 6, vColorPick: "./images/profile/group-p-6.svg" },
    { iColorId: 7, vColorPick: "./images/profile/group-p-7.svg" },
    { iColorId: 8, vColorPick: "./images/profile/group-p-8.svg" },
    { iColorId: 9, vColorPick: "./images/profile/group-p-9.svg" },
];

let finalProfilePick = "";
let finalColorSelection = "";
let isGroupProfileEdit = false;
let isDeleteFile = 0;

$(document).on("click", "#vGroupPicturePick", () => {
    ProfileImageType = 2;
    $("#vGroupProfilePickModal").modal("toggle");
    $("#NewGroupProfilePickSubmit").removeClass("d-none");
    $("#EditUserProfileSubmit").addClass("d-none");

    isGroupProfileEdit = false;

    $("#ImageCropperHeading").text("Create New Group");

    $("#vColorOptionHtml").html("");
    GroupColorOption.map((curEle, index) => {
        let html = `<li>
                    <a class="cursor-pointer profile vProfileColorOptions rounded-3 ${finalProfilePick == "" && finalColorSelection == curEle.iColorId ? 'active' : ''}"  data-id="${curEle.iColorId}">
                        <img src="${curEle.vColorPick}" class="rounded-3" alt="group-profile">
                    </a>
                </li>`;
        $("#vColorOptionHtml").append(html);
    })

    $("#item-img-output").addClass("rounded-3");
    $("#item-img-output").removeClass("rounded-circle");

    if (finalProfilePick != "") {
        $("#item-img-output").attr("src", finalProfilePick);
        $("#deletGroupProfile").removeClass("d-none");
        $("#vChooseProfileBtn").addClass("d-none");
        vCroppingImageBase64 = finalProfilePick;
    } else {

        $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");
        vCroppingImageBase64 = "";
    }
})

let ProfileImageType = "";

let ColorOptionSelect = 0;
$(document).on("click", ".vProfileColorOptions", (e) => {
    $(".vProfileColorOptions").removeClass("active");
    $(e.currentTarget).addClass("active");

    ColorOptionSelect = $(e.currentTarget).attr("data-id");
    vCroppingImageBase64 = "";
    tempFilename = "";


    if (ProfileImageType == 1) {
        $("#item-img-output").removeClass("rounded-3");
        $("#item-img-output").addClass("rounded-circle");
    } else if (ProfileImageType == 2 || ProfileImageType == 3) {
        $("#item-img-output").addClass("rounded-3");
        $("#item-img-output").removeClass("rounded-circle");
    }

    $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
    $("#deletGroupProfile").addClass("d-none");
    $("#vChooseProfileBtn").removeClass("d-none");
})

var $uploadCrop, tempFilename, rawImg, imageId;

function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('.upload-demo').addClass('ready');
            $('#cropImagePop').modal('show');
            $("#file_photo").val("");
            rawImg = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    } else {
        swal("Sorry - you're browser doesn't support the FileReader API");
    }
}

$uploadCrop = $('#upload-demo').croppie({
    viewport: {
        width: 100,
        height: 100,
    },
    enforceBoundary: false,
    enableExif: true
});

$('#cropImagePop').on('shown.bs.modal', function () {
    $uploadCrop.croppie('bind', {
        url: rawImg
    }).then(function () {
        console.log('jQuery bind complete');
    });
});

$('.item-img').on('change', function () {
    $(".cr-image").attr("src", "./images/profile/custom-group-profile.svg")
    imageId = $(this).data('id');
    tempFilename = $(this).val();
    $('#cancelCropBtn').data('id', imageId);
    readFile(this);
});

let vCroppingImageBase64 = "";
$('#cropImageBtn').on('click', function (ev) {
    $uploadCrop.croppie('result', {
        type: 'base64',
        format: 'jpeg',
        size: {
            width: 100,
            height: 100
        }
    }).then(function (resp) {
        vCroppingImageBase64 = resp;
        $('#item-img-output').attr('src', resp);
        $('#cropImagePop').modal('hide');
        $("#file_photo").val("");
        $("#deletGroupProfile").removeClass("d-none");
        $(".vProfileColorOptions").removeClass("active");
        $("#vChooseProfileBtn").addClass("d-none");
    });
});

$(document).on("click", "#deletGroupProfile", () => {
    ColorOptionSelect = getRandomInt(9);

    if (isGroupProfileEdit) {
        $("#delGrpProfConfModal").modal("toggle");
    } else {
        vCroppingImageBase64 = "";
        tempFilename = "";

        $("#item-img-output").removeClass("rounded-circle");
        $("#item-img-output").removeClass("rounded-3");
        
        // console.log("ProfileImageType=>",ProfileImageType)
        if(ProfileImageType==2){
            $("#item-img-output").addClass("rounded-3");
        }

        $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");


        $(".vProfileColorOptions").each((e, item) => {
            const id = $(item).attr("data-id");
            if (id == ColorOptionSelect) {
                $(item).addClass('active');
            }
        })
    }
})

$(document).on("click", "#delGrpProfConfModalClose,#delGrpProfConfModalCancel", () => {
    $("#delGrpProfConfModal").modal("toggle");
})

$(document).on("click", "#delGrpProfConfModalSubmit", () => {
    vCroppingImageBase64 = "";
    tempFilename = "";

    $("#item-img-output").removeClass("rounded-3");
    $("#item-img-output").removeClass("rounded-circle");
    
    if(ProfileImageType==3){
        $("#item-img-output").addClass("rounded-3");
    }

    $("#item-img-output").attr("src", "./images/profile/custom-group-profile.svg");
    $("#deletGroupProfile").addClass("d-none");
    $("#vChooseProfileBtn").removeClass("d-none");


    $(".vProfileColorOptions").each((e, item) => {
        const id = $(item).attr("data-id");
        if (id == ColorOptionSelect) {
            $(item).addClass('active');
        }
    })

    $("#delGrpProfConfModal").modal("toggle");
})

$(document).on("click", "#NewGroupProfilePickSubmit", () => {
    const splitPath = String(tempFilename).split("\\");
    const fileName = tempFilename != "" ? splitPath[splitPath.length - 1] : "";

    tempFilename = fileName;

    finalProfilePick = vCroppingImageBase64;
    finalColorSelection = ColorOptionSelect;

    if (vCroppingImageBase64 == "") {
        isDeleteFile = 1;
    } else {
        isDeleteFile = 0;
    }

    if (isGroupProfileEdit) {
        if (vCroppingImageBase64 != "") {
            $("#vGroupEditProfile").attr("src", vCroppingImageBase64)
        } else {
            const filterColorOption = GroupColorOption.filter((curEle2, index) => {
                return curEle2.iColorId == ColorOptionSelect
            })

            if (filterColorOption.length > 0) {
                $("#vGroupEditProfile").attr("src", filterColorOption[0]['vColorPick']);
            }
        }
    } else {
        if (vCroppingImageBase64 != "") {
            $("#vGroupPicSelected").attr("src", vCroppingImageBase64);
        } else {
            const filterColorOption = GroupColorOption.filter((curEle2, index) => {
                return curEle2.iColorId == ColorOptionSelect
            })

            if (filterColorOption.length > 0) {
                $("#vGroupPicSelected").attr("src", filterColorOption[0]['vColorPick']);
            }
        }
    }

    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click", "#vBackGroupProfilePick", () => {
    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click", "#vGroupProfilePickClose", () => {
    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click", "#vGroupProfilePickCancel", () => {
    $("#vGroupProfilePickModal").modal("toggle");
})

//Edit Profile Pick Of Group Code End

//Edit User Profile Code Start
$(document).on("click", "#vEditProfilePickDrop", () => {
    isDeleteFile = 0;
    ColorOptionSelect = "";
    finalColorSelection = "";
    finalProfilePick = "";
    $("#editProfilePickModal").modal("toggle");
    $("#vEditUserProfilePick").attr("src", $("#vProfilePick").attr("xlink:href"));
    $("#vEditProfileFullName").val($("#vUserName").text());

    $("#vUserChangePwdTab").removeClass("active");
    $("#vUserDeleteProfTab").removeClass("active");
    $("#vUserDetailTab").addClass("active");
    $("#editProfPassSuccesMsg").addClass("d-none");
    $("#editProfChngePwd").removeClass("disabled d-none");
    $("#user-basic-tab").addClass("show active");
    $("#user-change-password").removeClass("show active");
    $("#user-delete-profile").removeClass("show active");
    
    let vEmail="";
    let vUserIdDispl="";
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        vEmail=dd?.vEmail;
        vUserIdDispl=dd?.iEngId;
    }
    $("#vEditEmailAddrss").val(vEmail);
    $("#vUserDispId").val(vUserIdDispl);
})

$(document).on("click","#vUserDeleteProfTab",()=>{
    $("#vDeleProfVerfPwdErr").attr("data-error","Required");
    $("#vDeleProfVerfPwdErr").removeClass("error-cust");
    $("#vDeleProfVerfPwd").val("");
})

//Change Email Address
$(document).on("click","#changeEmailAddressBtn",()=>{
    $("#changeEmailModal").modal("toggle");
    $("#vEmailOldPassword").val("");
    $("#vNewEmailAddrs").val("");

    $("#vEmailChangeVerfCode").val("");
    $("#vChangeEmailForm").removeClass("d-none");
    $("#vChangeEmailOtp").addClass("d-none");
    $("#vChangeEmailErrMsg").addClass("d-none");
    $("#vNewEmailAddrs").val("");
    $("#vEmailOldPasswordErr").val("");
    
    $("#vNewEmailAddrsErr").removeClass("error-cust");
    $("#vNewEmailAddrsErr").attr("data-error","Required");
    $("#vEmailOldPasswordErr").removeClass("error-cust");
    $("#vEmailOldPasswordErr").attr("data-error","Required");

    $("#vEmailChangeTitle").text("Change Email");
    $("#submitChangeEmail").removeClass("d-none");
    $("#resendChangeEmail").addClass("d-none");
    $("#submitChangeEmailClose").removeClass("d-none");
    $("#finalSubmitEmail").addClass("d-none");

    $("#ViewEmailOldPassrd").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
    feather.replace();
})

// resendChangeEmail
function sendCheckPassForEmail(){
    const vEmailOldPassword=$("#vEmailOldPassword").val();
    const vNewEmailAddrs=$("#vNewEmailAddrs").val();

    if(vNewEmailAddrs=="" || vEmailOldPassword==""){
        if(vEmailOldPassword==""){
            $("#vEmailOldPasswordErr").addClass("error-cust");
            $("#vEmailOldPasswordErr").attr("data-error","Required");
        }

        if(vNewEmailAddrs==""){
            $("#vNewEmailAddrsErr").addClass("error-cust");
            $("#vNewEmailAddrsErr").attr("data-error","Required");
        }
    }else{
        if(!validateEmail(vNewEmailAddrs)){
            $("#vNewEmailAddrsErr").addClass("error-cust");
            $("#vNewEmailAddrsErr").attr("data-error","Please enter valid email address.");
        }else{
            $("#vNewEmailAddrsErr").removeClass("error-cust");
            $("#vNewEmailAddrsErr").attr("data-error","Required");
        }
    
        $("#vEmailOldPasswordErr").removeClass("error-cust");
        $("#submitChangeEmail").addClass("disabled");
    
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            $("#changeEmailModalLoader").removeClass("d-none");
    
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: API_URL + 'checkPassword',
                data: {
                    iUserId:dd.iLoginId,
                    vPassWord:vEmailOldPassword
                },
                success: function (data, status, xhr) {
                    $("#submitChangeEmail").removeClass("disabled");
                    if(data.status==411){
                        $("#changeEmailModalLoader").addClass("d-none");
    
                        $("#vEmailOldPasswordErr").addClass("error-cust");
                        $("#vEmailOldPasswordErr").attr("data-error","Invalid password.");
    
                        // $("#vChangeEmailErrMsg").removeClass("d-none");
                        // $("#vChangeEmailErrMsg").text(data.message);
                    }else if(data.status==200){
                        if(validateEmail(vNewEmailAddrs)){
                            $("#vChangeEmailForm").addClass("d-none");
                            $("#vChangeEmailOtp").removeClass("d-none");
                            $("#submitChangeEmail").addClass("d-none");
                            $("#finalSubmitEmail").removeClass("d-none");
    
                            $("#vEmailChangeTitle").text("Verify Email Code");
                            
                            sendVerifyChangeEmail();
                        }else{
                            $("#changeEmailModalLoader").addClass("d-none");
                        }
                    }
                }
            })
        }
    }
}

function sendVerifyChangeEmail(){
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vNewEmailAddrs=$("#vNewEmailAddrs").val();
        $("#changeEmailModalLoader").removeClass("d-none");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            url: API_URL + 'resend_verify_email',
            data: {
                vUsername:dd.iEngId,
                vNewEmailAddrs:vNewEmailAddrs,
                type:2
            },
            success: function (data, status, xhr) {
                $("#resendChangeEmail").removeClass("d-none");
                $("#changeEmailModalLoader").addClass("d-none");
            }
        })
    }
}

$(document).on("click","#submitChangeEmail",()=>{
    sendCheckPassForEmail();
})

$(document).on("click","#submitChangeEmailClose",()=>{
    $("#changeEmailModal").modal("toggle");
})

$(document).on("click","#resendChangeEmail",()=>{
    sendCheckPassForEmail();
})

$(document).on("click","#finalSubmitEmail",()=>{
    const vEmailChangeVerfCode=$("#vEmailChangeVerfCode").val();
    const vNewEmailAddrs=$("#vNewEmailAddrs").val();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
    
        $("#changeEmailModalLoader").removeClass("d-none")

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            url: API_URL +'email_code_verify',
            data: {
                vUsername: dd.iEngId,
                vOtp: vEmailChangeVerfCode
            },
            success: function(data, status, xhr) {
                if(data.status==200){
                    $("#verificationErrMsg").addClass("d-none");
    
                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        url: API_URL +'change_email',
                        data: {
                            iUserId:dd.iLoginId,vEmail:vNewEmailAddrs
                        },
                        success: function (data2, status2, xhr) {
                            $("#changeEmailModalLoader").addClass("d-none")

                            if(data2.status==200){
                                $("#vEditEmailAddrss").val(vNewEmailAddrs);

                                $("#changeEmailModal").modal("toggle");
                                $("#vEmailChangeVerfCode").val("");
                                $("#vChangeEmailForm").removeClass("d-none");
                                $("#vChangeEmailOtp").addClass("d-none");
                                $("#vChangeEmailErrMsg").addClass("d-none");
                                $("#vNewEmailAddrs").val("");
                                $("#vEmailOldPasswordErr").val("");

                                let whatsAppCloneData = localStorage.getItem("whatsAppClone");
                                if (whatsAppCloneData != null) {
                                    whatsAppCloneData = JSON.parse(whatsAppCloneData);
                                    whatsAppCloneData['vEmail'] = vNewEmailAddrs;
                                    localStorage.setItem("whatsAppClone", JSON.stringify(whatsAppCloneData));
                                }
                            }
                        }
                    })
                }else{
                    $("#changeEmailModalLoader").addClass("d-none")
                    $("#verificationErrMsg").removeClass("d-none")
                }
            }
        });
    }
})

$(document).on("click","#ViewEmailOldPassrd",()=>{
    const vPassWordtype=$("#vEmailOldPassword").attr("type");
    if(vPassWordtype=="password"){
        $("#vEmailOldPassword").attr("type","text");
        $("#ViewEmailOldPassrd").html(`<i class="feather feather-18" data-feather="eye"></i>`);
        feather.replace();
    }else{
        $("#vEmailOldPassword").attr("type","password");
        $("#ViewEmailOldPassrd").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
        feather.replace();
    }
})


$(document).on("click", "#vEditUserProfilePickBtn", () => {
    ProfileImageType = 1;
    const vLoggedColorOption = Number($("#vLoggedColorOption").val());
    finalColorSelection = vLoggedColorOption;
    isGroupProfileEdit = true;
    $("#NewGroupProfilePickSubmit").addClass("d-none");
    $("#EditUserProfileSubmit").removeClass("d-none");

    $("#vGroupProfilePickModal").modal("toggle");

    $("#ImageCropperHeading").text("Edit User Profile");

    $("#item-img-output").removeClass("rounded-3");
    $("#item-img-output").addClass("rounded-circle");

    if (vLoggedColorOption == 0) {
        $("#item-img-output").attr("src", $("#vEditUserProfilePick").attr("src"));
        $("#deletGroupProfile").removeClass("d-none");
        $("#vChooseProfileBtn").addClass("d-none");
    } else {
        $("#item-img-output").attr("src", './images/profile/custom-group-profile.svg');
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");
    }


    $("#vColorOptionHtml").html("");

    colorOption.map((curEle, index) => {
        let html = `<li>
                    <a class="cursor-pointer profile vProfileColorOptions rounded-circle ${finalProfilePick == "" && finalColorSelection == curEle.iColorId ? 'active' : ''}"  data-id="${curEle.iColorId}">
                        <img src="${curEle.vColorPick}" class="rounded-circle" alt="group-profile">
                    </a>
                </li>`;
        $("#vColorOptionHtml").append(html);
    })
})

$(document).on("click", "#EditUserProfileSubmit", () => {
    $("#vGroupProfilePickModal").modal("toggle");

    const splitPath = String(tempFilename).split("\\");
    const fileName = tempFilename != "" ? splitPath[splitPath.length - 1] : "";

    tempFilename = fileName;

    finalProfilePick = vCroppingImageBase64;
    finalColorSelection = ColorOptionSelect;

    if (vCroppingImageBase64 == "") {
        isDeleteFile = 1;
    } else {
        isDeleteFile = 0;
    }

    $("#vLoggedColorOption").val(finalColorSelection)

    if (vCroppingImageBase64 != "") {
        $("#vEditUserProfilePick").attr("src", vCroppingImageBase64)
    } else {
        const filterColorOption = colorOption.filter((curEle2, index) => {
            return curEle2.iColorId == ColorOptionSelect
        })

        if (filterColorOption.length > 0) {
            $("#vEditUserProfilePick").attr("src", filterColorOption[0]['vColorPick']);
        }
    }
})

//Password Change
$(document).on("click","#editProfChngePwd",()=>{
    const vOldPassword=$("#vOldPassword").val();
    const vNewPassword=$("#vNewPassword").val();

    if(vOldPassword=="" && vNewPassword==""){
        if(vOldPassword==""){
            $("#vOldPasswordErr").addClass("error-cust");
            $("#vOldPassword").click();
            $("#vOldPassword").focus();
        }

        if(vNewPassword==""){
            $("#vNewPasswordErr").addClass("error-cust");
        }
    }else{
        $("#vOldPasswordErr").attr("data-error","Required");
        $("#vNewPasswordErr").attr("data-error","Required");

        if(vOldPassword==""){
            $("#vOldPasswordErr").addClass("error-cust");
        }else{
            $("#vOldPasswordErr").removeClass("error-cust");
        }


        if(vNewPassword==""){
            $("#vNewPasswordErr").addClass("error-cust");
        }else{
            $("#vNewPasswordErr").removeClass("error-cust");
        }

        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
        
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: API_URL + 'checkPassword',
                data: {
                    iUserId:dd.iLoginId,
                    vPassWord:vOldPassword
                },
                success: function (data, status, xhr) {
                    if(data.status==411){
                        if(vOldPassword==""){
                            $("#vOldPasswordErr").addClass("error-cust");
                        }else{
                            $("#vOldPasswordErr").addClass("error-cust");
                            $("#vOldPasswordErr").attr("data-error","Invalid password.");
                        }
                    }else{
                        if(vNewPassword!="" && addErrorPaswordCust(vNewPassword,"passwordErrSuggest","passwordErrorList")){
                            $.ajax({
                                type: 'POST',
                                dataType: "JSON",
                                url: API_URL + 'new_password',
                                data: {
                                    iUserId:dd.iLoginId,vPassWord:vNewPassword,vOldPassword:vOldPassword
                                },
                                success: function (data, status, xhr) {
                                    $("#userChangePwdLoader").addClass("d-none");
                                    if(data.status==411){
                                        $("#vOldPasswordErr").addClass("error-cust");
                                        $("#vOldPasswordErr").attr("data-error","Invalid password.");
                                        $("#editProfChngePwd").removeClass("disabled");
                                    }else{
                                        $("#vChangePasswordTab").addClass("d-none");
    
                                        $("#vOldPassword").val("");
                                        $("#vNewPassword").val("");
                                        $("#editProfChngePwd").addClass("d-none");
                                        $("#editProfPassSuccesMsg").removeClass("d-none");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        }
    }
})


$("#vOldPassword").on("focus",(e)=>{
    const vOldPasswordSt=String($("#vOldPassword").val()).trim();
    addErrorPaswordCust(vOldPasswordSt,"passwordErrSuggest","passwordErrorList");
})

$("#vNewPassword").on("focus",(e)=>{
    const vPassWordStr=String($("#vNewPassword").val()).trim();
    addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
})

$("#vNewPassword").on("input",(e)=>{
    $("#passwordErrSuggest").removeClass("d-none");
    const vPassWordStr=String(e.target.value).trim();
    if(addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList")){
        $("#vNewPasswordErr").removeClass("error-cust");
    }else{
        $("#vNewPasswordErr").addClass("error-cust");
    }
})

$("#vOldPassword").on("input",(e)=>{
    $("#passwordErrSuggest").removeClass("d-none");
    const vPassWordStr=String(e.target.value).trim();
    if(addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList")){
        $("#vOldPasswordErr").removeClass("error-cust");
    }else{
        $("#vOldPasswordErr").addClass("error-cust");
    }
})

$(document).on("click","#vUserChangePwdTab",()=>{
    $("#vOldPassword").val("");
    $("#vNewPassword").val("");

    $("#vOldPasswordErr").removeClass("error-cust");
    $("#vNewPasswordErr").removeClass("error-cust");

    $("#passwordErrSuggest").addClass("d-none");
    $("#passwordErrorList").html("");
    $("#ViewOldPassword").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
    $("#ViewNewPassword").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
    feather.replace();
    $("#editProfPassSuccesMsg").addClass("d-none");
    $("#vChangePasswordTab").removeClass("d-none");
    $("#editProfChngePwd").removeClass("d-none");
})

$("#vOldPassword").on("click",(e)=>{
    const htmlChild=String($('#passwordErrorList').html()).trim();
    const vPassWordStr=$("#vOldPassword").val();
    addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
    // if (htmlChild==""){
    // }
})

$("#vNewPassword").on("click",(e)=>{
    const htmlChild=String($('#passwordErrorList').html()).trim();
    const vPassWordStr=$("#vNewPassword").val();
    addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
    // if (htmlChild==""){
    // }
})

$("#ViewOldPassword").on("click",(e)=>{
    const vPassWordtype=$("#vOldPassword").attr("type");
    if(vPassWordtype=="password"){
        $("#vOldPassword").attr("type","text");
        $("#ViewOldPassword").html(`<i class="feather feather-18" data-feather="eye"></i>`);
        feather.replace();
    }else{
        $("#vOldPassword").attr("type","password");
        $("#ViewOldPassword").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
        feather.replace();
    }
})

$("#ViewNewPassword").on("click",(e)=>{
    const vPassWordtype=$("#vNewPassword").attr("type");
    if(vPassWordtype=="password"){
        $("#vNewPassword").attr("type","text");
        $("#ViewNewPassword").html(`<i class="feather feather-18" data-feather="eye"></i>`);
        feather.replace();
    }else{
        $("#vNewPassword").attr("type","password");
        $("#ViewNewPassword").html(`<i class="feather feather-18" data-feather="eye-off"></i>`);
        feather.replace();
    }
})

$(document).on("input","#vEditProfileFullName",(e)=>{
    // console.log("class names",$("#vEditProfileFullNameErr.error-cust").classList())
    if(e.target.value==""){
        $("#vEditProfileFullNameErr").addClass("error-cust");
    }else{
        $("#vEditProfileFullNameErr").removeClass("error-cust");
    }
})

$(document).on("click", "#editProfilePickModalSubmit", () => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vEditProfileFullName = $("#vEditProfileFullName").val();
        const vUserProflePick = [{ fileName: tempFilename, imageData: finalProfilePick }];

        if (vEditProfileFullName == "") {
            $("#vEditProfileFullNameErr").addClass("error-cust");
        } else {
            $("#vEditProfileFullNameErr").removeClass("error-cust");

            $("#userProfileNmChangeLoader").removeClass("d-none");
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'ProfileUpdate',
                data: {
                    tToken: dd.tToken,
                    vImage: vUserProflePick,
                    iColorOption: finalColorSelection,
                    isDeleteFile: isDeleteFile,
                    vEditProfileFullName: vEditProfileFullName
                },
                success: function (data, status, xhr) {
                    $("#userProfileNmChangeLoader").addClass("d-none");

                    if (data.status == 200) {
                        tempFilename = "";
                        finalProfilePick = "";
                        finalColorSelection = "";

                        $("#editProfilePickModal").modal("toggle");
                        if (data?.data) {
                            $("#vLoggedColorOption").val(data.data.iColorOption);

                            if (Number(data.data.iColorOption) > 0) {
                                colorOption.map((curEl, index) => {
                                    if (curEl.iColorId == data.data.iColorOption) {
                                        $("#vProfilePick").attr("xlink:href", curEl.vColorPick);
                                        $(".sender_chat_profile").attr("src",curEl.vColorPick)
                                    }
                                })
                            } else {
                                $("#vProfilePick").attr("xlink:href", API_URL + data.data.vProfilePic);
                                $(".sender_chat_profile").attr("src",API_URL + data.data.vProfilePic)
                            }
                        }

                        $("#vUserName").text(vEditProfileFullName);

                        let vConvertionChatArr = $("#vConvertionChatArr").val();

                        if (vConvertionChatArr != "") {
                            const ChatUserListArr = JSON.parse(vConvertionChatArr);
                            const vUsers=[];

                            ChatUserListArr.map((curEle,index)=>{
                                vUsers.push(curEle.iUserId);
                            })

                            if(vUsers.length){
                                socket.emit('AllUserGetMyNewSts',{
                                    tToken:dd.tToken,
                                    vUsers:vUsers.toString()
                                });
                            }
                        }
                    }
                }
            })
        }

    }
})


$(document).on("click", "#editProfilePickModalCancel", () => {
    $("#editProfilePickModal").modal("toggle");
})
//Edit User Profile Code End

//Scroll Top Position start old record Code Start
const element = document.querySelector("#MainChatArea");
element.addEventListener("scroll", (event) => {
    if (event.target.scrollTop == 0) {
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);

            const vActiveGroupId = $("#vActiveGroupId").val();
            const vActiveUserId = $("#vActiveUserId").val();

            if($("#MessageList").html()!=""){
                if (vActiveGroupId > 0) {
                    const BackOneMonthDate = oneMonthBackDateGroup(filterDateStr);
    
                    const StringData = "GROUP_" + vActiveGroupId + "_" + BackOneMonthDate + ".json";
    
                    GetGroupMessage(dd, vActiveGroupId, StringData, 1);
    
                } else {
                    const BackOneMonthDate = oneMonthBackDate(filterDateStr);
                    const StringData = dd.iLoginId + "_" + BackOneMonthDate + ".json";
                    getMessageFunc(vActiveUserId, StringData, 1);
                }
            }
        }
    }
});

//Scroll Top Position start old record Code End

//New Chat Request Code Start
$(document).on("click", "#vRequestChatBtn", (e) => {
    const vActiveUserId = $("#vActiveUserId").val();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $("#vRequestChatDiv").addClass("d-none");
        $("#vUserDeleteChat").addClass("disabled");

        socket.emit('send_message', {
            receiverChatID: vActiveUserId,
            senderChatID: dd['iLoginId'],
            content: "",
            ImageDataArr: [],
            vReplyMsg: "",
            vReplyMsg_id: "",
            vReplyFileName: "",
            id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
            iRequestMsg: 1,
            isForwardMsg:0,
            isDeleteprofile:0
        });

        const activeChatName = $("#activeChatName").text();
        
        const date = timestampToAMPM();
        // if (timeLineDate == "") {
        //     timeLineDate = getCurrentDate();

        //     let htmlDate = `<div class="chat-time-line">
        //         <p>Today</p>
        //     </div>`;

        //     $("#MessageList").append(htmlDate);
        //     dynamicWithlabel();
        // }
        dateTimeLineAdd(getCurrentDateTime());
        dynamicWithlabel();

        let id = dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date())

        const html = chatRequestSendHtml(date, activeChatName,id);

        $("#MessageList").append(html);

        $("#vCancelRequest").closest("li").removeClass("d-none");

        $("#vConvertionChatArr").val("[]");
        
        getUserList();
    }
})


const chatRequesHtml = (data, isSend) => {
    let profileName = $("#activeChatName").text();
    const activeChatProfile = $("#activeChatProfile").attr("xlink:href");

    return `<div class="chat-message-outer-container recieve-message read" id="requestAction_${data.id}">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="main-message">
                            <img src="${activeChatProfile}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                            <div>
                                <div class="chat-message-alignment">
                                    <div class="chat-message">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <p class="mb-0">${profileName} sent you a chat request.</p>
                                                    <div class="mt-3 d-flex align-items-center">
                                                        <div class="me-1 pe-2">
                                                            <button class="btn btn-primary requestAccept" data-id="${data.id}"
                                                                id="reqAccept_${data.id}">Accept</button>
                                                        </div>
                                                        <button class="btn btn-secondary requestDecline" data-id="${data.id}"
                                                            id="reqDecline_${data.id}">Decline</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${profileName}</p>
                                    <p class="message-drop-time">${timestampToAMPM("" + data.created_at)}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
}

const chatRequestSendHtml = (created_at, vUserName,id) => {
    return `<div class="chat-message-outer-container recieve-message unread message-create-group requestSent" data-id="${id}">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/message-waiting.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">You have sent a chat request to ${vUserName}.</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}

const chatRequestAcceptHtml = (created_at, vUserName, isSend,isDivExist=0) => {
    const textMsg = isSend == 1 ? `You have accepted the ${vUserName}'s chat request.` : `${vUserName} accepted your chat request.`;

    const innerhtml=`<div class="chat-message-inner-container">
                        <div class="chat-message-container">
                            <div class="d-flex">
                                <img src="images/svgs/message-accept.svg" class="chat-message-profile" alt="chat-message-profile">
                                <div class="main-message message-create-group">
                                    <div class="d-flex align-items-center message-author">
                                        <p class="message-droper-name">${textMsg}</p>
                                        <p class="message-drop-time">${created_at}</p>
                                        <div class="message-status"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;

    return  isDivExist==1?innerhtml:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerhtml}
            </div>`
}

const chatRequestDeclineHtml = (created_at, vUsername, isSend,isDivExist=0) => {
    const textMsg = isSend == 1 ? `You have declined the ${vUsername}'s chat request.` : `${vUsername} declined your chat request.`;
    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/message-declined.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  isDivExist==1?innerHTML:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}

const chatRequestCancelledHtml = (created_at, vUsername, isSend,isDivExist=0) => {
    const textMsg = isSend == 1 ? `You have cancelled the chat request.` : `${vUsername} cancelled your chat request.`;
    const innerHTML=`<div class="chat-message-inner-container">
                        <div class="chat-message-container">
                            <div class="d-flex">
                                <img src="images/svgs/chat-orange.svg" class="chat-message-profile" alt="chat-message-profile">
                                <div class="main-message message-create-group">
                                    <div class="d-flex align-items-center message-author">
                                        <p class="message-droper-name">${textMsg}</p>
                                        <p class="message-drop-time">${created_at}</p>
                                        <div class="message-status"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>`;
    return  isDivExist==1?innerHTML:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}

const chatDeleteConnectHtml = (created_at, vUsername,isDivExist=0) => {
    const textMsg = `You no longer have chat connection with ${vUsername}.`;
    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/message-declined.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  isDivExist==1?innerHTML:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}
//New Chat Request Code End

//Group Chat Request Sent Html Code Start
const GroupChatRequestSendHtml = (created_at,id,iUserId) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(iUserId==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }

    const textMsg = `You have sent the group chat request to ${vProfileName}`;

    return `<div class="chat-message-outer-container recieve-message unread message-create-group grpRequestSent" data-id="${id}">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/message-waiting.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}.</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}

const GroupChatRequestAcceptHtml = (created_at,id,data,iLoginId,isAdmin) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(data.iFromUserId==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }

    const textMsg=iLoginId==data.iFromUserId?`You have accepted group chat request.`:isAdmin?`${vProfileName} accepted the group chat request.`:`${vProfileName} accepted the group chat request.`;

    return `<div class="chat-message-outer-container recieve-message unread message-create-group" data-id="${id}">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                           <img src="images/svgs/message-accept.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}


const GroupNewAdminHtml = (created_at,iLoginId,vNewAdminId) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();
    const vNewAdminIdOrg=vNewAdminId;

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(vNewAdminIdOrg==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }

    const textMsg=iLoginId==vNewAdminIdOrg?`You are now the group admin.`:`${vProfileName} is now the group admin`;

    return `<div class="chat-message-outer-container recieve-message unread message-create-group" data-id="">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                           <img src="images/svgs/user-check-success.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}

const GrpChatRequesHtml = (data) => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    let profilePick="";
    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(data.iFromUserId==curEle.iUserId){
                if(curEle.vProfilePic==""){
                    colorOption.map((curEl, index) => {
                        if (curEl.iColorId == curEle.iColorOption) {
                            profilePick=curEl.vColorPick;
                        }
                    })
                }else{
                    profilePick=curEle?.vProfilePic;
                }
                vProfileName=curEle?.vFullName;
            }
        })
    }

    return `<div class="chat-message-outer-container recieve-message read" id="grpRequestAction_${data.id}">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="main-message">
                            <img src="${profilePick}" class="chat-message-profile receive_chat_profile" alt="chat-message-profile">
                            <div>
                                <div class="chat-message-alignment">
                                    <div class="chat-message">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center">
                                                <div>
                                                    <p class="mb-0">${vProfileName} sent you a group chat request.</p>
                                                    <div class="mt-3 d-flex align-items-center">
                                                        <div class="me-1 pe-2">
                                                            <button class="btn btn-primary grpRequestAccept" data-id="${data.id}"
                                                                id="grpReqAccept_${data.id}">Accept</button>
                                                        </div>
                                                        <button class="btn btn-secondary grpRequestDecline" data-id="${data.id}"
                                                            id="grpReqDecline_${data.id}">Decline</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${vProfileName}</p>
                                    <p class="message-drop-time">${timestampToAMPM("" + data.created_at)}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
}

const GrpChatRequestDeclineHtml = (created_at, iUserId,isDivExist=0,isAdmin=0) => {

    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(iUserId==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }

    const textMsg = isAdmin == 1 ? `${vProfileName} declined the group chat request.` : `You have declined the group chat request.`;

    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/message-declined.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  isDivExist==1?innerHTML:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}

const GrpChatRequestCancelHtml = (created_at, iUserId,isDivExist=0,isAdmin=0) => {

    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    const vUserIds=String(iUserId).includes(",")?String(iUserId).split(",")[0]:iUserId;

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(vUserIds==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }

    const textMsg = isAdmin == 1 ? `You have cancelled the group chat request of ${vProfileName}.` : `${vProfileName} (group admin) cancelled your group chat request.`;

    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/chat-orange.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  isDivExist==1?innerHTML:`<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}
//Group Chat Request Sent Html Code End


//Admin Left Message Code Start
const AdminGroupLeft = (created_at,vMessage,iUserId,type="") => {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();
    const vActiveGroupId=$("#vActiveGroupId").val();

    let vProfileName="";
    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        
        ChatUserListArr.map((curEle,index)=>{
            if(iUserId==curEle.iUserId){
                vProfileName=curEle?.vFullName;
            }
        })
    }
    
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    let isAdmin=0;

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        if(dd.iLoginId==iUserId){
            vProfileName=$("#vUserName").text();

            if (vChatGroupListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatGroupListJsonArr);
                const filterData=chatGroupList.filter((CurEle,index)=>{
                    return CurEle.iGroupId==vActiveGroupId
                })
        
                if(filterData.length){
                    const iCreatedBy=filterData[0]['iCreatedBy'];
        
                    if(iCreatedBy==dd.iLoginId){
                        isAdmin=1;
                    }
                }
            }
        }
    }

    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/user-minus-danger.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${vProfileName}${isAdmin==1 || type=="AdminLeft"?' (group admin) ':' '}${type=="AdminLeft"?'is left.':'is no longer a member of the spot chat.'}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  `<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}
//Admin Left Message Code End

//Chat User is Left Code Start
const MemeberLeft = (created_at, vUsername,iUserId) => {
    let textMsg = `${vUsername} is no longer a member of the spot chat.`;
    
    const innerHTML=`<div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/user-remove.svg" class="chat-message-profile" alt="chat-message-profile">
                            <div class="main-message message-create-group">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">${textMsg}</p>
                                    <p class="message-drop-time">${created_at}</p>
                                    <div class="message-status"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`;
    return  `<div class="chat-message-outer-container recieve-message unread message-create-group">
                ${innerHTML}
            </div>`
}
//Chat User is left Code End

//Delete User All Chat Code Start
$(document).on("click","#vUserDeleteChat",()=>{
    $("#delUserChatHist").modal("toggle");
    $(".vDeleteUserNameChtConf").text($("#activeChatName").text());
})

$(document).on("click","#delUserChatHistSubmit",()=>{
    const vActiveUserId=$("#vActiveUserId").val();
        
    if(vActiveUserId>0){
        let iLastReuestMessageId="";
        $(".requestAccept").each((e, item) => {
            const getRowId = $(item).attr("data-id");
            iLastReuestMessageId=getRowId;
        })

        let isRequestSent=$(".requestSent").length;
        let isRequestAccept=$(".requestAccept").length;
    
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            $("#vUserDeleteChat").addClass("disabled");

            $("#delUserChatHistLoader").removeClass("d-none");

            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'DeleteAllChatUser',
                data: {
                    tToken: dd.tToken,
                    vActiveUserId:vActiveUserId
                },
                success: function (data, status, xhr) {

                    // if(isRequestSent || isRequestAccept){
                    //     socket.emit('chatRequestAccept', {
                    //         iToUserId: vActiveUserId,
                    //         status: 5,
                    //         tToken: dd.tToken,
                    //         iDelete:1
                    //     });
                    // }
                    
                    socket.emit('send_message', {
                        receiverChatID: vActiveUserId,
                        senderChatID: dd['iLoginId'],
                        content: "",
                        ImageDataArr: [],
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        vReplyFileName: "",
                        id: dd['iLoginId'] + "_" + vActiveUserId + "_" + Date.parse(new Date()),
                        iRequestMsg: 5,
                        isForwardMsg:0,
                        isDeleteprofile:0
                    });   

                    setTimeout(()=>{
                        window.location.reload();
                    },1000)
                }
            })
        }    
    }
})

$(document).on("click","#delUserChatHistCancel,#delUserChatHistClose",()=>{
    $("#delUserChatHist").modal("toggle");
})

//Delete Group All Chat Code End
$(document).on("click","#vGroupDeleteChat",()=>{
    $("#delGroupChatHist").modal("toggle");
})

$(document).on("click","#delGroupChatHistCancel,#delGroupChatHistClose",()=>{
    $("#delGroupChatHist").modal("toggle");
})

$(document).on("click","#delGroupChatHistSubmit",()=>{
    const vActiveGroupId=$("#vActiveGroupId").val();
    
    if(vActiveGroupId>0){
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            
            let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
            let isMember=1;
            if (vChatGroupListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatGroupListJsonArr);
                const filterData=chatGroupList.filter((CurEle,index)=>{
                    return CurEle.iGroupId==vActiveGroupId
                })
        
                if(filterData.length){
                    const memberList=String(filterData[0]['tGroupUsers']).split(",");
        
                    if(!memberList.includes(""+dd.iLoginId)){
                        isMember=0;
                    }
                }
            }
    
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'DeleteGroupAllChat',
                data: {
                    tToken: dd.tToken,
                    vActiveGroupId:vActiveGroupId,
                    isMember:isMember
                },
                success: function (data, status, xhr) {
                    window.location.reload();
                }
            })
        }    
    }
})

//Logout Feature
$(document).on("click","#vLogoutBtn",()=>{
    localStorage.removeItem("whatsAppClone");
    window.location.href="./login.php";
})

//Message Hover More Dropdown List
$(document).on('click', function(event) {
    if (!$(event.target).closest('.dropdown-btn').length) {
      $(".floating-dd").removeClass("show");
    }
});

$(document).on("click",".dropdown-btn",(e)=>{
    $(".floating-dd").removeClass("show");
    $(e.currentTarget).closest(".floating-dd").addClass("show");
})


// Delete Profile Code Start
$(document).on("click","#ViewDeletePwd",()=>{
    const vPassWordtype=$("#vDeleProfVerfPwd").attr("type");
    if(vPassWordtype=="password"){
        $("#vDeleProfVerfPwd").attr("type","text");
    }else{
        $("#vDeleProfVerfPwd").attr("type","password");
    }
})

$(document).on("input","#vDeleProfVerfPwd",(e)=>{
    if(e.target.value!=""){
        $("#vDeleProfVerfPwdErr").attr("data-error","Required");
        $("#vDeleProfVerfPwdErr").removeClass("error-cust");
    }else{
        $("#vDeleProfVerfPwdErr").attr("data-error","Required");
        $("#vDeleProfVerfPwdErr").addClass("error-cust");
    }
})

$(document).on("click","#editDeleteProfBtn",()=>{
    const vDeleProfVerfPwd=$("#vDeleProfVerfPwd").val();
    if(vDeleProfVerfPwd==""){
        $("#vDeleProfVerfPwdErr").attr("data-error","Required");
        $("#vDeleProfVerfPwdErr").addClass("error-cust");
    }else{
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {

            const dd = JSON.parse(isLocalStorageExist);
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: API_URL + 'checkPassword',
                data: {
                    iUserId:dd.iLoginId,
                    vPassWord:vDeleProfVerfPwd
                },
                success: function (data, status, xhr) {
                    if(data.status==411){
                        $("#vDeleProfVerfPwdErr").addClass("error-cust");
                        $("#vDeleProfVerfPwdErr").attr("data-error","Invalid password.");
                        $("#editDeleteProfBtn").removeClass("disabled");
                    }else{
                        $("#profileDeleteConfModal").modal("toggle");
                    }
                }
            })
        }
    }
})

$(document).on("click","#profileDeleteConfModalClose,#profileDeleteConfModalCancel",()=>{
    $("#profileDeleteConfModal").modal("toggle");
})

$(document).on("click","#profileDeleteConfModalSubmit",()=>{
    const vUserName=$("#vUserName").text();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        $("#profileDeleteConfModalSubmit").addClass("disabled");

        const dd = JSON.parse(isLocalStorageExist);

        const vConvertionChatArr=$("#vConvertionChatArr").val();
        if (vConvertionChatArr != "") {
            const ChatUserListArr = JSON.parse(vConvertionChatArr);
            ChatUserListArr.map((curE,index)=>{
                if(curE.isStartChat==1){
                    const textLeftMessage=vUserName+" is left.";
                    socket.emit('send_message', {
                        receiverChatID: curE.iUserId,
                        senderChatID: dd.iLoginId,
                        content: textLeftMessage,
                        ImageDataArr: [],
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        vReplyFileName: '',
                        id: dd['iLoginId'] + "_" + curE.iUserId + "_" + Date.parse(new Date()),
                        iRequestMsg: 0,
                        isForwardMsg:0,
                        isDeleteprofile:1
                    });
                }
            });
        }

        let vChatUserListJsonArr = $("#vChatUserListJson").val();

        let totalDeleteGrpArr=[];
        
        const vChatGroupListJsonArr=$("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const ChatGroupListArr = JSON.parse(vChatGroupListJsonArr);
            ChatGroupListArr.map((curE,index)=>{
                const tGroupJoinMembArr=String(curE.tGroupJoinMemb).split(",").filter(el=>el);
                const tGroupUserListArr=String(curE.tGroupUsers).split(",").filter(el=>el);
                if(curE.iCreatedBy==dd.iLoginId || tGroupUserListArr.includes(""+dd.iLoginId) || tGroupJoinMembArr.includes(""+dd.iLoginId)){
                    const textLeftMessage=curE.iCreatedBy==dd.iLoginId?"Admin is left":vUserName+" is left.";

                    if(tGroupUserListArr.length==0){
                        totalDeleteGrpArr.push(curE.iGroupId);
                    }
                    
                    socket.emit('send_grp_message', {
                        receiverChatID: curE.iGroupId,
                        senderChatID: dd['iLoginId'],
                        content: textLeftMessage,
                        ImageDataArr: [],
                        vReplyFileName: "",
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        id: dd['iLoginId'] + "_" + curE.iGroupId + "_" + Date.parse(new Date()),
                        isGreetingMsg: 0,
                        vMembersList: tGroupJoinMembArr.includes(""+dd.iLoginId)?curE.iCreatedBy:curE.tGroupUsers,
                        vGroupMessageType:curE.iCreatedBy==dd.iLoginId?"":"DeleteMemeber",
                        isForwardMsg:0,
                        isDeleteprofile:1,
                        iRequestMsg:0,
                        vDeleteMemberId:curE.iCreatedBy==dd.iLoginId?"":dd.iLoginId,
                        vNewAdminId:"",
                        RequestMemberId:""
                    });

                    if (vChatUserListJsonArr != "") {
                        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
                        const tGroupUserListArrFilt=tGroupUserListArr.filter(cur=>cur);
                        
                        if(tGroupUserListArrFilt.length>0){
                            const FilterAdminName=ChatUserListArr.filter((curFil,ind)=>{
                                return curFil.iUserId==tGroupUserListArrFilt[0]
                            })

                            if(FilterAdminName.length && curE.iCreatedBy==dd.iLoginId){
                                const NewAdminName=FilterAdminName[0]['vFullName']+" is now the group admin.";

                                setTimeout(() => {
                                    socket.emit('send_grp_message', {
                                        receiverChatID: curE.iGroupId,
                                        senderChatID: dd['iLoginId'],
                                        content: NewAdminName,
                                        ImageDataArr: [],
                                        vReplyFileName: "",
                                        vReplyMsg: "",
                                        vReplyMsg_id: "",
                                        id: dd['iLoginId'] + "_" + curE.iGroupId + "_" + Date.parse(new Date()),
                                        isGreetingMsg: 0,
                                        vMembersList:curE.tGroupUsers,
                                        vGroupMessageType:"NewAdmin",
                                        isForwardMsg:0,
                                        isDeleteprofile:0,
                                        iRequestMsg:0,
                                        vDeleteMemberId:"",
                                        vNewAdminId:tGroupUserListArrFilt[0],
                                        RequestMemberId:""
                                    });
                                }, 100);
                            }
                        }
                    }
                }
            });
        }

        $("#profileDeleteConfLoader").removeClass("d-none");
        setTimeout(() => {
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                url: API_URL + 'DeleteProfile',
                data: {
                    tToken:dd.tToken
                },
                success: function (data2, status2, xhr) {
                    if(data2.status==200){ 
                        
                        socket.emit('logout', {
                            iLoggedId: dd.iLoginId
                        });

                        totalDeleteGrpArr.map((curEle,index)=>{
                            socket.emit('GroupRefreshUpdate',{
                                vActiveGroupId: curEle,
                                vUsers:"",
                                isDelete:1
                            });
                        })

                        setTimeout(() => {
                            localStorage.removeItem("whatsAppClone");
                            window.location.href="./login.php";
                        }, 500);
                    }else{
                        $("#profileDeleteConfLoader").addClass("d-none");
                        $("#editDeleteProfBtn").removeClass("disabled");
                        $("#vDeleProfVerfPwdErr").addClass("error-cust");
                        $("#vDeleProfVerfPwdErr").attr("data-error",data2.message);
                    }
                }
            })
        }, 200);
    }

})
// Delete Profile Code End


//Group Chat Join Request Code Start
$(document).on("click",".grpRequestAccept",(e)=>{
    const id=$(e.currentTarget).attr("data-id");
    const vActiveGroupId=$("#vActiveGroupId").val();
    
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        if(activeTab == "User"){
            activeTab="Group";
            $("#userGroup").click();
        }
        
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            url: API_URL + 'GrpJoinRequestAccept',
            data: {
                iUserId:dd.iLoginId,
                iMessageId:id,
                vActiveGroupId:vActiveGroupId
            },
            success: function (data, status, xhr) {
                if(data.status==200){

                    dateTimeLineAdd(getCurrentDateTime());

                    getGroupList();

                    $("#vGroupDeleteChat").removeClass("disabled");
                    $("#vExitGroup").closest("li").removeClass("d-none");
                    $("#vDeleteGroup").closest("li").addClass("d-none");

                    $("#grpRequestAction_"+id).remove();

                    $("#TextEditorArea").removeClass("d-none");

                    let vOldUserList=[];
                    const vChatGroupListJson = $("#vChatGroupListJson").val();
                    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
                        const filterGroupDetail=JSON.parse(vChatGroupListJson).filter((curEle,index)=>{
                            return curEle.iGroupId==vActiveGroupId
                        })

                        if(filterGroupDetail.length){
                            vOldUserList=String(filterGroupDetail[0]['tGroupUsers']).split(",");
                        }
                    }

                    if(!vOldUserList.includes(""+dd.iLoginId)){
                        vOldUserList.push(dd.iLoginId);
                    }

                    const vUserName=$("#vUserName").text();
                    var vAddedUserMsg = htmlEncode(vUserName+"&nbsp;Join&nbsp;the&nbsp;group.");
                    const finalMsg = JSON.stringify(vAddedUserMsg);

                    socket.emit('send_grp_message', {
                        receiverChatID: vActiveGroupId,
                        senderChatID: dd['iLoginId'],
                        content: finalMsg,
                        ImageDataArr: [],
                        vReplyFileName: "",
                        vReplyMsg: "text",
                        vReplyMsg_id: "",
                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                        isGreetingMsg: 0,
                        vMembersList:vOldUserList.toString(),
                        vGroupMessageType:"AddMemeber",
                        isForwardMsg:0,
                        isDeleteprofile:0,
                        iRequestMsg:0,
                        vDeleteMemberId:"",
                        vNewAdminId:"",
                        RequestMemberId:""
                    });

                    socket.emit('GroupRefreshUpdate', {
                        vActiveGroupId: vActiveGroupId,
                        vUsers:"",
                        isDelete:0
                    });


                    const msgId=dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date());
                    
                    const html=GroupChatRequestAcceptHtml(timestampToAMPM(),msgId,{iFromUserId:dd['iLoginId']},dd.iLoginId,0);

                    $("#MessageList").append(html);

                    scrollToBottom();
                    feather.replace();
                    dynamicWithlabel();

                    // setTimeout(() => {
                    //     location.reload();
                    // }, 500);

                    // $(".vGroupIds").each((e, item) => {
                    //     const getRowId = $(item).attr("data-id");
                    //     if (getRowId == vActiveGroupId) {
                    //         $(item).click();
                    //     }
                    // })
                }
            }
        })
    }
})

$(document).on("click",".grpRequestDecline",(e)=>{
    const id=$(e.currentTarget).attr("data-id");
    const vActiveGroupId=$("#vActiveGroupId").val();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        if(activeTab == "User"){
            activeTab="Group";
            $("#userGroup").click();
        }
        
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            url: API_URL + 'GrpJoinRequestDecline',
            data: {
                iUserId:dd.iLoginId,
                iMessageId:id,
                vActiveGroupId:vActiveGroupId
            },
            success: function (data, status, xhr) {
                if(data.status==200){
                    
                    getGroupList();

                    $("#grpRequestAction_"+id).remove();
                    $("#vGroupDeleteChat").removeClass("disabled");
                    $("#vDeleteGroup").closest("li").removeClass("d-none");
                    $("#vGroupInfoBtn").closest("li").addClass("d-none");

                    const vUserName=$("#vUserName").text();
                    var vAddedUserMsg = htmlEncode(vUserName+"&nbsp;decline&nbsp;the&nbsp;group&nbsp;request.");
                    const finalMsg = JSON.stringify(vAddedUserMsg);

                    socket.emit('send_grp_message', {
                        receiverChatID: vActiveGroupId,
                        senderChatID: dd['iLoginId'],
                        content: finalMsg,
                        ImageDataArr: [],
                        vReplyFileName: "",
                        vReplyMsg: "text",
                        vReplyMsg_id: "",
                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                        isGreetingMsg: 0,
                        vMembersList:dd.iLoginId,
                        vGroupMessageType:"",
                        isForwardMsg:0,
                        isDeleteprofile:0,
                        iRequestMsg:3,
                        vDeleteMemberId:"",
                        vNewAdminId:"",
                        RequestMemberId:""
                    });

                    socket.emit('GroupRefreshUpdate', {
                        vActiveGroupId: vActiveGroupId,
                        vUsers:"",
                        isDelete:0
                    });

                    const html=GrpChatRequestDeclineHtml(timestampToAMPM(), dd['iLoginId'],0,0);

                    $("#MessageList").append(html);
                    scrollToBottom();
                    feather.replace();
                    dynamicWithlabel();

                    // setTimeout(() => {
                    //     location.reload();
                    // }, 500);

                    // $(".vGroupIds").each((e, item) => {
                    //     const getRowId = $(item).attr("data-id");
                    //     if (getRowId == vActiveGroupId) {
                    //         $(item).click();
                    //     }
                    // })

                }
            }
        })
    }
})
//Group Chat Join Request Code End


//Exit Group Code Start
$(document).on("click","#vExitGroup",()=>{
   $("#exitGroupConf").modal("toggle");
})

$(document).on("click","#exitGroupConfClose,#exitGroupConfCancel",()=>{
    $("#exitGroupConf").modal("toggle");
}) 

$(document).on("click","#exitGroupConfSubmit",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        
        const vActiveGroupId=$("#vActiveGroupId").val();

        const vChatGroupListJson = $("#vChatGroupListJson").val();
        if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
            const filterGroupDetail=JSON.parse(vChatGroupListJson).filter((curEle,index)=>{
                return curEle.iGroupId==vActiveGroupId
            })

            let vChatUserListJsonArr = $("#vChatUserListJson").val();
            const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

            if(filterGroupDetail.length){
                const iCreatedBy=filterGroupDetail[0]['iCreatedBy'];
                const tGroupJoinMemb=String(filterGroupDetail[0]['tGroupJoinMemb']).split(",").filter(c=>c);
                const tGroupUsers=String(filterGroupDetail[0]['tGroupUsers']).split(",").filter(c=>c);

                if(iCreatedBy==dd.iLoginId){
                    //Admin Left

                    const textLeftMessage=dd['vFullName']+" is left.";

                    socket.emit('send_grp_message', {
                        receiverChatID: vActiveGroupId,
                        senderChatID: dd['iLoginId'],
                        content: textLeftMessage,
                        ImageDataArr: [],
                        vReplyFileName: "",
                        vReplyMsg: "",
                        vReplyMsg_id: "",
                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                        isGreetingMsg: 0,
                        vMembersList:filterGroupDetail[0]['tGroupUsers']+","+dd['iLoginId'],
                        vGroupMessageType:tGroupUsers.includes(""+dd.iLoginId)?"DeleteMemeber":"AdminLeft",
                        isForwardMsg:0,
                        isDeleteprofile:0,
                        iRequestMsg:0,
                        vDeleteMemberId:"",
                        vNewAdminId:"",
                        RequestMemberId:""
                    });

                    if(tGroupUsers.length>0){

                        const FilterAdminName=ChatUserListArr.filter((curFil,ind)=>{
                            return curFil.iUserId==tGroupUsers[0]
                        })

                        const NewAdminName=FilterAdminName[0]['vFullName']+" is now the group admin.";

                        setTimeout(() => {
                            socket.emit('send_grp_message', {
                                receiverChatID: vActiveGroupId,
                                senderChatID: dd['iLoginId'],
                                content: NewAdminName,
                                ImageDataArr: [],
                                vReplyFileName: "",
                                vReplyMsg: "",
                                vReplyMsg_id: "",
                                id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                                isGreetingMsg: 0,
                                vMembersList:filterGroupDetail[0]['tGroupUsers'],
                                vGroupMessageType:"NewAdmin",
                                isForwardMsg:0,
                                isDeleteprofile:0,
                                iRequestMsg:0,
                                vDeleteMemberId:"",
                                vNewAdminId:tGroupUsers[0],
                                RequestMemberId:""
                            });
                        }, 100);
                    }
                    
                }else{
                    //Member Left
                    var vDeleteMsgUser = htmlEncode(dd.vFullName+"&nbsp;is&nbsp;left.");
                    const finalMsg = JSON.stringify(vDeleteMsgUser);

                    socket.emit('send_grp_message', {
                        receiverChatID: vActiveGroupId,
                        senderChatID: dd['iLoginId'],
                        content: finalMsg,
                        ImageDataArr: [],
                        vReplyFileName: "",
                        vReplyMsg: "text",
                        vReplyMsg_id: "",
                        id: dd['iLoginId'] + "_" + vActiveGroupId + "_" + Date.parse(new Date()),
                        isGreetingMsg: 0,
                        vMembersList:filterGroupDetail[0]['tGroupUsers'],
                        vGroupMessageType:"DeleteMemeber",
                        isForwardMsg:0,
                        isDeleteprofile:0,
                        iRequestMsg:0,
                        vDeleteMemberId:dd['iLoginId'],
                        vNewAdminId:"",
                        RequestMemberId:""
                    });
                }

                setTimeout(() => {
                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        url: API_URL + 'ExitGroup',
                        data: {
                            tToken:dd.tToken, 
                            vActiveGroupId:vActiveGroupId,
                            iNewUserId:tGroupUsers.length?tGroupUsers[0]:0
                        },
                        success: function (data, status, xhr) {
                            $("#exitGroupConf").modal("toggle");
    
                            socket.emit('GroupRefreshUpdate',{
                                vActiveGroupId: vActiveGroupId,
                                vUsers:"",
                                isDelete:0
                            });

                            if(tGroupUsers.length==0){
                                location.reload();
                            }

                            $("#texAreaEditorDiv").addClass("d-none");
                            if(activeTab == "User"){
                                activeTab="Group";
                                $("#userGroup").click();
                            }else{
                                getGroupList();
                            }
    
                            socket.emit('GroupRefreshUpdate',{
                                vActiveGroupId: vActiveGroupId,
                                vUsers:"",
                                isDelete:0
                            });
    
                            if(data.status==200){
                                $(".vGroupIds").each((e, item) => {
                                    const getRowId = $(item).attr("data-id");
                                    if (getRowId == vActiveGroupId) {
                                        $(item).click();
                                    }
                                })
                            }else{
                                alert(data.message)
                            }
                        }
                    })
                }, 200);

            }
        }
    }
})
//Exit Group Code End

//Delete group for me Code Start
$(document).on("click","#vDeleteGroup",()=>{
    $("#grpDeleteForMeConf").modal("toggle");
})

$(document).on("click","#grpDeleteForMeConfClose,#grpDeleteForMeConfCancel",()=>{
    $("#grpDeleteForMeConf").modal("toggle");
})

$(document).on("click","#grpDeleteForMeConfSubmit",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vActiveGroupId=$("#vActiveGroupId").val();

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            url: API_URL + 'DeleteGroupForMe',
            data: {
                tToken:dd.tToken, 
                vActiveGroupId:vActiveGroupId
            },
            success: function (data, status, xhr) {
                location.reload();
            }
        })
    }
})
//Delete group for me Code End


//Token Expiry Update
let endTime="";

function resetIdleTimer() {
    if(endTime!=""){
        let msDifference =  new Date() - endTime;
        let minutes = Math.floor(msDifference/1000/60);
        if(minutes>=15){
            const isLocalStorageExist = localStorage.getItem("whatsAppClone");
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
                socket.emit('join_msg', {
                    token: dd.tToken
                });
            }
        }else{
            endTime=new Date();
        }
    }else{
        endTime=new Date();
    }
}

// Event listener for mouse movements
window.addEventListener('click', resetIdleTimer);