const { app, BrowserWindow,screen,globalShortcut  } = require('electron')

process.env.APIPATH = 'http://192.168.1.35/file_manager/api/';
process.env.FTPHOST = '217.21.92.68';
process.env.FTPUSERNAME = 'u560104897.beta_test';
process.env.FTPPASSWORD = '#*1bCJR.ZYjw';
process.env.PRODUCTIONTYPE = 'Live';//Local Or Live

const createWindow = () => {
    const primaryDisplay = screen.getPrimaryDisplay()
    const { width, height } = primaryDisplay.workAreaSize

    const win = new BrowserWindow({
        autoHideMenuBar: true,
        width: width,
        height: height,
        webPreferences: {
            devTools: process.env.PRODUCTIONTYPE=="Local"?true:false, //For Preventing Develope console tab 
            nodeIntegration: true,
            contextIsolation: false,
        }
    })

    win.loadFile('login.html');
}

app.whenReady().then(() => {
    if(process.env.PRODUCTIONTYPE=="Live"){ //For Preventing Develope console tab 
        globalShortcut.register('Control+Shift+I', () => {
            return false;
        });
    }

    createWindow()

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow()
    })
})

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
})
