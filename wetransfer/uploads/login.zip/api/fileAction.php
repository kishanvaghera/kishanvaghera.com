<?php
include('common.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE');

$data = json_decode(file_get_contents('php://input'), true);
if ($data != "") {
    $_POST =  $data;
}

$LoggedData=mf_LoginCheck();

if($_POST['action'] == "getFolderList") {
    $jsonFile = './DB/file_structure.json';

    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    } else {
        $fileStrucData = array();
    }

    $folderListArr=array();

    foreach($fileStrucData as $value){
        $vPathPermArr=explode(",",$value['tFilePermission']);
        
        if(($value['iCreatedBy']==$LoggedData['iUserId'] || in_array($LoggedData['iUserId'],$vPathPermArr)) && $value['eStatus']="y"){
            $folderListArr[]=array("iFolderId"=>$value['iFolderId'],"isPermission"=>1,"vFolderName"=>$value['vFolderName'],"tFolderPath"=>$value['tFolderPath'],"tFilePermission"=>$value['tFilePermission'],"iCreatedBy"=>$value['iCreatedBy'],"eStatus"=>$value['eStatus']);
        }
    }

    if(!empty($folderListArr)){
        echo json_encode(array("status"=>201,"data"=>$folderListArr));
    }else{
        echo json_encode(array("status"=>412,"msg"=>"No Folder Found!"));
    }
    exit;
}else if($_POST['action'] == "addFolder") {
    $vFolderName=$_POST['vFolderName'];
    $vUsers=$_POST['vUsers'];
    $tFolderPath=$_POST['tFolderPath'];

    $jsonFile = './DB/file_structure.json';

    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    } else {
        $fileStrucData = array();
    }

    $isFolderPathExist=0;
    foreach ($fileStrucData as $value) {
        if($value['tFolderPath']==$tFolderPath){
            $isFolderPathExist=1;
        }
    }

    if($isFolderPathExist){
        echo json_encode(array("status"=>412,"msg"=>"Folder is already exist."));
        exit;
    }else{
        $newFolder = array(
            'iFolderId'=>count($fileStrucData)+1,
            'vFolderName'=>$vFolderName,
            'tFolderPath' => $tFolderPath,
            'tFilePermission' => $vUsers,
            'dCreatedDate' => date('Y-m-d H:i:s'),
            'iCreatedBy' => $LoggedData['iUserId'],
            'eStatus' => "y"
        );

        $fileStrucData[] = $newFolder;

        file_put_contents($jsonFile, json_encode($fileStrucData));

        echo json_encode(array("status"=>201,"msg"=>"Folder has been added successfully."));
        exit;
    }
}else if($_POST['action'] == "EditFolder") {
    $vFolderName=$_POST['vFolderName'];
    $vOldFolderName=$_POST['vOldFolderName'];
    
    $jsonFile = './DB/file_structure.json';

    $fileStrucData = array();
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    }

    $isFolderPathExist=0;
    foreach ($fileStrucData as $value) {
        if($value['tFolderPath']==$vFolderName && $value['iCreatedBy']!=$LoggedData['iUserId']){
            $isFolderPathExist=1;
        }
    }

    if($isFolderPathExist==1){
        echo json_encode(array("status"=>412,"msg"=>"Folder Name is already exist."));
        exit;
    }else{
        $index=0;
        foreach ($fileStrucData as $value) {
            if($value['tFolderPath']==$vOldFolderName){
                $fileStrucData[$index]['tFolderPath']=$vFolderName;
            }else if(strpos($value['tFolderPath'], $vOldFolderName) !== false) {

                $replacedPath = preg_replace('/'.preg_quote($vOldFolderName, '/').'/', '', $value['tFolderPath'], 1);

                $fileStrucData[$index]['tFolderPath']=$vFolderName.$replacedPath;
            }
            $index++;
        }

        file_put_contents($jsonFile, json_encode($fileStrucData));

        echo json_encode(array("status"=>201,"msg"=>"Folder has been updated successfully."));
        exit;
    }

}else if($_POST['action'] == "DeleteFolderFile") {
    $tFolderPath=$_POST['tFolderPath'];

    $jsonFile = './DB/file_structure.json';

    $fileStrucData = array();
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    }

    $isFolderPathExist=0;
    $isFolderOwner=0;
    $index=0;
    foreach ($fileStrucData as $value) {
        if($value['tFolderPath']==$tFolderPath && $value['eStatus']=="y"){
            if($value['iCreatedBy']==$LoggedData['iUserId']){
                $fileStrucData[$index]['eStatus']="d";
                $isFolderOwner=1;

                file_put_contents($jsonFile, json_encode($fileStrucData));
            }
            $isFolderPathExist=1;
        }
        $index++;
    }

    if($isFolderPathExist==0){
        echo json_encode(array("status"=>412,"msg"=>"Folder not found."));
        exit;
    }else{
        if($isFolderOwner==0){
            echo json_encode(array("status"=>412,"msg"=>"You are not folder owner."));
            exit;
        }else{
            echo json_encode(array("status"=>201,"msg"=>"Folder has been deleted successfully."));
            exit;
        }
    }
}else if($_POST['action'] == "GetUserList") {

    $jsonFile = './DB/users.json';

    // Check if the JSON file exists and read its contents
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $users = json_decode($jsonData, true);
    } else {
        $users = array();
    }

    $userListArr=array();
    if(!empty($users)){
        foreach($users as $value){
            if($value['iUserId']!=$LoggedData['iUserId']){
                $userListArr[]=array("vUserName"=>$value['vUserName'],"iUserId"=>$value['iUserId']);
            }
        }
    }

    if(!empty($userListArr)){
        echo json_encode(array("status"=>201,"data"=>$userListArr));
        exit;
    }else{
        echo json_encode(array("status"=>412,"msg"=>"No User Found!"));
        exit;
    }
}else if($_POST['action'] == "GetFolderPermission") {
    $folderPath=$_POST['tFolderPath'];

    $jsonFile = './DB/file_structure.json';

    $fileStrucData = array();
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    }

    $isFolderOwner=0;
    $tFilePermission="";
    foreach ($fileStrucData as $value) {
        if($value['tFolderPath']==$folderPath && $value['iCreatedBy']==$LoggedData['iUserId']){
            $isFolderOwner=1;    
            $tFilePermission=$value['tFilePermission'];
        }
    }

    if($isFolderOwner){
        echo json_encode(array("status"=>201,"data"=>$tFilePermission));
        exit;
    }else{
        echo json_encode(array("status"=>412,"msg"=>"You are not owner of the folder."));
        exit;
    }
}else if($_POST['action'] == "UpdatePermission") {
    $vFolderName=$_POST['vFolderName'];
    $vUsers=$_POST['vUsers'];

    $jsonFile = './DB/file_structure.json';

    $fileStrucData = array();
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    }

    $FolderOwner=0;
    $FolderExist=0;
    $index=0;
    foreach ($fileStrucData as $value) {
        if($value['tFolderPath']==$vFolderName){
            if($value['iCreatedBy']==$LoggedData['iUserId']){
                $FolderOwner=1;
                $fileStrucData[$index]['tFilePermission']=$vUsers;
                file_put_contents($jsonFile, json_encode($fileStrucData));
            }
            $FolderExist=1;
        }
        $index++;
    }

    if($FolderExist==0){
        echo json_encode(array("status"=>412,"msg"=>"Folder Not Found."));
        exit;
    }else{
        if($FolderOwner==0){
            echo json_encode(array("status"=>412,"msg"=>"You are not owner of the folder."));
            exit;
        }else{
            echo json_encode(array("status"=>201,"msg"=>"Permission has been updated successfully."));
            exit;
        }
    }
    exit;
}else if($_POST['action'] == "CheckFolderPermssion") {
    $vFolderName=$_POST['vFolderName'];

    $jsonFile = './DB/file_structure.json';

    $fileStrucData = array();
    if (file_exists($jsonFile)) {
        $jsonData = file_get_contents($jsonFile);
        $fileStrucData = json_decode($jsonData, true);
    }

    $isFolderPerm=0;

    foreach($fileStrucData as $value){
        $PermissionUserArr=explode(",",$value['tFilePermission']);
        if($value['tFolderPath']==$vFolderName && ($value['iCreatedBy']==$LoggedData['iUserId'] || in_array($LoggedData['iUserId'],$PermissionUserArr))){
            $isFolderPerm=1;
        }
    }

    echo json_encode(array("status"=>201,"data"=>$isFolderPerm));
    exit;
}

