"use strict";

const axios = require('axios');
const fs = require("fs");
const path = require('path');
const { Client } = require("basic-ftp");
const { Readable } = require('stream');
const Swal = require('sweetalert2');

console = console || {};
console.log = function(){};

window.addEventListener('DOMContentLoaded', () => {

    let apiBaseUrl=process.env.APIPATH;

    const loggedData=localStorage.getItem("fileManagerData");

    let vUserName="";
    if(loggedData!=null){
        const loggedDataCheck=JSON.parse(loggedData);
        vUserName=loggedDataCheck['vUserName'];
        document.getElementById("vUserNameDisp").innerHTML=vUserName;

        const syncPath=loggedDataCheck?.syncPath?loggedDataCheck.syncPath:"";
        document.getElementById("vDownloadFolderPath").value=syncPath;
    }

    let parentDirPath="/";

    const changePath=()=>{
        document.getElementById("bread-crumb").innerHTML=parentDirPath;
    }

    changePath();

    const folderList=document.getElementById("folderList");

    //check is file or not 
    const isFile = (pathname) => pathname.split('/').pop().indexOf('.') > -1;
    
    //Check is folder or not
    const isDir = (pathname) => !isFile(pathname);

    //Get Folder Path From Full Path String
    const filterFolderPath = (fileListArr, checkPath) => {
        const splitMainFolder = String(checkPath).split("/");
        const limit = (splitMainFolder.length === 2 || splitMainFolder.length === 3) ? 1 : 2;
        const isMainFoldPathFinal = splitMainFolder.filter((_, index) => index <= limit).join('/');

        return fileListArr.filter(curEle => 
            (curEle.tFolderPath === checkPath || isMainFoldPathFinal === curEle.tFolderPath) && curEle.isPermission
        );
    };

    //get File Directory List
    
    async function getFolderList(parentDir = "/") {
        if (client.closed) {
            await connectFTP();
        }

        let vAuthtoken = JSON.parse(loggedData).vAuthtoken;

        try {
            await axios.post(apiBaseUrl + 'fileAction.php', { action: 'getFolderList', vAuthtoken }).then(async function (response) {
                if (response.data.status == 201) {
                    const dFolderList = response.data.data;
                    changePath();
    
                    await client.cd(parentDir);
                    const fileList = await client.list();
    
                    let fileHtml = "";
    
                    fileList.forEach(file => {
                        const filterPermission = filterFolderPath(dFolderList, parentDirPath + file.name);
                        if (filterPermission.length > 0 && filterPermission[0].isPermission === 1) {
                            fileHtml += `<li class='${file.type === 0 ? "" : "folderList"}' data-id='${file.name}'>${file.name}</li>`;
                        }
                    });
    
                    folderList.innerHTML = "<ul>" + fileHtml + "</ul>";
    
                    document.querySelectorAll('.folderList').forEach(folderLink => {
                        folderLink.addEventListener('click', function() {
                            if(isDir(this.dataset.id)){
                                parentDirPath += `${this.dataset.id}/`;
                                getFolderList(parentDirPath);
                            }
                        });
                    });
    
                } else if (response.data.status == 411) {
                    localStorage.removeItem("fileManagerData");
                    window.location = "./login.html";
                }
            })
            .catch(function (error) {
                console.log(error);
            });
        } catch (error) {
            console.log(error);
        }
    }
    

    let isCheckUser=[];
    //Get User List 
    const getUserList=(isId="userList")=>{
        document.getElementById(isId).innerHTML = "";
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'GetUserList',vAuthtoken})
              .then(function (response) {
            if(response.data.status==201){
                const userHtml = response.data.data.map(curEle => 
                    `<div class="userListRow">
                        <div><input type="checkbox" class="checkbox chkUser" name="iUserId_${curEle.iUserId}" id="iUserId_${curEle.iUserId}" value="${curEle.iUserId}" ${isCheckUser.includes(String(curEle.iUserId)) ? "checked" : ""}/></div>
                        <div class="checkbox-label">${curEle.vUserName}</div>
                    </div>`).join('');
                document.getElementById(isId).innerHTML = userHtml;
            }
        })
    }

    // RefreshData
    document.getElementById('RefreshData').addEventListener('click', function(){
        getFolderList(parentDirPath);
    });

    //New Folder
    document.getElementById('addcBtn').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "flex";
        getUserList();
    });
    
    document.querySelector('#AddFolderModalClose').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "none";
    });

    function getCheckedBoxes(chkboxName) {
        const checkboxes = document.getElementsByClassName(chkboxName);
        return Array.from(checkboxes).filter(checkbox => checkbox.checked).map(checkbox => checkbox.value);
    }

    //Submit Folder in DB
    document.getElementById('submitFolder').addEventListener('click', function(e){
        e.preventDefault();
        const folderName = document.getElementById('vFolderName').value;
        const vUsers = getCheckedBoxes("chkUser").toString();

        if(folderName==""){
            Swal.fire({ title: 'Error!', text: 'Please enter folder name!', icon: 'error', confirmButtonText: 'OK' });
            // alert("please enter folder name!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;

            axios.post(apiBaseUrl+'fileAction.php', {action:'addFolder',vAuthtoken,vFolderName:folderName,vUsers,tFolderPath:parentDirPath+folderName})
                  .then(async function (response) {
                if(response.data.status==201){
                    await client.cd("/");
                    await client.ensureDir(parentDirPath+folderName);
                    document.querySelector("#AddFolderModal").style.display = "none";
                    document.getElementById("vFolderName").value="";
                    getFolderList(parentDirPath);    
                }else{
                    Swal.fire({ title: 'Error!', text: response.data.msg, icon: 'error', confirmButtonText: 'OK' });
                    // alert(response.data.msg)
                }
            })
        }
    })

    //File Upload Code Start
    const fileInput = document.getElementById('file-input');
    const dropArea = document.getElementById('drop-area');

    // Handle file selection
    fileInput.addEventListener('change', handleFileSelect);

    // Handle drag and drop
    dropArea.addEventListener('dragover', handleDragOver);
    dropArea.addEventListener('drop', handleDrop);

    function handleFileSelect(event) {
        const files = event.target.files;
        handleFiles(files);
    }

    function handleDragOver(event) {
        event.stopPropagation();
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
    }

    function handleDrop(event) {
        event.stopPropagation();
        event.preventDefault();
        const files = event.dataTransfer.files;
        handleFiles(files);
    }
      
    //Upload file in live ftp
    function handleFiles(files) {
        // Process each file
        document.getElementById("loaderMain").classList.remove("d-none");

        for (const file of files) {
            const reader = new FileReader();
            reader.onload = async () => {
                const fileBuffer = Buffer.from(reader.result);

                const stream = new Readable();
                stream._read = () => {};
                stream.push(fileBuffer);
                stream.push(null);

                try {
                    await client.cd(parentDirPath);
                    await client.uploadFrom(stream, parentDirPath + file.name);

                    console.log("File transferred successfully!");

                    getFolderList(parentDirPath);
                } catch (err) {
                    console.error("Error transferring file:", err);
                }
                
                document.getElementById("loaderMain").classList.add("d-none");
            }

            reader.readAsArrayBuffer(file);
        }
    }

    //Logout Code
    document.getElementById('logout').addEventListener('click', function(e){
        localStorage.removeItem("fileManagerData");
        window.location="./login.html";
    })

    //Back Page
    document.getElementById('backButton').addEventListener('click', function(e){
        let newArr = String(parentDirPath).split("/").filter(e => e);
        if(newArr.length>1){
            if(newArr.length==1){
                parentDirPath="/";
            }else{
                newArr.pop();
                let text = "/"+newArr.join("/")+"/";
                parentDirPath=text;
            }
            getFolderList(parentDirPath);
        }else{
            parentDirPath="/";
            getFolderList(parentDirPath);
        }
    })

    //Right Click File & Folder
    let isFileEditActive="";
    let isNewFileName="";
    document.body.addEventListener("mousedown", event => {
        if (event.button == 2){ 
            if(event?.target.closest("li")!=null){
                const fileName=parentDirPath+event?.target?.textContent;
        
                let vAuthtoken=JSON.parse(loggedData).vAuthtoken;

                isFileEditActive=fileName;
                isNewFileName=event?.target?.textContent;

                if(isDir(fileName)){
                    axios.post(apiBaseUrl+'fileAction.php', {action:'GetFolderPermission',vAuthtoken,tFolderPath:fileName})
                        .then(function (response) {
                        if(response.data.status==201){
                            let newArr = String(response.data.data).split(",").filter(e => e);
                            isCheckUser=newArr;
                            document.querySelector("#FolderMoreModal").style.display = "flex";
                        }else{
                            isCheckUser=[];
                        }
                    })
                }else{
                    document.querySelector("#FolderMoreModal").style.display = "flex";
                }
            }
        }
    });

    //More Modal Code Start
    document.querySelector('#FolderMoreModalClose').addEventListener('click', function(){
        document.querySelector("#FolderMoreModal").style.display = "none";
        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
    });
    
    document.querySelector('#PermissionFolderFile').addEventListener('click', function(){
        document.querySelector("#AddFilePermission").style.display = "flex";
        getUserList("userListFile");
    });

    document.querySelector('#RenameFolderFile').addEventListener('click', function(){
        document.querySelector("#RenameFolderFileModal").style.display = "flex";

        document.getElementById("vNewFolderName").value=isNewFileName;
    });

    // Submit Rename Folder & File Live And DB
    document.querySelector('#SubmitRenameFolderFile').addEventListener('click',async function(e){
        e.preventDefault();

        const vNewFolderName=document.getElementById("vNewFolderName").value;

        if(isDir(vNewFolderName)){
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'EditFolder',vAuthtoken,vFolderName:parentDirPath+vNewFolderName,vOldFolderName:parentDirPath+isNewFileName})
                .then(async function (response) {
                if(response.data.status==201){
                    await client.rename(isNewFileName, vNewFolderName);

                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#RenameFolderFileModal").style.display = "none";

                    document.querySelector("#FolderMoreModal").style.display = "none";
                    getFolderList(parentDirPath);
                }
            })
            
        }else{
            await client.rename(isNewFileName, vNewFolderName);
            isFileEditActive="";
            isNewFileName="";
            document.querySelector("#RenameFolderFileModal").style.display = "none";
            document.querySelector("#FolderMoreModal").style.display = "none";
            getFolderList(parentDirPath);
        }
    });

    // Rename Folder & File Close
    document.querySelector('#RenameFolderFileClose').addEventListener('click', function(e){
        e.preventDefault();

        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
        document.querySelector("#RenameFolderFileModal").style.display = "none";

        document.querySelector("#FolderMoreModal").style.display = "none";
    })

    //Delete Folder Or File From Live & DB
    document.querySelector('#DeleteFolderFile').addEventListener('click', async function(){
        if (isDir(isFileEditActive)) {
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'DeleteFolderFile',vAuthtoken,tFolderPath:isFileEditActive})
            .then(async function (response) {
                if(response.data.status==201){
                    await client.removeDir(isFileEditActive);
                    getFolderList(parentDirPath);
                    document.querySelector("#FolderMoreModal").style.display = "none";
                    isCheckUser=[];
                    isFileEditActive="";
                }
            })
        }else{
            await client.remove(isFileEditActive);
            document.querySelector("#FolderMoreModal").style.display = "none";
            getFolderList(parentDirPath);
            isCheckUser=[];
            isFileEditActive="";
        }
    });
    
    // Add File Permission Close
    document.querySelector('#AddFilePermissionClose').addEventListener('click', function(){
        isCheckUser=[];
        isFileEditActive="";
        document.querySelector("#AddFilePermission").style.display = "none";
    });

    //Submit Permission For Folder in DB
    document.getElementById('submitAddFilePerm').addEventListener('click', function(e){
        e.preventDefault();
        const folderName=isFileEditActive;
        const getUsrList=getCheckedBoxes("chkUser");
        const vUsers=getUsrList.toString();

        if(folderName==""){
            Swal.fire({ title: 'Error!', text: 'Please select file or folder only!', icon: 'error', confirmButtonText: 'OK' })
            // alert("Please select file or folder only!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'UpdatePermission',vAuthtoken,vFolderName:folderName,vUsers:vUsers})
                  .then(function (response) {
                if(response.data.status==201){
                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#AddFilePermission").style.display = "none";
                    document.querySelector("#FolderMoreModal").style.display = "none";
                }
            })
        }
    })

    //Get File List Recursive One By One
    function getFilesRecursively(directory) {
        let files = [];
        const contents = fs.readdirSync(directory);
        contents.forEach(item => {
            const fullPath = path.join(directory, item);
            const stats = fs.statSync(fullPath);
    
            if (stats.isFile()) {
                files.push(fullPath);
            } else if (stats.isDirectory()) {
                files.push(fullPath);
                files = files.concat(getFilesRecursively(fullPath));
            }
        });
        return files;
    }

    //Get File Name From Full Path
    function getFileNameFromUrl(url) {
        const regex = /[^/]+(?=\?|$)/;
        const matches = url.match(regex);
        return matches ? matches[0] : null;
    }

    //Upload File in Live
    async function uploadFile(localPath, remotePath) {
        try {
            const getFolderPath = getDirectoryPath(remotePath);
            const fileName=getFileNameFromUrl(remotePath);
            await client.cd("/"+getFolderPath);
            await client.uploadFrom(localPath, fileName);
        } catch (error) {
            console.log("error file upload=>",error)
        }
        return 1;
    }

    //Async Foreach Function
    const asyncForEach = async (array, callback) => {
        for (let index = 0; index < array.length; index++) {
            await callback(array[index], index, array);
        }
    };

    //Get Path Folder url From Full Url
    function getDirectoryPath(url) {
        return url.substring(0, url.lastIndexOf('/') + 1);
    }

    //Ftp Connection Code Start
    const client = new Client(0);
    client.ftp.timeout = 1800 * 1000;
    // client.ftp.verbose = true

    let isFirstLoad=0;
    let ConnectionTimeDate=new Date();
    const connectFTP = async () => {
        if (client.closed) {
            console.log("connection is close reconnect.");
            await client.close();
            await client.access({
                host: process.env.FTPHOST,
                user: process.env.FTPUSERNAME,
                password: process.env.FTPPASSWORD,
                secure: true,
                secureOptions: { rejectUnauthorized: false },
                port: 21
            });
    
            if (isFirstLoad === 0) {
                await getFolderList(parentDirPath);
                isFirstLoad = 1;
            }
    
            setTimeout(async () => {
                let timeDifference = new Date() - ConnectionTimeDate;
                if (timeDifference / 1000 > 20) {
                    if (client.closed) {
                        await connectFTP();
                    }
                    ConnectionTimeDate = new Date();
                }
            }, 20000);
        }
    };


    connectFTP();
    //Ftp Connection Code End
      
    //File Download From Live To Local 
    async function fileDownload(path, callback) {
        const vDownloadFolderPath = document.getElementById("vDownloadFolderPath").value;
        if (vDownloadFolderPath === "") {
            Swal.fire({ title: 'Error!', text: 'Please Enter Local Directory Path.', icon: 'error', confirmButtonText: 'OK' })
            // alert("Please Enter Local Directory Path.");
            callback();
            return;
        }
    
        const list = await client.list(path);
        let pending = list.length;
        if (!pending) {
            callback();
            return; // No files to download
        }
    
        await asyncForEach(list, async (file) => {
            const filePath = `${path}/${file.name}`;
            const remoteFilePath = String(filePath).replace("./", "").replace("//","/");
            const localFilePath = vDownloadFolderPath + remoteFilePath;
    
            if (file.isDirectory) {
                if (String(remoteFilePath).split("/").length === 2) {
                    let vAuthtoken = JSON.parse(loggedData).vAuthtoken;
                    const response = await axios.post(apiBaseUrl + 'fileAction.php', { action: 'CheckFolderPermssion', vAuthtoken, vFolderName: path + file.name }).then(function (response) {
                        if (response.data.status === 201 && response.data.data === 1) {
                            if (!fs.existsSync(localFilePath)) {
                                fs.mkdirSync(localFilePath, { recursive: true });
                            }
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
                } else {
                    const newPath = String(path).replace("./", "");
                    if (fs.existsSync(vDownloadFolderPath + newPath)) {
                        if (!fs.existsSync(localFilePath)) {
                            fs.mkdirSync(localFilePath, { recursive: true });
                        }
                    }
                }
                await fileDownload(filePath, () => {
                    pending -= 1;
                    if (pending === 0) {
                        callback();
                    }
                });
            } else {
                const newPath = String(filePath).replace(".//", "./");
    
                if (file.size > 0 && newPath !== "./db.txt") {
                    const getFolderPath = getDirectoryPath(localFilePath);
                    if (fs.existsSync(getFolderPath)) {
                        await client.downloadTo(localFilePath, newPath);
                        console.log("File copied successfully!");
                    }
                }
    
                pending -= 1;
                if (pending === 0) {
                    callback();
                }
            }
        });
    }

    //Check Folder Exist Or not in Live
    async function folderExists(client, path) {
        try {
          await client.cd(path); 
          return true; 
        } catch (error) {
          if (error.message.includes('No such file or directory')) {
            return false; 
          }
          throw error;
        }
    }

    //Create Folder in Live
    async function createFolder(client, path) {
        const parts = path.split('/').filter(part => part); 
        let currentPath = '';
      
        for (const part of parts) {
          currentPath = `${currentPath}/${part}`;
          await client.cd(currentPath);
          await client.ensureDir(currentPath);
        }
    }

    //Sync Data Local And Live Same.
    async function syncFolder(){
        if (client.closed) {
            await connectFTP();
        }

        const directoryPath=document.getElementById("vDownloadFolderPath").value;
        if(directoryPath==""){
            Swal.fire({ title: 'Error!', text: 'Please Enter Local Directory Path.', icon: 'error', confirmButtonText: 'OK' })
            // alert("Please Enter Local Directory Path.");
        }else{
            const fileList = getFilesRecursively(directoryPath);

            const replaceDirePath = String(directoryPath);
    
            const asyncForEach = async (array, callback) => {
                for (let index = 0; index < array.length; index++) {
                    await callback(array[index], index, array);
                }
            };

            if(fileList.length){
                const uploadAndDownloadFiles = async () => {
                    await asyncForEach(fileList, async (curEle, index) => {
                        const stats = fs.statSync(curEle);

                        const folderPath = String(curEle).replace(/\\/g, '/').replace(replaceDirePath, "");

                        if (!stats.isFile()) {
                            const exists = await folderExists(client, folderPath);
                            if(!exists){
                                await createFolder(client,folderPath);

                                let vAuthtoken = JSON.parse(loggedData).vAuthtoken;
                                axios.post(apiBaseUrl + 'fileAction.php', { action: 'addFolder', vAuthtoken, vFolderName: folderPath, vUsers: "", tFolderPath: "/"+folderPath })
                                .then(function (response) {
                                    // resolve();
                                })
                                .catch(function (error) {
                                    // reject(error);
                                });
                            }
                        }else{
                            const localFilePath=String(curEle).replace(/\\/g, '/');
                            await uploadFile(localFilePath, folderPath);
                        }

                        if (index === fileList.length - 1) {
                            await client.cd("/");
                            await fileDownload("/", () => {
                                console.log("Sync Completed.")
                                Swal.fire({ title: 'Success', text: 'Sync Completed.', icon: 'success', confirmButtonText: 'OK' })
                                // alert("Sync Completed.");
                            });
                            await getFolderList(parentDirPath);
                        }
                    });
                };

                uploadAndDownloadFiles().catch((error) => {
                    // console.error("Error:", error);
                });
            }else{
                await fileDownload("/", () => {
                    console.log("Sync Completed.")
                    Swal.fire({ title: 'Success', text: 'Sync Completed.', icon: 'success', confirmButtonText: 'OK' })
                    // alert("Sync Completed.");
                });
                await getFolderList(parentDirPath);
            }
        }
    }

    //Sync Button Action
    document.getElementById('SyncData').addEventListener('click', function(e){
        e.preventDefault();
        const directoryPath=document.getElementById("vDownloadFolderPath").value;
        if(directoryPath==""){
            alert("Please Enter Local Directory Path.");
        }else{
            let loggedDataGet=localStorage.getItem("fileManagerData");
            if(loggedDataGet!=null){
                loggedDataGet=JSON.parse(loggedDataGet);
                loggedDataGet['syncPath']=directoryPath;
                localStorage.setItem("fileManagerData",JSON.stringify(loggedDataGet));
            }
            syncFolder();
        }
    })
})