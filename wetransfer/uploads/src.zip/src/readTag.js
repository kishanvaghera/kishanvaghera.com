const RFIDReader = require('rfid-reader-lib');

const reader = new RFIDReader({
    port: '/dev/ttyUSB0', // replace with your actual port
    baudRate: 9600, // adjust to match your reader's configuration
});

reader.connect();

reader.on('tag', (tag) => {
    console.log('RFID Tag:', tag);
});

reader.on('error', (error) => {
    console.error('RFID Error:', error);
});

reader.disconnect();