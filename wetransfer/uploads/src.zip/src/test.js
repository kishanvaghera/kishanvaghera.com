const http = require('http');

const ipAddress = '192.168.1.111';
const port = 4370; // Assuming the server is running on port 80

// Make an HTTP GET request to retrieve data
const options = {
  hostname: ipAddress,
  port: port,
  path: '/path/to/resource', // Replace with the actual path to your resource
  method: 'GET',
};

const req = http.request(options, (res) => {
  let data = '';

  // A chunk of data has been received.
  res.on('data', (chunk) => {
    data += chunk;
  });

  // The whole response has been received.
  res.on('end', () => {
    console.log('Received data from the server:');
    console.log(data);
  });
});

req.on('error', (e) => {
  console.error(`Request error: ${e.message}`);
});

// End the request
req.end();
