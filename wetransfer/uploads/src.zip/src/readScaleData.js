const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

const port = new SerialPort({
    path: 'COM8',
    baudRate: 9600,
    dataBits: 7,
    parity: 'none',
    stopBits: 1,
});

const parser = new ReadlineParser({ delimiter: '\r\n' });
port.pipe(parser);

port.on('data', (data) => {
    const buf2 = Buffer.from(data);
    let wArray = buf2.toString('utf8');
    let wSlice = wArray.slice(3, wArray.length);
    let rawWeight = wSlice.slice(0, -3);
    let fWeight = rawWeight.trim();
    let weight = parseFloat(fWeight);
    console.log("weight", weight);
});
  
port.on('error', (err) => {
    console.error('Error:', err.message);
});

port.on('open', () => {
    console.log('Serial port is open');
   
});

port.on('close', () => {
    console.log('Serial port is closed');
});

