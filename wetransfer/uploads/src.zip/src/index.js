const express = require('express');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const bodyParser = require("body-parser"); 
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Function to find the appropriate serial port dynamically
function findSerialPort() {
  return new Promise((resolve, reject) => {
    SerialPort.list()
      .then(ports => {
        console.log("ports",ports)
        const port = ports.find(p => p.manufacturer && p.friendlyName.includes('Communications Port'));
        if (port) {
          resolve(port.path);
        } else {
          reject(new Error('Serial port not found.'));
        }
      })
      .catch(err => reject(err));
  });
}

// Use the function to dynamically get the serial port
findSerialPort()
  .then(path => {
    const serialPort = new SerialPort({
      path: path,
      baudRate: 9600,
      dataBits: 7,
      parity: 'none',
      stopBits: 1,
    });

    const parser = new ReadlineParser({ delimiter: '\r\n' });
    serialPort.pipe(parser);

    app.get('/weight', (req, res) => {
      res.setHeader('Content-Type', 'application/json');

      parser.once('data', (data) => {
        const buf2 = Buffer.from(data);
        let wArray = buf2.toString('utf8');
        let wSlice = wArray.slice(3, wArray.length);
        let rawWeight = wSlice.slice(0, -3);
        let fWeight = rawWeight.trim();
        let weight = parseFloat(fWeight);

        let [netValue, tarValue] = rawWeight.split('/'); // Assuming the values are separated by '/'
        let fNetValue = netValue.trim();
        let fTarValue = tarValue.trim();
        let netWeight = parseFloat(fNetValue);
        let tarWeight = parseFloat(fTarValue);

        res.json({ weight });
      });

      serialPort.write('W');
    });

    serialPort.on('error', (err) => {
      console.error('Error:', err.message);
    });

    serialPort.on('open', () => {
      console.log('Serial port is open');
    });

    serialPort.on('close', () => {
      console.log('Serial port is closed');
    });

    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  })
  .catch(err => console.error(err));
