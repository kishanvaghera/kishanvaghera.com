const http = require('http');
const hostname = 'localhost';
const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')
const { io } = require('socket.io');
let express = require('express');
const cors = require('cors');

const serialPort = new SerialPort({ 
    path: 'COM4',
    baudRate: 9600 ,
})
const parser = serialPort.pipe(new ReadlineParser({ delimiter: '\r\n' }))
let app = express();
var port = 8080;

app.use(cors());

const server = http.createServer(app);

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
app.get('/', function(req, res) {
    console.log(parser);
    // parser.on('data', function(data) {
    //     // res.send(data);
    //     console.log("Data Read",data);
    // })
    
    res.send(parser.on('data', function(data) {
        // res.send(data);
        console.log("Data Read",data);
    }));
});