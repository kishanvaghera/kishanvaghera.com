<?php

$ftp_server_IP = "217.21.92.68";
$ftp_username = "u560104897.beta_test";
$ftp_userpass = '#*1bCJR.ZYjw';


?>