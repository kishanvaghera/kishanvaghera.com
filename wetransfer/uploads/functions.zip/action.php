<?php
include "./config.php";

if($_POST['action']=="create_new_folder"){
    mkdir($_POST['vPath']."/".$_POST['vFolderName'], 0777);
}else if($_POST['action']=="upload_file"){  

    if( $_FILES['file']['name'] != "" ) {
        $path=$_FILES['file']['name'];
        $pathto=$_POST['vPath']."/".$path;
        move_uploaded_file($_FILES['file']['tmp_name'],$pathto) or die( "Could not copy file!");
        echo json_encode(array("status"=>200,"msg"=>"File has been uploaded successfully."));
    }
    else {
        echo json_encode(array("status"=>412,"msg"=>"Some error get."));
    }
}else if($_POST['action']=="create_folder_ftp"){  
    // connect and login to FTP server
    $ftp_conn = ftp_connect($ftp_server_IP) or die("Could not connect to $ftp_server_IP");
    ftp_login($ftp_conn, $ftp_username, $ftp_userpass);
    
    ftp_mkdir($ftp_conn, $_POST['vPath']."/".$_POST['vFolderName']);

    ftp_close($ftp_conn);   
    exit;
}else if($_POST['action']=="upload_file_ftp"){  
    if( $_FILES['file']['name'] != "" ) {
        $path=$_FILES['file']['name'];
        $file = $_FILES['file']['tmp_name'];

        $ftp_conn = ftp_connect($ftp_server_IP) or die("Could not connect to $ftp_server_IP");
        ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

        if (ftp_put($ftp_conn, $_POST['vPath']."/".$path, $file, FTP_BINARY))
        {
            echo "Successfully uploaded $file.";
        }
        else
        {
            echo "Error uploading $file.";
        }

        ftp_close($ftp_conn);   

        echo json_encode(array("status"=>200,"msg"=>"File has been uploaded successfully."));
    }
    else {
        echo json_encode(array("status"=>412,"msg"=>"Some error get."));
    }
}  

?>