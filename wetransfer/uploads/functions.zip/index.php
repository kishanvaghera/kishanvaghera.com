<html>
<?php
$folderUrl = isset($_GET['file']) ? $_GET['file'] : "";

function folder_exist($folder)
{
    // Get canonicalized absolute pathname
    $path = realpath($folder);

    // If it exist, check if it's a directory
    return ($path !== false and is_dir($path)) ? $path : false;
}

function read_dir_content($parent_dir, $lastPath = "")
{
    $str_result = "";
    if ($handle = opendir($parent_dir)) {
        while (false !== ($file = readdir($handle))) {
            if (in_array($file, array('.', '..'))) continue;
            if (is_dir($parent_dir . "/" . $file)) {
                // $str_result .= "<li>" . read_dir_content($parent_dir . "/" . $file, $depth++) . "</li>";
            }

            if (FALSE !== folder_exist($parent_dir . "/" . $file)) {
                $str_result .= '<a class="folder" href="index.php?file=' . $lastPath . '/' . $file . '">
                    <i class="material-icons">folder</i>
                    <h1>' . $file . '</h1>
                </a>';
            } else {
                $str_result .= '<a class="folder">
                                    <i class="material-symbols-outlined">description</i>
                                    <h1>' . $file . '</h1>
                                </a>';
            }
        }
        closedir($handle);
    }

    return $str_result;
}

?>

<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./style.css" />
</head>

<body id="drop-area">
    <header>
        <i class="material-icons icon-menu">menu</i>
        <h1>Files</h1>
        <span></span>
        <i class="material-icons" id="vCreateFolderBtn" data-bs-toggle="modal" data-bs-target="#exampleModal">add</i>
        <i class="material-icons">more_vert</i>
    </header>
    <input type="hidden" id="folderUrl" value="<?=$folderUrl?>" />
    <main>
        <?php
            echo read_dir_content("d:/" . $folderUrl, $folderUrl);
        ?>
    </main>

    <form enctype="multipart/form-data" id="file-form">
        <input type="file" id="file-input" name="files[]" multiple style="display: none;">
    </form>

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Create New Folder</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Folder Name</label>
                    <input type="text" class="form-control" id="vFolderName" value="" placeholder="Enter Folder name" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" id="vSubmitBtn" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
    </div>


    <div id="progressBar" class="d-none">
        <div class="progress-bar__wrapper">
            <label class="progress-bar__value" htmlFor="progress-bar"> 0% </label>
            <progress id="progress-bar" value="0" max="100"></progress>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./main.js"></script>

</body>

</html>