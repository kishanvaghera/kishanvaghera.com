<?php
$ftp_server_IP="43.204.136.107";
$ftp_username="comet@comet.ooo";
$ftp_userpass='$Zm-66i(exLP';

// connect and login to FTP server
$ftp_conn = ftp_connect($ftp_server_IP) or die("Could not connect to $ftp_server_IP");
$login = ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

// allocate space
$file_list = ftp_nlist($ftp_conn, "./enliven.comet.ooo/");
echo "<pre>";
print_r($file_list);

// close connection
ftp_close($ftp_conn);
?>