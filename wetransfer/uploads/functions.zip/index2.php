<html>
<?php
error_reporting(0);
include './config.php';

$folderUrl = isset($_GET['file']) ? $_GET['file'] : ".";

function getFtpDir($string)
{
    global $ftp_server_IP;
    global $ftp_username;
    global $ftp_userpass;

    // connect and login to FTP server
    $ftp_conn = ftp_connect($ftp_server_IP) or die("Could not connect to $ftp_server_IP");
    ftp_login($ftp_conn, $ftp_username, $ftp_userpass);

    // File List
    $file_list = ftp_nlist($ftp_conn, $string);

    $newFileArr=array();

    if(is_array($file_list) && count($file_list)>0){
        foreach($file_list as $value){
            $file_type = ftp_size($ftp_conn, $value) !== -1 ? 'file' : (ftp_mlsd($ftp_conn, $value) !== false ? 'directory' : 'unknown');
            $newFileArr[]=array("fileName"=>$value,"file_type"=>$file_type);
        }
    }

    ftp_close($ftp_conn);

    return $newFileArr;
}


function read_dir_content($dirList,$folderUrl)
{
    $str_result = "";

    foreach($dirList as $value){
        $remDom=str_replace($folderUrl."/","",$value['fileName']);
        // $remDom=$value['fileName'];

        if (in_array($remDom, array('.', '..','./','/..','/.'))) continue;
        
        if ($value['file_type']=="directory") {
            $str_result .= '<a class="folder" href="index2.php?file='.$value['fileName'].'">
                                <i class="material-icons">folder</i>
                                <h1>' . $remDom . '</h1>
                            </a>';
        }else{
            $str_result .= '<a class="folder">
                                <i class="material-symbols-outlined">description</i>
                                <h1>' . $remDom . '</h1>
                           </a>';
        }
    }

    if($str_result==""){
        $str_result="No File Or Folder Found.";
    }

    return $str_result;
}

?>

<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./style.css" />
</head>

<body id="drop-area">
    <!-- Header Section -->
    <header>
        <i class="material-icons icon-menu">menu</i>
        <h1>Files</h1>
        <span></span>
        <i class="material-icons" id="vCreateFolderBtn" data-bs-toggle="modal" data-bs-target="#exampleModal">add</i>
        <i class="material-icons">more_vert</i>
    </header>
    <input type="hidden" id="folderUrl" value="<?= $folderUrl ?>" />

    <!-- Folder List Section -->
    <main>
        <?php
            echo read_dir_content(getFtpDir($folderUrl),$folderUrl);
        ?>
    </main>

    <!-- File Upload Form -->
    <form enctype="multipart/form-data" id="file-form">
        <input type="file" id="file-input" name="files[]" multiple style="display: none;">
    </form>


    <!-- New Folder Upload Code -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Create New Folder</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Folder Name</label>
                        <input type="text" class="form-control" id="vFolderName" value="" placeholder="Enter Folder name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" id="vSubmitBtn" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>


    <!-- File Upload Progress Bar -->
    <div id="progressBar" class="d-none">
        <div class="progress-bar__wrapper">
            <label class="progress-bar__value" htmlFor="progress-bar"> 0% </label>
            <progress id="progress-bar" value="0" max="100"></progress>
        </div>
    </div>


    <!-- Footer Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="./main.js"></script>
</body>
</html>