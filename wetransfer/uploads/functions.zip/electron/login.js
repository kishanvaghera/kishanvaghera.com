const axios = require('axios');

window.addEventListener('DOMContentLoaded', () => { 
    
    const loggedData=localStorage.getItem("fileManagerData");
    if(loggedData!=null){
        const dd=JSON.parse(loggedData);
        if(dd.vAuthtoken!=""){
            window.location="./index.html";
        }
    }   

    const loginApi=async()=>{
        const vUserName=document.getElementById("vUserName").value;
        const vPassword=document.getElementById("vPassword").value;

        if(vUserName=="" || vPassword==""){
            document.getElementById('error-msg').classList.remove("d-none");
            document.getElementById('error-msg').innerHTML="Please enter username & password!";
        }else{
            axios.post('http://192.168.1.35/file_manager/api/auth.php', {action:'login',vUserName,vPassword})
              .then(function (response) {
                if(response.data.status==201){
                    document.getElementById('error-msg').classList.add("d-none");
                    document.getElementById('error-msg').innerHTML="";
    
                    localStorage.setItem("fileManagerData", JSON.stringify(response.data.data));

                    window.location="./index.html";
    
                }else if(response.data.status==412){
                    document.getElementById('error-msg').classList.remove("d-none");
                    document.getElementById('error-msg').innerHTML=response.data.msg;
                }
                console.log(response);
              })
              .catch(function (error) {
                console.log(error);
            });
        }

    }

    document.getElementById('submit').addEventListener('click', function(){
        loginApi();
    });
})