var jsftp = require("jsftp");
const axios = require('axios');
const fs = require("fs");
const path = require('path');

window.addEventListener('DOMContentLoaded', () => {

    let apiBaseUrl="http://192.168.1.35/file_manager/api/";

    const loggedData=localStorage.getItem("fileManagerData");

    //Credential List
    var Ftp = new jsftp({ 
        host: "217.21.92.68",
        port: 21,
        user: "u560104897.beta_test",
        pass: "#*1bCJR.ZYjw"
    });

    let parentDirPath="./";

    const fileDeleteApi=(fileName)=>{
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'DeleteFolderFile',vAuthtoken,tFolderPath:fileName})
                    .then(function (response) {
        })
    }

    const changePath=()=>{
        document.getElementById("bread-crumb").innerHTML=parentDirPath;
    }

    changePath();

    // console.log("parentDirPath",parentDirPath)
    const folderList=document.getElementById("folderList");

    function isFile(pathname) {
        return pathname.split('/').pop().indexOf('.') > -1;
    }
    
    function isDir(pathname) { return !isFile(pathname); }

    function removeDirectory(path, callback) {
        Ftp.ls(path, (err, files) => {
            if (err) {
                return callback(err);
            }
    
            let pending = files.length;
            if (!pending) {
                fileDeleteApi(path);
                return Ftp.raw("RMD", path, callback);
            }
    
            files.forEach(file => {
                const filePath = `${path}/${file.name}`;
                if (isDir(filePath)) {
                    removeDirectory(filePath, (err) => {
                        if (!--pending) {
                            fileDeleteApi(path);
                            Ftp.raw("RMD", path, callback);
                        }
                    });
                } else {
                    Ftp.raw("DELE", filePath, (err) => {
                        if (!--pending) {
                            fileDeleteApi(path);
                            Ftp.raw("RMD", path, callback);
                        }
                    });
                }
            });
        });
    }

    //get File Directory List
    function getFolderList(parentDir="."){
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'getFolderList',vAuthtoken})
              .then(function (response) {
                if(response.data.status==201){
                     const dFolderList = response.data.data;
                     
                     changePath();

                     Ftp.ls(parentDir, (err, res) => {
                        let fileHtml="";
                        res.forEach(file => {
                            if(dFolderList.includes(parentDirPath+file.name)){
                                if(file.type==0){
                                    fileHtml+="<li>"+file.name+"</li>";
                                }else{
                                    fileHtml+="<li class='folderList' data-id='"+file.name+"' >"+file.name+"</li>";
                                }
                            }
                        });
                        folderList.innerHTML="<ul>"+fileHtml+"</ul>";
            
                        var folderListLink = document.querySelectorAll('.folderList');
                        for (var i = 0; i < folderListLink.length; i++) {
                            folderListLink[i].addEventListener('click', function(event) {
                                parentDirPath=parentDirPath+this.dataset.id+"/";
                                getFolderList(parentDirPath);
                            });
                        }
                    });
                }
            })
            .catch(function (error) {
            // console.log(error);
        });
    }

    getFolderList(parentDirPath);

    let isCheckUser=[];
    const getUserList=(isId="userList")=>{
        document.getElementById(isId).innerHTML = "";
        let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
        axios.post(apiBaseUrl+'fileAction.php', {action:'GetUserList',vAuthtoken})
              .then(function (response) {
            if(response.data.status==201){
                let userHtml="";
                response.data.data.map((curEle,index)=>{
                    userHtml+=` <div class="userListRow">
                                    <div><input type="checkbox" class="checkbox chkUser" name="iUserId_${curEle.iUserId}" id="iUserId_${curEle.iUserId}" value="${curEle.iUserId}" ${isCheckUser.includes(""+curEle.iUserId)?"checked":""}/></div>
                                    <div class="checkbox-label">${curEle.vUserName}</div>
                                </div>`;
                })
                document.getElementById(isId).innerHTML=userHtml;
            }
        })
    }

    //New Folder
    document.getElementById('addcBtn').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "flex";
        getUserList();
    });
    
    document.querySelector('#AddFolderModalClose').addEventListener('click', function(){
        document.querySelector("#AddFolderModal").style.display = "none";
    });

    function getCheckedBoxes(chkboxName) {
        var checkboxes = document.getElementsByClassName(chkboxName);
        var checkboxesChecked = [];
        // loop over them all
        for (var i=0; i<checkboxes.length; i++) {
           // And stick the checked ones onto an array...
           if (checkboxes[i].checked) {
              checkboxesChecked.push(checkboxes[i].value);
           }
        }
        // Return the array if it is non-empty, or null
        return checkboxesChecked.length > 0 ? checkboxesChecked : [];
    }


    document.getElementById('submitFolder').addEventListener('click', function(e){
        e.preventDefault();
        const folderName=document.getElementById('vFolderName');
        const getUsrList=getCheckedBoxes("chkUser");
        const vUsers=getUsrList.toString();

        if(folderName.value==""){
            alert("please enter folder name!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'addFolder',vAuthtoken,vFolderName:folderName.value,vUsers,tFolderPath:parentDirPath+folderName.value})
                  .then(function (response) {
                if(response.data.status==201){
    
                    Ftp.raw("mkd", parentDirPath+folderName.value, (err, data) => {
                        if (err) {
                            return console.error(err);
                        }
                        // console.log(data.text); // Show the FTP response text to the user
                        // console.log(data.code); // Show the FTP response code to the user
                        document.querySelector("#AddFolderModal").style.display = "none";
                        getFolderList(parentDirPath);
                    });
    
                }
            })
        }
    })

    //File Upload Code Start
    const fileInput = document.getElementById('file-input');
    const dropArea = document.getElementById('drop-area');

    // Handle file selection
    fileInput.addEventListener('change', handleFileSelect);

    // Handle drag and drop
    dropArea.addEventListener('dragover', handleDragOver);
    dropArea.addEventListener('drop', handleDrop);

    function handleFileSelect(event) {
        const files = event.target.files;
        handleFiles(files);
    }

    function handleDragOver(event) {
        event.stopPropagation();
        event.preventDefault();
        event.dataTransfer.dropEffect = 'copy';
    }

    function handleDrop(event) {
        event.stopPropagation();
        event.preventDefault();
        const files = event.dataTransfer.files;
        handleFiles(files);
    }
      
    function handleFiles(files) {
        // Process each file
        for (const file of files) {
            const reader = new FileReader();
            reader.onload = () => {
            const fileBuffer = Buffer.from(reader.result);
                let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
                document.getElementById("loaderMain").classList.remove("d-none");
                axios.post(apiBaseUrl+'fileAction.php', {action:'addFolder',vAuthtoken,vFolderName:file.name,tFolderPath:parentDirPath+file.name})
                    .then(function (response) {
                    if(response.data.status==201){
                        Ftp.put(fileBuffer, parentDirPath+file.name, err => {
                            // console.log("err",err)
                            if (!err) {
                                console.log("File transferred successfully!");
                                getFolderList(parentDirPath);
                                document.getElementById("loaderMain").classList.add("d-none");
                            }
                        });
                    }
                })
            };
            reader.readAsArrayBuffer(file);
        }
    }



    //Logout Code Start
    document.getElementById('logout').addEventListener('click', function(e){
        localStorage.removeItem("fileManagerData");
        window.location="./login.html";
    })


    //Back Page
    document.getElementById('backButton').addEventListener('click', function(e){
        let newArr = String(parentDirPath).split("/").filter(e => e);
        newArr.pop();
        let text = newArr.join("/");

        if(String(text+"/")!="/"){
            parentDirPath=text+"/";
            getFolderList(parentDirPath);
        }
    })


    //Right Click File & Folder
    let isFileEditActive="";
    let isNewFileName="";
    document.body.addEventListener("mousedown", event => {
        if (event.button == 2){ 
            if(event?.target.closest("li")!=null){
                const fileName=parentDirPath+event?.target?.textContent;
        
                let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
                let iUserId=JSON.parse(loggedData).iUserId;

                isFileEditActive=fileName;
                isNewFileName=event?.target?.textContent;

                axios.post(apiBaseUrl+'fileAction.php', {action:'GetFolderPermission',vAuthtoken,tFolderPath:fileName})
                    .then(function (response) {
                    if(response.data.status==201){
                        if(response.data.iCreatedBy==iUserId){
                            let newArr = String(response.data.data).split(",").filter(e => e);
                            isCheckUser=newArr;

                            document.querySelector("#FolderMoreModal").style.display = "flex";
                        }else{
                            isCheckUser=[];
                        }

                    }else{
                        isCheckUser=[];
                    }
                })
            }
        }
    });


    //More Modal Code Start
    document.querySelector('#FolderMoreModalClose').addEventListener('click', function(){
        document.querySelector("#FolderMoreModal").style.display = "none";
        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
    });
    
    document.querySelector('#PermissionFolderFile').addEventListener('click', function(){
        document.querySelector("#AddFilePermission").style.display = "flex";
        getUserList("userListFile");
    });

    document.querySelector('#RenameFolderFile').addEventListener('click', function(){
        document.querySelector("#RenameFolderFileModal").style.display = "flex";

        document.getElementById("vNewFolderName").value=isNewFileName;
    });

    // SubmitRenameFolderFile
    document.querySelector('#SubmitRenameFolderFile').addEventListener('click', function(e){
        e.preventDefault();

        const vNewFolderName=document.getElementById("vNewFolderName").value;

        Ftp.rename(parentDirPath+isNewFileName,parentDirPath+vNewFolderName, (err, res) => {
            if (!err) {
              console.log("Renaming successful!");
            }

            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'EditFolder',vAuthtoken,vFolderName:parentDirPath+vNewFolderName,vOldFolderName:parentDirPath+isNewFileName})
                    .then(function (response) {
                if(response.data.status==201){
                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#RenameFolderFileModal").style.display = "none";

                    document.querySelector("#FolderMoreModal").style.display = "none";
                    getFolderList(parentDirPath);
                }
            })
        });
    });

    // RenameFolderFileClose
    document.querySelector('#RenameFolderFileClose').addEventListener('click', function(e){
        e.preventDefault();

        isCheckUser=[];
        isFileEditActive="";
        isNewFileName="";
        document.querySelector("#RenameFolderFileModal").style.display = "none";

        document.querySelector("#FolderMoreModal").style.display = "none";
    })

    //Delete Folder Or File
    document.querySelector('#DeleteFolderFile').addEventListener('click', function(){
        removeDirectory(isFileEditActive, (err, data) => {
            if (err) {
                return console.error(err);
            }
            
            document.querySelector("#FolderMoreModal").style.display = "none";
            getFolderList(parentDirPath);
        });
    });
    
    // AddFilePermissionClose
    document.querySelector('#AddFilePermissionClose').addEventListener('click', function(){
        isCheckUser=[];
        isFileEditActive="";
        document.querySelector("#AddFilePermission").style.display = "none";
    });

    document.getElementById('submitAddFilePerm').addEventListener('click', function(e){
        e.preventDefault();
        const folderName=isFileEditActive;
        const getUsrList=getCheckedBoxes("chkUser");
        const vUsers=getUsrList.toString();

        if(folderName==""){
            alert("Please select file or folder only!");
        }else{
            let vAuthtoken=JSON.parse(loggedData).vAuthtoken;
            axios.post(apiBaseUrl+'fileAction.php', {action:'UpdatePermission',vAuthtoken,vFolderName:folderName,vUsers:vUsers})
                  .then(function (response) {
                if(response.data.status==201){
                    isCheckUser=[];
                    isFileEditActive="";
                    isNewFileName="";
                    document.querySelector("#AddFilePermission").style.display = "none";
                }
            })
        }
    })



    //Ftp File And Folder Download
    let downloadFolderPath="";
    const fileDownload = (path, callback) => {
        Ftp.ls(path, (err, files) => {
            if (err) {
                return callback(err);
            }
    
            let pending = files.length;
            if (!pending) {
                return callback(null); // No files to download
            }
    
            files.forEach(file => {
                const filePath = `${path}/${file.name}`;
                const remoteFilePath = String(filePath).replace("./", "");
                const localFilePath = downloadFolderPath + remoteFilePath;

                if (file.type==1) {
                    if (!fs.existsSync(localFilePath)) {
                        fs.mkdirSync(localFilePath, { recursive: true });
                    }
                    fileDownload(filePath, () => {
                        pending--;
                        if (pending === 0) {
                            callback(null);
                        }
                    });
                } else {

                    const fileStream = fs.createWriteStream(localFilePath);

                    Ftp.get(remoteFilePath, (err, socket) => {
                        if (err) {
                            console.error("Error retrieving file:", err);
                            return;
                        }

                        socket.on("data", data => {
                            // Write the received data to the local file
                            fileStream.write(data);
                        });

                        socket.on("close", () => {
                            // Close the file stream when the download is complete
                            fileStream.end();
                            console.log("File downloaded successfully!");
                        });

                        socket.resume(); // Resume reading from the socket
                    });
                }
            });

            document.querySelector("#DownloadBackupModal").style.display = "none";
        });
    };
    

    //Sync Folder Code Start
    document.getElementById('DownloadFolders').addEventListener('click', function(e){
        e.preventDefault();
        document.querySelector("#DownloadBackupModal").style.display = "flex";
    })

    document.getElementById('DownloadBackupModalClose').addEventListener('click', function(e){
        e.preventDefault();
        document.querySelector("#DownloadBackupModal").style.display = "none";
    })

    document.getElementById('submitDownloadBackup').addEventListener('click', function(e){
        e.preventDefault();
        const vDownloadFolderPath=document.getElementById("vDownloadFolderPath").value;
        if(vDownloadFolderPath==""){
            alert("Please enter folder path.");
        }else{
            downloadFolderPath=vDownloadFolderPath;
            fileDownload("./");
        }
    })

    function getFilesRecursively(directory) {
        let files = [];
        const contents = fs.readdirSync(directory);
        contents.forEach(item => {
            const fullPath = path.join(directory, item);
            const stats = fs.statSync(fullPath);
    
            if (stats.isFile()) {
                files.push(fullPath);
            } else if (stats.isDirectory()) {
                files.push(fullPath);
                files = files.concat(getFilesRecursively(fullPath));
            }
        });
        return files;
    }

    function getFileSize(filePath, callback) {
        let newArr = String(filePath).split("/").filter(e => e);
        newArr.pop();
        let text = newArr.join("/");

        Ftp.ls(text, function(err, files) {
            if (err) {
                callback(err);
                return;
            }
            
            let fileName = String(filePath).split("/").filter(e => e);
            
            var file = files.find(function(file) {
                return file.name === fileName[fileName.length-1];
            });

            if (!file) {
                callback("200");
                return;
            }
    
            callback(null, file.size);
        });
    }

    function uploadFile(localPath, remotePath, callback) {
        fs.readFile(localPath, function(err, data) {
            if (err) {
                callback(err);
                return;
            }
            Ftp.put(data, remotePath, function(err) {
                if (err) {
                    callback(err);
                    return;
                }
                callback(null);
            });
        });
    }

    document.getElementById('SyncFolder').addEventListener('click', function(e){
        e.preventDefault();

        const directoryPath = 'D:/My New Project';
        const fileList = getFilesRecursively(directoryPath);

        const replaceDirePath=String(directoryPath).replace("/","\\");

        const newMapData=fileList.filter((curEle,index)=>{
            const stats = fs.statSync(curEle);

            if (!stats.isFile()) {
                const newPath=String(curEle).replace(replaceDirePath,"");
                const newString=newPath.split("\\").join("/");

                Ftp.raw("mkd", newString, (err, data) => {
                    if (err) {
                        // return console.error(err);
                    }
                });
            }else{
                return stats.isFile();
            }
        })

        if(newMapData.length){
            newMapData.map((curEle,index)=>{
                const newPath=String(curEle).replace(replaceDirePath,"");
                const newString=newPath.split("\\").join("/");

                const stats = fs.statSync(curEle);
                var fileSizeInMegabytes = stats.size / (1024*1024);

                getFileSize(newString, function(err, size) {
                    if (err) {
                        if(err==200){
                            uploadFile(curEle, newString, function(err) {
                                if (err) {
                                    console.error("Error:", err);
                                } else {
                                    console.log("File transferred successfully!");
                                }
                            });
                        }
                    } else {

                        var ftpFileSize = size / (1024*1024);

                        if(ftpFileSize!=fileSizeInMegabytes){
                            uploadFile(curEle, newString, function(err) {
                                if (err) {
                                    console.error("Error:", err);
                                } else {
                                    console.log("File transferred successfully!");
                                }
                            });
                        }
                    }
                });
            })
        }
    })

})