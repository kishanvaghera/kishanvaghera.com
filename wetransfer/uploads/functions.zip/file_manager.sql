-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.1.35:3306
-- Generation Time: Jun 28, 2024 at 04:49 AM
-- Server version: 11.0.3-MariaDB-log
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `file_manager`
--

-- --------------------------------------------------------

--
-- Table structure for table `file_system`
--

CREATE TABLE `file_system` (
  `iFileId` int(11) NOT NULL,
  `vFolderName` varchar(250) NOT NULL,
  `tFolderPath` text NOT NULL,
  `tFilePermission` text NOT NULL,
  `eStatus` enum('y','n','d') NOT NULL,
  `iCreatedBy` int(11) NOT NULL,
  `dCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `file_system`
--

INSERT INTO `file_system` (`iFileId`, `vFolderName`, `tFolderPath`, `tFilePermission`, `eStatus`, `iCreatedBy`, `dCreatedDate`) VALUES
(51, 'Deleted Folders', './db.txt', '', 'y', 0, '2024-05-09 15:34:31'),
(80, 'Kishan', './Kishan', '', 'y', 5, '2024-05-10 14:33:28'),
(81, 'Kishan2', './Kishan2', '', 'y', 5, '2024-05-10 14:33:32'),
(82, 'Kishan3', './Kishan3', '', 'y', 5, '2024-05-10 14:33:36'),
(83, 'Kishan_1', './Kishan/Kishan_1', '', 'y', 5, '2024-05-10 14:33:42'),
(84, 'Kishan2_1', './Kishan2/Kishan2_1', '', 'y', 5, '2024-05-10 14:33:50'),
(85, 'Kishan3_1', './Kishan3/Kishan3_1', '', 'y', 5, '2024-05-10 14:34:01'),
(86, 'ABC', './ABC', '', 'y', 6, '2024-05-10 14:34:20'),
(87, 'ABC2', './ABC2', '', 'y', 6, '2024-05-10 14:34:24'),
(88, 'ABC3', './ABC3', '', 'y', 6, '2024-05-10 14:34:27'),
(89, 'ABC_1', './ABC/ABC_1', '', 'y', 6, '2024-05-10 14:34:33'),
(90, 'ABC2_1', './ABC2/ABC2_1', '', 'y', 6, '2024-05-10 14:35:05'),
(91, 'ABC3_1', './ABC3/ABC3_1', '', 'y', 6, '2024-05-10 14:35:15'),
(92, 'Common', './Common', '5', 'y', 5, '2024-05-10 14:35:51'),
(93, 'Abc', './Common/Abc', ',6,5', 'y', 6, '2024-05-10 14:36:18'),
(96, 'Kishan', './Common/Abc/Kishan', ',6,5', 'y', 6, '2024-05-10 15:26:31'),
(97, 'Test', './Test', '', 'y', 6, '2024-05-20 17:44:06'),
(98, 'yes', './yes', '', 'y', 7, '2024-05-20 17:46:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `iUserId` int(11) NOT NULL,
  `vUserName` varchar(250) NOT NULL,
  `vPassword` varchar(250) NOT NULL,
  `vAuthtoken` varchar(250) NOT NULL,
  `eStatus` enum('y','n','d') NOT NULL,
  `dCreatedDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`iUserId`, `vUserName`, `vPassword`, `vAuthtoken`, `eStatus`, `dCreatedDate`) VALUES
(5, 'Kishan', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'X8fdsOraPQG4nZ++Ioq3VFXNT9Wf8jmkH2whu12hmaqm6wq/JnDJWoIGSpj/oTao', 'y', '2024-05-09 08:47:47'),
(6, 'Abc', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'xkVtI9QoJjrt+GmeqP3sEMZwKzvZtON/Iz1xP/axP/Jq5zPC21cEynxmhys/Av7t', 'y', '2024-05-09 08:48:41'),
(7, 'admin', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'scGg6H6NbmFPf071Q6RtHtsH6Ts1rLLz6KKM7eqZUdhaGX38CUJ8tHj2D7LEW2ad', 'y', '2024-05-20 17:30:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `file_system`
--
ALTER TABLE `file_system`
  ADD PRIMARY KEY (`iFileId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`iUserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `file_system`
--
ALTER TABLE `file_system`
  MODIFY `iFileId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `iUserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
