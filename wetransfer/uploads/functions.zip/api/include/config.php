<?php
	error_reporting(0);
	// header('Access-Control-Allow-Origin: *');  
	// header('Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE');
	// header("Access-Control-Allow-Headers: X-Requested-With"); 
	// header("Content-Type: application/json"); 
	// header("Cache-Control: no-cache");
	$mode="LOCAL";
	
	$HOSTNAME="localhost";
	$USERNAME="root";
	$PASSWORD="";
	$DATABASE="file_manager";

	$MAIN_URL="http://192.168.1.5/file_manager/";
	ini_set('memory_limit', '400M');
	ini_set('post_max_size', '300M');
	ini_set('upload_max_filesize', '300M');
	ini_set('max_execution_time', 3600);
	
	$time_zone = "Asia/Kolkata";
	date_default_timezone_set($time_zone);

	$myCon=mysqli_connect($HOSTNAME, $USERNAME,$PASSWORD, $DATABASE);
	mysqli_query($myCon,"SET CHARACTER SET 'utf8'");
	// print_r($myCon);
	// echo "is there"; exit;
	
?>