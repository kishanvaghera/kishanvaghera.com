<?php
class db_class
{
	var $cn, $db, $db_host, $db_user, $db_pass, $db_name;
	function mf_query($query) // EXECUTE USER QUERY
	{
		$_SESSION['Last_query'] = $query;
		if (mysqli_error($GLOBALS['myCon']) != '') {
			$iEngIdErr = 0;
			if(isset($_POST['iEngId'])){
				$iEngIdErr = $_POST['iEngId'];
			}else{
				$iEngIdErr = $_SESSION['Admin_UserID'];
			}

			if (mysqli_error($GLOBALS['myCon']) != '') {
				$iEngIdErr = 0;
				if(isset($_POST['iEngId'])){
					$iEngIdErr = $_POST['iEngId'];
				}else{
					$iEngIdErr = $_SESSION['Admin_UserID'];
				}
				mysqli_query($GLOBALS['myCon'], "INSERT INTO sql_long_query(vFromPage,vPageUrl,vSqlQuery,vError,iUserId,iFrom,dCreatedDate) values('".$this->add_security($_SERVER['HTTP_REFERER'])."','" . $this->add_security($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']) . "','" . $this->add_security($query) . "','" . $this->add_security(mysqli_error($GLOBALS['myCon'])) . "','".$iEngIdErr."',1,'" . $this->curTimedate() . "')");
			}
		}
		return mysqli_query($GLOBALS['myCon'], $query);
	}
	function last_query()
	{
		return $_SESSION['Last_query'];
	}

	function mf_error() // EXECUTE USER QUERY
	{
		return mysqli_error($GLOBALS['myCon']);
	}

	public function getAddress($latitude, $longitude)
	{
		$geolocation = $latitude . ',' . $longitude;
		$request = 'https://maps.googleapis.com/maps/api/geocode/json?latlng=' . $geolocation . '&sensor=false&key=AIzaSyBtFsBlEXUEzFqIEw5AZnXj6DucvOqu4PQ';
		$file_contents = file_get_contents($request);
		$json_decode = json_decode($file_contents);
		$json_decode->results[0]->formatted_address;
		return $json_decode->results[0]->formatted_address;
	}

	public function is_ajax_request()
	{
		return (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
	}

	public function mf_num_rows($query)
	{
		if($query){
			return mysqli_num_rows($query);
		}else{
			return 0;
		} 
	}


	function sendHRPushNotification($registration_ids, $message = array(), $data = array())
	{
		global $mode;
		if($mode == "LIVE"){
			$count = COUNT((array)$registration_ids);
			$vSend = 'to';
			if (is_array($registration_ids) || $count > 1) {
				$vSend = 'registration_ids';
			}

			if (empty($data)) {
				$data = array("page" => '');
			}

			$data['pushId'] = $this->getOtp(2);
			$message['icon'] = 'xxxhdpi_push_icon';
			$message['color'] = '#00c0ef';

			global $IOSAPNKEY;
			global $ANDROIDAPNKEY;

			$api_key = 'AAAABhbJzO4:APA91bHRvpiOJZeGeyftjIhvtClxGZjCJX4r7p4k2wieGGD3u3YH4cVtR0JZlLBXPJRV7amUmy3QX5kPTe-AhBFiSxX7XhWV98jMDV1U19jBYRBmJKqdBv3aBmY2D9eMth1EYEYnof4N';
			
			$fields = array($vSend => $registration_ids, 'notification' => $message, 'data' => $data);

			$headers = array(
				'Content-Type:application/json',
				'Authorization:key=' . $api_key
			);
			$url = 'https://fcm.googleapis.com/fcm/send';

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
			$result = curl_exec($ch);

			// if ($result) {
			// 	$this->wh_log(json_encode($fields));
			// }

			if ($result === FALSE) {
				die('FCM Send Error: ' . curl_error($ch));
			}
			curl_close($ch);
		}else{
			$result = true;
			return $result;
		}
	}

	function haversineGreatCircleDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
	{

		// convert from degrees to radians

		$latFrom = deg2rad($latitudeFrom);
		$lonFrom = deg2rad($longitudeFrom);
		$latTo = deg2rad($latitudeTo);
		$lonTo = deg2rad($longitudeTo);
		$latDelta = $latTo - $latFrom;
		$lonDelta = $lonTo - $lonFrom;
		$angle = 2 * asin(sqrt(pow(sin($latDelta / 2), 2) + cos($latFrom) * cos($latTo) * pow(sin($lonDelta / 2), 2)));
		$meters = $angle * $earthRadius;
		return number_format((float) ($meters / 1000), 2);
	}

	function mf_getValue($table, $field, $where, $condition) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$qry = "SELECT $field from $table where $where='$condition' LIMIT 1";

		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			return stripslashes($row[$field]);
		} else {
			return "";
		}

	}

	function mf_getValue_Qry($table, $field, $where) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$qry = "SELECT $field from $table $where LIMIT 1";
		// echo $qry.'<br>';
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			return stripslashes($row[$field]);
		} else {
			return "";
		}
	}

	public function mf_getMultiValue_Qry($table, $field, $where) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE

	{
		$fldlist = "";
		if (is_array($field)) {
			foreach ($field as $k => $v) {
				if ($fldlist == "") {
					$fldlist .= $v;
				} else {
					$fldlist .= "," . $v;
				}
			}
		}

		$rval = array();
		$qry = "SELECT $fldlist from $table $where ";
		// echo $qry.'<br/>';
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			foreach ($field as $k => $v) {
				$rval[] = stripslashes($row[$v]);
			}
		}
		return $rval;
	}

	public function mf_getMultiValue_Qrynew($table, $field, $where) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$fldlist = "";
		if (is_array($field)) {
			foreach ($field as $k => $v) {
				if ($fldlist == "") {
					$fldlist .= $v;
				} else {
					$fldlist .= "," . $v;
				}
			}
		}
		$rval = array();
		$qry = "SELECT $fldlist from $table $where ";
		// echo $qry.'<br/>';
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			foreach ($row as $k => $v) {
				$rval[] = $v;
			}
		}
		return $rval;
	}

	function is_valueexist($qry) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			return stripslashes($row['id']);
		} else {
			return "";
		}
	}

	function mf_fetch_array($result) // RETURN SINGLE ROW IN ARRAY FORM
	{
		if($result){
			return mysqli_fetch_array($result, MYSQLI_ASSOC);
		}else{
			return array();
		}
		
	}

	function mf_affected_rows() // RETURN TOTAL AFFECTED ROW WHILE QUERY EXECUTED
	{
		return mysqli_affected_rows($GLOBALS['myCon']);
	}

	function mf_getMultiValue($table, $field, $where, $condition) // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$fldlist = "";
		if (is_array($field)) {
			foreach ($field as $k => $v) {
				if ($fldlist == "") {
					$fldlist .= $v;
				} else {
					$fldlist .= "," . $v;
				}
			}
		}

		$rval = array();
		$qry = "SELECT $fldlist from $table where $where='$condition'";
		//echo $qry;
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			foreach ($field as $k => $v) {
				$rval[] = stripslashes($row[$v]);
			}
		}

		return $rval;
	}

	function createSlug($str)
	{
		$str = strtolower(strip_tags(stripslashes(trim($str))));
		$str = str_replace(" & ", " and ", $str);
		$str = preg_replace('/[^a-zA-Z0-9]/i', '-', $str);
		$expStr = explode("--", $str);
		while (count((array)$expStr) > 1) {
			$str = implode("-",(array)  $expStr);
			$expStr = explode("--",$str);
		}

		if (substr($str, 0, 1) == "-") {
			$str = substr($str, 1);
		}

		if (substr($str, -1) == "-") {
			$str = substr($str, 0, -1);
		}
		return $str;
	}

	function createSlugUrl($table, $pid = 0, $str = "")
	{
		$str = $this->createSlug($str);
		$exRes = $this->mf_query("SELECT slug from " . $table . " where slug='" . $str . "' and id!='" . $pid . "'");
		$cnt = 1;
		if ($this->mf_affected_rows() > 0) {
			while ($exRow = $this->mf_fetch_array($exRes)) {
				$cnt++;
				$estr = $str . "-" . $cnt;
				$exRes = $this->mf_query("SELECT slug from " . $table . " where slug='" . $estr . "' and id!='" . $pid . "'");
			}

			$str = $estr;
		} else {
			$exRes = $this->mf_query("SELECT page_name from `page` where page_name='" . $str . "'");
			$c = 1;
			if ($this->mf_affected_rows() > 0) {
				while ($exRow = $this->mf_fetch_array($exRes)) {
					$c++;
					$estr = $str . "-" . $c;
				}

				$str = $estr;
			}
		}

		return $str;
	}

	function mf_dbinsert($table, $data) // FUNCTION TO INSERT NEW RECORD IN SPECIFIED TABLE
	{
		$qry = "INSERT INTO " . $table . " set ";
		foreach ($data as $fld => $val) {
			$qry .= $fld . "='" . $this->add_security($val) . "',";
		}

		$qry = substr($qry, 0, -1);
		//echo $qry; exit();
		return $this->mf_query($qry);
	}

	function mf_dbinsert_id()
	{
		return mysqli_insert_id($GLOBALS['myCon']);
	}

	function mf_dbselect($table, $fields, $conditions, $orderby = "") // FUNCTION TO SELECT RECORD IN SPECIFIED TABLE
	{
		$qry = "SELECT ";
		foreach ($fields as $fld) {
			$qry .= $fld . ",";
		}

		$qry = substr($qry, 0, -1);
		$qry .= " where 1=1 ";
		if (is_array($conditions)) {
			foreach ($conditions as $fld => $val) {
				$qry .= " and $fld='$val' ";
			}
		}

		if ($orderby != "") {
			$qry .= " order by $orderby ";
		}

		$result = $this->mf_query($qry);
		return $result;
	}

	function mf_dbupdate($table, $data, $whare) // FUNCTION TO UPDATE TABLE DATA
	{
		$qry = "UPDATE " . $table . " set ";
		foreach ($data as $fld => $val) {
			$qry .= $fld . "='" . $this->add_security($val) . "',";
		}

		$qry = substr($qry, 0, -1);
		$qry .= " " . $whare;
		// echo $qry;
		// exit();
		return $this->mf_query($qry);
	}

	function mf_dbdelete($table, $fld, $val) // FUNCTION TO DELETE TABLE ROW
	{
		$qry = "DELETE FROM " . $table . " where " . $fld . "='" . $val . "'";
		return $this->mf_query($qry);
	}

	function rand_string($length)
	{
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$size = strlen($chars);
		$str = '';
		for ($i = 0; $i < $length; $i++) {
			$str .= $chars[rand(0, $size - 1)];
		}

		return $str;
	}

	function randfilename($id)
	{
		return uniqid() . $id;
	}

	function createFileName($id)
	{
		return uniqid() . $id;
	}

	function mf_createcombo($query, $opt_value, $disp_value, $selected = "", $firstval = "-Select-")
	{

		if ($firstval != "") {
			$cmbtext = "<option value=''>$firstval</option>";
		}
		$result = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				if (stripslashes($row[$opt_value]) == stripslashes($selected)) {
					$sel = "selected='selected'";
				}

				$cmbtext .= "<option value='" . $row[$opt_value] . "' $sel>" . stripslashes($row[$disp_value]) . "</option>";
			}
		}
		//echo $cmbtext;
		return $cmbtext;
	}


	function mf_comboconfig($query, $opt_value, $disp_value, $selected = "", $firstval = "-Select-", $eType = 0)
	{
		if (!$eType) {
			$cmbtext = "<option value=''>Select " . $firstval . "</option>";
		}

		$result = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				if (stripslashes($row[$opt_value]) == stripslashes($selected)) {
					$sel = "selected='selected'";
				}

				$cmbtext .= "<option value='" . $row[$opt_value] . "' $sel>" . stripslashes($row[$disp_value]) . "</option>";
			}
		}
		return $cmbtext;
	}
	function mf_createcombonew($query, $selected = "", $firstval = "-Select-")
	{
		$cmbtext = "<option value=''>$firstval</option>";
		$result = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				if (stripslashes($row['iPartId']) == stripslashes($selected)) {
					$sel = "selected='selected'";
				}

				$cmbtext .= "<option  data-shorttext='" . $row['vShortText'] . "' value='" . $row['iPartId'] . "' $sel>" . stripslashes($row['vPartName']) . "</option>";
			}
		}

		return $cmbtext;
	}

	function mf_createcombo_array($array, $selected = "") // RETURN COMBOBOX OPTIONS LIST USING ARRAY
	{
		$cmbtext = "<option value=''>-Select-</option>";
		foreach ($array as $key => $value) {
			$sel = "";
			if (stripslashes($key) == stripslashes($selected)) {
				$sel = "selected='selected'";
			}

			$cmbtext .= "<option value='" . $key . "' $sel>" . stripslashes($value) . "</option>";
		}

		return $cmbtext;
	}

	function mf_createcombo_multi($query1, $opt_value1, $disp_value1, $query2, $opt_value2, $disp_value2, $selected = "")
	{
		$selected = explode(",", $selected);
		$cmbtext = "";
		$result = $this->mf_query($query1);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				$cmbtext .= "<optgroup label='" . stripslashes($row[$disp_value1]) . "'>";
				$new_query = str_replace("[COMMON]", $row[$opt_value1], $query2);
				$result2 = $this->mf_query($new_query);
				if ($this->mf_affected_rows() > 0) {
					while ($row2 = $this->mf_fetch_array($result2)) {
						$sel = "";
						if (in_array(stripslashes($row2[$opt_value2]),(array) $selected)) {
							$sel = "selected='selected'";
						}

						$cmbtext .= "<option value='" . $row2[$opt_value2] . "' $sel>" . stripslashes($row2[$disp_value2]) . "</option>";
					}
				}

				$cmbtext .= "</optgroup>";
			}
		}

		return $cmbtext;
	}

	function mf_createradio($radioname, $opt_list, $selected = "") // RETURN RADIO BUTTONS LIST
	{
		$radtext = "";
		foreach ($opt_list as $rmsg => $rval) {
			$sel = "";
			if (stripslashes($rval) == stripslashes($selected)) {
				$sel = "checked";
			}

			$radtext .= "<input type='radio' name='$radioname' id='$radioname' value='" . $rval . "' $sel> " . stripslashes($rmsg);
		}

		return $radtext;
	}

	function getValueMC($table, $field, $conditions = array())
	{
		$unm = "";
		$extC = "1";
		foreach ($conditions as $fld => $val) {
			$extC .= " and $fld='" . $val . "'";
		}

		$usrRes = $this->mf_query("SELECT $field from $table where $extC LIMIT 1");
		if ($this->mf_affected_rows() > 0) {
			$usrRow = $this->mf_fetch_array($usrRes);
			$unm = $usrRow[$field];
		}

		return $unm;
	}

	function delUploadFile($table, $field, $where, $condition, $path = "")
	{
		$qry = "SELECT $field from $table where $where='$condition'";
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			$vid = stripslashes($row[$field]);
			if (is_file($path . $vid)) {
				unlink($path . $vid);
			}
		}
	}

	function creatDir($fixPath)
	{
		$year = date("y");
		$month = date("m");
		$directory = "$year/$month/";

		if (!is_dir($fixPath . $directory)) {
			mkdir($fixPath . $directory, 755, true);
		}

		return $directory;
	}

	function checkUploadFileExt($ext, $allowedExt)
	{
		$ret = true;
		if ($allowedExt != '') {
			$ret = false;
			$alext = explode('|', $allowedExt);
			foreach ($alext as $val) {
				if (strtolower($val) == strtolower($ext)) {
					$ret = true;
				}
			}
		}
		return $ret;
	}

	function uploadFile($tmpPath, $fileName, $fixPath)
	{
		$year = date("y");
		$month = date("m");
		$directory = "$year/$month/";
		$fullPath = $fixPath . $directory . $fileName;
		if (!is_dir($fixPath . $directory)) {
			mkdir($fixPath . $directory, 0777, true);
		}

		if($tmpPath!=''){
			if (copy($tmpPath, $fullPath)) {
				return $directory . $fileName;
			}
		}
	}
	function uploadBase64File($image, $fileName, $fixPath)
	{
		$year = date("y");
		$month = date("m");
		$directory = "$year/$month/";
		$fullPath = $fixPath . $directory . $fileName;
		
		if (!is_dir($fixPath . $directory)) {
			mkdir($fixPath . $directory, 0777, true);
		}
		if (file_put_contents($fullPath, $image)) {
			return $directory . $fileName;
		}
	}

	function checkPageAccess($isAccess, $pgMsg)
	{
		if ($isAccess == 0) $this->mf_setmessage("<p class='msgred'>Sorry, You have not permission to access: $pgMsg</p>", "dashboard.php");
	}

	function generateCode($length = 8, $table = "", $field = "")
	{
		$characters = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$string = "";
		do {
			$string .= $characters[mt_rand(0, strlen($characters))];
		} while (strlen($string) < $length);
		if ($table != "" && $field != "") {
			while ($this->mf_getValue($table, $field, $field, $string)) {
				$string = "";
				do {
					$string .= $characters[mt_rand(0, strlen($characters))];
				} while (strlen($string) < $length);
			}
		}

		return $string;
	}

	function generatePassword($length = 8)
	{
		$characters = "0123456789AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWXxYyZz";
		$string = "";
		do {
			$string .= $characters[mt_rand(0, strlen($characters))];
		} while (strlen($string) < $length);
		return $string;
	}
	function curTimedate()
	{
		date_default_timezone_set('Asia/Kolkata');
		return date("Y-m-d H:i:s");
	}
	function curDate()
	{
		date_default_timezone_set('Asia/Kolkata');
		return date("Y-m-d");
	}

	function curTime()
	{
		date_default_timezone_set('Asia/Kolkata');
		return date("H:i:s");
	}

	function curDateFormat()
	{
		date_default_timezone_set('Asia/Kolkata');
		return date("d/m/Y");
	}

	function dispTZTimedate($dtval)
	{
		if ($dtval != '0000-00-00 00:00:00' && $dtval != '') {
			return date("d/m/Y h:i A", strtotime($dtval));
		}
	}

	function dispTZdate($dtval)
	{
		if ($dtval != '0000-00-00') {
			return date("d/m/Y", strtotime($dtval));
		}
	}

	function convert_number_to_words($number)
	{
		$no = round((float)$number);
		$point = round((float)$number - $no, 2) * 100;
		$hundred = null;
		$digits_1 = strlen($no);
		$i = 0;
		$str = array();
		$words = array(
			'0' => '',
			'1' => 'One',
			'2' => 'Two',
			'3' => 'Three',
			'4' => 'Four',
			'5' => 'Five',
			'6' => 'Six',
			'7' => 'Seven',
			'8' => 'Eight',
			'9' => 'Nine',
			'10' => 'Ten',
			'11' => 'Eleven',
			'12' => 'Twelve',
			'13' => 'Thirteen',
			'14' => 'Fourteen',
			'15' => 'Fifteen',
			'16' => 'Sixteen',
			'17' => 'Seventeen',
			'18' => 'Eighteen',
			'19' => 'Nineteen',
			'20' => 'Twenty',
			'30' => 'Thirty',
			'40' => 'Forty',
			'50' => 'Fifty',
			'60' => 'Sixty',
			'70' => 'Seventy',
			'80' => 'Eighty',
			'90' => 'Ninety'
		);
		$digits = array(
			'',
			'Hundred',
			'Thousand',
			'Lakh',
			'Crore'
		);
		$output = array();
		while ($i < $digits_1) {
			$divider = ($i == 2) ? 10 : 100;
			$number = floor($no % $divider);
			$no = floor($no / $divider);
			$i += ($divider == 10) ? 1 : 2;
			if ($number) {
				$plural = (($counter = count((array)$str)) && $number > 9) ? 's' : null;
				$hundred = ($counter == 1 && $str[0]) ? '  ' : null;
				$str[] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
			} else $str[] = null;
		}

		$str = array_reverse($str);
		$result = implode('',(array) $str);
		$output[] .= ($point < 21) ? $words[$point] : $words[floor($point / 10) * 10] . " " . $words[$point % 10] . " ";
		$result1 = implode('',(array) $output);
		if ($point > 0) {
			$result . "Rupees And " . $result1 . " Paise Only";
		} else {
			$result . "Rupees  " . " Only";
		}

		return $result;
	}

	function getSubString($string, $length, $postfix = "")
	{
		$string = trim(preg_replace("[\r]", " ", $string));
		$string = trim(preg_replace("[\n]", " ", $string));
		if (strlen($string) > $length) {
			$string = wordwrap($string, $length);
			$i = strpos($string, "\n");
			if ($i) {
				$string = substr($string, 0, $i) . $postfix;
			}
		}

		return $string;
	}

	function getPagination($count)
	{
		$paginationCount = floor($count / PAGE_PER_NO);
		$paginationModCount = $count % PAGE_PER_NO;
		if (!empty($paginationModCount)) {
			$paginationCount++;
		}

		return $paginationCount;
	}
	function CommonPaginationLM($count, $iPageNo = 1, $perPage = 10, $function = "")
	{
		$output = '';
		if ($iPageNo <= 0) {
			$iPageNo = 1;
		}
		if ($perPage != 0) {
			$pages  = ceil($count / $perPage);
		}
		$iPageNo1 = $iPageNo + 1;
		if ($iPageNo1 <= $pages && $pages > 1) {
			//$output .= '';
			$output = $output . '<a href="javascript:void(0)" class="btn btn-block btn-medium" onclick="' . $function . '(' . $iPageNo1 . ');showLoadMore(this)">Load More</a>';
			//$output .= '';
		}
		return $output;
	}

	function CommonPagination($count, $iPageNo = 1, $perPage = 10, $function = "")
	{
		$output = '';
		if ($iPageNo <= 0) {
			$iPageNo = 1;
		}
		if ($perPage != 0)
			$pages  = ceil($count / $perPage);
		if ($pages > 1) {

			$output .= '<ul class="pagination">';
			if ($iPageNo == 1) {
				$output = $output . '<li class="link first disabled"><a href="javascript:void(0)"><i class="fa fa-angle-double-left"></i></a></li><li class="link prev disabled"><a href="javascript:void(0)"><i class="fa fa-angle-left"></i></a></li>';
			} else {
				$output = $output . '<li class="link first" ><a onclick="' . $function . '(1)" ><i class="fa fa-angle-double-left"></i></a></li><li class="link prev"><a onclick="' . $function . '(\'' . ($iPageNo - 1) . '\')" ><i class="fa fa-angle-left"></i></a></li>';
			}

			if (($iPageNo - 2) > 0) {
				if ($iPageNo == 1)
					$output = $output . '<li class="link current" ><a href="javascript:void(0)">1</a><li>';
				else
					$output = $output . '<li class="link" ><a onclick="' . $function . '(1)" >1</a></li>';
			}
			if (($iPageNo - 2) > 1) {
				$output = $output . '<li class="link dot"><a href="javascript:void(0)" >...</a></li>';
			}

			for ($i = ($iPageNo - 1); $i <= ($iPageNo + 1); $i++) {
				if ($i < 1) continue;
				if ($i > $pages) break;
				if ($iPageNo == $i)
					$output = $output . '<li class="link current" ><a href="javascript:void(0)" id=' . $i . '>' . $i . '</a></li>';
				else
					$output = $output . '<li class="link" ><a href="javascript:void(0)" onclick="' . $function . '(' . $i . ')" >' . $i . '</a></li>';
			}

			if (($pages - ($iPageNo + 1)) > 1) {
				$output = $output . '<li class="link dot"><a href="javascript:void(0)" >...</a></li>';
			}
			if (($pages - ($iPageNo + 1)) > 0) {
				if ($iPageNo == $pages)
					$output = $output . '<li class="link current"><a href="javascript:void(0)" id=' . ($pages) . ' >' . ($pages) . '</a></li>';
				else
					$output = $output . '<li class="link"><a href="javascript:void(0)" onclick="' . $function . '(' . $pages . ')" >' . ($pages) . '</a></li>';
			}

			if ($iPageNo < $pages) {
				$output = $output . '<li class="link next" ><a onclick="' . $function . '(' . ($iPageNo + 1) . ')" ><i class="fa fa-angle-right"></i></a></li><li class="link second" ><a onclick="' . $function . '(' . ($pages) . ')"><i class="fa fa-angle-double-right"></i></a></li>';
			} else {
				$output = $output . '<li class="link next disabled"><a href="javascript:void(0)" ><i class="fa fa-angle-right"></i></a></li><li class="link second disabled"><a href="javascript:void(0)" ><i class="fa fa-angle-double-right"></i></a></li>';
			}

			$output .= '</ul>';
		}
		return $output;
	}

	function mf_total_nums_row($table, $where) // RETURN TOTAL COUNT OF RECORDS
	{
		$qry = "SELECT count(*) as total from $table $where ";
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			return $num_results = $row['total'];
		} else {
			return "";
		}
	}

	function getCoordLL($fulladdress) // THIS FUNCTION WILL BE DEFINED IN CLASS FILE
	{
		$geocode = file_get_contents('http://maps.google.com/maps/api/geocode/json?address=' . urlencode($fulladdress) . '&sensor=true');
		$output = json_decode($geocode);
		$LLArr = array();
		$LLArr[] = $output->results[0]->geometry->location->lat; // latitude
		$LLArr[] = $output->results[0]->geometry->location->lng; // longitude
		return $LLArr;
	}

	/*************************** GENERAL FUNCTIONS ******************************/
	// REDIRECT TO SPECIFIED PAGE
	function mf_redirect($pgname)
	{
		echo "<script> window.location='" . $pgname . "'; </script>";
		exit;
	}

	// FUNCTION TO SET SPECIFIED MESSAGE IN SESSION
	function mf_setmessage($str, $pgname = "")
	{
		$_SESSION['custmsg'] = $str;
		if ($pgname != "") {
			$this->mf_redirect($pgname);
			exit;
		}
	}

	function mf_viewmessage() // FUNCTION TO DISPLAY USER MESSAGE FROM SESSION AND THEN CLEAR MESSAGE SESSION
	{
		echo ($_SESSION['custmsg'] != "") ? $_SESSION['custmsg'] : "";

		$_SESSION['custmsg'] = "";
	}

	// CHECK USER IS LOGGED IN OR NOT IF YES THEN REDIRECT TO ASSIGNED MODULE
	function mf_notadmin()
	{
		global $SERVICE_URL;
		global $SALES_URL;
		global $OPLUS_URL;
		if ($_SESSION['App_UserID'] > 0) {
			if ($_SESSION['Default_Module'] == 2) {
				$this->mf_redirect($SERVICE_URL . "dashboard.php");
			} else if ($_SESSION['Default_Module'] == 1) {
				$this->mf_redirect($SALES_URL . "dashboard.php");
			} else if ($_SESSION['Default_Module'] == 3) {
				$this->mf_redirect($OPLUS_URL . "dashboard.php");
			} else if ($_SESSION['Default_Module'] == '') {
				$this->mf_redirect($SALES_URL . "dashboard.php");
			}
		}
	}

	// CHECK USER IS LOGGED IN OR NOT
	function mf_isuser()
	{
		if (intval($_SESSION['HV_UserID']) == 0) {
			$this->mf_setmessage("<p class='msgred'>Sorry, please login to access your account.</p>", "login.php");
		}
	}

	function mf_iscontrator() // CHECK USER IS LOGGED IN OR NOT
	{
		if (intval($_SESSION['HV_ContractorID']) == 0) {
			$this->mf_setmessage("<p class='msgred'>Sorry, please login to access your account.</p>", "contractor-login.php");
		}
	}

	function mf_getfilenames() // RETURN CURRENT FILENAME
	{
		$pt = substr($_SERVER['REQUEST_URI'], 1);
		$pt3 = explode("/", $pt);
		$totpt = count((array)$pt3);
		$pt2 = $pt3[$totpt - 1];
		$ptArr = explode("?", $pt2);
		$filename = $ptArr[0];
		return $filename;
	}

	function mf_puretext($str) // RETURN PURE VALUE - REMOVING ALL SPECIAL CHARACTERS/SYMBOLS ETC...
	{
		$newstr = preg_replace("/[^A-Za-z0-9.]/", "", $str);
		return $newstr;
	}

	function date2savenew($date) // CONVERT DATE TO STORE FORMAT (MYSQL FORMAT)
	{
		if ($date == "") {
			return "";
		} else {
			$dtArr = explode("/", $date);
			$newDt = $dtArr[2] . "-" . $dtArr[1] . "-" . $dtArr[0];
			return $newDt;
		}
	}

	function date2saveinline($date) // CONVERT DATE TO STORE FORMAT (MYSQL FORMAT)
	{
		if ($date == "") {
			return "";
		} else {

			$dtArr = explode("-", $date);
			$newDt = $dtArr[0] . "-" . $dtArr[2] . "-" . $dtArr[1];
			return $newDt;
		}
	}

	function date2save($date) // CONVERT DATE TO STORE FORMAT (MYSQL FORMAT)
	{
		if ($date == "") {
			return "";
		} else {
			$dtArr = explode("/", $date);
			$newDt = $dtArr[2] . "-" . $dtArr[0] . "-" . $dtArr[1];
			return $newDt;
		}
	}

	function timetosave($time) // CONVERT TIME TO STORE FORMAT (MYSQL FORMAT)

	{
		if ($time != "") {
			return date("H:i:s", strtotime($time));
		}
		return '';
	}

	function datetime2save($date, $format = 'Y-m-d H:i:s') // CONVERT DATE & TIME TO STORE FORMAT (MYSQL FORMAT)
	{
		if ($date == "") {
			return "";
		} else {
			$dt = str_replace("/", "-", $date);
			$newDt = date($format, strtotime($dt));
			return $newDt;
		}
	}

	function timeDifference($startTime = '', $endTime = '') // COUNT TIME BETWEEN TO TIMES
	{
		// return $startDate.''.$endDate;
		$startTimeConverted = strtotime($startTime);
		$endTimeConverted = strtotime($endTime);

		$Diff = $endTimeConverted - $startTimeConverted;
		$substractedTime = max(intval($Diff), 0);
		$timeDifference = round((float)abs($substractedTime) / 3600) + 1;
		// echo $dateDifference;
		return $timeDifference;
	}

	function timeDifferenceMinutes($startTime = '', $endTime = '') // COUNT TIME BETWEEN TO TIMES

	{
		// return $startDate.''.$endDate;
		$date = date('Y-m-d');
		if (strtotime($endTime) < strtotime($startTime)) {
			$Ndate = date('Y-m-d', strtotime("+1 Day", strtotime($date)));
			$startTime = $date . " " . $startTime;
			$endTime = $Ndate . " " . $endTime;
		} else {
			$startTime = $date . " " . $startTime;
			$endTime = $date . " " . $endTime;
		}

		$startTimeConverted = strtotime($startTime);
		$endTimeConverted = strtotime($endTime);

		$Diff = $endTimeConverted - $startTimeConverted;
		$timeDifference = $Diff / 60;

		// echo $dateDifference;
		return $timeDifference;
	}

	function dateDifference($startDate = '', $endDate = '') // COUNT DAY BETWEEN TO DATES
	{
		//return $startDate.''.$endDate;
		$startDateConverted = strtotime($startDate);
		$endDateConverted = strtotime($endDate);
		$substractedDate = $endDateConverted - $startDateConverted;
		$substractedDate = max(intval($substractedDate), 0);
		$dateDifference = round((float)abs($substractedDate) / 86400) + 1;
		return $dateDifference;
	}

	public function dateDifferenceFormat($sDate, $eDate, $Format = '%a Days')
	{
		$datetime1 = date_create($sDate);
		$datetime2 = date_create($eDate);

		$interval = date_diff($datetime1, $datetime2);
		if ($sDate != '0000-00-00' && $eDate != '0000-00-00') {
			return $interval->format($Format);
		} else {
			return 0;
		}
	}

	function date2dispnew($date) // CONVERT DATE TO DISPLAY FORMAT (INDIAN FORMAT)
	{
		if ($date == "" || $date == "0000-00-00") {
			return "";
		} else {
			return date("d/m/Y", strtotime($date));
		}
	}
	function datetime2dispnew($date) // CONVERT DATE & TIME TO DISPLAY FORMAT (INDIAN FORMAT)
	{
		if ($date == "" || $date == "0000-00-00 00:00:00") {
			return "";
		} else {
			return date("d/m/Y H:i:s", strtotime($date));
		}
	}

	function date2disp($date) // CONVERT DATE TO DISPLAY FORMAT (INDIAN FORMAT)
	{
		if ($date == "" || $date == "0000-00-00") {
			return "";
		} else {
			return date("m/d/Y", strtotime($date));
		}
	}


	function convertDateTime($date, $format = 'd/m/Y H:i:s') // CONVERT DATE & TIME TO  FORMAT (INDIAN FORMAT)
	{
		if ($date == "" || $date == "0000-00-00 00:00:00" || $date == "0000-00-00") {
			return "";
		} else {
			return date($format, strtotime($date));
		}
	}

	function timetodisp($time) // CONVERT TIME TO STORE FORMAT (MYSQL FORMAT)

	{
		if ($time != "" && $time != '0000-00-00 00:00:00' && $time != '00:00:00') {
			return date("h:i A", strtotime($time));
		}
		return '';
	}


	function mf_viewimage($imgpath, $width = 100, $height = 100) // FUNCTION TO DISPLAY SPECIFIED IMAGE WITH SPECIFIED WIDTH X HEIGHT
	{
		if (is_file($imgpath)) {
			echo "<img src='$imgpath' width='$width' height='$height' border='0' />";
		}
	}

	function mf_unlink($imgpath) // REMOVE SPECIFIED IMAGE FROM FOLDER
	{
		if (is_file($imgpath)) {
			unlink($imgpath);
		}
	}

	function mf_filerename($path, $oldname, $newname) // FUNCTION TO GET THE EXTENTION OF THE FILE
	{
		$pathinfo = pathinfo($path . $oldname);
		$ext = $pathinfo['extension'];
		rename($path . $oldname, $path . $newname . '.' . $ext);
		return $newname . '.' . $ext;
	}

	function mf_getcommavalues($fieldname) // FUNCTION FOR FETCH COMMA SEPRATED VALUES FROM FIELD..
	{
		$returnval = "";
		if (is_array($fieldname)) {
			foreach ($fieldname as $k => $v) {
				if ($returnval == "") {
					$returnval .= $v;
				} else {
					$returnval .= "," . $v;
				}
			}
		}

		return $returnval;
	}

	function mf_createfck($fck_name, $fck_value, $width = 300, $height = 600) // FUNCTION FOR FETCH COMMA SEPRATED VALUES FROM FIELD..
	{
		/*include_once("fckeditor/fckeditor.php") ;
		$oFCKeditor = new FCKeditor($fck_name) ;
		$oFCKeditor->BasePath = 'fckeditor/' ;
		$oFCKeditor->Height = $width ;
		$oFCKeditor->Width = $height ;
		$oFCKeditor->Value = stripslashes($fck_value) ;
		$oFCKeditor->Create() ;*/
		global $ADMIN_URL;
		echo '<textarea id="' . $fck_name . '" name="' . $fck_name . '" style="width:' . $width . 'px; height:' . $height . 'px;">' . $fck_value . '</textarea>
				<script type="text/javascript">
						CKEDITOR.replace( "' . $fck_name . '",
						{
							filebrowserBrowseUrl :"' . $ADMIN_URL . 'ckeditor/filemanager/browser/default/browser.html?Connector=' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/connector.php",
							filebrowserImageBrowseUrl : "' . $ADMIN_URL . 'ckeditor/filemanager/browser/default/browser.html?Type=Image&Connector=' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/connector.php",
							filebrowserFlashBrowseUrl :"' . $ADMIN_URL . 'ckeditor/filemanager/browser/default/browser.html?Type=Flash&Connector=' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/connector.php",
							filebrowserUploadUrl  :"' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/upload.php?Type=File",
							filebrowserImageUploadUrl : "' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/upload.php?Type=Image",
							filebrowserFlashUploadUrl : "' . $ADMIN_URL . 'ckeditor/filemanager/connectors/php/upload.php?Type=Flash"
						});
				</script>';
	}

	function add_security($val) // RETURN VALUE WITH SECURITY
	{
		return mysqli_real_escape_string($GLOBALS['myCon'], $val);
	}

	// CHECK USER AUTHENTICATION
	function mf_check_engineer_login($table, $vUserNameWhere, $pass)
	{
		$qry = "SELECT eng.id,first_name,last_name,employee_code,email,eng.status,branch_id,eng.vProfilePic,vGrade,iDepartmentId,isPasswordChange,dv.status as vDesignation,eng.vPunchType
			FROM " . $this->add_security($table) . " as eng
				LEFT JOIN dropdown_value as dv ON dv.id = eng.vDesignation
				LEFT JOIN hr_punch_type as hpt ON FIND_IN_SET(hpt.iPunchTypeId,eng.vPunchType)
			WHERE " . $vUserNameWhere . " AND vFinPWdUsr='" . sha1($this->add_security($pass)) . "' AND isPasswordChange=1 AND del_status = 0 ";

		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			$vPunchType = $row['vPunchType'];
			// echo $vPunchType;
			// exit();
			$iTifId = $this->mf_getValue_Qry("op_tif","COUNT(iTifId)","
                                    WHERE
                                        eStatus = 'y' AND eHodStatus = 'Approved'
                                        AND '".$this->curDate()."' BETWEEN dDepartureDate AND dToArrivalDate AND iUserId ='".$row['id']."'
								");
			$row['Punch_Permissions'] = (in_array(1, explode(',', $vPunchType)) || in_array(5, explode(',', $vPunchType)) || $iTifId > 0) ? true : false;
			return $row;
		} else {
			return 0;
		}
	}

	function mf_check_duplicate($table, $field, $value, $conditions = "") // CHECK DUPLAICATE RECORD AT NEW ENTRY	// USE : MF_CHECK_DUPLICATE("USER","EMAIL",$EMAIL,ARRAY("FIELD"=>$VALUE) );
	{
		$extQry = "";
		if (is_array($conditions)) {
			foreach ($conditions as $id_field => $id_value) {
				$extQry .= " and `" . $id_field . "`='" . $this->add_security($id_value) . "'";
			}
		}

		$query = "select `" . $field . "` from `" . $table . "` where `" . $field . "` <> '" . $this->add_security($value) . "' $extQry ";
		$r = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) return true;
		else return false;
	}

	function mf_check_duplicate_pro_cat($table, $field, $value, $conditions = "") // CHECK DUPLAICATE RECORD AT NEW ENTRY	// USE : MF_CHECK_DUPLICATE("USER","EMAIL",$EMAIL,ARRAY("FIELD"=>$VALUE) );
	{
		$extQry = "";
		if (is_array($conditions)) {
			foreach ($conditions as $id_field => $id_value) {
				$extQry .= " and `" . $id_field . "`!='" . $this->add_security($id_value) . "'";
			}
		}

		$query = "select `" . $field . "` from `" . $table . "` where `" . $field . "` = '" . $this->add_security($value) . "' $extQry ";
		$r = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) return true;
		else return false;
	}

	function mf_paging($query, $recperpg = 20) // RETURN RESULTSET AND PAGINATION	// USER   LIST($RESULT,$PAGING)=MF_PAGING("SELECT * FROM USER",25);
	{
		$page = intval($_POST['page']);
		$filename = $this->mf_getfilenames();
		$qstrArr = explode("&", $_SERVER['QUERY_STRING']);
		$qstr = "";
		if (is_array($qstrArr) && count((array)$qstrArr) > 1) {
			foreach ($qstrArr as $k => $v) {
				$attArr = explode("=", $v);
				if ($attArr[0] != "page" && $attArr[1] != "") {
					$qstr .= "&" . $attArr[0] . "=" . $attArr[1];
				}
			}
		}

		$totRes = $this->mf_query($query);
		$totRecords = $this->mf_affected_rows();
		$totPages = ceil($totRecords / $recperpg);
		$pgpergroup = 10;
		$pgGroup = intval($page / $pgpergroup);
		$returnVal = array();
		$pgtext = "";
		$pgStart = $pgpergroup * $pgGroup;
		$pgEnds = ($pgpergroup * ($pgGroup + 1));
		if ($pgEnds > $totPages) {
			$pgEnds = $totPages;
		}

		if ($totPages > 1) {
			$pgtext = "<table border='0' cellspacing='0' cellpadding='3'><tr>";
			if ($page > 0) {
				$pgtext .= "<td><a href='" . $filename . "?page=0" . $qstr . "' class='pglink' style='font-family:verdana;'>&laquo;</a></td>";
				$pgtext .= "<td><a href='" . $filename . "?page=" . ($page - 1) . $qstr . "' class='pglink' style='font-family:verdana;'>&lsaquo;</a></td>";
			} else {
				$pgtext .= "<td><a href='#' class='pglink' style='font-family:verdana;' onclick='return false;'>&laquo;</a></td>";
				$pgtext .= "<td><a href='#' class='pglink' style='font-family:verdana;' onclick='return false;'>&lsaquo;</a></td>";
			}

			for ($aa = $pgStart; $aa < $pgEnds; $aa++) {
				if ($page == $aa) {
					$pgtext .= "<td class='pglink_act'>" . ($aa + 1) . "</td>";
				} else {
					$pglink = $filename . "?page=" . $aa . $qstr;
					$pgtext .= "<td><a href='" . $pglink . "' class='pglink'>" . ($aa + 1) . "</a></td>";
				}
			}

			if ($page < ($totPages - 1)) {
				$pgtext .= "<td><a href='" . $filename . "?page=" . ($page + 1) . $qstr . "' class='pglink' style='font-family:verdana;'>&rsaquo;</a></td>";
				$pgtext .= "<td><a href='" . $filename . "?page=" . ($totPages - 1) . $qstr . "' class='pglink' style='font-family:verdana;'>&raquo;</a></td>";
			} else {
				$pgtext .= "<td><a href='#' class='pglink' style='font-family:verdana;' onclick='return false;'>&rsaquo;</a></td>";
				$pgtext .= "<td><a href='#' class='pglink' style='font-family:verdana;' onclick='return false;'>&raquo;</a></td>";
			}

			$pgtext .= "</tr></table>";
		}

		$start = $page * $recperpg;
		$newquery = $query . " LIMIT $start, $recperpg";
		$result = $this->mf_query($newquery);
		$returnVal[0] = $result;
		$returnVal[1] = $pgtext;
		return $returnVal;
	}
	function mf_createcombo_multi_array($qeury1, $opt_value, $disp_value, $selected = "", $firstval = "-Select-", $Isfirst = true)		// RETURN COMBOBOX OPTIONS LIST USING ARRAY
	{
		if ($Isfirst) {
			$cmbtext = "<option value=''>" . $firstval . "</option>";
		}
		$selected = explode(",", $selected);
		$result = $this->mf_query($qeury1);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				foreach ($selected as $key => $value) {
					if (stripslashes($row[$opt_value]) == stripslashes($value)) {
						$sel = "selected='selected'";
					}
				}
				$cmbtext .= '<option value=' . $row[$opt_value] . ' ' . $sel . '>' . stripslashes($row[$disp_value]) . '</option>';
			}
		}
		return $cmbtext;
	}

	function mf_createcombo_tools($query, $opt_value, $disp_value, $selected = "", $firstval = "-Select-") // RETURN COMBOBOX OPTIONS LIST
	{
		$decode_string = base64_decode($selected);
		$cmbtext = "<option value='' disabled='disabled'>$firstval</option>";
		$result = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				if (in_array($row[$opt_value], explode(',', $decode_string))) {
					$sel = "selected='selected'";
				}

				$cmbtext .= "<option value='" . $row[$opt_value] . "' $sel>" . stripslashes($row[$disp_value]) . "</option>";
			}
		}

		return $cmbtext;
	}

	function mf_createcombo_branch($query, $opt_value, $disp_value, $selected = "", $firstval = "-Select-") // RETURN COMBOBOX OPTIONS LIST
	{
		$cmbtext = "<option value=''>$firstval</option>";
		$result = $this->mf_query($query);
		if ($this->mf_affected_rows() > 0) {
			while ($row = $this->mf_fetch_array($result)) {
				$sel = "";
				if (stripslashes($row[$opt_value]) == stripslashes($selected)) {
					$sel = "selected='selected'";
				}

				$cmbtext .= "<option value='" . $row[$opt_value] . "' $sel>" . stripslashes($row[$disp_value]) . "</option>";
			}
		}

		return $cmbtext;
	}
 
	function human_value($srt)
	{
		if ($srt != "") {
			return mb_convert_encoding($srt, "UTF-8", "Windows-1252");
		} else {
			return "N/A";
		}
	}

	function humanNumber($srt)
	{
		if ($srt > 0) {
			return $srt;
		}
	}

	 

	function isDelete()
	{
		if ($_SESSION['Role_ID'] == 1) {
			return 1;
		}
	}
	function permission($user_id, $module_id)
	{
		if ($_SESSION['Role_ID'] == 1) {
			return 3;
		} else if ($_SESSION['Role_ID'] == 6) {
			if (in_array($module_id, array(17, 19, 20, 22, 26, 27, 29, 34))) {
				return 3;
			}
		} else {
			$SerPeRArR = $_SESSION['SerPeRArR'];
			return intval($SerPeRArR[$module_id]);
		}
	}

	

	function permissionUser($iUserId, $iSubModuleId, $iPermissionId, $vMainModule = '', $permArr = array())
	{
		if(empty($permArr)){
			$queryPer = $this->mf_query("
				SELECT
					iUserId,iSubModuleId,vPermission
				FROM
					module_permissions
				WHERE
					iUserId = ".$iUserId."
			");
			
			$permArr = array();
			if($this->mf_affected_rows()>0){
				$newArr = array();
				while($rowPer = $this->mf_fetch_array($queryPer)){
					$newArr[$rowPer['iSubModuleId']] = $rowPer['vPermission'];
				}
				$permArr = $newArr;
			}
		}

		if (in_array(1,(array) $_SESSION['Role_ID_' . $vMainModule])) {
			return 1;
		} else {
			if (in_array($iPermissionId, explode(',', $permArr[$iSubModuleId]))) {
				return 1;
			} else {
				return 0;
			}
		}
	}


	function permissionSales($user_id, $module_id)
	{
		if ($_SESSION['Role_ID'] == 1) {
			return 3;
		} else if ($_SESSION['Role_ID'] == 7) {
			if (in_array($module_id, array(18, 19, 20, 22, 26, 27, 29, 34, 38, 37, 41, 55, 59))) {
				return 3;
			} else if ($_SESSION['Role_ID'] == 18 && in_array($module_id, array(18, 19, 20, 22, 26, 27, 29, 34, 38, 37, 41, 55, 59))) {
				return 3;
			}
		} else if ($_SESSION['Role_ID'] == 24) {
			if (in_array($module_id, array(59))) {
				return 3;
			}
		} else {
			$sPeRArRv = $_SESSION['sPeRArR'];
			return intval($sPeRArRv[$module_id]);
		}
	}

	/*function permissionOplus($module_id)
		{
			$OpPeRArR=$_SESSION['OpPeRArR'];
			return intval($OpPeRArR[$module_id]);
		}*/

	function check_in_range($start_date, $end_date) //2009-08-28
	{
		// Convert to timestamp

		$now = new DateTime();
		$startdate = new DateTime(str_replace('/', '-', $start_date));
		$enddate = new DateTime(str_replace('/', '-', $end_date));

		// Check that user date is between start & end
		return ($startdate <= $now && $now <= $enddate);
	}

	function amountCurrency($expr, $curIcon, $decplaces = 2)
	{

		return '<i class="fa fa-rupee"></i> ' . number_format((float) $expr, $decplaces);
	}

	function formatamount($expr, $decplaces = 2)
	{
		return number_format((float) $expr, $decplaces);
	}

	function formatAmt($expr, $currency)
	{
		return number_format((float) $expr, 2) . ' ' . $currency;
	}

	function formatPer($expr)
	{
		return $expr . '%';
	}

	function mf_total_nums_row_qry($qry) // RETURN TOTAL COUNT OF RECORDS
	{
		$result = $this->mf_query($qry);
		if ($this->mf_affected_rows() > 0) {
			$row = $this->mf_fetch_array($result);
			return $num_results = $row['total'];
		} else {
			return "";
		}
	}

	function getRealIpAddr()
	{
		if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
		{
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	// Get Date Range Based on Week Number and Year
	function getStartAndEndDate($week, $year)
	{
		$dto = new DateTime();
		$dto->setISODate($year, $week);
		$ret['week_start']	= $dto->format('Y-m-d');
		$dto->modify('+6 days');
		$ret['week_end']	= $dto->format('Y-m-d');
		return $ret;
	}

	function calDiffDays($startdate, $enddate)
	{

		$now = strtotime($startdate);
		$then = strtotime($enddate);
		$difference = $now - $then;
		$days = floor($difference / (60 * 60 * 24));

		return $days;
	}

	function calDiffHours($startdate, $enddate)
	{
		return round((float)(strtotime(str_replace('/', '-', $enddate)) - strtotime(str_replace('/', '-', $startdate))) / 3600, 1);
	}
	function get_enum_values($table, $field)
	{
		$typeq = $this->mf_query("SHOW COLUMNS FROM {$table} WHERE Field = '{$field}'");
		$row = $this->mf_fetch_array($typeq);
		$type = $row['Type'];
		preg_match("/^enum\(\'(.*)\'\)$/", $type, $matches);
		$enum = explode("','", $matches[1]);
		return $enum;
	}
	function sendSalesNotification($nSubject, $iModuleId)
	{ //sales notification
		$msgArr = array();
		$msgArr['vNotification'] = $nSubject;
		$msgArr['iModuleId'] = $iModuleId;
		$msgArr['eModuleType'] = 'SO';
		$msgArr['dCreatedDate'] = $this->curTimedate();
		$this->mf_dbinsert("sales_notifications", $msgArr);
	}

	function sendQuotNotification($nSubject, $iModuleId, $eModuleType)
	{ //Quotation notification
		$msgArr = array();
		$msgArr['vNotification'] = $nSubject;
		$msgArr['iModuleId'] = $iModuleId;
		$msgArr['eModuleType'] = $eModuleType;
		$msgArr['dCreatedDate'] = $this->curTimedate();
		$this->mf_dbinsert("sales_notifications", $msgArr);
	}

	function sendServiceNotification($nSubject, $iComplainId, $ModuleType, $name = "")
	{ //service notification
		$newArr = array();
		$newArr['vNotificationMessage'] = $nSubject . ' ' . $name;
		if ($ModuleType == 'Material') {
			$newArr['iMaterialId'] = $iComplainId;
		} else {
			$newArr['ModuleType'] = 'Complain';
			$newArr['iComplainId'] = $iComplainId;
		}

		$newArr['ModuleType'] = $ModuleType;
		$newArr['tReadBy'] = '';
		$newArr['dCreatedDate'] = $this->curTimedate();
		$this->mf_dbinsert('notifications', $newArr);
	}

	function sendTesNotification($nSubject, $eTourType, $vModule, $iTifId)
	{
		$newArr = array();
		$newArr['vNotificationMessage'] = $nSubject;
		$newArr['eTourType'] = $eTourType;
		$newArr['eModuleType'] = $vModule;
		$newArr['iTifId'] = $iTifId;
		$newArr['dCreatedDate'] = $this->curTimedate();

		$iEngineerId = 0;
		if ($eTourType == 'Tour') {
			$iEngineerId = $this->mf_getValue('op_tif_tour', 'iUserId', 'iTifId', $iTifId);
		} else {
			$iEngineerId = $this->mf_getValue('op_tif', 'iUserId', 'iTifId', $iTifId);
		}
		$newArr['iEngineerId'] = $iEngineerId;

		$this->mf_dbinsert('op_notifications', $newArr);
	}

	function sendHRNotification($nSubject, $iModuleId, $eModuleType, $iCreatedBy = 0,$tSendEngineerId="")
	{ //HR notification
		$msgArr = array();
		$msgArr['vNotification'] = $nSubject;
		$msgArr['iModuleId'] = $iModuleId;
		$msgArr['eModuleType'] = $eModuleType;
		$msgArr['eType'] = 'Web';
		$msgArr['tSendEngineerId'] = $tSendEngineerId;
		$msgArr['iCreatedBy'] = $iCreatedBy;
		$msgArr['dCreatedDate'] = $this->curTimedate();
		$this->mf_dbinsert("hr_notifications", $msgArr);
	}

	function time_ago($ptime)
	{
		$time = strtotime($ptime);
		$periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
		$lengths = array("60", "60", "24", "7", "4.35", "12", "10");

		//$now = time();
		$now = strtotime(date('Y-m-d H:i:s'));
		$difference = $now - $time;
		$tense = "ago";

		for ($j = 0; $difference >= $lengths[$j] && $j < count((array)$lengths) - 1; $j++) {
			$difference /= $lengths[$j];
		}
		$difference = round((float)$difference);
		if ($difference != 1) {
			$periods[$j] .= "s";
		}
		$timeAgoText = (($difference < 0) ? "Just Now" : $difference . " " . $periods[$j] . " " . "ago");
		return $timeAgoText;
	}

	function download($path = "")
	{
		if ($path != "" && file_exists($path)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . $path . '"');
			header('Content-Transfer-Encoding: binary');
			header('Connection: Keep-Alive');
			header('Expires: 0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');
			header('Content-Length: ' . filesize($path));
			@readfile($path);
			exit();
		} else {
			$this->mf_setmessage("<p class='msgred alert alert-error'>File not found.</p>", "dashboard.php");
		}
	}

	function readFile($path = "")
	{
		if ($path != "" && file_exists($path)) {
			$extArr = explode('.', $path);
			$nameArr = explode('/', $path);
			$extension = end($extArr);
			$filename = end($nameArr);

			$contentType = '';
			if ($extension == 'pdf') {
				$contentType = 'application/pdf';
			} else if ($extension == 'png') {
				$contentType = 'image/png';
			} else if ($extension == 'jpeg') {
				$contentType = 'image/jpeg';
			} else if ($extension == 'docx' || $extension == 'doc') {
				$contentType = 'application/msword';
			} else if ($extension == 'jpg' || $extension == 'JPG') {
				$contentType = 'image/jpg';
			} else if ($extension == 'dwg') {
				$contentType = 'application/dwg';
			} else if ($extension == 'dxf') {
				$contentType = 'application/dxf';
			} else if ($extension == 'xlsx') {
				$contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
			} else if ($extension == 'igs' || $extension == 'iges') {
				$contentType = 'application/igs';
			}

			if ($contentType != '') {
				if (!in_array($extension, array('png', 'jpeg', 'jpg', 'docx', 'doc'))) {
					header('Content-type: ' . $contentType);
					header('Content-Disposition: inline; filename="' . $filename . '"');
					header('Content-Transfer-Encoding: binary');
					header('Accept-Ranges: bytes');
					@readfile($path);
				} else if (in_array($extension, array('docx', 'doc'))) {

					if ($_SESSION['ModuleType'] == 'Service') {
						$path = 'https://finix.jyoti.co.in/service/' . $path;
					} else {
						$path = 'https://finix.jyoti.co.in/sales/' . $path;
					}
?>
					<iframe src='https://docs.google.com/viewer?url=<?= $path ?>&embedded=true' width="100%" height="1200" frameborder='0'></iframe>
				<?php
				} else {

				?>
					<div class="image-main">
						<div class="top-btn">
							<button type="button" class="btn w3-btn w3-green" value="90" onClick="rotateImage(this.value);"><svg class="feather feather-rotate-cw sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
									<polyline points="23 4 23 10 17 10"></polyline>
									<path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
								</svg> 90</button>
							<button type="button" class="btn last w3-btn w3-green" value="-90" onClick="rotateImage(this.value);"><svg class="feather feather-rotate-ccw sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
									<polyline points="1 4 1 10 7 10"></polyline>
									<path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
								</svg> -90</button>
						</div>
						<div class="image-box-main">
							<div class="image-box" style="text-align:center"><img class="image-" src="<?= $path ?>" id="rotate-image"></div>
						</div>
					</div>
					<style>
						body {
							padding: 0;
							margin: 0;
							background: #ecf0f5;
						}

						.image-main {
							width: 100%;
							height: 100%;
							position: relative;
						}

						.top-btn {
							position: fixed;
							right: 20px;
							top: 20px;
							z-index: 999;
						}

						.top-btn .btn {
							background: #fff;
							box-shadow: 0 1px 3px 1px rgba(0, 0, 0, 0.1);
							border: none;
							border-radius: 10px;
							font-weight: 400;
							font-family: 'Roboto', sans-serif;
							line-height: 40px;
							color: #858585;
							font-size: 14px;
							padding: 0 18px 0 50px;
							margin: 0 15px 15px 0;
							-moz-transition: all .3s linear;
							-webkit-transition: all .3s linear;
							cursor: pointer;
							position: relative;
						}

						.top-btn .btn svg {
							position: absolute;
							left: 18px;
							top: 0;
							bottom: 0;
							margin: auto 0;
							width: 18px;
							height: 18px;
						}

						.top-btn .btn.last {
							margin-right: 0;
						}

						.top-btn .btn:hover {
							background: #00c0ef;
							color: #fff;
						}

						.image-box-main {
							width: 100%;
							text-align: center;
							display: table;
						}

						.image-box {
							display: table-cell;
							vertical-align: middle;
							max-width: 100%;
							height: 100%;
						}

						.image-box img {
							max-width: 100%;
							width: auto;
						}
					</style>
					<script src="plugins/jQuery/jQuery-2.2.0.min.js"></script>
					<script>
						$(document).ready(function() {
							function setHeight() {
								windowHeight = $(window).innerHeight();
								$('.image-box').css('height', windowHeight);
								$('.image').css('height', windowHeight);
							};
							setHeight();

							$(window).resize(function() {
								setHeight();
							});
						});
					</script>
					<script>
						var degreeNew = 0;

						function rotateImage(degree) {
							degreeNew += parseInt(degree);
							$('#rotate-image').css({
								'-webkit-transform': 'rotate(' + degreeNew + 'deg)',
								'-moz-transform': 'rotate(' + degreeNew + 'deg)',
								'transform': 'rotate(' + degreeNew + 'deg)'
							});
						}
					</script>
<?php
				}
			}
		} else {
			$this->mf_setmessage("<p class='msgred alert alert-error'>File not found.</p>", "dashboard.php");
		}
	}

	function readFileDoc($path = "")
	{
		if ($path != "" && file_exists($path)) {
			$filename = 'test.doc';
			header('Content-type: application/msword');
			header('Content-Disposition: inline; filename="' . $filename . '"');
			header('Content-Transfer-Encoding: binary');
			header('Accept-Ranges: bytes');
			@readfile($path);
		} else {
			$this->mf_setmessage("<p class='msgred alert alert-error'>File not found.</p>", "dashboard.php");
		}
	}
	//Function for indian style currency
	function moneyFormatIndia($no, $icon = true)
	{
		$num = round((float)$no);
		$num = str_replace('-', '', $num);
		$explrestunits = "";
		if (strlen($num) > 3) {
			$lastthree = substr($num, strlen($num) - 3, strlen($num));
			$restunits = substr($num, 0, strlen($num) - 3); // extracts the last three digits
			$restunits = (strlen($restunits) % 2 == 1) ? "0" . $restunits : $restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
			$expunit = str_split($restunits, 2);
			for ($i = 0; $i < sizeof((array)$expunit); $i++) {
				// creates each of the 2's group and adds a comma to the end
				if ($i == 0) {
					$explrestunits .= (int)$expunit[$i] . ","; // if is first value , convert into integer
				} else {
					$explrestunits .= $expunit[$i] . ",";
				}
			}
			$thecash = $explrestunits . $lastthree;
		} else {
			$thecash = $num;
		}

		if ($no < 0) {
			$thecash = '-' . $thecash;
		}

		if ($icon) {
			return '<i class="fa fa-rupee"></i> ' . $thecash; // writes the final format where $currency is the currency symbol.
		} else {
			return $thecash; // writes the final format where $currency is the currency symbol.
		}
	}

	function getCurrentFinancialYear($formate = '')
	{
		if (date('m') > 3) {
			$year = date('y') . "-" . (date('y') + 1);
		} else {
			if ($formate != '') {
				$year = (date('Y') - 1) . "-" . date('y');
			} else {
				$year = (date('y') - 1) . "-" . date('y');
			}
		}
		return $year;
	}
	function getCurrentFinancialYearByDate($date, $formate = '')
	{
		$sdate = strtotime($date);
		if (date('m', $sdate) > 3) {
			if ($formate != '') {
				$year = date($formate, $sdate) . "-" . (date($formate, $sdate) + 1);
			} else {
				$year = date('y', $sdate) . "-" . (date('y', $sdate) + 1);
			}
		} else {
			if ($formate != '') {
				$year = (date($formate, $sdate) - 1) . "-" . date($formate, $sdate);
			} else {
				$year = (date('y', $sdate) - 1) . "-" . date('y', $sdate);
			}
		}
		return $year;
	}
	function GetFormatedTifNumber($date, $userId, $refNo)
	{
		return $tifNo = $this->getCurrentFinancialYearByDate($date, "y") . '/' . str_pad($userId, 4, '0', STR_PAD_LEFT) . '/' . str_pad($refNo, 3, '0', STR_PAD_LEFT);
	}

	function getQUARTER($month = '')
	{
		if ($month != '') {
			if ($month >= 4 && $month <= 6) return 1;
			if ($month >= 7 && $month <= 9) return 2;
			if ($month >= 10 && $month <= 12) return 3;
			return 4;
		} else {
			return '';
		}
	}

	function compress_image_size($source, $destination, $quality)
	{
		$info = getimagesize($source);
		if ($info['mime'] == 'image/jpeg')
			$image = imagecreatefromjpeg($source);

		elseif ($info['mime'] == 'image/gif')
			$image = imagecreatefromgif($source);

		elseif ($info['mime'] == 'image/png')
			$image = imagecreatefrompng($source);

		imagejpeg($image, $destination, $quality);
		return $destination;
	}

	function secondstoHours($inputSeconds = 0, $separated = 0)
	{
		$secondsInAMinute = 60;
		$secondsInAnHour  = 60 * $secondsInAMinute;


		$hourSeconds = $inputSeconds;
		$hours = floor($hourSeconds / $secondsInAnHour);


		$minuteSeconds = $hourSeconds % $secondsInAnHour;
		$minutes = floor($minuteSeconds / $secondsInAMinute);


		/*$remainingSeconds = $minuteSeconds % $secondsInAMinute;
		   	$seconds = ceil($remainingSeconds);*/

		$returnString = '';
		if ($separated > 0) {
			if ($hours > 0) {
				$returnString = $hours . ' Hrs. ';
			}
			$returnString .= $minutes . ' Min.';
			return $returnString;
		}
		return $hours . ':' . $minutes;
	}
	function GetDrivingDistance($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo)
	{
		if ($latitudeFrom != '' && $longitudeFrom != '' && $latitudeTo != '' && $longitudeTo != '') {
			$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=" . $latitudeFrom . "," . $longitudeFrom . "&destinations=" . $latitudeTo . "," . $longitudeTo . "&mode=driving&language=pl-PL&key=AIzaSyARxi1Kt101mcPwL9kUEh6rezrjZwnlA1c";

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$response = curl_exec($ch);
			curl_close($ch);
			$response_a = json_decode($response, true);
			$dist = round((float)($response_a['rows'][0]['elements'][0]['distance']['value'] / 1000), 2);
			$time = $response_a['rows'][0]['elements'][0]['duration']['value'];
			return  array('distance' => $dist, "addresses" => $response_a['destination_addresses'][0], "iTime" => $time);
		} else {
			return array('distance' => 0);
		}
	}

	function mf_LoginCheck()
	{
		$vAuthtoken = $_POST['vAuthtoken'];

		$CheckToken = $this->mf_query("SELECT vUserName,iUserId,vAuthtoken FROM users WHERE vAuthtoken = '" . $vAuthtoken . "' AND eStatus='y'");
		// echo $this->last_query();
		if ($this->mf_affected_rows() > 0) {
			$row=$this->mf_fetch_array($CheckToken);
			return $row;
		} else {
			$res = array('status' => 411, "message" => "Please login to continue!");
			echo json_encode($res);
			exit();
		}
	}

	function ResizeUploadImage($ifile, $fileNewName, $folderPath)
	{
		if (is_array($_FILES)) {
			$uploadedFile = $_FILES[$ifile]['tmp_name'];
			$sourceProperties = getimagesize($uploadedFile);
			$ext = pathinfo($_FILES[$ifile]['name'], PATHINFO_EXTENSION);
			$imageType = $sourceProperties[2];

			switch ($imageType) {
				case IMAGETYPE_PNG:
					$imageSrc = imagecreatefrompng($uploadedFile);
					$tmp = imageResize($imageSrc, $sourceProperties[0], $sourceProperties[1]);
					imagepng($tmp, $folderPath . $fileNewName . "_thump." . $ext);
					break;

				case IMAGETYPE_JPEG:
					$imageSrc = imagecreatefromjpeg($uploadedFile);
					$tmp = imageResize($imageSrc, $sourceProperties[0], $sourceProperties[1]);
					imagejpeg($tmp, $folderPath . $fileNewName . "_thump." . $ext);
					break;

				case IMAGETYPE_GIF:
					$imageSrc = imagecreatefromgif($uploadedFile);
					$tmp = imageResize($imageSrc, $sourceProperties[0], $sourceProperties[1]);
					imagegif($tmp, $folderPath . $fileNewName . "_thump." . $ext);
					break;

				default:
					//echo "Invalid Image type.";
					//exit;
					break;
			}
			move_uploaded_file($uploadedFile, $folderPath . $fileNewName . "." . $ext);
			echo "Image Resize Successfully.";
		}
	}

	function ResizeUploadImage1($ifile, $fileNewName, $folderPath)
	{
		if (is_array($_FILES)) {
			$file = $_FILES[$ifile]['tmp_name'];
			$sourceProperties = getimagesize($file);
			$ext = pathinfo($_FILES[$ifile]['name'], PATHINFO_EXTENSION);
			$imageType = $sourceProperties[2];

			$uploadedFile = $_FILES['image']['tmp_name'];
			$sourceProperties = getimagesize($uploadedFile);
			$newFileName = time();
			$dirPath = "uploads/";
			$ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
			$imageType = $sourceProperties[2];


			switch ($imageType) {


				case IMAGETYPE_PNG:
					$imageResourceId = imagecreatefrompng($file);
					$targetLayer = $this->imageResize($imageResourceId, $sourceProperties[0], $sourceProperties[1]);
					imagepng($targetLayer, $folderPath . $fileNewName . "_thump." . $ext);
					break;


				case IMAGETYPE_GIF:
					$imageResourceId = imagecreatefromgif($file);
					$targetLayer = $this->imageResize($imageResourceId, $sourceProperties[0], $sourceProperties[1]);
					imagegif($targetLayer, $folderPath . $fileNewName . "_thump." . $ext);
					break;


				case IMAGETYPE_JPEG:
					$imageResourceId = imagecreatefromjpeg($file);
					$targetLayer = $this->imageResize($imageResourceId, $sourceProperties[0], $sourceProperties[1]);
					imagejpeg($targetLayer, $folderPath . $fileNewName . "_thump." . $ext);
					break;


				default:
					//echo "Invalid Image type.";
					//exit;
					break;
			}


			//move_uploaded_file($file, $folderPath. $fileNewName. ".". $ext);
			//echo "Image Resize Successfully.";
			return $this->uploadFile($file, $fileNewName, $folderPath);
		}
	}

	function imageResize($imageSrc, $imageWidth, $imageHeight)
	{
		$newImageWidth = $imageWidth;
		$newImageHeight = $imageHeight;
		$newImageLayer = imagecreatetruecolor($newImageWidth, $newImageHeight);
		imagecopyresampled($newImageLayer, $imageSrc, 0, 0, 0, 0, $newImageWidth, $newImageHeight, $imageWidth, $imageHeight);
		return $newImageLayer;
	}

	function AddNewCompetitorAndModel($compName, $ModelName)
	{
		$retComptId = "";
		$retModelId = "";
		if ($compName != "") {
			$insCArr = array();
			$insCArr['vCompetitorName'] = $compName;
			$insCArr['eStatus'] = 'y';
			$res = $this->mf_dbinsert("sales_competitorlist", $insCArr);
			if ($res && $ModelName != "") {
				$retComptId = $this->mf_dbinsert_id();
				$insMArr = array();
				$insMArr['model_name'] = $ModelName;
				$insMArr['iCompId'] = $retComptId;
				$insMArr['vType'] = 'Machine';
				$this->mf_dbinsert("sales_competitor_model", $insMArr);
				$retModelId = $this->mf_dbinsert_id();
			}
		}
		return array("retComptId" => $retComptId, "retModelId" => $retModelId);
	}

	function AddNewCompetitorModel($comptId, $ModelName)
	{
		$retModelId = "";
		if ($comptId > 0 && $ModelName != "") {
			$insMArr = array();
			$insMArr['model_name'] = $ModelName;
			$insMArr['iCompId'] = $comptId;
			$insMArr['vType'] = 'Machine';
			$this->mf_dbinsert("sales_competitor_model", $insMArr);
			$retModelId = $this->mf_dbinsert_id();
		}
		return $retModelId;
	}

	
	public function timediffInMinutes($startDate = '', $endDate = '') // COUNT DAY BETWEEN TO DATES

	{
		//Convert them to timestamps.
		$startTimeConverted = strtotime($startDate);
		$endTimeConverted = strtotime($endDate);
		$substractedTime = abs($endTimeConverted - $startTimeConverted);
		return round((float)$substractedTime / 60, 2);
	}

	// Function to get all the dates in given range
	public function getDatesFromRange($start, $end, $format = 'Y-m-d')
	{
		$array = array();
		$interval = new DateInterval('P1D');

		$realEnd = new DateTime($end);
		$realEnd->add($interval);

		$period = new DatePeriod(new DateTime($start), $interval, $realEnd);

		foreach ($period as $date) {
			$array[] = $date->format($format);
		}

		return $array;
	}

	// public function sendSMTPMail($toEmail, $vSubject, $vEmailBody, $ccEmail = '', $attachFile = '')
	// {
	// 	//$toEmail comma separated
	// 	//$ccEmail comma separated
	// 	global $mode;
	// 	include_once "../../PHPMailer-master/PHPMailerAutoload.php";
	// 	$mail = new PHPMailer;
	// 	$mail->isSMTP();
	// 	$mail->Host = "ssl://smtp.gmail.com";
	// 	$mail->Port = 465;
	// 	$mail->SMTPAuth = true;
	// 	$mail->Username = "system@finix.jyoti.co.in"; //SMTPUSERNAME;
	// 	$mail->Password = "wvmzxecfbipfesqy"; //SMTPPASSWORD;
	// 	$mail->setFrom('system@finix.jyoti.co.in', 'Jyoti CNC');
	// 	if (!empty($toEmail)) {
	// 		foreach (explode(',', $toEmail) as $singleTOEmail) {
	// 			if ($singleTOEmail != '') {
	// 				$mail->addAddress($singleTOEmail);
	// 			}
	// 		}
	// 	}

	// 	if (!empty($ccEmail)) {
	// 		foreach (explode(',', $ccEmail) as $singleCCEmail) {
	// 			if ($singleCCEmail != '') {
	// 				$mail->AddCC($singleCCEmail);
	// 			}
	// 		}
	// 	}
	// 	$mail->Subject = $vSubject;
	// 	$mail->msgHTML($vEmailBody);
	// 	if ($attachFile != '') {
	// 		$mail->AddAttachment($attachFile);
	// 	}

	// 	if ($mode == 'LIVE') {
	// 		$mail->Send();
	// 	}
	// }

	public function getOtp($n)
	{
		//0123456789abcdefghijklmnopqrstuvwxyz
		$characters = '123456789';
		$randomString = '';

		for ($i = 0; $i < $n; $i++) {
			$index = rand(0, strlen($characters) - 1);
			$randomString .= $characters[$index];
		}
		return $randomString;
	}

	function convertCamelCase($str)
	{
		$i = array("-", "_");
		$str = preg_replace('/([a-z])([A-Z])/', "\\1 \\2", $str);
		$str = preg_replace('@[^a-zA-Z0-9\-_ ]+@', '', $str);
		$str = str_replace($i, ' ', $str);
		$str = str_replace(' ', '', ucwords(strtolower($str)));
		$str = strtolower(substr($str, 0, 1)) . substr($str, 1);
		return $str;
	}

	public function getFinancialYearByYearNew($year, $formate = '')
	{
		$d = $year . '-01-01';
		if ($formate != '') {
			$Year = date($formate, strtotime($d)) . "-" . (date($formate, strtotime($d)) + 1);
		} else {
			$Year = $year . "-" . ($year + 1);
		}
		return $Year;
	}

	function wh_log($log_msg)
	{
		$log_filename = "log";
		if (!file_exists($log_filename)) {
			// create directory/folder uploads.
			mkdir($log_filename, 0777, true);
		}

		$log_file_data = $log_filename . '/log_' . date('d-M-Y') . '.log';
		// if you don't add `FILE_APPEND`, the file will be erased each time you add a log
		file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
	}

	public function getEngAttendanceSummary($iEmpId, $iMonth, $iYear)
	{
		$dDate = date("Y-m-d", strtotime($iYear . "-" . $iMonth . "-01"));
		$iMonth = date('m', strtotime($dDate));
		$iYear = date('Y', strtotime($dDate));

		$curDate = $this->curDate();
		$curTime = $this->curTime();
		// $curTime = '20:35:05';

		$iShiftIds = $this->mf_getValue_Qry("hr_shift","GROUP_CONCAT(iShiftId)"," WHERE eStatus = 'y' 
                            AND '".$curTime."' >= tStartTime AND '".$curTime."' <= tEndTime
				");
		
		$aEngData = $this->mf_getMultiValue_Qry("engineer", array('vWeekOffDay', 'iLocationId', 'vPunchType', 'iShiftId'), " WHERE id = " . $iEmpId);
		$vWeekOffDay = $aEngData[0];
		$iLocationId = $aEngData[1];
		$vPunchType = $aEngData[2];
		$iShiftId = $aEngData[3];

		$aShiftData = $this->mf_getMultiValue_Qry("hr_shift", array('isTwoDay','tStartTime','tEndTime'), " WHERE iShiftId = " . $iShiftId);
		$isTwoDay = $aShiftData[0];
		$tStartTime = $aShiftData[1];

		if ($iMonth == '') {
			$iMonth = date('m', strtotime($curDate));
		}

		if ($iYear == 0) {
			$iYear = date('Y', strtotime($curDate));
		}

		$TotDays = 0;
		if((int)$iMonth>0 && (int)$iYear>0){
			$TotDays = cal_days_in_month(CAL_GREGORIAN, $iMonth, $iYear);
		}
		$FirstDateOfMonth = $iYear . '-' . $iMonth . '-01';
		$LastDateOfMonth = $iYear . '-' . $iMonth . '-' . $TotDays;
		$dMonthDateRange = $this->getDatesFromRange($FirstDateOfMonth, $LastDateOfMonth);
		$curDateString = strtotime($this->curDate());
		$TotDaysTillDate = 0;
		if ($curDateString < strtotime($LastDateOfMonth)) {
			$TotDaysTillDate = ($this->convertDateTime($this->curDate(), 'j'));
		} else {
			$TotDaysTillDate = $TotDays;
		}
		
		// echo $TotDaysTillDate;
		$iTotalWokringDaysTillDate = 0;
		$iTotalWeekOff = 0;
		$iTotalWorkingHours = 0;

		// echo $iTotalWeekOff;
		/******* Holidays *******/
		$selQryHoli = "SELECT SUM((IF(tEndDate<='" . $LastDateOfMonth . "',DAY(tEndDate),DAY('" . $LastDateOfMonth . "')))-(DAY(tStartDate))+1) as iTotalHolyDays  FROM hr_holiday WHERE eStatus = 'y' AND (MONTH(tStartDate) = '" . $iMonth . "' OR MONTH(tEndDate) = '" . $iMonth . "') AND (YEAR(tStartDate) = '" . $iYear . "' OR YEAR(tEndDate) = '" . $iYear . "') AND (FIND_IN_SET(" . $iLocationId . ",iLocationIds) OR iLocationIds='')";
		$queryHoli = $this->mf_query($selQryHoli);
		$rowHoli = $this->mf_fetch_array($queryHoli);
		$paidHoliday = $rowHoli['iTotalHolyDays'];

		$selQryHoli = "SELECT vHoliday,tStartDate,tEndDate FROM hr_holiday WHERE eStatus = 'y' AND (MONTH(tStartDate) = '" . $iMonth . "' OR MONTH(tEndDate) = '" . $iMonth . "') AND (YEAR(tStartDate) = '" . $iYear . "' OR YEAR(tEndDate) = '" . $iYear . "') AND (FIND_IN_SET(" . $iLocationId . ",iLocationIds) OR iLocationIds='')";
		$queryHoli = $this->mf_query($selQryHoli);
		$aHoliDayRange = array();
		// $aHoliDayDetailsArr = array();
		// $aTmpArr = array();
		while ($rowHoli = $this->mf_fetch_array($queryHoli)) {
			// $aTmpArr = $rowHoli;
			// $aTmpArr['iUserId'] = $iEmpId;
			$aDateRangeL = $this->getDatesFromRange($rowHoli['tStartDate'], $rowHoli['tEndDate']);
			array_push($aHoliDayRange, $aDateRangeL);
			// foreach ($aDateRangeL as $key => $dLDate) {
			// 	$aTmpArr['Day'][] = $dLDate;
			// }
			// array_push($aHoliDayDetailsArr, $aTmpArr);
		}

		$aHolidayArr = array();
		foreach ($aHoliDayRange as $key => $dHDate) {
			foreach ($dHDate as $key => $dHoliDate) {
				array_push($aHolidayArr, $dHoliDate);
			}
		}
		// print_pre($aHolidayArr);
		/******* Holidays *******/

		/******** Week off ********/
		$aWeekOffDateArr = array();
		$dTotalTillDateWeekOff = 0;
		$iActualWeekOff = 0;
		for ($i = 1; $i <= $TotDays; $i++) {
			$iLoopCurDate = $iYear . '-' . $iMonth . '-' . sprintf('%02d', $i);
			if ($this->convertDateTime($iLoopCurDate, 'l') == $vWeekOffDay) {
				$iActualWeekOff++;
				if (!in_array($iLoopCurDate,(array) $aHolidayArr)) {
					$iTotalWeekOff++;
					if (strtotime($iLoopCurDate) <= $curDateString) {
						$dTotalTillDateWeekOff++;
						// echo $iLoopCurDate;
						array_push($aWeekOffDateArr, $iLoopCurDate);
					}
				}
			}
		}
		/******** Week off ********/

		$iTotalLeaveDays = 0;
		$iActulLeaveDays = 0;
		/********************* GET LEAVE FROM CURRENT MONTH ********************/
		$selQryLeave = "SELECT hla.iDayStatus,hlt.iLeaveTypeId,hla.dLvStartDate,hla.dLvEndDate FROM hr_leave_application as hla LEFT JOIN hr_leave_type as hlt ON hlt.iLeaveTypeId = hla.iLeaveTypeId WHERE hla.iAppStatus = 'Approved' AND hla.eStatus='y' AND (MONTH(dLvStartDate) = '" . $iMonth . "' OR MONTH(dLvEndDate) = '" . $iMonth . "') AND (YEAR(dLvStartDate) = '" . $iYear . "' OR YEAR(dLvEndDate) = '" . $iYear . "') AND (DATE(dLvStartDate) <= '" . $curDate . "' OR DATE(dLvEndDate) <= '" . $curDate . "') AND hla.iUserId='" . $iEmpId . "'";

		$queryLeave = $this->mf_query($selQryLeave);
		$aLeaveDateArr = array();
		while ($rowLeave = $this->mf_fetch_array($queryLeave)) {
			$dLvStartDate = $FirstDateOfMonth;
			if (strtotime($rowLeave['dLvStartDate']) > strtotime($FirstDateOfMonth)) {
				$dLvStartDate = $rowLeave['dLvStartDate'];
			}

			$dLvEndDate = $LastDateOfMonth;
			if (strtotime($rowLeave['dLvEndDate']) < strtotime($LastDateOfMonth)) {
				$dLvEndDate = $rowLeave['dLvEndDate'];
			}

			$aDateRange = $this->getDatesFromRange($dLvStartDate, $dLvEndDate);
			array_push($aLeaveDateArr, $aDateRange);
			$iDayStatus = $rowLeave['iDayStatus'];
			$dDateDiff = $this->dateDifference($dLvStartDate, $dLvEndDate);
			if ($iDayStatus == 549) {
				$iTotalLeaveDays += $dDateDiff;
			} else if ($iDayStatus == 550) {
				$iTotalLeaveDays += 0.5;
				if (!in_array($dLvStartDate, (array) $aHolidayArr)) {
					$iActulLeaveDays += 0.5;
				}
			}
			// print_pre($aDateRange);
			foreach ($aDateRange as $dLeaveDate) {
				if (!in_array($dLeaveDate, (array) $aHolidayArr)) {
					if ($iDayStatus == 549) {
						$iActulLeaveDays += 1;
					}
				}
				if (in_array($dLeaveDate, (array) $aWeekOffDateArr)) {
					$dTotalTillDateWeekOff--;
				}
			}
			// print_pre($aDateRange);
		}

		$aLeaveArr = array();
		foreach ($aLeaveDateArr as $val) {
			foreach ($val as $value) {
				array_push($aLeaveArr, $value);
			}
		}
		// print_pre($aLeaveArr);
		// echo $iActulLeaveDays;
		/********************* GET LEAVE RANGE FROM CURRENT MONTH ********************/

		/*********************** Start Holiday Count Till Date ********************/
		$selQryHoliTillDate = "SELECT SUM((IF(tEndDate<='" . $curDate . "',DAY(tEndDate),DAY('" . $curDate . "')))-(DAY(tStartDate))+1) as iTotalHolyDaysTillDate  FROM hr_holiday WHERE eStatus = 'y' AND (MONTH(tStartDate) = '" . $iMonth . "' OR MONTH(tEndDate) = '" . $iMonth . "') AND (YEAR(tStartDate) = '" . $iYear . "' OR YEAR(tEndDate) = '" . $iYear . "') AND (FIND_IN_SET(" . $iLocationId . ",iLocationIds) OR iLocationIds='') AND tEndDate <= '" . $curDate . "'";
		$queryHoliTillDate = $this->mf_query($selQryHoliTillDate);
		$rowHoliTillDate = $this->mf_fetch_array($queryHoliTillDate);
		$paidHolidayTillDate = $rowHoliTillDate['iTotalHolyDaysTillDate'];
		/*********************** End Holiday Count Till Date  ********************/

		$iTotalWokringDaysTillDate = ($TotDaysTillDate - $paidHolidayTillDate);

		$aResignationArr = $this->mf_getMultiValue_Qry("hr_emp_resignation as her LEFT JOIN engineer as eng ON (eng.id=her.iEngId AND eng.iRegignation_Status=2)", array("iResignationId", "dActualResignDate", "iEngId"), "WHERE her.eStatus='y' AND her.iEngId = '" . $iEmpId . "' AND her.dActualResignDate >= '" . $FirstDateOfMonth . "' AND her.dActualResignDate <= '" . $LastDateOfMonth . "' ");
		// echo $mfp->mf_last_query();
		$iResignationId = $aResignationArr[0];
		$dActualResignDate = $aResignationArr[1];
		$iEngId = $aResignationArr[2];

		$dDailyEndDate = $LastDateOfMonth;
		if ($iResignationId != 0 && $dActualResignDate != '' && $iEngId != 0) {
			$dDailyEndDate = $dActualResignDate;
		}

		$threeMAgoDate =  date("Y-m-01", strtotime("-3 Months"));

		$attendancetable = "hr_daily_attendance";
		if ($dDate < $threeMAgoDate) {
			$attendancetable = "arc_hr_daily_attendance";
		}

		$selAtt = "
			SELECT
				hda.*,TIMESTAMPDIFF(MINUTE,hda.dFirstPunch,hda.dLastPunch) as TimeDiff
			FROM
			$attendancetable as hda
			WHERE
				hda.iUserId = '" . $iEmpId . "' AND MONTH(hda.dAttendanceDate) = '" . $iMonth . "' AND YEAR(hda.dAttendanceDate) = '" . $iYear . "' AND hda.dAttendanceDate <= '" . $dDailyEndDate . "'
		";


		$queryAtt = $this->mf_query($selAtt);
		if ($isTwoDay == 1) {
			$curDateIdle = date("Y-m-d", strtotime($curDate . " -1 Days"));
		} else {
			$curDateIdle = $curDate;
		}
		$iTotalFullDays = 0;
		$iTotalHalfDays = 0;
		$dTotWorkingMins = 0;
		$iTotalMissPunch = 0;
		$iTotalADaysWithoutWH = 0; // total available days without Week of/holidays
		$aDailyAttArr = array();
		if ($this->mf_affected_rows() > 0) {
			while ($rowAtt = $this->mf_fetch_array($queryAtt)) {
				$aDailyAttArr[$rowAtt['dAttendanceDate']] = $rowAtt;
			}
		}

		foreach ($dMonthDateRange as $dDate) {
			if (!empty($aDailyAttArr[$dDate]) && $iEmpId > 0) {
				$rowAtt = $aDailyAttArr[$dDate];
				$dWorkingMins = $rowAtt['dWorkingMins'];
				$dFirstPunch = date('Y-m-d', strtotime($rowAtt['dFirstPunch']));
				$dLastPunch = date('Y-m-d', strtotime($rowAtt['dLastPunch']));
				$dTotWorkingMins += $dWorkingMins;
				// if ((in_array($dFirstPunch, (array) $aWeekOffDateArr) || in_array($dLastPunch, (array) $aWeekOffDateArr)) && $dWorkingMins >= (6 * 60)) {
				// 	$dTotalTillDateWeekOff--;
				// }
				if (in_array($dFirstPunch, (array) $aWeekOffDateArr) && $dWorkingMins >= (6 * 60)) {
					$dTotalTillDateWeekOff--;
				}

				if ((in_array($dFirstPunch, (array) $aHolidayArr) && $dWorkingMins >= (6 * 60)) || (in_array($dFirstPunch, (array) $aHolidayArr) && $dFirstPunch != '' && $dDate == $curDate)) {
					$iTotalWokringDaysTillDate++;
				}
				if (strtotime($dLastPunch) <= $curDateString && strtotime($dFirstPunch) <= $curDateString) {
					if ($dWorkingMins >= (6 * 60) || ($dFirstPunch != '' && $dDate == $curDate)) {
						$iTotalFullDays += 1;
						$iTotalADaysWithoutWH += 1;
					} else if ($dWorkingMins >= (2 * 60) && $dWorkingMins < (6 * 60)) {
						$iTotalHalfDays += 0.5;
						if (!in_array($dFirstPunch, (array) $aWeekOffDateArr) && (!in_array($dFirstPunch, (array) $aHolidayArr) && !in_array($dLastPunch, (array) $aHolidayArr))) {
							$iTotalADaysWithoutWH += 0.5;
						}
					} else if ($dWorkingMins <= (2 * 60)) {
						// $iTotalAbsent +=1;
					}
					if ($dWorkingMins == 0 && $rowAtt['eLastPunchType'] == 'I' && strtotime($rowAtt['dAttendanceDate']) < strtotime($curDateIdle)) {
						$iTotalMissPunch += 1;
						if (in_array($dFirstPunch, (array) $aWeekOffDateArr) || (in_array($dFirstPunch, (array) $aHolidayArr) && in_array($dLastPunch, (array) $aHolidayArr))) {
							$iTotalADaysWithoutWH -= 1;
						}
					}
				}
				// echo "<br/> Attendance Date => ".$dDate;
				// echo "<br/> Working Min. => ".$dWorkingMins;
				// echo "<br/> Week Off => ".$dTotalTillDateWeekOff.'<br/>';
			} else if (in_array('2', explode(',', $vPunchType)) && $dDate == $curDate) {
				if (!in_array($dDate, (array) $aWeekOffDateArr) && !in_array($dDate, (array) $aLeaveArr) && !in_array($dDate, (array) $aHolidayArr)) {
					$iTotalFullDays++;
					$iTotalADaysWithoutWH++;
				}
			} else if (!in_array($iShiftId, explode(',', $iShiftIds)) && $curDate == $dDate && strtotime($curTime) <= strtotime($tStartTime)) {
				if (!in_array($dDate, (array) $aWeekOffDateArr) && !in_array($dDate, (array) $aLeaveArr) && !in_array($dDate, (array) $aHolidayArr)) {
					$iTotalWokringDaysTillDate--;
				}
			}
		}
		// echo $curTime;
		// echo $tStartTime;
		// print_r($aWeekOffDateArr);
		// print_r($aHolidayArr);
		// exit;

		$iTotalAvailableDays = ($iTotalFullDays + $iTotalHalfDays);
		$iTotalWorkingHours = round((float)$dTotWorkingMins / 60, 2);
		$iTotalWokringDays = ($TotDays) - ($paidHoliday + $iTotalWeekOff);
		// echo $iTotalHalfDays.' '.$iTotalADaysWithoutHD;
		// if ($this->isSalesSuprAdmin()) {
			// echo $iTotalWokringDaysTillDate.' - '.$iTotalADaysWithoutWH.' - '.$iActulLeaveDays.' - '.$dTotalTillDateWeekOff.' - '.$iTotalMissPunch;
			// echo $TotDays.'-'.$iTotalWeekOff.'-'.$paidHoliday;
		// }

		$iTotalAbsent = $iTotalWokringDaysTillDate - $iTotalADaysWithoutWH - $iActulLeaveDays - $dTotalTillDateWeekOff - $iTotalMissPunch;
		$iTotalAbsent = ($iTotalAbsent < 0) ? 0 : $iTotalAbsent;

		$aReturnArr = array();
		$aReturnArr['iTotDays'] = $TotDays;
		$aReturnArr['iTotalPresentDays'] = $iTotalAvailableDays;
		$aReturnArr['iTotalLeave'] = $iTotalLeaveDays;
		$aReturnArr['iTotalAbsent'] = (($iMonth <= date('m') && $iYear == date('Y') || $iYear != date('Y')) && $iEmpId > 0) ? $iTotalAbsent : 0;
		$aReturnArr['iTotalWeekOff'] = $iActualWeekOff;
		$aReturnArr['iTotalWorkingHours'] = $iTotalWorkingHours;
		$aReturnArr['iTotalWorkingDays'] = ($iEmpId > 0) ? ($iTotalWokringDays) : 0;
		$aReturnArr['iTotalMissPunch'] = $iTotalMissPunch;
		$aReturnArr['iPaidHoliday'] = ($paidHoliday > 0) ? $paidHoliday : 0;
		// print_pre($aReturnArr);
		return $aReturnArr;
	}

	public function SendSMS($amcSMSArr)
	{
		// global $mode;
		// if (!empty($amcSMSArr) && $mode == 'LIVE') {
		// 	$messages = array(
		// 		'sender' => "JYOTFX",
		// 		'messages' => $amcSMSArr,
		// 	);

		// 	$data = array(
		// 		'apikey' => 'dJujzei6P50-U7IPF3mvrzz8jht8J0Fcx5fn4V7v6g',
		// 		'data' => json_encode($messages),
		// 	);

		// 	$ch = curl_init('https://api.textlocal.in/bulk_json/');
		// 	curl_setopt($ch, CURLOPT_POST, true);
		// 	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		// 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// 	return $response = curl_exec($ch);
		// 	curl_close($ch);
		// }
	}

	public function checkFileType($fileExtention){
		$fileExtention = strtolower($fileExtention);
		$aImgExt = array('jpg','jpeg','png','gif','bmp');
		$aVideoExt = array('mp4','3gp','mov','m4a','aac','mkv','wav');
		$aAudioExt = array('ogg','mp3','wma','wav');
		$aPdfExt = array('pdf');

		$Extention = '';
		if(in_array($fileExtention,$aImgExt)){
			$Extention = 'image';
		}

		if(in_array($fileExtention,$aVideoExt)){
			$Extention = 'video';
		}

		if(in_array($fileExtention,$aAudioExt)){
			$Extention = 'audio';
		}

		if(in_array($fileExtention,$aPdfExt)){
			$Extention = 'pdf';
		}

		return $Extention;
	}

	public function saveAddress($str) //Store address with special character
	{
		return htmlspecialchars($str, REPLACE_FLAGS, 'UTF-8');
	}

	public function viewAddress($str) //View address with special character
	{
		return utf8_encode($str);
	}

	public function strip_address($str)
	{
		return html_entity_decode($str);
	}

	function file_decode($vFileData, $fixPath, $fileName = "")
	{	
		$image_parts = explode(";base64,", $vFileData);
		$image_type_aux = explode("/", $image_parts[0]);
		$image_base64 = base64_decode($image_parts[1]);

		$orgFileName = $fileName;
		$orgFileName = preg_replace('/[^a-zA-Z0-9_ ()-.]/s', '', $orgFileName);
		$orgFileName = preg_replace('/[ ]/s', '_-_', $orgFileName);
		$expName = explode(".", $orgFileName);

		$vNewFileName = uniqid() . '^' . $expName[0] . '.' . $image_type_aux[1];

		$year = date("y");
		$month = date("m");
		$directory = "$year/$month/";
		$fullPath = $fixPath . $directory . $vNewFileName;
		if (!is_dir($fixPath . $directory)) {
			mkdir($fixPath . $directory, 0777, true);
		}
		if (file_put_contents($fullPath, $image_base64)) {
			return $directory . $vNewFileName;
		}
	}

	public function decimalFormat($value,$decimalPoint){
		return number_format((float)$value, $decimalPoint, '.', '');
	}
}

function print_pre($arr)
{
	echo '<pre>';
	print_r($arr);
	echo '</pre>';
}
?>