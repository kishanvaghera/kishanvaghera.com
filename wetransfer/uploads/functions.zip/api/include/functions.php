<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception; 

function NewSMTPMailSend($toEmail, $vSubject, $vEmailBody, $ccEmail = '', $attachFile = '',$encodingFile='',$typeFile='')
{	
	global $mode; global $mfp;
	if($mode=='LIVE'){
		include_once $_SERVER['DOCUMENT_ROOT']."/library/PHPMailer_v8/vendor/autoload.php";
	}else{
		include_once "../library/PHPMailer_v8/vendor/autoload.php";
	}

	// print_pre($toEmail);
	// print_pre($ccEmail);
	// print_pre($vSubject);
	// print_pre($vEmailBody); exit;
	
	$mail = new PHPMailer(true);
	$iTotalEmail = 0;
	$vSMTPEmailId = "system@finix.jyoti.co.in";
	try {
	//Server settings
	$mail->SMTPDebug = false;                      // Enable verbose debug output
	$mail->isSMTP();                                            // Send using SMTP
	$mail->Host       = 'ssl://smtp.gmail.com';                 // Set the SMTP server to send through
	$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
	$mail->Username   = $vSMTPEmailId; // SMTP username system@finix.jyoti.co.in
	$mail->Password   = ''; // // SMTP password wvmzxecfbipfesqy
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
	$mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
	$mail->setFrom($vSMTPEmailId, 'Jyoti CNC');

	if (!empty($toEmail)) {
		$singleTO = '';
		if(is_array($toEmail)){
			foreach ($toEmail as $singleTOEmail) {
				if ($singleTOEmail != '' && trim($singleTOEmail) != '') {
					$mail->addAddress($singleTOEmail);
					$singleTO = $singleTOEmail;
					$iTotalEmail++;
				}
			}
		}else{
			foreach (explode(',', $toEmail) as $singleTOEmail) {
				if ($singleTOEmail != '' && trim($singleTOEmail) != '') {
					$mail->addAddress($singleTOEmail);
					$singleTO = $singleTOEmail;
					$iTotalEmail++;
				}
			}
		}

		if (!empty($ccEmail)) {
			if(is_array($ccEmail)){
				foreach ($ccEmail as $singleCCEmail) {
					if ($singleCCEmail != '') {
						$mail->AddCC($singleCCEmail);
						$iTotalEmail++;
					}
				}
			}else{
				foreach (explode(',', $ccEmail) as $singleCCEmail) {
					if ($singleCCEmail != '') {
						$mail->AddCC($singleCCEmail);
						$iTotalEmail++;
					}
				}
			}
			
		}
	}

	// exit();
	

	// Content
	$mail->isHTML(true);                                  // Set email format to HTML
	$mail->Subject = $vSubject;
	$mail->msgHTML($vEmailBody);
	if (!empty($attachFile)) {
		foreach (explode(',', $attachFile) as $attechmentPath) {
			if ($attechmentPath != '') {
				if($encodingFile!='' && $typeFile!=''){
					$mail->AddAttachment($attechmentPath, '', $encoding = $encodingFile, $type = $typeFile);
					// $mail->AddAttachment($attechmentPath, '', $encoding = 'base64', $type = 'application/pdf');
				}else{
					$mail->AddAttachment($attechmentPath);
				}
			}
		}
	}
	// return $mail->Send();
	if ($mode == 'LIVE' && $singleTO != '') {
		if($mail->Send()){
			if($iTotalEmail > 0){
				$iId = intval($mfp->mf_getValue_Qry("tmp_mail_sent_history", "iId", "WHERE dDate = '".$mfp->curDate()."' AND vFromEmailId='".$vSMTPEmailId."'"));
				if($iId > 0){
					$mfp->mf_query("UPDATE tmp_mail_sent_history SET iSentCount = (iSentCount + ".$iTotalEmail.") WHERE iId = '".$iId."'");
				}else{
					$aInsArr = array();
					$aInsArr['dDate'] = $mfp->curDate();
					$aInsArr['vFromEmailId'] = $vSMTPEmailId;
					$aInsArr['iSentCount'] = $iTotalEmail;
					$mfp->mf_dbinsert("tmp_mail_sent_history", $aInsArr);
				}
			}
			return 1;
		}else{
			return 0;
		}
		
	}

	} catch (Exception $e) {
		return 0;
	}
	//return 1;

}

?>
