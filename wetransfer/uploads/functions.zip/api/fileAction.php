<?php
include('../connect.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE');

$data = json_decode(file_get_contents('php://input'), true);
if ($data != "") {
    $_POST =  $data;
}

$LoggedData=$mfp->mf_LoginCheck();

if($_POST['action'] == "getFolderList") {
    $sqlFolder=$mfp->mf_query("SELECT vFolderName FROM file_system WHERE eStatus='y' AND FIND_IN_SET(".$LoggedData['iUserId'].", tFilePermission)");
    if($mfp->mf_affected_rows()>0){
        $folderListArr=array();

        while($row=$mfp->mf_fetch_array($sqlFolder)){
            $folderListArr[]=$row['vFolderName'];
        }

        echo json_encode(array("status"=>201,"data"=>$folderListArr));
    }else{
        echo json_encode(array("status"=>412,"msg"=>"No Folder Found!"));
    }
    exit;
}else if($_POST['action'] == "addFolder") {
    $vFolderName=$_POST['vFolderName'];
    $vUsers=$_POST['vUsers'];
    $tFolderPath=$_POST['tFolderPath'];

    $insArr=array();
    $insArr['vFolderName']=$vFolderName;
    $insArr['tFolderPath']=$tFolderPath;
    $insArr['tFilePermission']=$vUsers;
    $insArr['iCreatedBy']=$LoggedData['iUserId'];
    $insArr['dCreatedDate']=$mfp->curTimedate();
    $mfp->mf_dbinsert("file_system",$insArr);

    echo json_encode(array("status"=>201,"msg"=>"Folder has been added successfully."));
    exit;
}else if($_POST['action'] == "EditFolder") {
    $vFolderName=$_POST['vFolderName'];
    $vUsers=$_POST['vUsers'];
    $tFolderPath=$_POST['tFolderPath'];
    $iFileId=$_POST['iFileId'];

    $updArr=array();
    $updArr['vFolderName']=$vFolderName;
    $updArr['tFolderPath']=$tFolderPath;
    $updArr['tFilePermission']=$vUsers;
    $mfp->mf_dbupdate("file_system",$updArr," WHERE iFileId='".$iFileId."'");

    echo json_encode(array("status"=>201,"msg"=>"Folder has been updated successfully."));
    exit;
}else if($_POST['action'] == "DeleteFolder") {
    $iFileId=$_POST['iFileId'];

    $updArr=array();
    $updArr['eStatus']="d";
    $mfp->mf_dbupdate("file_system",$updArr," WHERE iFileId='".$iFileId."'");

    echo json_encode(array("status"=>201,"msg"=>"Folder has been deleted successfully."));
    exit;
}

