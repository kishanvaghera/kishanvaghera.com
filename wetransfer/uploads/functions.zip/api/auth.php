<?php
include('connect.php');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
header('Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE');

$data = json_decode(file_get_contents('php://input'), true);
if ($data != "") {
    $_POST =  $data;
}

if ($_POST['action'] == "login") {
    $vUserName=$_POST['vUserName'];
    $vPassword=$_POST['vPassword'];

    $sqlCheckUser=$mfp->mf_query("SELECT vPassword,iUserId FROM users WHERE vUserName='".$vUserName."' AND eStatus='y' LIMIT 1");
    if($mfp->mf_affected_rows()>0){
        if($row['vPassword']==sha1($vPassword)){
            
            $data = json_encode(array("iUserId"=>$row['iUserId'],"vUserName"=>$vUserName));

            $encryptionMethod = "AES-256-CBC";
            $secretKey = "FileManageMentSystem";
            $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($encryptionMethod));
            $encryptedData = openssl_encrypt($data, $encryptionMethod, $secretKey, 0, $iv);

            $updateArr=array();
            $updateArr['vAuthtoken']=$encryptedData;
            $mfp->mf_dbupdate("users",$updateArr," WHERE iUserId='".$row['iUserId']."'");

            echo json_encode(array("status"=>201,"data"=>array("iUserId"=>$row['iUserId'],"vAuthtoken"=>$encryptedData)));
        }else{
            echo json_encode(array("status"=>412,"msg"=>"Please check username or password!"));
        }
    }else{
        echo json_encode(array("status"=>412,"msg"=>"User is not existed!"));
    }

    exit;
}else if ($_POST['action'] == "register_user") {
    $vUserName=$_POST['vUserName'];
    $vPassword=$_POST['vPassword'];

    $sqlCheckUser=$mfp->mf_query("SELECT iUserId FROM users WHERE vUserName='".$vUserName."' AND eStatus='y' LIMIT 1");
    if($mfp->mf_affected_rows()>0){
        $row=$mfp->mf_fetch_array($sqlCheckUser);
        echo json_encode(array("status"=>412,"msg"=>"Username is already registerd!"));
    }else{
        $insArr=array();
        $insArr['vUserName']=$vUserName;
        $insArr['vPassword']=$vPassword;
        $insArr['dCreatedDate']=$mfp->curTimedate();
        $mfp->mf_dbinsert("users",$insArr);
        echo json_encode(array("status"=>200,"msg"=>"Username has been registerd successfully."));
    }
    exit;
}
