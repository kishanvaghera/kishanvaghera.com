//Create Folder New Modal
var btn = document.getElementById("vCreateFolderBtn");
btn.onclick = function () {
    $('#vFolderName').val("");
}

//Create New Folder Action
$("#vSubmitBtn").on("click", function (e) {
    e.preventDefault();
    const folderUrl=$("#folderUrl").val();

    const folderName=$('#vFolderName').val();

    if(folderName==""){
        alert("Please enter folder name.");
    }else{
        var formData = {
            'action': "create_folder_ftp",
            'vFolderName': $('#vFolderName').val(),
            'vPath': folderUrl
        };
    
        $.ajax({
            url: "action.php",
            type: "post",
            data: formData,
            success: function (d) {
                location.reload();
            }
        });
    }
});


const fileInput = document.getElementById('file-input');
const dropArea = document.getElementById('drop-area');

// Handle file selection
fileInput.addEventListener('change', handleFileSelect);

// Handle drag and drop
dropArea.addEventListener('dragover', handleDragOver);
dropArea.addEventListener('drop', handleDrop);

function handleFileSelect(event) {
    const files = event.target.files;
    handleFiles(files);
}

function handleDragOver(event) {
    event.stopPropagation();
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
}

function handleDrop(event) {
    event.stopPropagation();
    event.preventDefault();
    const files = event.dataTransfer.files;
    handleFiles(files);
}

function handleFiles(files) {
    const folderUrl=$("#folderUrl").val();
    // Process each file
    for (const file of files) {
        const formData = new FormData();
        formData.append('action', "upload_file_ftp");
        formData.append('file', file);
        formData.append('vPath', folderUrl);

        $("#progressBar").removeClass("d-none");
        $.ajax({
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = evt.loaded / evt.total;
                        percentComplete = parseInt(percentComplete * 100);
                        console.log(percentComplete);

                        $(".progress-bar__value").text(percentComplete + "%");
                        $("#progress-bar").val(percentComplete);

                        if (percentComplete === 100) {
                            setTimeout(() => {
                                $(".progress-bar__value").text("0%");
                                $("#progress-bar").text(0);
                            }, 1000)
                        }
                    }
                }, false);
                return xhr;
            },
            url: "action.php",
            type: "post",
            processData: false,
            contentType: false,
            data: formData,
            success: function (d) {
                location.reload();
            }
        });
    }
}