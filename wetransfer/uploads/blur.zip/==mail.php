<?php 
session_start();
include "functions.php";
include("connect.php");

function encrpytString($str){
    $ciphering = "AES-128-CTR";
    $options = 0;
    $encryption_iv = '1234567891011121';
    $encryption_key = "ChatApp001";
    $encryption = openssl_encrypt($str,$ciphering,$encryption_key, $options, $encryption_iv);
    return $encryption;
}

$mainUrl="http://192.168.1.229/chat-app-dev/";

if(!empty($_POST)){
    if($_POST['action']=="forgot_password"){
        $isLoggedUser=trim($_POST['isLoggedUser']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);
        
        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$vFullName."</b></p> <p>Forgot password link:- </p> ".$mainUrl."forgot_password.php?id=".$encrptStr;
            
            if(NewSMTPMailSend($vEmailAdr,"forgot password",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="verify_email"){
        $isLoggedUser=trim($_POST['isLoggedUser']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);

        $randomNumber = rand(100000, 999999);

        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName,"vEmail"=>$vEmailAdr)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$vFullName."</b> <br/>OTP Code :- ".$randomNumber."</p> <br/> <p>Verify email with link:-</p> <br/> ".$mainUrl."check_verify.php?id=".$encrptStr;
            
            if(NewSMTPMailSend($vEmailAdr,"Verify Email",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="send_verify_email"){
        $isLoggedUser=trim($_POST['iUserId']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);
        $iEngId=trim($_POST['iEngId']);

        $randomNumber = rand(100000, 999999);

        mysqli_query($conn, "UPDATE chat_users SET vOtp='".$randomNumber."' WHERE iEngId='".$iEngId."'");
        
        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$iEngId."</b> <br/> User Name:- <b>".$vFullName."</b> <br/>OTP Code :- ".$randomNumber."</p> <br/> <br/>";
            
            if(NewSMTPMailSend($vEmailAdr,"Verify Email",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="verfication_check"){
        if($_SESSION['vVerfiyEmailOtp']==$_POST['vEmailChangeVerfCode']){
            echo json_encode(array("status"=>200,"msg"=>"Verification is correct."));
            exit;
        }else{
            echo json_encode(array("status"=>412,"msg"=>"mail error."));
            exit;
        }
    }else if($_POST['action']=="delete_profile"){
        $isLoggedUser=trim($_POST['iUserId']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);
        
        if($vEmailAdr!=""){

            $html="<p>Your profile is deleted. Below are the details of your account for your reference:</p><p>Username: ".$isLoggedUser."<br/>Email Address: ".$vEmailAdr."<br/>Full Name: ".$vFullName."</p>";
            
            if(NewSMTPMailSend($vEmailAdr,"Profile Deletion",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully."));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="resend_mail"){
        $isLoggedUser=trim($_POST['isLoggedUser']);

        $sql=mysqli_query($conn,"SELECT vFullName,iUserId,vEmail FROM chat_users WHERE iEngId='".$isLoggedUser."' AND eStatus='y'");
        $row=mysqli_fetch_assoc($sql);

        $randomNumber = rand(100000, 999999);

        if(!empty($row)){
            if($row['vEmail']!=""){
                $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$row['vFullName'],"vEmail"=>$row['vEmail'])));
                $encrptStr=urlencode($encrptStr);
    
                $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$row['vFullName']."</b> <br/>OTP Code :- ".$randomNumber."</p> <br/> <br/>";
                
                $vEmail = preg_replace('/(?<=.....).(?=.*@)/', '*', $row['vEmail']);

                if(NewSMTPMailSend($row['vEmail'],"Verify Email",$html)){

                    mysqli_query($conn, "UPDATE chat_users SET vOtp='".$randomNumber."' WHERE iEngId='".$isLoggedUser."'");

                    echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr,"vEmail"=>$vEmail));
                    exit;
                }else{
                    echo json_encode(array("status"=>412,"msg"=>"mail error."));
                    exit;
                }
            }else{
                echo json_encode(array("status"=>412,"msg"=>"Email not found."));
                exit;
            }
        }else{
            echo json_encode(array("status"=>412,"msg"=>"User not found."));
            exit;
        }
    }else if($_POST['action']=="verify_str"){
        $isLoggedUser=$_POST['isLoggedUser'];
        $vFullName=$_POST['vFullName'];

        $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
        $encrptStr=urlencode($encrptStr);

        echo json_encode(array("status"=>200,"msg"=>"please verify email.","url"=>$encrptStr));
        exit;
    }
}

?>
