<?php

$conn = new mysqli("192.168.1.229","root","123456","chatapp-dev");