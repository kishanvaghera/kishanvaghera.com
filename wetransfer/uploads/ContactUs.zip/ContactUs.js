import { ScrollView, StyleSheet, Text, View, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import CommonHeader from '../Common/CommonHeader'
import theme from '../Theme/ThemeConfig'
import { Image } from 'react-native'
import images from '../../assets'
import { moderateScale, scale, verticalScale } from '../Common/Scalling'
import { widthPercentageToDP } from 'react-native-responsive-screen'
import apiUrls from '../Services/ApiUrls';
import * as APIService from '../Services/APIService';

const ContactUs = () => {

  const [ConfigDataArr,setConfigDataArr]=useState({});


  return (
    <CommonHeader name={'Contact Us'}>
      <View style={{paddingBottom:40}}>
        <ScrollView
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: 40, paddingTop: 10 }} >

            <View style={styles.row}>
              <View>
                <Image source={images.web2} style={styles.imageView}/>
              </View>
              <View style={styles.rowText}>
                <Text style={styles.heading}>Our Website</Text>
                <Text style={{...styles.heading,color:theme.colors.textColor}}>https://shreegeetagarbhsanskar.com</Text>
              </View>
            </View>

            <View style={styles.row}>
              <View>
                <Image source={images.mail2} style={styles.imageView}/>
              </View>
              <View style={styles.rowText}>
                <Text style={styles.heading}>Write to Us</Text>
                <Text style={{...styles.heading,color:theme.colors.textColor}}>shreegeetagarbhsanskar@gmail.com</Text>
              </View>
            </View>

            <View style={styles.row}>
              <View>
                <Image source={images.call2} style={styles.imageView}/>
              </View>
              <View style={styles.rowText}>
                <Text style={styles.heading}>Technical Support</Text>
                <Text style={{...styles.heading,color:theme.colors.textColor}}>+91 7043381554</Text>
              </View>
            </View>

            <View style={styles.row}>
              <View>
                <Image source={images.conatct_home} style={styles.imageViewHome}/>
              </View>
              <View style={styles.rowText}>
                <Text style={styles.heading}>Address</Text>
                <Text style={{...styles.heading,color:theme.colors.textColor}}>Shree Geeta Garbhsanskar, Near Swati Park Rajkot-360002.</Text>
              </View>
            </View>

        </ScrollView>
      </View>
    </CommonHeader>
  )
}

export default ContactUs

const styles = StyleSheet.create({
  row:{
    flexDirection:'row',
    borderBottomColor:"#9DB2BF",
    borderBottomWidth:1,
    paddingBottom:10,
    // paddingTop:15,
    paddingHorizontal:25,
    alignItems:'center'
  },
  imageView:{
      width:moderateScale(50),
      height:verticalScale(50),
      marginTop:5
  },
  imageViewHome:{
    width:moderateScale(53),
    height:verticalScale(51),
    marginTop:5
  },
  icon:{
    backgroundColor:'#348bce',
    padding:15,
    borderRadius:100,
  },
  subHeading:{
    color:theme.colors.secondary,
    marginLeft:15,
    marginBottom:5,
    fontWeight:'400',
    width:widthPercentageToDP('65%')
  },
  heading:{
    color:theme.colors.secondary,
    marginLeft:15,
    marginBottom:5,
    fontWeight:'600',
    width:widthPercentageToDP('65%')
  },
  rowText:{
    marginTop:10
  },
  contactText:{
    color:theme.colors.secondary,
    fontWeight:'600',
    fontSize:20,
    alignSelf:'center',
    marginTop:10
  },
})