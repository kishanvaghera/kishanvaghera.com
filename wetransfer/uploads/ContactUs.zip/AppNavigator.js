import React, { useEffect, useState } from 'react';
import { View,Dimensions } from 'react-native';
import { NavigationContainer,getFocusedRouteNameFromRoute,useNavigation, useNavigationState, useRoute} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createDrawerNavigator } from '@react-navigation/drawer';

import VectorIcon from '../Common/VectorIcon'

// Import your screens/components here
import BasicHome from '../Basic/Home';
import PremiumHome from '../Premium/Home';
import Login from '../Auth/Login';
import MainContainer from '../../MainContainer';
import YogaCategoryList from '../Meditation/YogaCategoryList';
import YogaMainDetail from '../Meditation/YogaMainDetail';
import YogaMainList from '../Meditation/YogaMainList';
import YogaSubCategoryList from '../Meditation/YogaSubCategoryList';
import YogaSubSubCateList from '../Meditation/YogaSubSubCateList';
import MusicCategoryList from '../Music/MusicCategoryList';
import MusicDetail from '../Music/MusicDetail';
import MusicSubCategoryList from '../Music/MusicSubCategoryList';
import MusicSubData from '../Music/MusicSubData';
import DietList from '../Diet/DietList';
import ActivityCategoryList from '../Activity/ActivityCategoryList';
import ActivityDetail from '../Activity/ActivityDetail';
import ActvitySubCategoryList from '../Activity/ActvitySubCategoryList';
import MainActivityList from '../Activity/MainActivityList';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loginSuccess, logout } from '../../Redux/actions/loginActions';
import { useDispatch, useSelector } from 'react-redux';
import CustomSidebar from './CustomSidebar';
import MomScreen from '../Premium/MomScreen';
import BabyScreen from '../Premium/BabyScreen';
import Live from '../Live/Live';
import LiveMainData from '../Live/LiveMainData';
import LiveSubData from '../Live/LiveSubData';
import FreeData from '../Basic/FreeData';
import FreeDataDetail from '../Basic/FreeDataDetail';
import SubscribeSelect from '../Basic/SubscribeSelect';
import SubscribeDetailPlan from '../Basic/SubscribeDetailPlan';
import Profile from '../Auth/Profile';
import AboutUs from '../More/AboutUs';
import ContactUs from '../More/ContactUs';
import FAQ from '../More/FAQ';
import MyOrders from '../More/MyOrders';
import PrivacyPolicy from '../More/PrivacyPolicy';
import ProductsPlans from '../More/ProductsPlans';
import TermsConditios from '../More/TermsConditios';
import MoreList from '../More/MoreList';
import Address from '../Basic/Address';
import UpdateApp from '../Common/UpdateApp';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

const MorePageStack=()=>{
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }} > 
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
    </Stack.Navigator>
    )
}

const AppStackBasic = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="BasicHome" component={BasicHome} />
      <Stack.Screen name="UpdateApp" component={UpdateApp} />
      <Stack.Screen name="Live" component={Live} />
      <Stack.Screen name="LiveMainData" component={LiveMainData} />
      <Stack.Screen name="LiveSubData" component={LiveSubData} />
      <Stack.Screen name="FreeData" component={FreeData} />
      <Stack.Screen name="FreeDataDetail" component={FreeDataDetail} />
      <Stack.Screen name="SubScribeSelect" component={SubscribeSelect} />
      <Stack.Screen name="SubscribeDetailPlan" component={SubscribeDetailPlan} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
    </Stack.Navigator>
  );
};

const AppStackPremium = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="PremiumHome" component={PremiumHome} />
      <Stack.Screen name="UpdateApp" component={UpdateApp} />
      <Stack.Screen name="FreeData" component={FreeData} />
      <Stack.Screen name="FreeDataDetail" component={FreeDataDetail} />
      <Stack.Screen name="MomScreen" component={MomScreen} />
      <Stack.Screen name="BabyScreen" component={BabyScreen} />
      <Stack.Screen name="Live" component={Live} />
      <Stack.Screen name="LiveMainData" component={LiveMainData} />
      <Stack.Screen name="LiveSubData" component={LiveSubData} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="Address" component={Address} />
    </Stack.Navigator>
  );
};

const AppStackMeditation = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="YogaCategoryList" component={YogaCategoryList} />
      <Stack.Screen name="YogaMainDetail" component={YogaMainDetail} />
      <Stack.Screen name="YogaMainList" component={YogaMainList} />
      <Stack.Screen name="YogaSubCategoryList" component={YogaSubCategoryList} />
      <Stack.Screen name="YogaSubSubCateList" component={YogaSubSubCateList} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
      <Stack.Screen name="SubScribeSelect" component={SubscribeSelect} />
      <Stack.Screen name="SubscribeDetailPlan" component={SubscribeDetailPlan} />
    </Stack.Navigator>
  );
};

const AppStackMusic = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MusicCategoryList" component={MusicCategoryList} />
      <Stack.Screen name="MusicDetail" component={MusicDetail}/>
      <Stack.Screen name="MusicSubCategoryList" component={MusicSubCategoryList} />
      <Stack.Screen name="MusicSubData" component={MusicSubData} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
      <Stack.Screen name="SubScribeSelect" component={SubscribeSelect} />
      <Stack.Screen name="SubscribeDetailPlan" component={SubscribeDetailPlan} />
    </Stack.Navigator>
  );
}

const AppStackD = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DietList" component={DietList} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
    </Stack.Navigator>
  );
}

const AppStackActivity=()=>{
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ActivityCategoryList" component={ActivityCategoryList} />
      <Stack.Screen name="ActivityDetail" component={ActivityDetail} />
      <Stack.Screen name="ActvitySubCategoryList" component={ActvitySubCategoryList} />
      <Stack.Screen name="MainActivityList" component={MainActivityList} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="MoreList" component={MoreList} />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="ContactUs" component={ContactUs} />
      <Stack.Screen name="FAQ" component={FAQ} />
      <Stack.Screen name="MyOrders" component={MyOrders} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen name="ProductsPlans" component={ProductsPlans} />
      <Stack.Screen name="TermsConditios" component={TermsConditios} />
      <Stack.Screen name="Address" component={Address} />
      <Stack.Screen name="SubScribeSelect" component={SubscribeSelect} />
      <Stack.Screen name="SubscribeDetailPlan" component={SubscribeDetailPlan} />
    </Stack.Navigator>
  );
}

const DrawerScreen = () => {
  return (
    <View style={{}}>
      <CustomSidebar />
    </View>
  );
}

const AppNavigator = () => {
  return (
    <NavigationContainer
    >
      <MainContainer>
        <Drawer.Navigator initialRouteName='AppTabs' drawerContent={DrawerScreen} drawerPosition="left">
          <Drawer.Screen name="AppTabs" component={AppTabs} options={{ headerShown: false }} />
          {/* <Drawer.Screen name="MorePageStack" component={MorePageStack} options={{ headerShown: false }} /> */}
        </Drawer.Navigator>
      </MainContainer>
    </NavigationContainer>
  );
};

const AppTabs = () => {
  const logedData=useSelector(state=>state)
  const planId=logedData?.user?.iPlanId;

  const navigation = useNavigation();

  const [PageNameCurr,setPageNameCurr]=useState("");
  const getTabBarVisible = (route) => {
    const routeName = getFocusedRouteNameFromRoute(route);
    if(routeName!=undefined){
      setPageNameCurr(routeName);
    }
    // Add any conditions here to determine if the tab bar should be visible for a specific screen
    return routeName !== MusicDetail;
  };

  const [isShowBottomBar,setIsShowBottomBar]=useState(true);
  useEffect(() => {
    const onOrientationChange = () => {
      const { width, height } = Dimensions.get('window');
      if (width > height) {
        setIsShowBottomBar(false);
      } else {
        setIsShowBottomBar(true);
      }
    };

    Dimensions.addEventListener('change', onOrientationChange);

    return () => {
      Dimensions.removeEventListener('change', onOrientationChange);
    };
}, []);

  return (
    <Tab.Navigator
      initialRouteName='Home'
      screenOptions={({ route }) => ({
        unmountOnBlur: true, // or set to false
        activeTintColor: 'grey',
        inactiveTintColor: 'red',
        style: {
          backgroundColor: '#e0e0e0',
        },
        tabBarIconStyle: {
          marginTop: 10,
        },
        tabBarLabelStyle: {
          textAlign: 'center',
          fontSize: 12,
          paddingBottom: 2
        },
        tabBarStyle: {
          // display: logedData.isLoggedIn && PageNameCurr!=='MusicDetail'?'flex':'none',
          display: logedData.isLoggedIn && PageNameCurr!=='Address' && PageNameCurr!=='UpdateApp' && isShowBottomBar?'flex':'none',
          height: 50,
        },
        tabBarActiveTintColor: '#0B4E98',
        tabBarVisible: getTabBarVisible(route),
      })}
      tabBarOptions={{
        inactiveTintColor: '#a3a0a0',
      }}

    >
      {
        planId==0?
        <Tab.Screen name="BasicHome" component={AppStackBasic}
            options={{
              headerShown: false,
              tabBarLabel: 'Home',
              tabBarIcon: ({ color, size }) => (
                <VectorIcon IconName={'home'} LibraryName={'AntDesign'} IconSize={22} IconColor={color} />
              ),
            }} 
          />
        :<Tab.Screen name="PremiumHome" component={AppStackPremium}
        options={{
          headerShown: false,
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <VectorIcon IconName={'home'} LibraryName={'AntDesign'} IconSize={22} IconColor={color} />
          ),
        }} />
      }

      {/* <Tab.Screen name="BasicHome" component={AppStackBasic}
        options={{
          headerShown: false,
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <VectorIcon IconName={'home'} LibraryName={'AntDesign'} IconSize={22} IconColor={color} />
          ),
        }} 
        listeners={{
          tabPress: e => {
            navigation.navigate("BasicHome")
            e.preventDefault();
          },
        }}
      />

      <Tab.Screen name="PremiumHome" component={AppStackPremium}
        options={{
          headerShown: false,
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <VectorIcon IconName={'home'} LibraryName={'AntDesign'} IconSize={22} IconColor={color} />
          ),
        }} 
        listeners={{
          tabPress: e => {
            navigation.navigate("PremiumHome")
            e.preventDefault();
          },
        }}
      /> */}

      <Tab.Screen name="YogaCategoryList" component={AppStackMeditation}
        options={{
          headerShown: false,
          tabBarLabel: 'Meditation',
          tabBarIcon: ({ color, size }) => (
            <VectorIcon IconName={'meditation'} LibraryName={'MaterialCommunityIcons'} IconSize={22} IconColor={color} />
          ),
        }} 
        listeners={{
          tabPress: e => {
            navigation.navigate("YogaCategoryList")
            e.preventDefault();
          },
        }}
        />
      <Tab.Screen name="MusicCategoryList" component={AppStackMusic}
          options={{
            headerShown: false,
            tabBarLabel: 'Music',
            tabBarIcon: ({ color, size }) => (
              <VectorIcon IconName={'music-circle'} LibraryName={'MaterialCommunityIcons'} IconSize={22} IconColor={color} />
            ),
          }} 
          tabBarOptions={{
            display:'none'
          }}
          listeners={{
            tabPress: e => {
              navigation.navigate("MusicCategoryList")
              e.preventDefault();
            },
          }}
        />
      <Tab.Screen name="DietList" component={AppStackD}
          options={{
            headerShown: false,
            tabBarLabel: 'Diet',
            tabBarIcon: ({ color, size }) => (
              <VectorIcon IconName={'emoji-food-beverage'} LibraryName={'MaterialIcons'} IconSize={22} IconColor={color} />
            ),
          }} 
          listeners={{
            tabPress: e => {
              navigation.navigate("DietList")
              e.preventDefault();
            },
          }}
        />
      <Tab.Screen name="ActivityCategoryList" component={AppStackActivity}
          options={{
            headerShown: false,
            tabBarLabel: 'Activity',
            tabBarIcon: ({ color, size }) => (
              <VectorIcon IconName={'timetable'} LibraryName={'MaterialCommunityIcons'} IconSize={22} IconColor={color} />
            ),
          }} 
          listeners={{
            tabPress: e => {
              navigation.navigate("ActivityCategoryList")
              e.preventDefault();
            },
          }}
        />
    </Tab.Navigator>
  );
};

export default AppNavigator;
