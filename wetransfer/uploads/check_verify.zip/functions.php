<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception; 

function NewSMTPMailSend($toEmail, $vSubject, $vEmailBody)
{	
    include_once "library/PHPMailer_v8/vendor/autoload.php";
	
	$mail = new PHPMailer(true);
	$iTotalEmail = 0;
	$vSMTPEmailId = "kishan.v@enlivendc.com";
	try {
	//Server settings
	$mail->SMTPDebug = false;                      // Enable verbose debug output
	$mail->isSMTP();                                            // Send using SMTP
	$mail->Host       = 'ssl://smtp.gmail.com';                 // Set the SMTP server to send through
	$mail->SMTPAuth   = true;                                   // Enable SMTP authentication
	$mail->Username   = $vSMTPEmailId; // SMTP username system@finix.jyoti.co.in
	$mail->Password   = 'separ@462*'; // // SMTP password wvmzxecfbipfesqy
	// $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
	$mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
	$mail->setFrom($vSMTPEmailId, 'Chat App');

	if (!empty($toEmail)) {
		if(is_array($toEmail)){
			foreach ($toEmail as $singleTOEmail) {
				if ($singleTOEmail != '' && trim($singleTOEmail) != '') {
					$mail->addAddress($singleTOEmail);
					$singleTO = $singleTOEmail;
					$iTotalEmail++;
				}
			}
		}else{
			foreach (explode(',', $toEmail) as $singleTOEmail) {
				if ($singleTOEmail != '' && trim($singleTOEmail) != '') {
					$mail->addAddress($singleTOEmail);
					$singleTO = $singleTOEmail;
					$iTotalEmail++;
				}
			}
		}
	}

	// Content
	$mail->isHTML(true);                                  // Set email format to HTML
	$mail->Subject = $vSubject;
	$mail->msgHTML($vEmailBody);
	
	// return $mail->Send()
    if($mail->Send()){
        return 1;
    }else{
        return 0;
    }

	} catch (Exception $e) {
        return 0;
	}
	//return 1;

}