// Sidebar users-list-container Calculation
function setNewTop() {
    var userListContainerTop = $('.users-list-container').offset().top;
    var newTop = $(window).height() - userListContainerTop;
    $('.users-list-container').css('height', newTop + 'px');
}
$(window).on('resize', setNewTop);
setNewTop();


// Feather Icon
$(document).ready(function () {
    feather.replace();
});

// New Chat Open Popup
$(document).ready(function () {
    $('#addNewChatModal').click(function () {
        $('.add-user-popup').addClass('active');
        adjustUserPopupHeight();
        $(window).resize(adjustUserPopupHeight);
    });

    $('#CloseNewChat').click(function () {
        $('.add-user-popup').removeClass('active');
    });

    function adjustUserPopupHeight() {
        var containerOffset = $('.add-user-popup-container').offset();
        var userPopupOffset = $('.add-user-popup-users').offset();
        var topOfferBannerHeight = userPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 22;

        $('.add-user-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }
});

// New Add Group Popup
$(document).ready(function () {
    function adjustGroupPopupHeight() {
        var containerOffset = $('.add-group-popup-container').offset();
        var groupPopupOffset = $('.add-group-popup-users').offset();
        var topOfferBannerHeight = groupPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 57;

        $('.add-group-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
        $('.add-group-popup-users').css('min-height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }

    $('#NewChatGroup').click(function () {
        $('.add-group-popup').addClass('active');
        adjustGroupPopupHeight();
        $(window).resize(adjustGroupPopupHeight);
        $("#vCreateNewGroupNext").addClass("d-none");
    });

    $('#CloseNewChat').click(function () {
        $('.add-group-popup').removeClass('active');
    });

    $('#CloseNewGroupUserModal').click(function () {
        $('.add-group-popup').removeClass('active');
    });
    
});

// New Create Group Popup
$(document).ready(function () {
    function adjustGroupPopupHeight() {
        var containerOffset = $('.create-group-popup-container').offset();
        var groupPopupOffset = $('.create-group-popup-users').offset();
        var topOfferBannerHeight = groupPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 57;

        $('.create-group-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
        $('.create-group-popup-users').css('min-height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }

    $('.add-group-popup-btn').click(function () {
        $('.create-group-popup').addClass('active');
        adjustGroupPopupHeight();
        $(window).resize(adjustGroupPopupHeight);
    });

    $('.close-new-group').click(function () {
        $('.create-group-popup').removeClass('active');
    });
});

// New Add Group Popup - Chat List Checkbox
$(document).ready(function () {
    $('#flexCheckDefault').change(function () {
        var groupUsersCheck = $(this).closest('.chat-list');
        if ($(this).is(':checked')) {
            groupUsersCheck.addClass('active');
        } else {
            groupUsersCheck.removeClass('active');
        }
    });
});

// Chat Area Calculate Height
$(window).resize(function () {
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
});

$(document).ready(function () {
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
});


$(document).ready(function () {
    // Check on page load if the checkbox is checked initially
    $('.chat-message-outer-container.select-message .selection .form-check-input').each(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        }
    });

    // Listen for changes in the checkbox state
    $('.chat-message-outer-container.select-message .selection .form-check-input').change(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        } else {
            $(this).closest('.chat-message-outer-container').removeClass('selected');
        }
    });
});

$('.message-droper-name').each(function () {
    if ($(this).text().length < 8) {
        $(this).css('width', 'auto');
    }
});


function scrollToBottom() {
    var div = document.getElementById('MessageList');
    div.scrollTop = div.scrollHeight;

    $('.chat-area').scrollTop(div.scrollHeight);

    var outerheight = $('.textarea-outer-container').outerHeight() + 32 + 24;
    $(".chat-area-bottom-space").css("padding-bottom", outerheight + 'px');
}

$(document).ready(function () {
    scrollToBottom()
})


$(".type").click(function (event) {
    event.stopPropagation(); // Prevents the click event from propagating to parent elements
    $(".type-functions").toggleClass("show");
});

$(window).on('load', function () {
    // Wait for all content to be loaded
    var height = $('.textarea-reply-container').outerHeight();
    var toolHeight = $('.toolbar').outerHeight();
    var totalHeight = height + toolHeight;
    var remainingHeight = 240 - totalHeight;

    // Set max-height of .editor
    // $('.editor').css('max-height',  '0px');
    // $('.editor.show').css('max-height', remainingHeight + 'px');
    
    $('.teatarea-file-uploadeditor').css('max-height',  '0px');
    $('.teatarea-file-upload.show').css('max-height', remainingHeight + 'px');

    // console.log(remainingHeight);
});


//Html To Text Convert for db json
let textEditorMsg="";

function removeLeadingNbspBeforeText(html, text) {
    let regex = new RegExp(`((&nbsp;|\\s)+)(?=${text})`);
    return text!=""?html.replace(regex, ''):html;
}

function updateJson() {
    const vMessage=$("#vMessage").text();
    if(vMessage!=""){
        $(".plc-holder").addClass("d-none");
    }
    const getFirstCharacter=String(vMessage).trim().substring(0, 1);
    var htmlContent = $(".editor").html();
    const NewhtmlContent=removeLeadingNbspBeforeText(""+htmlContent,getFirstCharacter);
    var encodedContent = $("<div>").text(NewhtmlContent).html();

    // console.log("htmlContent",htmlContent);

    textEditorMsg=JSON.stringify(encodedContent);

    if ($("#vMessage").find('img').length==0) {
        if(textEditorMsg=='"&lt;br&gt;"'){
            textEditorMsg="";
            $("#vMessage").html("");
        }
    }else{
        $(".plc-holder").addClass("d-none");
    }
}

$('#vLinkFetLink').keypress(function(event) {
    if (event.keyCode == 13 || event.which == 13) {
        event.preventDefault();
        $("#ApplyLinkTag").click();
    }
});

$(document).ready(function () {
    // Update JSON object on input event
    $("#vMessage").on("input", function () {
        updateJson();
    });

    // Call updateJson() initially to log the initial content
    updateJson();
});


//Index Page Js Codes

// Define emoji to image mapping
const emojiToImage = {
    "😁": "./images/emojis/beaming-face-with-smiling-eyes.png",
    "😀": "./images/emojis/grinning-face.png",
    "😇": "./images/emojis/smiling-face-with-halo.png",
    "👉🏻": "./images/emojis/backhand-index-pointing-right.png",
    "👇🏻": "./images/emojis/backhand-index-pointing-down.png",
    "👈🏻": "./images/emojis/backhand-index-pointing-left.png",
    "👆🏻": "./images/emojis/backhand-index-pointing-up.png",
    "☝🏻": "./images/emojis/index-pointing-up.png",
    "✌🏻": "./images/emojis/victory-hand.png",
    "👌🏻": "./images/emojis/ok-hand.png",
    "👍🏻": "./images/emojis/thumbs-up.png",
    "👎🏻": "./images/emojis/thumbs-down.png",
    "🙌🏻": "./images/emojis/raising-hands.png",
    "👏🏻": "./images/emojis/clapping-hands.png",
    "🙏🏻": "./images/emojis/folded-hands.png",
    "✉️": "./images/emojis/envelope.png",
    "☕": "./images/emojis/hot-beverage.png",
    "🍽️": "./images/emojis/fork-and-knife-with-plate.png",
    "🌏": "./images/emojis/globe-showing-asia-australia.png",
    "⛳": "./images/emojis/flag-in-hole.png",
    "🎯": "./images/emojis/bullseye.png",
    "💡": "./images/emojis/light-bulb.png",
    "✅": "./images/emojis/check-mark-button.png",
    "☑️": "./images/emojis/check-box-with-check.png",
    "✔️": "./images/emojis/check-mark.png",
    "❎": "./images/emojis/cross-mark-button.png",
    "❌": "./images/emojis/cross-mark.png",
    "❓": "./images/emojis/red-question-mark.png",
};

document.querySelectorAll('.bold, .italic, .underline, .strikethrough, .bulleted-list').forEach(button => {
    button.addEventListener('click', () => {
        const command = button.classList[0];

        if (button.classList.contains('active')) {
            button.classList.remove('active');
        } else {
            button.classList.add('active');
        }

        if (button.classList.contains('bulleted-list')) {
            if(textEditorMsg!='""' && textEditorMsg!=''){
                // console.log("textEditorMsg==>",textEditorMsg)
                document.execCommand('insertUnorderedList', false, null);
            }
        } else {
            document.execCommand(command, false, null);
        }
        document.querySelector('.editor').focus();
    });
});




//Link Feature Code Start
let vLinkTextSelection="";
$(document).on("click","#vLinkFeatureOption",(e)=>{
    $(".plc-holder").addClass("d-none");
    $(".type-functions").addClass("show");

    var selected = document.getSelection();
    isLinkAdded=false;
    if(selected.toString()!=""){
        $("#vTextLinkDisp").addClass("d-none");
    }else{
        $("#vTextLinkDisp").removeClass("d-none");
    }
    
    $("#vLinkText").val("");
    $("#vLinkFetLink").val("");

    const sText = selected.toString();

    if (sText) {
        const range = selected.getRangeAt(0);
        range.deleteContents();
        
        const anchor = document.createElement('a');
        anchor.href = "";
        anchor.target = "_blank";
        anchor.textContent = sText;
        anchor.id = getRandomNumbers();
        
        range.insertNode(anchor);
        
        selected.removeAllRanges();
        selected.addRange(document.createRange());
    }
})

const targetNode = document.getElementById('addLinkFeature');
const config = { attributes: true, attributeFilter: ['class'] };
let isSubmitNew=false;
const callback = (mutationsList, observer) => {
    for (let mutation of mutationsList) {
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
            const cssClassToArr=String(targetNode.classList).split(" ");
            if(!cssClassToArr.includes("show")){
                if(!isLinkAdded){
                    $('#vMessage').find('a[href=""]').each(function() {
                        $(this).replaceWith($(this).html());
                        editLinkId="";
                        $("#vUnlinkTag").addClass("d-none");
                    });
                }
            }
        }
    }
};

const observer = new MutationObserver(callback);
observer.observe(targetNode, config);

let isLinkAdded=false;
let editLinkId="";
$("#ApplyLinkTag").click(() => {
    $(".plc-holder").addClass("d-none");

    const vLinkFetLink = $("#vLinkFetLink").val();
    const vLinkText = $("#vLinkText").val();
    isLinkAdded=true;
    
    if(editLinkId!=""){
        $(".editor a").each((e,item)=>{
            if(item.id==editLinkId){
                let strLink = vLinkFetLink;
                if(!strLink.includes("https") && !strLink.includes("http")){
                    strLink="http://"+vLinkFetLink
                }

                $(item).attr("href",strLink);
                editLinkId="";
                updateJson();
                $("#vUnlinkTag").addClass("d-none");
            }
        })
    }else{
        if(vLinkFetLink!=""){
            if(vLinkText==""){
                $('#vMessage').find('a[href=""]').each(function() {
                    let strLink = vLinkFetLink;
                    if(!strLink.includes("https") && !strLink.includes("http")){
                        strLink="http://"+vLinkFetLink
                    }

                    $(this).attr('href', strLink);
                    updateJson();
                });
            }else{
                addLinkNewTagCursurPo(vLinkFetLink,vLinkText);
            }
        }
    }
});

$(document).on("click","#vUnlinkTag",()=>{
    $(".editor a").each((e,item)=>{
        if(item.id==editLinkId){
            var anchorElement = item;
            var anchorText = anchorElement.textContent || anchorElement.innerText;
            var textNode = document.createTextNode(anchorText);
            anchorElement.parentNode.replaceChild(textNode, anchorElement);
            editLinkId="";
            updateJson();
            $("#vUnlinkTag").addClass("d-none");
        }
    })

})

function getRandomNumbers() {
    const typedArray = new Uint8Array(10);
    const randomValues = window.crypto.getRandomValues(typedArray);
    return randomValues.join('');
}

$(document).on("click","#vMessage a",(e)=>{
    editLinkId=e.currentTarget.id;
    const value=e.currentTarget.getAttribute("href");

    $("#vUnlinkTag").removeClass("d-none");
    $("#vLinkFeatureOption").click();
    $("#vTextLinkDisp").addClass("d-none");
    $("#vLinkFetLink").val(value);
})


function addLinkNewTagCursurPo(link,text){
    const urlLink = link;
    const custLinkText = text;
    var htmlContent = $(".editor").html();
    htmlContent = htmlContent+`<a href="${urlLink}" target="_blank" id="${getRandomNumbers()}">${custLinkText}</a>`;

    $('#vMessage').html(htmlContent);
    $("#sendMessage").removeClass("disabled");
    updateJson();

}

//Link Feature Code End

document.querySelectorAll('.color-button').forEach(button => {
    button.addEventListener('click', () => {
        const color = button.getAttribute('data-color');

        $(".color_picker").removeClass("active");
        $(".color_picker").each((el, item) => {
            const currentColor = String($(item).data('color')).toLocaleUpperCase();
            if (currentColor == String(color).toLocaleUpperCase()) {
                $(item).addClass("active");
            }
        })

        document.execCommand('foreColor', false, color);
        document.querySelector('.editor').focus();

        button.classList.add('active');
    });
});

document.querySelectorAll('.emoji').forEach(emojiButton => {
    emojiButton.addEventListener('click', () => {
        document.querySelector('.editor').focus();
        const emoji = emojiButton.getAttribute('data-emoji');
        insertTextAtCursor(emoji);
        $("#sendMessage").removeClass("disabled");
    });
});

function insertTextAtCursor(text) {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const content = emojiToImage[text] ? `<img src="${emojiToImage[text]}" alt="${text}" style="width: 25px;">` : text;
        const node = document.createElement('span');
        node.innerHTML = content;
        range.insertNode(node);
        range.setStartAfter(node);
        selection.removeAllRanges();
        selection.addRange(range);
        updateJson();
    }
}

document.addEventListener('click', event => {
    if (!event.target.closest('.emoji-dropdown')) {
        document.querySelector('.emoji-dropdown').classList.remove('show');
    }
});

document.querySelector('.editor').addEventListener('paste', (event) => {
    event.preventDefault();
    var text = event.clipboardData.getData('text/plain')
    document.execCommand('insertText', false, text)

    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const content = text;
        const node = document.createElement('span');
        node.innerHTML = content;
        range.insertNode(node);
        range.setStartAfter(node);
        selection.removeAllRanges();
        selection.addRange(range);
        updateJson();
    }

    // $("#vMessage").html(vMessage+formattedText)
    updateJson();
    // const selection = window.getSelection();
    // document.querySelector('.editor').focus();
    // if (!selection.rangeCount) return;
    // selection.deleteFromDocument();
    // selection.getRangeAt(0).insertNode(document.createTextNode(text));
});


document.addEventListener('keydown', event => {
    //Insert Un Order List.
    if ((event.altKey && event.keyCode === 55) || (event.keyCode === 55 && navigator.platform.toUpperCase().indexOf('MAC') >= 0)) {
        document.execCommand('insertUnorderedList', false, null);
        event.preventDefault();
    }

    //Strike Through Text Apply.
    if ((event.altKey && event.shiftKey && event.keyCode === 53) || (event.shiftKey && event.keyCode === 53 && navigator.platform.toUpperCase().indexOf('MAC') >= 0)) {
        document.execCommand('strikethrough', false, null);
        event.preventDefault();
    }

    //Underline Text Apply.
    if ((event.ctrlKey || event.metaKey) && event.keyCode === 85) {
        document.execCommand('underline', false, null);
        event.preventDefault();
    }

    //Bold Text Apply.
    if ((event.ctrlKey || event.metaKey) && event.keyCode === 66) {
        document.execCommand('bold', false, null);
        event.preventDefault();
    }

    //Italic Code Apply
    if ((event.ctrlKey || event.metaKey) && event.keyCode === 73) {
        document.execCommand('italic', false, null);
        event.preventDefault();
    }
});



$(document).ready(() => {
    //Focus On Input
    $(".textarea-functions-icon").click(function () {
        $("#vMessage").focus();
    });

    //Enter type text remove placeholder
    $(".plc-holder").removeClass("d-none");
    
    $("#vMessage").on("click", () => {
        $(".plc-holder").addClass("d-none");
    })

    $("#vMessage").on("blur", () => {
        const editorText = $("#vMessage").html();
        if (editorText != "") {
            $(".plc-holder").addClass("d-none");
        } else {
            $(".plc-holder").removeClass("d-none");
        }
    })


    //Upload File Code
    $('.upload-file').click(function () {
        $('.upload-file-input').click();
    });

    $(".type.textarea-functions-icon").on("click",()=>{
        $(".plc-holder").addClass("d-none");
    })
    
    //Text Color Picker Code
    $(".color-button").click(function () {
        $(".color-button").removeClass("active");
        $(this).addClass("active");
        var color = $(this).data("color");
        $(".color-circle").css("background-color", color);
    });



    // Set initial color
    var initialColor = $(".color-button.active").data("color");
    $(".color-circle").css("background-color", initialColor);

    $(".color_picker").each((el, item) => {
        const currentColor = String($(item).data('color')).toLocaleUpperCase();
        if (currentColor == "#212121") {
            $(item).addClass("active");
        }
    })

    $(document).on("click", ".editor", (e) => {
        // const colorText = e.target.getAttribute("color");
        // $(".color_picker").removeClass("active");
        // if (colorText != "" && colorText != null) {
        //     $(".color_picker").each((el, item) => {
        //         const currentColor = String($(item).data('color')).toLocaleUpperCase();
        //         if (currentColor == String(colorText).toLocaleUpperCase()) {
        //             $(item).addClass("active");
        //         }
        //     })

        //     $(".color-circle").css("background-color", colorText);
        // } else {
        //     $(".color_picker").each((el, item) => {
        //         const currentColor = String($(item).data('color')).toLocaleUpperCase();
        //         if (currentColor == "#212121") {
        //             $(item).addClass("active");
        //         }
        //     })
        //     $(".color-circle").css("background-color", "#212121");
        // }

        // var children = e.currentTarget;

        // console.log("e.target.tagName",children)
    })

    let allTags=[];
    const findAscendingTag = (el, idName) => {
        if(el.parentNode){
            if(el.tagName!="DIV"){
                allTags.push(el.tagName);
            }
            if(el?.id === idName){
                return false;
            }else{
                findAscendingTag(el.parentNode,idName)
            }
        }else{
            return false;
        }
    }

    const tagNameAndClassObj=[
        {tagName:"I",tagNameClass:"italic"},
        {tagName:"B",tagNameClass:"bold"},
        {tagName:"U",tagNameClass:"underline"},
        {tagName:"STRIKE",tagNameClass:"strikethrough"},
        {tagName:"UL",tagNameClass:"bulleted-list"},
    ]

    var outerDiv = document.getElementById("vMessage");
    outerDiv.addEventListener("click", function(event) {
        allTags=[];
        var a = findAscendingTag(event.target, "vMessage");
    
        $(".textEditorSpecial").each((e,item)=>{
            $(item).removeClass("active");
        })

        if(allTags.length){
            tagNameAndClassObj.map((curEle,index)=>{
                if(allTags.includes(""+curEle.tagName)){
                    $(".textEditorSpecial").each((e,item)=>{
                        if($(item).hasClass(""+curEle.tagNameClass)){
                            $(item).addClass("active");
                        }
                    })
                }
            })
        }else{
            const lastTextIsNode=checkLastChildType("vMessage");

            if(lastTextIsNode=="Element"){
                allChildTag=[];
                const parentElement = document.getElementById("vMessage");
                const lastChildElem=parentElement.children;
                if(lastChildElem?.length){
                    if(lastChildElem?.length){
                        const lastChild = lastChildElem[lastChildElem.length - 1];

                        allChildTag.push(lastChild.tagName);
                        getAllChildTag(lastChild);
                        
                        tagNameAndClassObj.map((curEle,index)=>{
                            if(allChildTag.includes(""+curEle.tagName)){
                                $(".textEditorSpecial").each((e,item)=>{
                                    if($(item).hasClass(""+curEle.tagNameClass)){
                                        $(item).addClass("active");
                                    }
                                })
                            }
                        })
                    }
                }
            }
        }
    });

    let ParentTags=[];
    let colorPickerColor="#212121";
    const findAscendingTag2 = (el, idName) => {
        if(el.parentNode){
            if(el.tagName=="FONT"){
                const colorText = el.getAttribute("color");
                colorPickerColor=colorText;
            }
            if(el.tagName!="DIV"){
                ParentTags.push(el.tagName);
            }
            if(el?.id === idName){
                return false;
            }else{
                findAscendingTag2(el.parentNode,idName)
            }
        }else{
            return false;
        }
    }

    document.getElementById('vMessage').addEventListener('keyup', function() {
        var selection = document.getSelection();
        if (selection.rangeCount > 0) {
            var range = selection.getRangeAt(0);
            var container = range.startContainer;
            var parentElement = container.nodeType === 3 ? container.parentNode : container;
            ParentTags=[]
            colorPickerColor="#212121";
            $(".textEditorSpecial").each((e,item)=>{
                $(item).removeClass("active");
            })
            findAscendingTag2(parentElement,"vMessage");

            $(".color_picker").removeClass("active");
            $(".color_picker").each((el, item) => {
                const currentColor = String($(item).data('color')).toLocaleUpperCase();
                if (currentColor == String(colorPickerColor).toLocaleUpperCase()) {
                    $(item).addClass("active");
                }
            })

            $(".color-circle").css("background-color", colorPickerColor);

            if(ParentTags.length){
                tagNameAndClassObj.map((curEle,index)=>{
                    if(ParentTags.includes(""+curEle.tagName)){
                        $(".textEditorSpecial").each((e,item)=>{
                            if($(item).hasClass(""+curEle.tagNameClass)){
                                $(item).addClass("active");
                            }
                        })
                    }
                })
            }
        }
    });

    document.getElementById('vMessage').addEventListener('mouseup', function() {
        var selection = document.getSelection();
        if (selection.rangeCount > 0) {
            var range = selection.getRangeAt(0);
            var container = range.startContainer;
            var parentElement = container.nodeType === 3 ? container.parentNode : container;
            ParentTags=[]
            colorPickerColor="#212121";
            
            $(".textEditorSpecial").each((e,item)=>{
                $(item).removeClass("active");
            })

            findAscendingTag2(parentElement,"vMessage");

            $(".color_picker").removeClass("active");
            $(".color_picker").each((el, item) => {
                const currentColor = String($(item).data('color')).toLocaleUpperCase();
                if (currentColor == String(colorPickerColor).toLocaleUpperCase()) {
                    $(item).addClass("active");
                }
            })

            if(ParentTags.length==0){
                $(".textEditorSpecial").each((e,item)=>{
                    $(item).removeClass("active");
                })
            }

            $(".color-circle").css("background-color", colorPickerColor);

            if(ParentTags.length){
                tagNameAndClassObj.map((curEle,index)=>{
                    if(ParentTags.includes(""+curEle.tagName)){
                        $(".textEditorSpecial").each((e,item)=>{
                            if($(item).hasClass(""+curEle.tagNameClass)){
                                $(item).addClass("active");
                            }
                        })
                    }
                })
            }
        }
    });

    let allChildTag=[];
    function getAllChildTag(element){
        const children = element?.children;
        if (children?.length) {
            allChildTag.push(children[0].tagName);
            getAllChildTag(children[0]);
        }else{
            return false;
        }
    }

    function checkLastChildType(elementId) {
        const element = document.getElementById(elementId);
        if (!element) {
            console.error(`Element with ID ${elementId} not found`);
            return;
        }

        const lastChild = element.lastChild;
        if (lastChild?.nodeType === Node.TEXT_NODE) {
            return "Text";
        } else if (lastChild?.nodeType === Node.ELEMENT_NODE) {
            return "Element";
        } else {
            return "NotDefined";
        }
    }

    $(".color-button").click(function () {
        $(".editor").focus();
    });

    $(document).on("click",".textEditorSpecial",()=>{
        $(".plc-holder").addClass("d-none");
    })

    
})