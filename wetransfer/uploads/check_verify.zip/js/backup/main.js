//Soceket Connection Code Start
var socket = io('http://192.168.1.35:9000', {
   transports: ['websocket']
});

const isLocalStorageExist = localStorage.getItem("whatsAppClone");
if (isLocalStorageExist != null) {
   const dd = JSON.parse(isLocalStorageExist);
   socket.emit('join_msg', {
       token: dd.tToken
   });
}

//Socket Send Message Single
socket.on('send_message', function(msg) {
   // EMP => console.log("send_message msg", msg);
});


// Default Variable
let timeLineDate = "";
let ImageProfileArr = [];
let filterDateStr = "";
let activeTab = "User";

$(document).ready(function () {
    //Tab Change Code
    $(document).on("click", "#userChat", (e) => {
        activeTab = "User";
        $("#vSearchUser").val("");
        getUserList();
        $("#vSearchText").val("");
    })

    $(document).on("click", "#userGroup", (e) => {
        activeTab = "Group";
        getGroupList();
        $("#vSearchText").val("");
    })


    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    
    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
    
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetProfileData',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                const resData = data.data;
    
                if (data.status == 401) {
                    localStorage.removeItem("whatsAppClone");
                    window.location = "./login.php";
                } else {
                    if(resData.vProfilePic==""){
                        colorOption.map((curEl,index)=>{
                            if(curEl.iColorId==resData.iColorOption){
                                $("#vProfilePick").attr("xlink:href", curEl.vColorPick);
                            }
                        })
                    }else{
                        $("#vProfilePick").attr("xlink:href", API_URL + resData.vProfilePic);
                    }

                    $("#vUserName").text(resData.vFullName);
                    $("#vActiveProfileSts").val(resData.eCustStatus);
                    $("#vLoggedColorOption").val(resData.iColorOption);

                    if(resData.eCustStatus==2){
                        $("#vUserLoggedSts").text("Online");
                        $("#vLoggedSts").removeClass("offline");
                        $("#vLoggedSts").addClass("online");
                    }else{
                        if(resData.eCustStatus==1){
                            $("#vUserLoggedSts").text("Online");
                            $("#vLoggedSts").removeClass("offline");
                            $("#vLoggedSts").addClass("online");
                        }else{
                            $("#vUserLoggedSts").text("Offline");
                            $("#vLoggedSts").addClass("offline");
                            $("#vLoggedSts").removeClass("online");
                        }
                    }

                    $(".changeOnlineStst").each((e,item)=>{
                        const datId=$(item).attr("data-id");
                        if(datId==resData.eCustStatus){
                            $(item).addClass("active");
                        }else{
                            $(item).removeClass("active");
                        }
                    })
                }
            }
        });
    
        getUserList();
        getGroupList();
        getAllUserList();
    }
})

const chatUserHtmlFun = (filterData) => {
    const vActiveUserId = $("#vActiveUserId").val();

    let htmlUser = "";
    filterData.map((curEle, index) => {
        let profileImage = curEle.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2,index)=>{
                if(curEle2.iColorId==curEle.iColorOption){
                    profileImage = curEle2.vColorPick;
                }
            })
        }

        const iTotalUnReadMsg = Number(vActiveUserId == curEle.iUserId ? 0 : curEle.iTotalUnReadMsg);

        htmlUser += `
                <li>
                    <a href="javascript:;" class="chat-list ${iTotalUnReadMsg>0?'unread-chat':''} vUserIdsCls ${vActiveUserId == curEle.iUserId ? 'chat-active' : ''}" data-id='${curEle.iUserId}' data-status='${curEle.iStatus}' id="vUserIdsCls_${curEle.iUserId}">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <svg role="none" viewBox="0 0 96 96">
                                        <mask id="profile-image">
                                            <circle fill="white" cx="48" cy="48" r="48"></circle>
                                            <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                        </mask>
                                        <g mask="url(#profile-image)">
                                            <image x="0" y="0" height="100%"
                                                preserveAspectRatio="xMidYMid slice" width="100%"
                                                xlink:href="${profileImage}"></image>
                                        </g>
                                    </svg>
                                    <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                </div>
                                <div>
                                    <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                    <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                </div>
                            </div>
                            <div class="unread-message">
                                <span><img src="images/profile/unread-message.svg" alt="unread-message"></span>
                            </div>
                        </div>
                    </a>
                </li>
        `;
    })

    $("#chatUserList").append(htmlUser);
}

const chatAllUserHtmlFun = (filterData) => {
    let htmlUser = "";

    filterData.map((curEle, index) => {
        let profileImage = curEle.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2,index)=>{
                if(curEle2.iColorId==curEle.iColorOption){
                    profileImage = curEle2.vColorPick;
                }
            })
        }

        htmlUser += `<li>
                        <a href="javascript:;" class="chat-list vNewChatStart" data-id='${curEle.iUserId}' data-status='${curEle.iStatus}'>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="user-profile-image me-3">
                                        <svg role="none" viewBox="0 0 96 96">
                                            <mask id="profile-image">
                                                <circle fill="white" cx="48" cy="48" r="48">
                                                </circle>
                                                <circle fill="black" cx="86%" cy="86%" r="18">
                                                </circle>
                                            </mask>
                                            <g mask="url(#profile-image)">
                                                <image x="0" y="0" height="100%"
                                                    preserveAspectRatio="xMidYMid slice" width="100%"
                                                    xlink:href="${profileImage}">
                                                </image>
                                            </g>
                                        </svg>
                                        <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                    </div>
                                    <div>
                                        <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                        <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                    </div>
                                </div>

                                <div class="unread-message">
                                    <span><img src="images/profile/unread-message.svg"
                                            alt="unread-message"></span>
                                </div>
                            </div>
                        </a>
                    </li>`;

    })

    $("#vChatUserListAll").append(htmlUser);
}

function getUserList() {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    $("#chatUserList").html("");

    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetUserList',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    const filterData = data.data.sort((a, b) => {
                        var aLastTime = a.lastTime == "" ? 0 : Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime == "" ? 0 : Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime;
                    });

                    $("#vConvertionChatArr").val(JSON.stringify(filterData));

                    chatUserHtmlFun(filterData);
                }
            }
        });
    }
}

function getAllUserList(isNewChat = 0) {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    
    $("#vChatUserListAll").html("");

    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'GetChatUserList',
            data: {
                tToken: dd.tToken
            },
            success: function (data, status, xhr) {
                if (data.status == 200) {
                    const filterData = data.data.sort((a, b) => {
                        var aLastTime = a.lastTime == "" ? 0 : Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime == "" ? 0 : Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime;
                    });

                    if (isNewChat) {
                        chatAllUserHtmlFun(filterData);
                    } else {
                        $("#vChatUserListJson").val(JSON.stringify(filterData));
                    }
                }
            }
        });
    }
}

$(document).on("click", "#addNewChatModal", () => {
    $("#SearchUserAllInp").val("");
    getAllUserList(1)
})

//Search Chat User
function searchChatUser(serachText) {
    let vConvertionChatArr = $("#vConvertionChatArr").val();
    
    if (vConvertionChatArr != "") {
        const ChatUserListArr = JSON.parse(vConvertionChatArr);

        $("#chatUserList").html("");
        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(serachText).toLocaleLowerCase());
        })

        chatUserHtmlFun(filterData);
    } else {
        $("#chatUserList").html("");
    }
}

$("#vSearchUser").on('input', (e) => {
    searchChatUser(e.target.value);
})

//Search All User New Chat
function searchChatAllUser(serachText) {
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        $("#vChatUserListAll").html("");
        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(serachText).toLocaleLowerCase());
        })

        chatAllUserHtmlFun(filterData);
    } else {
        $("#vChatUserListAll").html("");
    }
}

$("#SearchUserAllInp").on("input", (e) => {
    searchChatAllUser(e.target.value);
})

//Group List Code
const GroupHtmlFunc=(filterData)=>{
    const vActiveGroupId=$("#vActiveGroupId").val();

    filterData.map((curEle, index) => {
        const totalMember=String(curEle.tGroupUsers).split(",");
        const totalMemberCnt=totalMember.filter(curEle=>curEle);
        const filterColorOption=colorOption.filter((curEle2,index)=>{
            return curEle2.iColorId==curEle.iColorOption
        })

        const vColorOptionImg=filterColorOption.length?filterColorOption[0]['vColorPick']:""

        if(vActiveGroupId==curEle.iGroupId){
            $("#activeChatStsDisp").text(totalMemberCnt.length+" Members");
        }

        let html=`<li>
                    <a href="javascript:;" class="chat-list vGroupIds ${curEle.iTotalUnReadMsg>0 && vActiveGroupId!=curEle.iGroupId?'unread-chat':''} ${vActiveGroupId==curEle.iGroupId?'chat-active':''}" data-id='${curEle.iGroupId}'> 
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <img src="${curEle.vGroupImage==""?vColorOptionImg:curEle.vGroupImage}" alt="group-profile" class="rounded-2">
                                </div>
                                <div>
                                    <h5 class="user-profile-name">${curEle.vGroupName}</h5>
                                    <P class="user-profile-activity">${totalMemberCnt.length} Members</P>
                                </div>
                            </div>

                            <div class="unread-message">
                                <span><img src="images/profile/unread-message.svg"
                                        alt="unread-message"></span>
                            </div>
                        </div>
                    </a>
                </li>`;

        $("#ChatGroupList").append(html);
    })
}

function getGroupList(){
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    //Get User List
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        $(".vGroupIds").remove();
        $(".vUserIdsCls").remove();

        $("#ChatGroupList").html("");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL+'GetGroupList',
            data: {
                tToken: dd.tToken
            },
            success: function(data, status, xhr) {
                if (data.status == 200) {                    
                    const filterData=data.data.sort((a, b) => {
                        var aLastTime = a.lastTime==""?0:Number(Date.parse(new Date(a.lastTime)));
                        var bLastTime = b.lastTime==""?0:Number(Date.parse(new Date(b.lastTime)));

                        return bLastTime - aLastTime ;
                    });
                    
                    $("#vChatGroupListJson").val(JSON.stringify(filterData));
                    
                    if(activeTab == "Group"){
                        GroupHtmlFunc(filterData);
                    }
                }
            }
        });
    }
}

function searchGroupName(serachText) {
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();

    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);

        $("#ChatGroupList").html("");
        const filterData = chatGroupList.filter((curEle, index) => {
            const vGroupName = String(curEle.vGroupName).toLocaleLowerCase();
            return vGroupName.includes(String(serachText).toLocaleLowerCase());
        })

        GroupHtmlFunc(filterData);
    } else {
        $("#ChatGroupList").html("");
    }
}

$("#searchGroupName").on("input", (e) => {
    searchGroupName(e.target.value);
})

function NewGroupUserHtml(dataArr){
    $("#NewGroupUserList").html("");

    const vNewGrpUserSelect=$("#vNewGrpUserSelect").val();
    const UserSelectListArr=vNewGrpUserSelect!=""?String(vNewGrpUserSelect).split(","):[];

    let htmlUser = "";
    dataArr.map((curEle, index) => {
        let profileImage = curEle.vProfilePic;
        if (profileImage == "") {
            colorOption.map((curEle2,index)=>{
                if(curEle2.iColorId==curEle.iColorOption){
                    profileImage = curEle2.vColorPick;
                }
            })
        }

        let isChecked=UserSelectListArr.includes(""+curEle.iUserId);

        htmlUser += `<li>
            <a href="javascript:;" class="chat-list">
                <label class="d-flex align-items-center justify-content-between form-check ps-0"
                    for="NewGroupUserChbx_${curEle.iUserId}">
                    <div class="d-flex align-items-center">
                        <div class="user-profile-image me-3">
                            <svg role="none" viewBox="0 0 96 96">
                                <mask id="profile-image">
                                    <circle fill="white" cx="48" cy="48" r="48">
                                    </circle>
                                    <circle fill="black" cx="86%" cy="86%" r="18">
                                    </circle>
                                </mask>
                                <g mask="url(#profile-image)">
                                    <image x="0" y="0" height="100%"
                                        preserveAspectRatio="xMidYMid slice" width="100%"
                                        xlink:href="${profileImage}">
                                    </image>
                                </g>
                            </svg>
                            <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                        </div>
                        <div>
                            <h5 class="user-profile-name">${curEle.vFullName}</h5>
                            <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                        </div>
                    </div>

                    <span>
                        <input class="form-check-input NewGroupUserChbx" type="checkbox" value="${curEle.iUserId}" id="NewGroupUserChbx_${curEle.iUserId}" ${isChecked?'checked':''}>
                    </span>
                </label>
            </a>
        </li>`;
    })
    $("#NewGroupUserList").html(htmlUser);
}

$("#CreateNewGroup").on("click",()=>{
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    // vGroupProfilePick=[];
    tempFilename="";
    finalProfilePick="";
    finalColorSelection="";

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);
        NewGroupUserHtml(ChatUserListArr);
    } else {
        $("#NewGroupUserList").html("");
    }
})

$("#SeachNewGroupUser").on("input",(e)=>{
    let vChatUserListJsonArr = $("#vChatUserListJson").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        const filterData = ChatUserListArr.filter((curEle, index) => {
            const vFullName = String(curEle.vFullName).toLocaleLowerCase();
            return vFullName.includes(String(e.target.value).toLocaleLowerCase());
        })

        NewGroupUserHtml(filterData);
    } else {
        $("#NewGroupUserList").html("");
    }
})

$(document).on("change",".NewGroupUserChbx",(e)=>{
    const iUserId=e.target.value;
    const vNewGrpUserSelect=$("#vNewGrpUserSelect").val();
    const UserSelectListArr=vNewGrpUserSelect!=""?String(vNewGrpUserSelect).split(","):[];

    if(e.target.checked){
        UserSelectListArr.push(iUserId);
        $("#vNewGrpUserSelect").val(UserSelectListArr.join(","));

        if(UserSelectListArr.length>0){
            $("#vCreateNewGroupNext").removeClass("d-none");
        }else{
            $("#vCreateNewGroupNext").addClass("d-none");
        }
    }else{
        const filterNewData=UserSelectListArr.filter((curEle,index)=>{
            return Number(curEle)!=Number(iUserId)
        })

        $("#vNewGrpUserSelect").val(filterNewData.join(","));
        
        if(filterNewData.length>0){
            $("#vCreateNewGroupNext").removeClass("d-none");
        }else{
            $("#vCreateNewGroupNext").addClass("d-none");
        }
    }
})



$(document).on("click","#CloseNewGroupUserModal",()=>{
    $("#vNewGrpUserSelect").val("");
})

//New Group Create Sidebar Code Start

$(document).on("click","#vCreateNewGroupNext",()=>{
    $("#vNewGroupOwnName").text($("#vUserName").text());
    $("#vNewGrpOwnImg").attr("xlink:href",$("#vProfilePick").attr("xlink:href"));
    // $("#vUserLoggedSts").text();

    getListMemberSelect();

    $("#vGroupName").closest("div").removeClass("error-cust");

    const randNumber=getRandomInt(4);

    finalColorSelection=randNumber

    const filterColorOption=colorOption.filter((curEle2,index)=>{
        return curEle2.iColorId==randNumber
    })

    if(filterColorOption.length>0){
        $("#vGroupPicSelected").attr("src",filterColorOption[0]['vColorPick']);
    }

})


function getListMemberSelect(){
    const vNewGrpUserSelect=$("#vNewGrpUserSelect").val();
    const UserSelectListArr=vNewGrpUserSelect!=""?String(vNewGrpUserSelect).split(","):[];

    const getAllUsers=$("#vChatUserListJson").val();
    const getAllUsersList=getAllUsers!=""?JSON.parse(getAllUsers):[];

    let htmlUser="";

    getAllUsersList.map((curEle,index)=>{
        if(UserSelectListArr.includes(""+curEle.iUserId)){
            let profileImage = curEle.vProfilePic;
            if (profileImage == "") {
                colorOption.map((curEle2,index)=>{
                    if(curEle2.iColorId==curEle.iColorOption){
                        profileImage = curEle2.vColorPick;
                    }
                })
            }

            htmlUser+=`<li id="delGroupNewMemb_${curEle.iUserId}">
                            <a href="javascript:;" class="chat-list">
                                <label class="d-flex align-items-center justify-content-between form-check ps-0"
                                    for="flexCheckDefault2">
                                    <div class="d-flex align-items-center">
                                        <div class="user-profile-image me-3">
                                            <svg role="none" viewBox="0 0 96 96">
                                                <mask id="profile-image-${curEle.iUserId}">
                                                    <circle fill="white" cx="48" cy="48" r="48">
                                                    </circle>
                                                    <circle fill="black" cx="86%" cy="86%" r="18">
                                                    </circle>
                                                </mask>
                                                <g mask="url(#profile-image-${curEle.iUserId})">
                                                    <image x="0" y="0" height="100%"
                                                        preserveAspectRatio="xMidYMid slice" width="100%"
                                                        xlink:href="${profileImage}">
                                                    </image>
                                                </g>
                                            </svg>
                                            <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                        </div>
                                        <div>
                                            <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                            <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                        </div>
                                    </div>
                        
                                    <span><input class="form-check-input form-check-cross delGroupNewMemb" type="checkbox"
                                            value="${curEle.iUserId}" id="flexCheckDefault2"></span>
                                </label>
                            </a>
                        </li>`;
        }
    })

    $("#newGroupMember").html(htmlUser);
    $("#vGroupUserErr").addClass("d-none");
}

$(document).on("click",".delGroupNewMemb",(e)=>{
    const iUserId=Number(e.target.value);

    if(iUserId>0){
        const vNewGrpUserSelect=$("#vNewGrpUserSelect").val();
        const UserSelectListArr=vNewGrpUserSelect!=""?String(vNewGrpUserSelect).split(","):[];

        const filterNewData=UserSelectListArr.filter((curEle,index)=>{
            return Number(curEle)!=Number(iUserId)
        })

        
        if(filterNewData.length==0){
            $("#groupMemberModal").modal("toggle");
            // alert("Atleast one memeber required for group.");
            e.preventDefault();
        }else{
            $("#delGroupNewMemb_"+iUserId).remove();
            $("#NewGroupUserChbx_"+iUserId).prop("checked",false)
            $("#vNewGrpUserSelect").val(filterNewData.join(","));
        }
    }
})

$(document).on("click","#groupMemberModalSubmit,#groupMemberModalClose",()=>{
    $("#groupMemberModal").modal("toggle");
})

$(document).on("click","#AddNewGroup",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    const vGroupName=$("#vGroupName").val();
    const tDescription=$("#tDescription").val();
    const vUsers=$("#vNewGrpUserSelect").val();
    if (isLocalStorageExist != null && vGroupName!="" && vUsers!="") {
        const dd = JSON.parse(isLocalStorageExist);
        $("#vGroupName").closest("div").addClass("error-cust");
        $("#vGroupUserErr").addClass("d-none");

        const vGroupProfilePick=[{fileName:tempFilename,imageData:finalProfilePick}];

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL+'AddNewGrp',
            data: {
                tToken: dd.tToken,
                vGroupName,
                tDescription,
                vUsers, 
                vActiveGroupId:0, 
                vGroupProfile:vGroupProfilePick,
                ColorOptionSelect:finalColorSelection,
                isDeleteFile:0
            },
            success: function(data, status, xhr) {
                if (data.status == 200) {  
                    $("#vGroupName").val("");        
                    $("#tDescription").val("");        
                    $("#vNewGrpUserSelect").val("");     

                    $(".add-user-popup").removeClass("active");
                    $(".add-group-popup").removeClass("active");
                    $(".create-group-popup").removeClass("active");

                    getGroupList();

                    tempFilename="";
                    finalProfilePick="";
                    finalColorSelection="";
                }
            }
        });
    }else{
        if(vGroupName==""){
            $("#vGroupName").closest("div").addClass("error-cust");
        }

        if(vUsers==""){
            $("#vGroupUserErr").removeClass("d-none");
        }
    }
})

// let vGroupProfilePick=[];
// $(document).on("change","#vGroupPicture",(e)=>{
//     var file = e.target.files[0];

//     if (file.type.match('image.*')) {
//         var reader = new FileReader();
//         reader.onload = function (e) {
//             var image = new Image();

//             image.src = e.target.result;
//             image.onload = function () {
//                 var height = this.height;
//                 var width = this.width; 
//             }

//             $('#vGroupPicSelected').attr('src', e.target.result);
//             vGroupProfilePick=[{fileName:file.name,imageData:e.target.result}];
//         }

//         reader.readAsDataURL(file);
//     } else {
//         $('#vGroupPicSelected').attr('src', 'images/profile/group-profile.svg');
//     }
// })
//New Group Create Sidebar Code End

//User Chat Code Start
$(document).on("click", ".vUserIdsCls", (e) => {
    timeLineDate = "";
    filterDateStr = "";

    // activeChatProfile

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");

    $("#GroupDropDown").addClass("d-none");
    $(".vUserIdsCls").removeClass("chat-active");
    $(e.currentTarget).addClass("chat-active");
    $("#MessageList").html("");
    $("#vSearchText").val("");
    $("#vMessage").html('<span class="placeholder">Type your text here...</span>');

    $("#StartChatArea").addClass("d-none");
    $("#HeaderChatArea").removeClass("d-none");
    $("#MainChatArea").removeClass("d-none");
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

    iEditMsgId="";
    vEditMsgText="";
    vEditMsgType="";
    vEditMessageMainId="";

    $("#fileUploadDiv").removeClass("show");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");
    ImageDataArr = [];


    const iUserId = $(e.currentTarget).data('id');
    const UserStatus = $(e.currentTarget).data('status') == 1 ? 'Online' : 'Offline';

    const vConvertionChatArr = $("#vConvertionChatArr").val();
    const UserList = JSON.parse(vConvertionChatArr);

    UserList.map((curEle, index) => {
        if (curEle.iUserId == iUserId) {
            if (curEle.vProfilePic != "") {
                $("#activeChatProfile").attr("xlink:href", curEle.vProfilePic)
            }else{
                colorOption.map((curEle2,index)=>{
                    if(curEle2.iColorId==curEle.iColorOption){
                        $("#activeChatProfile").attr("xlink:href", curEle2.vColorPick)
                    }
                })
            }

            $("#vActiveUserId").val(iUserId);
            $("#vActiveGroupId").val('');

            if (filterDateStr == "") {
                if (curEle?.lastDate && curEle?.lastDate != "") {
                    filterDateStr = curEle.lastDate;
                }
            }

            $("#vUserIdsCls_" + iUserId).removeClass("unread-chat");
            if(UserStatus=="Online"){
                $("#activeChatSts").removeClass("offline");
                $("#activeChatSts").addClass("online");
            }else{
                $("#activeChatSts").removeClass("online");
                $("#activeChatSts").addClass("offline");
            }
            $("#activeChatName").text(curEle.vFullName);
            $("#activeChatStsDisp").text(UserStatus);

            getMessageFunc(curEle.iUserId, filterDateStr);
        }
    })
})

//Group Chat Message Start
$(document).on("click",".vGroupIds",(e)=>{
    $(".vGroupIds").removeClass("chat-active");
    $(e.currentTarget).addClass("chat-active");

    timeLineDate = "";
    filterDateStr = "";

    iEditMsgId="";
    vEditMsgText="";
    vEditMsgType="";
    vEditMessageMainId="";

    $("#fileUploadDiv").removeClass("show");
    $(".type-link").removeClass("d-none");
    $(".emoji-link").removeClass("d-none");
    ImageDataArr = [];

    $("#GroupDropDown").removeClass("d-none");
    $("#vMessage").html('<span class="placeholder">Type your text here...</span>');

    $("#vGroupTabActive").removeClass("d-none");
    $("#vUseTabActive").addClass("d-none");
    $("#vSearchText").val("");

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");

    $("#StartChatArea").addClass("d-none");
    $("#HeaderChatArea").removeClass("d-none");
    $("#MainChatArea").removeClass("d-none");
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");

    const iGroupId = $(e.currentTarget).data('id');

    const vChatGroupListJson = $("#vChatGroupListJson").val();
    const GroupList = JSON.parse(vChatGroupListJson);
    $("#MessageList").html("");
    
    $("#vReplyMsg").val("");
    $("#vReplyMsg_id").val("");
    $("#vReplyMsg_type").val("");
    $("#vReplyFileName").val("");

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        GroupList.map((curEle, index) => {
            if (curEle.iGroupId == iGroupId) {
                const totalMember=String(curEle.tGroupUsers).split(",");
                $("#activeChatName").text(curEle.vGroupName);

                // $("#activeChatUsrDetail").html(curEle.vGroupName + "<br><span id='mainUserStats'>Online</span><span class='typingIndicator d-none' id='typingIndicator'>Typing...</span>");
                const filterColorOption=colorOption.filter((curEle2,index)=>{
                    return curEle2.iColorId==curEle.iColorOption
                })

                if (curEle.vGroupImage != "") {
                    $("#activeGroupProfile").attr("src", curEle.vGroupImage)
                }else{
                    $("#activeGroupProfile").attr("src",filterColorOption[0]['vColorPick'])
                }

                $("#activeGroupProfile").removeClass("rounded-circle");
                $("#activeGroupProfile").addClass("rounded-2");

                $("#activeChatStsDisp").text(totalMember.length+" Members");

                $("#vActiveGroupId").val(iGroupId);
                $("#vActiveUserId").val("");

                socket.emit('join_group', {
                    iGroupId
                });

                if (filterDateStr == "") {
                    if (curEle?.lastDate && curEle?.lastDate != "") {
                        filterDateStr = curEle.lastDate;
                    }
                }

                GetGroupMessage(dd, iGroupId, filterDateStr, 0);
            }
        })
    }
})


const dateTimeLineAdd = (created_at = "", isSecond = 0) => {
    if (created_at == "") {
        timeLineDate = getCurrentDate();

        const NewId = dateDispl(timeLineDate).replaceAll(" ", "_");

        let htmlDate = `<div class="chat-time-line" id="${NewId}">
                            <p>${dateDispl(timeLineDate)}</p>
                        </div>`;
        if (isSecond) {
            $("#MessageList").prepend(htmlDate);
        } else {
            $("#MessageList").append(htmlDate);
        }

    } else {
        if (timeLineDate != String(created_at).split(" ")[0]) {
            timeLineDate = String(created_at).split(" ")[0];
            const NewId = dateDispl(timeLineDate).replaceAll(" ", "_");

            let htmlDate = `<div class="chat-time-line" id="${NewId}">
                                <p>${dateDispl(timeLineDate)}</p>
                            </div>`;

            if (isSecond) {
                $("#MessageList").prepend(htmlDate);
            } else {
                $("#MessageList").append(htmlDate);
            }
        }
    }
}

const replyHtmlFunc = (vReplyMsg_id, vReplyMsg,vReplyFileName="",isSend = 0) => {
    let replyHtml = "";

    if (((vReplyMsg_id && vReplyMsg_id != "") || isSend) && vReplyMsg != "") {

        if(String(vReplyMsg).includes("base64,") || String(vReplyMsg).includes("vImages =>") || String(vReplyMsg).includes("images/uploads")){
            if(String(vReplyMsg).includes("base64,")){

                let imagePath =String(vReplyMsg).trim();
                if (String(vReplyMsg).includes("vImages =>")) {
                    imagePath = String(vReplyMsg).split("vImages =>");
                } else if (String(vReplyMsg).includes("images/uploads")) {
                    imagePath = vReplyMsg;
                }

                imagePath=typeof imagePath=="string"?imagePath:String(imagePath[1]).trim();

                const dotIndex = vReplyFileName.lastIndexOf('.');
                const type = vReplyFileName.substring(dotIndex + 1);

                const imageArr=["jpg","png","jpeg"];

                const fileName=String(vReplyFileName).split(".");

                if(imageArr.includes(""+type)){
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">You</p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-image-preview">
                                            <img src="${imagePath}" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileName[0]).substring(0,50)+fileName[0].length>100?'...':''+"."+fileName[1]}</p>
                                    </div>
                                </div>`
                }else{
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">You</p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-file-preview">
                                            <img src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileName[0]).substring(0,50)+fileName[0].length>100?'...':''+"."+fileName[1]}</p>
                                    </div>
                                </div>`;
                }

                // replyHtml =`<div class="message-reply-chat">
                //                 <p class="mb-0 name">You</p>
                //                 <div class="d-flex align-items-center">
                //                     <div class="message-image-preview">
                //                         <!-- For Nothing - message-preview -->
                //                         <!-- For Image - message-image-preview -->
                //                         <!-- For File - message-file-preview -->
                //                         <img src="${imagePath}" alt="File">
                //                     </div>
                //                     <p class="mb-0 message">Master_image_preview_updated.png</p>
                //                 </div>
                //             </div>`;
            }else{
                let imagePath = "";
                if (String(vReplyMsg).includes("vImages =>")) {
                    imagePath = String(vReplyMsg).split("vImages =>");
                } else if (String(vReplyMsg).includes("images/uploads")) {
                    imagePath = vReplyMsg;
                }

                imagePath=typeof imagePath=="string"?imagePath:imagePath[1];

                const dotIndex = imagePath.lastIndexOf('.');
                const type = imagePath.substring(dotIndex + 1);

                const imageArr=["jpg","png","jpeg"];

                const fileName=getFileName(String(imagePath).trim());

                const fileNameNew=String(fileName).split(".");

                if(imageArr.includes(""+type)){
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">You</p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-image-preview">
                                            <img src="${API_URL+String(imagePath).trim()}" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileNameNew[0]).substring(0,50)+fileNameNew[0].length>100?'...':''+"."+fileNameNew[1]}</p>
                                    </div>
                                </div>`
                }else{
                    replyHtml = `<div class="message-reply-chat">
                                    <p class="mb-0 name">You</p>
                                    <div class="d-flex align-items-center">
                                        <div class="message-file-preview">
                                            <img src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <p class="mb-0 message">${String(fileNameNew[0]).substring(0,50)+fileNameNew[0].length>100?'...':''+"."+fileNameNew[1]}</p>
                                    </div>
                                </div>`;
                }
            }
        }else{
            replyHtml = `<div class="message-reply-chat">
                            <p class="mb-0 name">You</p>
                            <div class="d-flex align-items-center">
                                <p class="mb-0 message">${String(htmlDecode(vReplyMsg)).substring(0,50)+"..."}</p>
                            </div>
                        </div>`
        }
    }

    return replyHtml;
}

const StringDisplLimit=(str,limit)=>{
    if(String(str).length>limit){
        return String(str).substring(0,limit)+"..."
    }else{
        return String(str).trim()
    }
}

const ImageOrFileDipHtml = (filePath,base64Name="") => {
    let imageHtml = "";

    if(base64Name!=""){
        const trimPath = String(base64Name).trim();
        const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

        const fileNameNew=String(trimPath).split(".");

        if (ImageExtensionArr.includes(get_url_extension(trimPath))) {
            imageHtml=`<div class="d-flex align-items-center">
                            <div class="message-image-preview">
                                <img src="${filePath}" alt="File">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0],50)+'.'+fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="${filePath}" target="_blank" class="file-action-btn"><i data-feather="eye" class="feather-20"></i></a>
                            </li>
                            <li>
                                <a href="javascript:;" class="file-action-btn vFileDownload" data-id="${filePath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        }else{
            imageHtml=`<div class="d-flex align-items-center">
                            <div class="message-file-preview">
                                <img src="./images/svgs/file.svg" alt="File">
                            </div>
                            <p class="mb-0"><p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0],50)+'.'+fileNameNew[1]}</p>
                            </p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="javascript:;" class="file-action-btn vFileDownload" data-id="${filePath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        }

    }else{
        const trimPath = String(filePath).trim();
        
        const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

        const fileNameNew=String(getFileName(trimPath)).split(".");

        if (ImageExtensionArr.includes(get_url_extension(trimPath))) {
            imageHtml=`<div class="d-flex align-items-center">
                            <div class="message-image-preview">
                                <img src="${API_URL+trimPath}" alt="File">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0],50)+'.'+fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="${API_URL+trimPath}" target="_blank" class="file-action-btn"><i data-feather="eye" class="feather-20"></i></a>
                            </li>
                            <li>
                                <a href="javascript:;" class="file-action-btn vFileDownload" data-id="${API_URL+trimPath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        } else {
            imageHtml=`<div class="d-flex align-items-center">
                            <div class="message-file-preview">
                                <img src="./images/svgs/file.svg" alt="File">
                            </div>
                            <p class="mb-0 message-text">${StringDisplLimit(fileNameNew[0],50)+'.'+fileNameNew[1]}</p>
                        </div>
                        <ul class="file-action-btn-container mb-0">
                            <li>
                                <a href="javascript:;" class="file-action-btn vFileDownload" data-id="${API_URL+trimPath}"><i data-feather="download" class="feather-20"></i></a>
                            </li>
                        </ul>`;
        }
    }


    return imageHtml;
}

const floatingDrop=(id,msg,type,dateTime,isSend,fileName="")=>{
    let deleteButton='';
    let editButton='';
    if(isSend==1){
        deleteButton=`<li>
                        <a class="dropdown-item deleteMsgSingle" href="javascript:void(0)" data-id='${id}' data-msg='${msg}' data-type="${type}" data-time="${dateTime}"><i data-feather="trash-2" class="feather-20 delete"></i> Delete</a>
                    </li>`;
        if(type=="text"){
            editButton=`<li>
                            <a class="dropdown-item EditMessage" href="javascript:void(0)" data-id='${id}' data-msg='${msg}' data-type="${type}" data-filename="${fileName}" data-time="${dateTime}"><i data-feather="edit-3" class="feather-20"></i>
                                Edit</a>
                        </li>`;
        }
    }
    return `<div class="floating-dd">
                <div class="dropdown dropup">
                    <div class="dropdown-btn" data-bs-toggle="dropdown" class="cursor-pointer">
                        <span>
                            <i data-feather="more-vertical" class="feather-20"></i>
                        </span>
                    </div>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item selectMultiple" href="javascript:void(0)"><i data-feather="check-circle" class="feather-20"></i>
                                Select</a>
                        </li>
                        <li>
                            <div class="dropdown-line"></div>
                        </li>
                        ${editButton}
                        <li>
                            <a class="dropdown-item replyIcon" href="javascript:void(0)" data-id='${id}' data-msg='${msg}' data-type="${type}" data-filename="${fileName}" data-time="${dateTime}"><i data-feather="corner-up-left" class="feather-20"></i> Reply</a>
                        </li>
                        <li>
                            <a class="dropdown-item forwardIcon" data-bs-toggle="modal" data-bs-target="#forwardModal" href="javascript:void(0)" data-id='${id}' data-msg='${msg}' data-type="${type}" data-time="${dateTime}"><i data-feather="corner-up-right" class="feather-20"></i> Forward</a>
                        </li>
                        ${deleteButton}
                    </ul>
                </div>
            </div>`;
}

const deleteMessageHtml=(mesgDate,isSend)=>{
    return `<div class="chat-message-outer-container recieve-message unread message-deleted">
                <div class="chat-message-inner-container">
                    <div class="chat-message-container">
                        <div class="d-flex">
                            <img src="images/svgs/delete-message.svg" class="chat-message-profile"
                                alt="chat-message-profile">
                            <div class="main-message message-deleted">
                                <div class="d-flex align-items-center message-author">
                                    <p class="message-droper-name">Message deleted by its author</p>
                                    <p class="message-drop-time">${timestampToAMPM(mesgDate)}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`
}

const getMessageFunc = (iUserId, filterDateStrVar = "", isSecond = 0) => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        socket.emit('messageReadUpdate', {
            iFromUserId:dd.iLoginId,
            iToUserId:iUserId
        });

        const activeChatName=$("#activeChatName").text();
        const vProfilePick=$("#vProfilePick").attr("xlink:href");
        const activeChatProfile=$("#activeChatProfile").attr("xlink:href");
        $("#vGroupTabActive").addClass("d-none");
        $("#vUseTabActive").removeClass("d-none");

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL+'GetMessage',
            data: {
                tToken: dd.tToken,
                iUserId: iUserId,
                filterDateStr: filterDateStrVar==""?iUserId+"_"+oneMonthBackDate("")+".json":filterDateStrVar
            },
            success: function(data, status, xhr) {
                if (data.status == 200) {

                    filterDateStr = data.dLastDate;

                    if(data.userStatus==1){
                        $("#activeChatSts").removeClass("offline");
                        $("#activeChatSts").addClass("online");
                    }else{
                        $("#activeChatSts").removeClass("online");
                        $("#activeChatSts").addClass("offline");
                    }

                    $("#activeChatStsDisp").text(data.userStatus==1?'Online':'Offline');


                    JSON.parse(data.data).map((curEle2, index) => {
                        let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2?.vReplyMsg,curEle2?.vReplyFileName);

                        if (curEle2.iToUserId == dd.iLoginId) {

                            if (curEle2.message.includes('vImages =>')) {
                                
                                let removePrefix = curEle2.message;
                                const myImageStr = removePrefix.split("vImages =>");
                                if (myImageStr.length > 0) {
                                    const myImageArr = myImageStr[1].split(",");
                                    if (myImageArr.length > 0) {
                                        myImageArr.map((curEle, index) => {
                                            const trimPath = String(curEle).trim();
                                            
                                            const imageHtml = ImageOrFileDipHtml(trimPath);
                                            
                                            let html="";

                                            if(curEle2.iDeleted==1){
                                                html=deleteMessageHtml(""+curEle2.created_at,0);
                                            }else{
                                                html=`<div class="chat-message-outer-container recieve-message message-reply read">
                                                                <div class="selection">
                                                                    <input class="form-check-input forwardChbx d-none" data-from="0" type="checkbox" value="${trimPath}"  id="${curEle2.id}" data-type="image">
                                                                </div>
                                                                <div class="chat-message-inner-container">
                                                                    <div class="chat-message-container">
                                                                        <div class="main-message">
                                                                            <img src="${activeChatProfile}" class="chat-message-profile" alt="chat-message-profile">
                                                                            <div>
                                                                                <div class="chat-message-alignment">
                                                                                    <div class="chat-message">
                                                                                        ${replyHtml}
                                                                                        <div class="d-flex align-items-center justify-content-between">
                                                                                            <div class="d-flex align-items-center">
                                                                                                ${imageHtml}
                                                                                            </div>
                                                                                            ${floatingDrop(curEle2.id,trimPath,"image",curEle2.created_at,0,trimPath)}
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="d-flex align-items-center message-author">
                                                                                    <p class="message-droper-name">${activeChatName}</p>
                                                                                    <p class="message-drop-time">${timestampToAMPM(""+curEle2.created_at)}</p>
                                                                                    <div class="message-status"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>`;
                                                            
                                            }
                                            // let html = `<div class="message-box friend-message">
                                            //                             <p>${replyHtml} ${imageHtml} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}</span></p>
                                            //                             ${forwardHtmlFunc(curEle2.id,curEle,"image")}
                                            //                             ${replyIconHtml(curEle2.id,curEle,"image")}
                                            //                             <input type="checkbox" data-type="image" class="forwardChbx d-none" data-from="0" value="${trimPath}"  id="${curEle2.id}" />
                                            //                     </div>`;

                                            if (!isSecond) {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);
                                                $("#MessageList").append(html);
                                                feather.replace();
                                                scrollToBottom();
                                                dynamicWithlabel();
                                            } else {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);
                                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");

                                                $("#" + NewId).after(html);
                                                feather.replace();
                                                dynamicWithlabel();
                                            }
                                        })
                                    }
                                }
                            } else {   

                                let html="";
                                if(curEle2.iDeleted==1){
                                    html=deleteMessageHtml(""+curEle2.created_at,0);
                                }else{
                                    const doc = curEle2.message;

                                    html = `<div class="chat-message-outer-container recieve-message message-reply read">
                                                    <div class="selection">
                                                        <input class="form-check-input forwardChbx d-none" data-from="0" type="checkbox" value="${curEle2.message}"  id="${curEle2.id}" data-type="text">
                                                    </div>
                                                    <div class="chat-message-inner-container">
                                                        <div class="chat-message-container">
                                                            <div class="main-message">
                                                                <img src="${activeChatProfile}" class="chat-message-profile" alt="chat-message-profile">
                                                                <div>
                                                                    <div class="chat-message-alignment">
                                                                        <div class="chat-message">
                                                                            ${replyHtml}
                                                                            <div class="d-flex align-items-center justify-content-between">
                                                                                <div class="d-flex align-items-center">
                                                                                    <div class="mb-0 message-text" id="msg_${curEle2.id}">${htmlDecode(doc)}</div>
                                                                                </div>
                                                                                ${floatingDrop(curEle2.id,curEle2.message,"text",curEle2.created_at,0)}
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex align-items-center message-author">
                                                                        <p class="message-droper-name">${activeChatName}</p>
                                                                        <p class="message-drop-time">${timestampToAMPM(""+curEle2.created_at)}</p>
                                                                        <div class="message-status"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>`;
                                }
                                // let html = `<div class="message-box friend-message">
                                //                     <p>${replyHtml}${curEle2.message} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}</span></p>
                                //                     ${forwardHtmlFunc(curEle2.id,curEle2.message,"text")}
                                //                     ${replyIconHtml(curEle2.id,curEle2.message,"text")}
                                //                     <input type="checkbox" class="forwardChbx d-none" data-type="text" data-from="0" value="${curEle2.message}" id="${curEle2.id}" />
                                //                 </div>`;

                                if (!isSecond) {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    feather.replace();
                                    scrollToBottom();
                                    dynamicWithlabel();

                                } else {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                    $("#" + NewId).after(html);
                                    feather.replace();
                                    dynamicWithlabel();
                                }
                            }

                        }else if (curEle2.iFromUserId == dd.iLoginId) {
                            if (curEle2.message.includes('vImages =>')) {
                                let removePrefix = curEle2.message;
                                const myImageStr = removePrefix.split("vImages =>");
                                if (myImageStr.length > 0) {
                                    const myImageArr = myImageStr[1].split(",");
                                    if (myImageArr.length > 0) {
                                        myImageArr.map((curEle, index) => {

                                            const imageHtml = ImageOrFileDipHtml(curEle);

                                            const blueTick=curEle2.iReadTo==1?'read':'unread';

                                            let html="";
                                            if(curEle2.iDeleted==1){
                                                html=deleteMessageHtml(""+curEle2.created_at,1);
                                            }else{
                                                html=`<div class="chat-message-outer-container send-message message-reply ${blueTick}">
                                                                <div class="selection">
                                                                    <input class="form-check-input forwardChbx d-none" data-from="1" type="checkbox" value="${curEle}"  id="${curEle2.id}" data-type="image" >
                                                                </div>
                                                                <div class="chat-message-inner-container">
                                                                    <div class="chat-message-container">
                                                                        <div class="main-message">
                                                                            <img src="${vProfilePick}" class="chat-message-profile" alt="chat-message-profile">
    
                                                                            <div>
                                                                                <div class="chat-message-alignment">
                                                                                    <div class="chat-message">
                                                                                        ${replyHtml}
                                                                                        <div class="d-flex align-items-center justify-content-between">
                                                                                            <div class="d-flex align-items-center">
                                                                                                ${imageHtml}
                                                                                            </div>
                                                                                            ${floatingDrop(curEle2.id,curEle,"image",curEle2.created_at,1,curEle)}
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="d-flex align-items-center message-author">
                                                                                    <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM(""+curEle2.created_at)}</p>
                                                                                    <div class="message-status"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>`;
                                            }

                                            // let html = `<div class="message-box my-message">
                                            //                     ${forwardHtmlFunc(curEle2.id,curEle,"image")}
                                            //                     ${replyIconHtml(curEle2.id,curEle,"image")}
                                            //                     <p>${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}${blueTick}</span>
                                            //                     </p>
                                            //                     <input type="checkbox" data-type="image" class="forwardChbx d-none" data-date="${curEle2.created_at}" data-from="1" value="${curEle}" id="${curEle2.id}" />
                                            //             </div>`;

                                            if (!isSecond) {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);
                                                $("#MessageList").append(html);
                                                scrollToBottom();
                                                feather.replace();
                                                dynamicWithlabel();

                                            } else {
                                                dateTimeLineAdd(curEle2.created_at, isSecond);
                                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");

                                                $("#" + NewId).after(html);
                                                feather.replace();
                                                dynamicWithlabel();
                                            }
                                        })
                                    }
                                }

                            } else {
                                const blueTick=curEle2.iReadTo==1?'read':'unread';

                                let html="";
                                if(curEle2.iDeleted==1){
                                    html=deleteMessageHtml(""+curEle2.created_at,1);
                                }else{
                                    const doc = curEle2.message;

                                    html=`<div class="chat-message-outer-container send-message message-reply ${blueTick}">
                                                                <div class="selection">
                                                                    <input type="checkbox" data-type="text" data-from="1" class="forwardChbx form-check-input d-none" data-date="${curEle2.created_at}" value="${curEle2.message}" id="${curEle2.id}" />
                                                                </div>
                                                                <div class="chat-message-inner-container">
                                                                    <div class="chat-message-container">
                                                                        <div class="main-message">
                                                                            <img src="${vProfilePick}" class="chat-message-profile" alt="chat-message-profile">
                                                                            <div>
                                                                                <div class="chat-message-alignment">
                                                                                    <div class="chat-message">
                                                                                        ${replyHtml}
                                                                                        <div class="d-flex align-items-center justify-content-between">
                                                                                            <div class="d-flex align-items-center">
                                                                                                <div class="mb-0 message-text" id="msg_${curEle2.id}">${htmlDecode(doc)}</div>
                                                                                            </div>
                                                                                            ${floatingDrop(curEle2.id,curEle2.message,"text",curEle2.created_at,1)}
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="d-flex align-items-center message-author">
                                                                                    <p class="message-droper-name">You</p>
                                                                                    <p class="message-drop-time">${timestampToAMPM(""+curEle2.created_at)}</p>
                                                                                    <div class="message-status"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>`;
                                }

                                // let html = `<div class="message-box my-message">
                                //                     ${forwardHtmlFunc(curEle2.id,curEle2.message,"text")}
                                //                     ${replyIconHtml(curEle2.id,curEle2.message,"text")}
                                //                     <p>${replyHtml}${curEle2.message} <span class="msgTime">${timestampToAMPM(""+curEle2.created_at)}${blueTick}</span></p>
                                //                     <input type="checkbox" data-type="text" data-from="1" class="forwardChbx d-none" data-date="${curEle2.created_at}" value="${curEle2.message}" id="${curEle2.id}" />
                                //                 </div>`;

                                if (!isSecond) {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    $("#MessageList").append(html);
                                    scrollToBottom();
                                    feather.replace();
                                    dynamicWithlabel();
                                } else {
                                    dateTimeLineAdd(curEle2.created_at, isSecond);
                                    const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");

                                    $("#" + NewId).after(html);
                                    feather.replace();
                                    dynamicWithlabel();
                                }
                            }
                        }
                    })

                    const scrollableDiv = document.getElementById('MessageList');
                    const scrollPosition = scrollableDiv.scrollTop;

                    if (scrollPosition == 0) {
                        $("#topFilter").removeClass("d-none");
                    } else {
                        $("#topFilter").addClass("d-none");
                    }

                } else {
                    if (isSecond == 0) {
                        $("#MessageList").html("");
                        timeLineDate = "";
                        $("#topFilter").addClass("d-none");
                    }
                }
            }
        });
    }
}

$(document).on("click",".forwardChbx",()=>{
    $('.chat-message-outer-container.select-message .selection .form-check-input').each(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        }
    });

    // Listen for changes in the checkbox state
    $('.chat-message-outer-container.select-message .selection .form-check-input').change(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        } else {
            $(this).closest('.chat-message-outer-container').removeClass('selected');
        }
    });
})

//read success message
socket.on('readSuccessMsg', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".send-message").removeClass("unread");
        $(".send-message").addClass("read");
    }
})

//Message Typing Start
socket.on('MessageTypingStart', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".typing-preview").removeClass("d-none");
        setTimeout(() => {
            $(".typing-preview").addClass("d-none");
        }, 30000)
    }
})

//Message Typing End
socket.on('MessageTypingEnd', data => {
    const dataContent = data.iFromUserId;
    const vActiveUserId = $("#vActiveUserId").val();

    if (vActiveUserId == dataContent) {
        $(".typing-preview").addClass("d-none");
    }
})

//Socket Receive Message Single
socket.on('receive_message', data => {
    const vActiveUserId = $("#vActiveUserId").val();
    if(data?.type && data?.type=="DeleteMessage"){
        if(vActiveUserId==data.iSenderId){
            let html=deleteMessageHtml("",0);
                        
            $("#"+data.content).closest(".chat-message-outer-container").removeClass("select-message");
            $("#"+data.content).closest(".chat-message-outer-container").html(html);
        }
    }else if(data?.type && data?.type=="UpdateMessage"){
        if(vActiveUserId==data.iSenderId){
            $("#msg_"+data.iMessageId).html(htmlDecode(data.content));

            updateDataInAllHtml(data.iMessageId,data.content)
        }
    }else{
    
        if (vActiveUserId > 0 || activeTab == "User") {
            getUserList();
        }
    
        const activeChatName = $("#activeChatName").text();
        const vProfilePick = $("#vProfilePick").attr("xlink:href");
        const activeChatProfile = $("#activeChatProfile").attr("xlink:href");
    
        const dataContent = data.content;
    
        const vReplyMsg = data?.vReplyMsg;
        const vReplyMsg_id = data?.vReplyMsg_id;
        const vReplyFileName=data?.vReplyFileName;
    
        let replyHtml = replyHtmlFunc(vReplyMsg_id, vReplyMsg,vReplyFileName);
    
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            socket.emit('messageReadUpdate', {
                iFromUserId: dd.iLoginId,
                iToUserId: vActiveUserId
            });
    
            if (vActiveUserId == data.iSenderId) {
                if (dataContent.includes('vImages =>')) {
                    let removePrefix = dataContent;
                    const myImageStr = removePrefix.split("vImages =>");
                    if (myImageStr.length > 0) {
                        const myImageArr = myImageStr[1].split(",");
                        if (myImageArr.length > 0) {
                            myImageArr.map((curEle, index) => {
    
                                let imageHtml = ImageOrFileDipHtml(curEle);
    
                                if (timeLineDate == "") {
                                    dateTimeLineAdd();
                                }
    
                                const id = dd.iLoginId + "_" + vActiveUserId + "_" + Date.parse(new Date());
    
                                let html = `<div class="chat-message-outer-container recieve-message message-reply read">
                                        <div class="selection">
                                            <input type="checkbox" data-type="image" data-from="0" class="form-check-input forwardChbx d-none" value="${curEle}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                        </div>
                                        <div class="chat-message-inner-container">
                                            <div class="chat-message-container">
                                                <div class="main-message">
                                                    <img src="${activeChatProfile}" class="chat-message-profile" alt="chat-message-profile">
                                                    <div>
                                                        <div class="chat-message-alignment">
                                                            <div class="chat-message">
                                                                ${replyHtml}
                                                                <div class="d-flex align-items-center justify-content-between">
                                                                    <div class="d-flex align-items-center">
                                                                        ${imageHtml}
                                                                    </div>
                                                                    ${floatingDrop(id,curEle,"image","",0,curEle)}
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center message-author">
                                                            <p class="message-droper-name">${activeChatName}</p>
                                                            <p class="message-drop-time">${timestampToAMPM()}</p>
                                                            <div class="message-status"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
    
                                // let html = `<div class="message-box friend-message">
                                //                 <p>${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM()}</span></p>
                                //                 ${forwardHtmlFunc(0,curEle,"image")}
                                //                 ${replyIconHtml(0,curEle,"image")}
                                //                     <input type="checkbox" data-type="image" data-from="0" class="forwardChbx d-none" value="${curEle}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                //         </div>`;
    
                                $("#MessageList").append(html);
                                scrollToBottom();
                                feather.replace();
                            })
                        }
                    }
                } else {
                    if (timeLineDate == "") {
                        dateTimeLineAdd();
                    }
    
                    const id = dd.iLoginId + "_" + vActiveUserId + "_" + Date.parse(new Date());
    
                    let html = `<div class="chat-message-outer-container recieve-message message-reply read">
                                <div class="selection">
                                    <input type="checkbox" data-type="text" data-from="0" class="form-check-input forwardChbx d-none" value="${data.content}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                </div>
                                <div class="chat-message-inner-container">
                                    <div class="chat-message-container">
                                        <div class="main-message">
                                            <img src="${activeChatProfile}" class="chat-message-profile" alt="chat-message-profile">
                                            <div>
                                                <div class="chat-message-alignment">
                                                    <div class="chat-message">
                                                        ${replyHtml}
                                                        <div class="d-flex align-items-center justify-content-between">
                                                            <div class="d-flex align-items-center">
                                                            <div class="mb-0 message-text" id="msg_${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}">${htmlDecode(data.content)}</div>
                                                            </div>
                                                            ${floatingDrop(id,data.content,"text","",0)}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center message-author">
                                                    <p class="message-droper-name">${activeChatName}</p>
                                                    <p class="message-drop-time">${timestampToAMPM()}</p>
                                                    <div class="message-status"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
    
                    // let html = `<div class="message-box friend-message">
                    //             <p>${replyHtml}${data.content} <span class="msgTime">${timestampToAMPM()}</span></p>
                    //             ${forwardHtmlFunc(0,data.content,"text")}
                    //             ${replyIconHtml(0,data.content,"text")}
                    //                 <input type="checkbox" data-type="text" data-from="0" class="forwardChbx d-none" value="${data.content}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                    //         </div>`;
    
                    $("#MessageList").append(html);
                    scrollToBottom();
                    feather.replace();
                }
            }
        }
        // Handle received message
    }
});


window.onload = (event) => {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist == null) {
        window.location = "./login.php";
    }
};

function MessageTypingSocket(msg) {
    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        socket.emit('MessageTyping', {
            iFromUserId: dd.iLoginId,
            iToUserId: vActiveUserId,
            msg: msg
        });
    }
}

$(document).ready(function() {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");

    getUserList();

    $("#vMessage").on("keyup",(e)=>{
        if (e.keyCode == 13 && e.shiftKey) {
            shiftEnterTag(e);
        }
    })

    const shiftEnterTag=(e)=>{
        if (e.key === 'Enter' && e.shiftKey) {
            let selection = window.getSelection();
            let range = selection.getRangeAt(0);
            let container = range.startContainer;
    
            // Traverse up the DOM to find the closest tag that is either 'li' or 'div'
            while (container && container.nodeName !== 'LI' && container.nodeName !== 'DIV') {
                container = container.parentNode;
            }
    
            // Determine the current tag
            let currentTag = container.nodeName;
    
            // Insert the appropriate tag
            if (currentTag === 'LI') {
                if(container.textContent!=""){
                    e.preventDefault();
                    insertNewTag('li');
                }else{
                    let ulElement = container.parentNode;
                    ulElement.removeChild(container);
                    if (ulElement.childElementCount === 0) {
                        let newParagraph = document.createElement('p');
                        newParagraph.appendChild(document.createElement('br')); 
                        ulElement.parentNode.insertBefore(newParagraph, ulElement.nextSibling);

                        let newRange = document.createRange();
                        newRange.setStart(newParagraph, 0);
                        newRange.setEnd(newParagraph, 0);
                        selection.removeAllRanges();
                        selection.addRange(newRange);
                    }
                }
            }
        }
    }

    $("#vMessage").on("keydown",(e)=>{
        let vMessage = MsgRemvQuotes(textEditorMsg);
        if(e.keyCode==13 && !e.shiftKey){
            e.preventDefault();
            if(vMessage!="&lt;br&gt;"){
                sendMessage();
            }
            return false;
        }else if(e.keyCode==13 && e.shiftKey){
            if(vMessage=="" || vMessage=="&lt;br&gt;"){
                e.preventDefault();
                return false;
            }
        }

        // shiftEnterTag(e);
    })

    function insertNewTag(tagName) {
        let selection = window.getSelection();
        let range = selection.getRangeAt(0);
    
        // Create a new element of the specified tag
        let newElement = document.createElement(tagName);
        newElement.appendChild(document.createElement('br')); // Add a line break to the new element
    
        // Insert the new element after the current range
        range.collapse(false);
        range.insertNode(newElement);
    
        // Move the cursor inside the new element
        range.setStart(newElement, 0);
        range.setEnd(newElement, 0);
    
        selection.removeAllRanges();
        selection.addRange(range);
    }

    var keyUpSpaceDisAllow = document.getElementById('vMessage');

    keyUpSpaceDisAllow.addEventListener('keyup', function(event) {
        if(String(keyUpSpaceDisAllow.textContent).trim()==""){
            $("#vMessage").html("");
        }
    });

    // document.body.addEventListener('keyup', function(event) {
    //     event.preventDefault();
    //     if ((event.keyCode === 13 || event.which === 13) && !event.shiftKey) {
    //         let vMessage = MsgRemvQuotes(textEditorMsg);
    //         console.log("vMessage",vMessage)
    //         if(htmlDecode(vMessage)!='<div><br></div><div><br></div>' && htmlDecode(vMessage)!='<span class="placeholder"><br></span><span class="placeholder">Type your text here...</span>'){
    //             sendMessage();
    //         }else{
    //             $("#vMessage").html('<span class="placeholder">Type your text here...</span>');
    //         }
    //     }
    // });


    document.querySelector('#vMessage').addEventListener('keyup', function(e) {
        setTimeout(() => {
            MessageTypingSocket("")
        }, 2000)

        const vMessageText=$("#vMessage").text();
        if(String(vMessageText).trim()==""){
            if($("#vMessage:has(img)").length==0){
                $("#sendMessage").addClass("disabled");
            }else{
                $("#sendMessage").removeClass("disabled");
            }
        }else{
            $("#sendMessage").removeClass("disabled");
        }
    })

    document.querySelector('#vMessage').addEventListener('keydown', function(e) {
        MessageTypingSocket(textEditorMsg)
    })
})

$(document).on("click", "#sendMessage", function(e) {
    sendMessage();
})

let ImageDataArr = [];

const MsgRemvQuotes=(msg)=>{
    let newMsg=msg.substring(1);
    return newMsg.substring(0, newMsg.length - 1);
}

function removeBackslashes(input) {
    return input.replace(/\\/g, '')
}

function htmlDecode(inputHTML){
    // Remove unnecessary escape characters and correct the tags
    const correctedHTML = inputHTML.replace(/&lt;/g, '<')
                                   .replace(/&gt;/g, '>')
                                   .replace(/&quot;/g, '"')
                                   .replace(/&amp;gt;/g, '>')
                                   .replace(/="" /g, '')
                                   .replace(/""/g, '')
                                   .replace(/&amp;nbsp;/g, ' '); // Correcting &amp;nbsp;
    return removeBackslashes(correctedHTML);
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function sendMessage() {
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const isMesage=$("#vMessage").text();

        if(String(isMesage).trim()!="" || ImageDataArr.length || $("#vMessage:has(img)").length){
            let vMessage = MsgRemvQuotes(textEditorMsg);
            // let vMessage=$("#vMessage").text();
            const vActiveUserId = $("#vActiveUserId").val();
            const vActiveGroupId = $("#vActiveGroupId").val();
    
            if(iEditMsgId==""){
                const vReplyMsg = $("#vReplyMsg").val();
                const vReplyMsg_id = $("#vReplyMsg_id").val();
                const vReplyMsg_type = $("#vReplyMsg_type").val();
                const vReplyFileName = $("#vReplyFileName").val();
        
                const senderImageHtml = $("#vProfilePick").attr("xlink:href");
        
                let replyHtml = replyHtmlFunc(vReplyMsg_id, vReplyMsg, vReplyFileName, 1);
        
                let isReadFlag=vActiveGroupId>0?'':`<div class="message-status"></div>`
    
                if (vMessage != "" || ImageDataArr.length > 0) {
                    if (ImageDataArr.length == 0) {
                        if (timeLineDate == "") {
                            timeLineDate = getCurrentDate();
        
                            let htmlDate = `<div class="chat-time-line">
                                <p>${dateDispl(timeLineDate)}</p>
                            </div>`;
        
                            $("#MessageList").append(htmlDate);
                            dynamicWithlabel();
                        }
    
                        // htmlDecode(vMessage)
        
                        var dataParseStr = Date.parse(new Date());
                        let id=vActiveUserId>0?dd['iLoginId']+"_"+vActiveUserId+"_"+Date.parse(new Date()):dd['iLoginId']+"_"+vActiveGroupId+"_"+Date.parse(new Date());

                        let html = `<div class="chat-message-outer-container send-message message-reply unread">
                                        <div class="selection">
                                            <input type="checkbox" data-type="text" data-from="1" id="${id}" class="form-check-input forwardChbx d-none" data-date="${getCurrentDateTime()}" value="${vMessage}"/>
                                        </div>
                                        <div class="chat-message-inner-container">
                                            <div class="chat-message-container">
                                                <div class="main-message">
                                                    <img src="${senderImageHtml}" class="chat-message-profile" alt="chat-message-profile">
                                                    <div>
                                                        <div class="chat-message-alignment">
                                                            <div class="chat-message">
                                                                ${replyHtml}
                                                                <div class="d-flex align-items-center justify-content-between">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="mb-0 message-text" id="msg_${dataParseStr}">
                                                                                ${htmlDecode(vMessage)}
                                                                            </div>
                                                                        </div>
                                                                        ${floatingDrop(id,vMessage,"text","",1)}
                                                                    </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center message-author">
                                                            <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM()}</p>
                                                            ${isReadFlag}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
        
                        // let html = `<div class="message-box my-message">
                        //                 ${forwardHtmlFunc("LastId", vMessage, "text")}
                        //                 ${replyIconHtml("LastId", vMessage, "text")}
                        //                 ${senderImageHtml}
                        //                 <p>${vUserName}${replyHtml}${vMessage} <span class="msgTime">${timestampToAMPM()}${blueTick}</span>
                        //                 </p>
                        //                 <input type="checkbox" data-type="text" data-from="1" id="${dataParseStr}" class="forwardChbx d-none" data-date="${getCurrentDateTime()}" value="${vMessage}"/>
                        //             </div>`;
        
                        $("#MessageList").append(html);
                        // $("#vMessage").html(`<span class="placeholder">Type your text here...</span>`);
                        $("#vMessage").html("");
                        $("#sendMessage").addClass("disabled");
                        updateJson();
                        scrollToBottom();
                        dynamicWithlabel();
                        feather.replace();
                        $(".textarea-reply-container").removeClass('show');
        
                        if (vActiveUserId > 0) {
                            socket.emit('send_message', {
                                receiverChatID: vActiveUserId,
                                senderChatID: dd['iLoginId'],
                                content: vMessage,
                                ImageDataArr: [],
                                vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                vReplyMsg_id: vReplyMsg_id,
                                vReplyFileName:vReplyFileName,
                                id:dd['iLoginId']+"_"+vActiveUserId+"_"+Date.parse(new Date())
                            });
                            if (activeTab == "Group") {
                                getGroupList();
                            } else {
                                getUserList();
                                MessageTypingSocket("")
                            }
                        } else {
                            socket.emit('send_grp_message', {
                                receiverChatID: vActiveGroupId,
                                senderChatID: dd['iLoginId'],
                                content: vMessage,
                                ImageDataArr: [],
                                vReplyFileName:vReplyFileName,
                                vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                vReplyMsg_id: vReplyMsg_id,
                                id:dd['iLoginId']+"_"+vActiveGroupId+"_"+Date.parse(new Date())
                            });
                            if (activeTab == "Group") {
                                getGroupList();
                            } else {
                                getUserList();
                                MessageTypingSocket("")
                            }
                        }
                    } else {
    
                        async function processArrayWithDelay(array, callback, delayTime) {
                            const results = [];
                            for (let i = 0; i < array.length; i++) {
                                //Logic Code
                                const curEle=array[i];
                                const index=i;
    
                                let imageHtml = ImageOrFileDipHtml(curEle.imageData, curEle.fileName);
        
                                if (timeLineDate == "") {
                                    timeLineDate = getCurrentDate();
                                    let htmlDate = "<div class='date-timeline'><p>" + dateDispl(timeLineDate) + "</p></div>";
                                    $("#MessageList").append(htmlDate);
                                    dynamicWithlabel();
                                }
            
                                const id = dd.iLoginId + "_" + vActiveUserId + "_" + Date.parse(new Date());
        
                                let html = `<div class="chat-message-outer-container send-message message-reply unread">
                                            <div class="selection">
                                                <input type="checkbox" data-type="image" data-from="1" class="form-check-input forwardChbx d-none" value="${curEle.imageData}" data-date="${getCurrentDateTime()}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                            </div>
                                            <div class="chat-message-inner-container">
                                                <div class="chat-message-container">
                                                    <div class="main-message">
                                                        <img src="${senderImageHtml}" class="chat-message-profile" alt="chat-message-profile">
                                                        <div>
                                                            <div class="chat-message-alignment">
                                                                <div class="chat-message">
                                                                    ${replyHtml}
                                                                    <div class="d-flex align-items-center justify-content-between">
                                                                        <div class="d-flex align-items-center">
                                                                            ${imageHtml}
                                                                        </div>
                                                                        ${floatingDrop(id,curEle.imageData,"image",getCurrentDateTime(),1,curEle.fileName)}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex align-items-center message-author">
                                                                <p class="message-droper-name">You</p><p class="message-drop-time">${timestampToAMPM()}</p>
                                                                ${isReadFlag}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>`;
            
                                // let html = `<div class="message-box my-message">
                                //             ${forwardHtmlFunc("LastId", curEle.imageData, "image")}
                                //             ${replyIconHtml("LastId", curEle.imageData, "image")}
                                //             ${senderImageHtml}
                                //         <p>${vUserName}${replyHtml}${imageHtml} <span class="msgTime">${timestampToAMPM()}${blueTick}</span></p>
                                //         <input type="checkbox" data-type="image" data-from="1" class="forwardChbx d-none" value="${curEle.fileName}" data-date="${getCurrentDateTime()}" id="${dd.iLoginId}_${vActiveUserId}_${Date.parse(new Date())}" />
                                //     </div>`;
            
                                $("#MessageList").append(html);
                                $("#vMessage").html("");
                                $("#sendMessage").addClass("disabled");
                                updateJson();
                                scrollToBottom();
                                feather.replace();
                                dynamicWithlabel();
                                $(".textarea-reply-container").removeClass('show');
            
                                if (vActiveUserId > 0) {
                                    socket.emit('send_message', {
                                        receiverChatID: vActiveUserId,
                                        senderChatID: dd['iLoginId'],
                                        content: vMessage,
                                        ImageDataArr: [curEle],
                                        vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                        vReplyMsg_id: vReplyMsg_id,
                                        vReplyFileName:vReplyFileName,
                                        id:dd.iLoginId+"_"+vActiveUserId+"_"+Date.parse(new Date())
                                    });
                                    if (Number(ImageDataArr.length) == Number(index + 1)) {
                                        ImageDataArr = [];
                                        if (activeTab == "Group") {
                                            getGroupList();
                                        } else {
                                            getUserList();
                                            MessageTypingSocket("")
                                        }
                                    }
                                } else {
                                    socket.emit('send_grp_message', {
                                        receiverChatID: vActiveGroupId,
                                        senderChatID: dd['iLoginId'],
                                        content: vMessage,
                                        ImageDataArr: [curEle],
                                        vReplyFileName:vReplyFileName,
                                        vReplyMsg: vReplyMsg_type == "text" ? vReplyMsg : "vImages => " + vReplyMsg,
                                        vReplyMsg_id: vReplyMsg_id,
                                        id:dd['iLoginId']+"_"+vActiveGroupId+"_"+Date.parse(new Date())
                                    });
                                    if (Number(ImageDataArr.length) == Number(index + 1)) {
                                        ImageDataArr = [];
                                        if (activeTab == "Group") {
                                            getGroupList();
                                        } else {
                                            getUserList();
                                            MessageTypingSocket("")
                                        }
                                    }
                                }
    
                                await delay(delayTime);
                            }
                            return results;
                        }
        
                        async function processItem(item) {
                            await delay(500);
                            return item * 2;
                        }
                        
                        processArrayWithDelay(ImageDataArr, processItem, 2000)
                        .then(results => {
                            console.log('All image processed');
                        });
    
    
                        // ImageDataArr.map((curEle, index) => {
                            
                        // })
                    }
        
                    $("#replyInputBox").addClass("d-none");
                    $("#vReplyMsg").val("");
                    $("#vReplyMsg_id").val("");
                    $("#vReplyMsg_type").val("");
                    $("#vReplyFileName").val("");
        
                    $(".teatarea-file-upload").removeClass("show");
                    $("#fileInput").val("");
                    $(".editor").addClass("show");
        
                    $('.file-preview').text("");
                    $(".type-link").removeClass("d-none");
                    $(".emoji-link").removeClass("d-none");
        
                    var outerheight = $('.textarea-outer-container').outerHeight() + 32 + 24;
                    $(".chat-area-bottom-space").css("padding-bottom", outerheight + 'px');
        
                    $("#fileInput").val("");
                }
            }else{
                if (vMessage != ""){
                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        async: false,
                        url: API_URL+'MessageUpdate',
                        data: {
                            tToken: dd.tToken,
                            msg:vMessage,
                            vActiveGroupId,
                            vActiveUserId,
                            msgId:iEditMsgId
                        },
                        success: function(data, status, xhr) {
                            if(data.status==200){
                                $("#vMessage").html(`<span class="placeholder">Type your text here...</span>`);
                                $("#msg_"+vEditMessageMainId).html(htmlDecode(vMessage));
                                $("#sendMessage").addClass("disabled");
    
                                updateJson();
    
                                const encodedContent=JSON.stringify(vMessage);
    
                                updateDataInAllHtml(vEditMessageMainId,encodedContent)
                                
                                socket.emit('update_message', {
                                    content:encodedContent,
                                    iMessageId:vEditMessageMainId,
                                    vActiveGroupId,
                                    vActiveUserId,
                                    tToken:dd.tToken
                                });
    
                                iEditMsgId="";
                                vEditMsgText="";
                                vEditMsgType="";
                                vEditMessageMainId="";
    
                            }
                        }
                    })
                }
            }
        }


    }
}

function updateDataInAllHtml(id,message){
    $(".forwardChbx").each((e,item)=>{
        const getRowId=$(item)[0].id;
        if(getRowId==id){
            $(item).val(message);
        }
    })

    $(".EditMessage").each((e,item)=>{
        const getRowId=$(item).attr("data-id");
        if(getRowId==id){
            $(item).attr("data-msg",message);
        }
    })

    $(".replyIcon").each((e,item)=>{
        const getRowId=$(item).attr("data-id");
        if(getRowId==id){
            $(item).attr("data-msg",message);
        }
    })

    $(".forwardIcon").each((e,item)=>{
        const getRowId=$(item).attr("data-id");
        if(getRowId==id){
            $(item).attr("data-msg",message);
        }
    })

    $(".deleteMsgSingle").each((e,item)=>{
        const getRowId=$(item).attr("data-id");
        if(getRowId==id){
            $(item).attr("data-msg",message);
        }
    })
}


//File Select And Delete Code Start
$(".upload-file-input").on('change', () => {
    ImageDataArr = [];
    $("#fileUploadDiv").html("");
    $("#sendMessage").addClass("disabled");

    const fileInput = document.getElementById('fileInput');
    const files = fileInput.files;

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();

        reader.onload = function(event) {
            const imageData = event.target.result;
            const ImageExtensionArr = ["png", "jpg", "jpeg", "webp"];

            const img = new Image();
            img.src = imageData;

            if (ImageExtensionArr.includes(get_url_extension(file.name))) {
                img.onload = function() {
                    if (ImageExtensionArr.includes(get_url_extension(file.name))) {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        canvas.width = img.width * 1;
                        canvas.height = img.height * 1;
                        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                        const base64ImageData = canvas.toDataURL(file.type);
                        const data = {
                            fileName: file.name,
                            imageData: base64ImageData,
                            type: file.type
                        };
                        ImageDataArr.push(data);

                        const fileNameNew=String(file.name).split(".");

                        const fileHtml = `<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data">
                                            <div class="d-flex align-items-center">
                                                <div class="preview-container">
                                                    <img class="preview-image" src="${imageData}">
                                                </div>
                                                <div class="file-preview mb-0">${StringDisplLimit(fileNameNew[0],50)+"."+fileNameNew[1]}</div>
                                            </div>

                                            <a href="javascript:;" class="close-reply clearImage" data-id="${file.name}"><i data-feather="x" class="feather-16"></i></a>
                                        </div>`;

                        $("#fileUploadDiv").append(fileHtml);
                        $("#sendMessage").removeClass("disabled");
                        feather.replace();
                    }
                };
            } else {

                const data = {
                    fileName: file.name,
                    imageData: imageData,
                    type: file.type
                };
                ImageDataArr.push(data);

                const fileNameNew=String(file.name).split(".");
                
                const fileHtml = `<div class="d-flex align-items-center justify-content-between teatarea-file-upload-data">
                                    <div class="d-flex align-items-center">
                                        <div class="preview-container">
                                            <img class="preview-image" src="./images/svgs/file.svg" alt="File">
                                        </div>
                                        <div class="file-preview mb-0">${StringDisplLimit(fileNameNew[0],50)+"."+fileNameNew[1]}</div>
                                    </div>

                                    <a href="javascript:;" class="close-reply clearImage" data-id="${file.name}"><i data-feather="x" class="feather-16"></i></a>
                                </div>`;

                $("#fileUploadDiv").append(fileHtml);
                $("#sendMessage").removeClass("disabled");
                feather.replace();
            }
        };

        reader.readAsDataURL(file);
    }

    $(".teatarea-file-upload").addClass("show");
    $(".editor").removeClass("show");
    $(".type-link").addClass("d-none");
    $(".type-functions").removeClass("show");
    $(".emoji-link").addClass("d-none");
    $('.preview-container').css('display', 'block');
});

$(document).on("click", ".clearImage", (e) => {
    const fileName = $(e.currentTarget).attr("data-id");

    const fileListFilter = ImageDataArr.filter((curEle, index) => {
        return curEle.fileName != fileName
    })

    ImageDataArr = fileListFilter;

    $(e.currentTarget).closest(".teatarea-file-upload-data").fadeOut(300).remove();

    if (fileListFilter.length == 0) {
        $(".teatarea-file-upload").removeClass("show");
        $(".editor").addClass("show");

        $('.file-preview').text("");
        $(".type-link").removeClass("d-none");
        $(".emoji-link").removeClass("d-none");
        $("#sendMessage").addClass("disabled");

        $("#fileInput").val("");
    }
})
//File Select And Delete Code End


//Reply Message Code Start
$(document).on("click", ".cancelReply", () => {
    $(".textarea-reply-container").removeClass("show");
    if(ImageDataArr.length==0){
        $(".editor").addClass("show");
    }
    // $('.file-preview').text("");

    $(".textarea-reply-container").html("");

    $("#vReplyMsg").val("");
    $("#vReplyMsg_id").val("");
    $("#vReplyMsg_type").val("");
    $("#vReplyFileName").val("");
    $(".textarea-inner-container").removeClass("textareaReply");
})

$(document).on("click", ".replyIcon", (e) => {
    $(".textarea-reply-container").addClass("show");
    $(".teatarea-file-upload").removeClass("show");
    $("#fileInput").val("");
    // $(".editor").removeClass("show");
    $(".textarea-inner-container").addClass("textareaReply");

    const getMainDivClass = $(e.currentTarget).closest(".chat-message-outer-container");
    const MainDivClassList = getMainDivClass[0].classList.value;

    let ReplyAuthName = "You";
    if (MainDivClassList.includes("recieve-message")) {
        ReplyAuthName = $("#activeChatName").text();
    }

    const dataId = $(e.currentTarget).attr('data-id');
    const dataMsg = $(e.currentTarget).attr('data-msg');
    const dataType = $(e.currentTarget).attr('data-type');
    const dataFileName = $(e.currentTarget).attr('data-filename');

    $(".textarea-reply-container").html("");

    $("#vReplyMsg").val(String(dataMsg).trim());
    $("#vReplyMsg_id").val(dataId);
    $("#vReplyMsg_type").val(dataType);
    $("#vReplyFileName").val(dataFileName);;

    // vReplyMsg

    if (dataType == "image") {
        const imageArr = ["jpg", "png", "jpeg"];
        const filterExten = dataFileName != "" ? get_url_extension(String(dataFileName).trim()) : get_url_extension(String(dataMsg).trim());

        const type = String(dataMsg).trim().split(';')[0].split('/')[1];

        const fileNameNew=String(dataFileName).split(".")

        if (imageArr.includes("" + filterExten)) {
            if (String(dataMsg).trim().includes("base64,")) {
                let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        href="javascript:;" class="close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-image-preview">
                                        <img src="${dataMsg}" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0],100)+"."+fileNameNew[1]}</p>
                                </div>
                            </div>`;
                // let html = `<p>
                //                 <img src="${String(dataMsg).trim()}" style="width:40px; height:40px;" />
                //                 <i class="fa-solid fa-circle-xmark" id="cancelReply"></i>
                //             </p>`;
                //             $("#replyInputBox").html(html);
                $(".textarea-reply-container").html(html);
                feather.replace();
            } else {
                let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        href="javascript:;" class="close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-image-preview">
                                        <img src="${API_URL+String(dataMsg).trim()}" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0],100)+"."+fileNameNew[1]}</p>
                                </div>
                            </div>`;
                // let html = `<p>
                //                 <img src="<?= $API_URL ?>${String(dataMsg).trim()}" style="width:40px; height:40px;" />
                //                 <i class="fa-solid fa-circle-xmark" id="cancelReply"></i>
                //             </p>`;
                // $("#replyInputBox").html(html);
                $(".textarea-reply-container").html(html);
                feather.replace();
            }
        } else {
            let html = `<div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                        href="javascript:;" class="close-reply cancelReply"><i data-feather="x"
                                            class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-file-preview">
                                        <img src="./images/svgs/file.svg" alt="File">
                                    </div>
                                    <p class="mb-0 message message-text">${StringDisplLimit(fileNameNew[0],100)+"."+fileNameNew[1]}</p>
                                </div>
                            </div>`;
            // let html = `<p><i class="fa-solid fa-file-arrow-down" aria-hidden="true"></i><i class="fa-solid fa-circle-xmark" id="cancelReply"></i></p>`;

            // $("#replyInputBox").html(html);
            $(".textarea-reply-container").html(html);
            feather.replace();
        }
    } else {
        let html = `<div class="textarea-reply-inner-container">
                        <p class="mb-0 name d-flex align-items-center justify-content-between">${ReplyAuthName}<a
                                href="javascript:;" class="close-reply cancelReply"><i data-feather="x"
                                    class="feather-16"></i></a></p>
                        <div class="d-flex align-items-center">
                            <p class="mb-0 message">${String(dataMsg).substring(0,100)+"..."}</p>
                        </div>
                    </div>`;
        // let html = `<p>${dataMsg} <i class="fa-solid fa-circle-xmark" id="cancelReply"></i></p>`;
        // $("#replyInputBox").html(html);
        $(".textarea-reply-container").html(html);
        feather.replace();
    }

})

let isMultiSelect = 0;
$(document).on("click", ".selectMultiple", () => {
    if (isMultiSelect == 0) {
        isMultiSelect = 1;
        $(".forwardChbx").removeClass("d-none");
        $(".chat-message-outer-container").addClass("select-message");
    } else {
        isMultiSelect = 0;
        $(".forwardChbx").addClass("d-none");
        $(".chat-message-outer-container").removeClass("select-message");
    }
})


//Forward Message Single Code Start 
let MultipleSelectMsg = [];
let MultipleSelectDel = [];
let MultipleMessageDeleIds = [];

$(document).on("change", ".forwardChbx", () => {
    MultipleSelectMsg = [];
    MultipleSelectDel = [];
    MultipleMessageDeleIds = [];

    let isTotalSelectedMsg = 0;
    let isNotMyMessage = 0;
    document.querySelectorAll('.forwardChbx').forEach(function(e) {
        const type = $(e).attr("data-type");
        const values = $(e).val();
        const isMyMessage = Number($(e).attr("data-from"));
        const messageDateTime = $(e).attr("data-date");
        const MsgId = $(e).attr("id");

        if (e.checked) {
            MultipleSelectMsg.push({
                type: type,
                values: values
            });
            isTotalSelectedMsg++;

            if (isMyMessage > 0) {
                MultipleSelectDel.push(messageDateTime);
                MultipleMessageDeleIds.push(MsgId);
            } else {
                isNotMyMessage = 1;
            }
        }
    });

    $("#iTotalMessageSelect").text(isTotalSelectedMsg+" Selected");

    if (isTotalSelectedMsg > 0) {
        $("#MultipleSelectDiv").removeClass("d-none");
        $("#topHeaderActiveArea").addClass("d-none");
    } else {
        $("#MultipleSelectDiv").addClass("d-none");
        $("#topHeaderActiveArea").removeClass("d-none");
    }

    if (isNotMyMessage == 0) {
        $("#MultipleMsgDelete").removeClass("disabled");
    } else {
        $("#MultipleMsgDelete").addClass("disabled");
    }
});

function forwardHtmlList(){
    const vChatUserListJson = $("#vChatUserListJson").val();
    const vChatGroupListJson = $("#vChatGroupListJson").val();

    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
        JSON.parse(vChatUserListJson).map((curEle, index) => {
            let profilePic=curEle.vProfilePic;
            if(curEle.vProfilePic==""){
                colorOption.map((curEle2,index)=>{
                    if(curEle2.iColorId==curEle.iColorOption){
                        profilePic=curEle2.vColorPick
                    }
                })
            }

            const htmlRows =`<li>
                            <a href="javascript:;" class="chat-list">
                                <label class="d-flex align-items-center justify-content-between form-check ps-0" for="vUser_${curEle.iUserId}">
                                    <div class="d-flex align-items-center">
                                        <div class="user-profile-image me-3">
                                            <svg role="none" viewBox="0 0 96 96">
                                                <mask id="profile-image">
                                                    <circle fill="white" cx="48" cy="48" r="48">
                                                    </circle>
                                                    <circle fill="black" cx="86%" cy="86%" r="18">
                                                    </circle>
                                                </mask>
                                                <g mask="url(#profile-image)">
                                                    <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="${profilePic}">
                                                    </image>
                                                </g>
                                            </svg>
                                            <div class="${curEle.iStatus==0?'offline':'online'}"></div>
                                        </div>
                                        <div>
                                            <h5 class="user-profile-name">${curEle.vFullName} </h5>
                                            <P class="user-profile-activity">${curEle.iStatus==0?'Offline':'Online'}</P>
                                        </div>
                                    </div>

                                    <span><input class="form-check-input vForwardUsers" type="checkbox" value="${curEle.iUserId}" id="vUser_${curEle.iUserId}"></span>
                                </label>
                            </a>
                        </li>`

            $("#forwrdModalGrpMembList").append(htmlRows);
        })
    }

    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {

        JSON.parse(vChatGroupListJson).map((curEle, index) => {
            const vGroupImage=(curEle?.vGroupImage && curEle?.vGroupImage!="")?curEle.vGroupImage:"images/profile/group-profile.svg";

            const htmlRows=`<li>
                                <a href="javascript:;" class="chat-list">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <div class="user-profile-image me-3">
                                                <img src="${vGroupImage}" alt="group-profile">
                                            </div>
                                            <div>
                                                <h5 class="user-profile-name">${curEle.vGroupName}</h5>
                                            </div>
                                        </div>

                                        <span><input class="form-check-input vForwardUsers" type="checkbox" value="${curEle.iGroupId}" id="vGroup_${curEle.iGroupId}"></span>
                                    </div>
                                </a>
                            </li>`

            // htmlRows += `<div class="form-check">
            //                 <input type="checkbox" class="form-check-input vForwardUsers" value="group_${curEle.iGroupId}" id="group_${curEle.iGroupId}">
            //                 <label class="form-check-label" for="group_${curEle.iGroupId}">${curEle.vGroupName}</label>
            //             </div>`;
            $("#forwrdModalGrpMembList").append(htmlRows);
        })
    }
}

$(document).on("click", ".forwardIcon", (e) => {
    const dataId = $(e.currentTarget).attr('data-id');
    const dataMsg = $(e.currentTarget).attr('data-msg');
    const dataType = $(e.currentTarget).attr('data-type');

    vUserForwrdSelect=[];
    vGroupForwrdSelect=[];
    
    $("#forwrdModalGrpMembList").html("");
    $("#ForwardSelTags").html("");
    $("#submitForwardForm").addClass("d-none");

    $("#iActiveMessageId").val(dataId);
    $("#vActiveMessage").val(dataMsg);
    $("#vForwardDataType").val(dataType);

    forwardHtmlList();
});

let vUserForwrdSelect=[];
let vGroupForwrdSelect=[];
$(document).on("click",".vForwardUsers",(e)=>{
    const idName=e.target.id;

    if(idName.includes("vUser_")){
        if(e.target.checked){
            $(e.currentTarget).closest(".chat-list").addClass("chat-active");
            vUserForwrdSelect.push(e.target.value);
            ForwardToSelectedData(vUserForwrdSelect,vGroupForwrdSelect);
        }else{
            const filterUser=vUserForwrdSelect.filter((curEle,index)=>{
                return Number(curEle)!=Number(e.target.value)
            })

            vUserForwrdSelect=filterUser;
            $(e.currentTarget).closest(".chat-list").removeClass("chat-active");
            ForwardToSelectedData(vUserForwrdSelect,vGroupForwrdSelect);
        }
    }else{
        if(e.target.checked){
            $(e.currentTarget).closest(".chat-list").addClass("chat-active");
            vGroupForwrdSelect.push(e.target.value);
            ForwardToSelectedData(vUserForwrdSelect,vGroupForwrdSelect);
        }else{
            const filterUser=vGroupForwrdSelect.filter((curEle,index)=>{
                return Number(curEle)!=Number(e.target.value)
            })

            vGroupForwrdSelect=filterUser;
            $(e.currentTarget).closest(".chat-list").removeClass("chat-active");
            ForwardToSelectedData(vUserForwrdSelect,vGroupForwrdSelect);
        }
    }


    if(vUserForwrdSelect.length==0 && vGroupForwrdSelect.length==0){
        $("#submitForwardForm").addClass("d-none");
    }else{
        $("#submitForwardForm").removeClass("d-none");
    }
})

function ForwardToSelectedData(selectedUser,selectedGroup){
    const vChatUserListJson = $("#vChatUserListJson").val();
    const vChatGroupListJson = $("#vChatGroupListJson").val();

    $("#ForwardSelTags").html("");

    if (vChatUserListJson != "" && JSON.parse(vChatUserListJson).length) {
        JSON.parse(vChatUserListJson).map((curEle, index) => {
            if(selectedUser.includes(""+curEle.iUserId)){
                $("#ForwardSelTags").append(
                    `<li id="forward_user_tag_${curEle.iUserId}">
                        <div class="custom-badge">
                            <p class="user-name">${curEle.vFullName}</p>
                            <a href="javascript:;" class="remove-user remvForwardTag" data-type="user" data-id="${curEle.iUserId}"><i data-feather="x" class="feather-18"></i></a>
                        </div>
                    </li>`  
                );
                feather.replace();
            }
        })
    }

    if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
        JSON.parse(vChatGroupListJson).map((curEle, index) => {
            if(selectedGroup.includes(""+curEle.iGroupId)){
                $("#ForwardSelTags").append(
                    `<li id="forward_user_tag_${curEle.iGroupId}">
                        <div class="custom-badge">
                            <p class="user-name">${curEle.vGroupName}</p>
                            <a href="javascript:;" class="remove-user remvForwardTag" data-type="group" data-id="${curEle.iGroupId}"><i data-feather="x" class="feather-18"></i></a>
                        </div>
                    </li>`  
                );
                feather.replace();
            }
        })
    }
}

$(document).on("click",".remvForwardTag",(e)=>{
    const iUserId=$(e.currentTarget).attr("data-id");
    const isType=$(e.currentTarget).attr("data-type");

    if(isType=="user"){
        const filterUser=vUserForwrdSelect.filter((curEle,index)=>{
            return Number(curEle)!=Number(iUserId)
        })

        vUserForwrdSelect=filterUser;

        $("#forward_user_tag_"+iUserId).remove();
        $("#vUser_"+iUserId).prop("checked",false);

        $("#vUser_"+iUserId).closest(".chat-list").removeClass("chat-active");
    }else{
        const filterUser=vGroupForwrdSelect.filter((curEle,index)=>{
            return Number(curEle)!=Number(iUserId)
        })

        vGroupForwrdSelect=filterUser;

        $("#forward_user_tag_"+iUserId).remove();
        $("#vGroup_"+iUserId).prop("checked",false);

        $("#vGroup_"+iUserId).closest(".chat-list").removeClass("chat-active");
    }

    if(vUserForwrdSelect.length==0 && vGroupForwrdSelect.length==0){
        $("#submitForwardForm").addClass("d-none");
    }else{
        $("#submitForwardForm").removeClass("d-none");
    }
})

$(document).on("click", "#submitForwardForm", (e) => {
    e.preventDefault();
    const iActiveMessageId = $("#iActiveMessageId").val();
    const vActiveMessage = $("#vActiveMessage").val();
    const vForwardDataType = $("#vForwardDataType").val();
    const vActiveGroupId=$("#vActiveGroupId").val();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $('input:checkbox.vForwardUsers').each(function(e,item) {
            const type=$(item)[0].id;
            var sThisVal = (this.checked ? $(this).val() : "");
            const splitStr = String(type).split("_");

            if(Number(sThisVal)>0){
                if (splitStr[0] == "vGroup") {
                    if (Number(splitStr[1]) > 0) {
                        if(MultipleSelectMsg.length){
                            MultipleSelectMsg.map((curEle,index)=>{
                                socket.emit('send_grp_message', {
                                    receiverChatID: splitStr[1],
                                    senderChatID: dd['iLoginId'],
                                    content: curEle.type == "text" ? curEle.values : "vImages => " + String(curEle.values).trim(),
                                    ImageDataArr: [],
                                    vReplyMsg: "",
                                    vReplyMsg_id: "",
                                    id:dd['iLoginId']+"_"+vActiveGroupId+"_"+Date.parse(new Date())
                                });
                            })
                            MultipleSelectMsg=[];
                        }else{
                            socket.emit('send_grp_message', {
                                receiverChatID: splitStr[1],
                                senderChatID: dd['iLoginId'],
                                content: vForwardDataType == "text" ? vActiveMessage : "vImages => " + String(vActiveMessage).trim(),
                                ImageDataArr: [],
                                vReplyMsg: "",
                                vReplyMsg_id: "",
                                id:dd['iLoginId']+"_"+vActiveGroupId+"_"+Date.parse(new Date())
                            });
                        }

                        if(vActiveGroupId>0){
                            getGroupList();
                        }else{
                            getUserList();
                        }
                    }
                } else {
                    if (Number(splitStr[1]) > 0) {
                        if(MultipleSelectMsg.length){
                            MultipleSelectMsg.map((curEle,index)=>{
                                socket.emit('send_message', {
                                    receiverChatID: splitStr[1],
                                    senderChatID: dd['iLoginId'],
                                    content: curEle.type == "text" ? curEle.values : "vImages => " + String(curEle.values).trim(),
                                    ImageDataArr: [],
                                    vReplyMsg: "",
                                    vReplyMsg_id: ""
                                });
                            })

                            MultipleSelectMsg=[];
                        }else{
                        socket.emit('send_message', {
                            receiverChatID: splitStr[1],
                            senderChatID: dd['iLoginId'],
                            content: vForwardDataType == "text" ? vActiveMessage : "vImages => " + String(vActiveMessage).trim(),
                            ImageDataArr: [],
                            vReplyMsg: "",
                            vReplyMsg_id: ""
                        });
                        }

                        if(vActiveGroupId>0){
                            getGroupList();
                        }else{
                            getUserList();
                        }
                    }
                }
            }
        });

        isMultiSelect=0;
        $(".chat-message-outer-container").removeClass("select-message selected");
        MultipleSelectMsg = [];
        MultipleSelectDel = [];
        MultipleMessageDeleIds = [];

        $(".forwardChbx").each((e,item)=>{
            $(item).prop("checked",false)
        })
    }

    $('#forwardModal').modal('toggle');
    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");
})
//Forward Message Single Code End


//Forward Multiple Message Code Start 
$(document).on("click","#forwardMultiple",()=>{
    vUserForwrdSelect=[];
    vGroupForwrdSelect=[];

    $("#forwrdModalGrpMembList").html("");
    $("#ForwardSelTags").html("");
    $("#submitForwardForm").addClass("d-none");

    forwardHtmlList();
})
//Forward Multiple Message Code End


// MultipleSelectDel
$(document).on("click","#msgMultiDelConfirmModalClose,#msgMultiDelConfirmModalCancel",()=>{
    $("#msgMultiDelConfirmModal").modal("toggle");
})

$(document).on("click","#msgMultiDelConfirmModalSubmit",()=>{
    multipleMsgDel();
    $("#msgMultiDelConfirmModal").modal("toggle");
})

const multipleMsgDel=()=>{
    const vActiveGroupId=$("#vActiveGroupId").val();
    const vActiveUserId = $("#vActiveUserId").val();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL+'MessageDelete',
            data: {
                tToken: dd.tToken,
                MultipleSelectDel,
                vActiveGroupId,
                vActiveUserId
            },
            success: function(data, status, xhr) {
                if(data.status==200){
                    // Message deleted by its author
                    MultipleMessageDeleIds.map((curEle,index)=>{
                        const mesgDate=$("#"+curEle).attr("data-date");

                        let html=deleteMessageHtml(mesgDate,1);
                        
                        $("#"+curEle).closest(".chat-message-outer-container").removeClass("send-message");
                        $("#"+curEle).closest(".chat-message-outer-container").addClass("recieve-message");
                        $("#"+curEle).closest(".chat-message-outer-container").removeClass("select-message");
                        $("#"+curEle).closest(".chat-message-outer-container").html(html);

                    })

                    clearMultipleSelect();
                    MultipleSelectDel=[];
                }
            }
        })
    }
}

$(document).on("click","#MultipleMsgDelete",()=>{
    $("#msgMultiDelConfirmModal").modal("toggle");
})

function clearMultipleSelect(){
    $("#MultipleSelectDiv").addClass("d-none");
    $("#topHeaderActiveArea").removeClass("d-none");
    isMultiSelect=0;
    $(".chat-message-outer-container").removeClass("select-message selected");
    MultipleSelectMsg = [];
    MultipleSelectDel = [];
    MultipleMessageDeleIds = [];

    $(".forwardChbx").each((e,item)=>{
        $(item).prop("checked",false)
    })
}

$(document).on("click","#MultipleMsgCancel",()=>{
    clearMultipleSelect();
})


const SingleMessageDeleteApi=()=>{
    MultipleSelectDel.push(deleteMsg);
    MultipleMessageDeleIds.push(deleteMsgId);
    
    const vActiveGroupId=$("#vActiveGroupId").val();
    const vActiveUserId = $("#vActiveUserId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL+'MessageDelete',
            data: {
                tToken: dd.tToken,
                MultipleSelectDel,
                vActiveGroupId,
                vActiveUserId
            },
            success: function(data, status, xhr) {
                if(data.status==200){
                    // Message deleted by its author
                    MultipleMessageDeleIds.map((curEle,index)=>{

                        let html=deleteMessageHtml(deleteMsg,1);
                        
                        $("#"+curEle).closest(".chat-message-outer-container").removeClass("send-message");
                        $("#"+curEle).closest(".chat-message-outer-container").addClass("recieve-message");
                        $("#"+curEle).closest(".chat-message-outer-container").removeClass("select-message");
                        $("#"+curEle).closest(".chat-message-outer-container").html(html);

                        socket.emit('delete_message', {
                            content:curEle,
                            vActiveGroupId,
                            vActiveUserId,
                            tToken:dd.tToken
                        });

                        deleteMsg="";
                        deleteMsgId=""; 
                    })

                    clearMultipleSelect();
                    MultipleSelectDel=[];
                }
            }
        })
    }
}

//Single Message Delete Code Start
let deleteMsg="";
let deleteMsgId="';"
$(document).on("click",".deleteMsgSingle",(e)=>{
    deleteMsg="";
    deleteMsgId="";

    const dateMsg=$(e.currentTarget).attr("data-time");
    const dataId=$(e.currentTarget).attr("data-id");
    deleteMsg=dateMsg;
    deleteMsgId=dataId;

    $("#msgDelConfirmModal").modal("toggle");
})


$(document).on("click","#msgDelConfirmModalClose,#msgDelConfirmModalCancel",()=>{
    $("#msgDelConfirmModal").modal("toggle");
    deleteMsg="";
    deleteMsgId="";
})

$(document).on("click","#msgDelConfirmModalSubmit",()=>{
    SingleMessageDeleteApi();
    $("#msgDelConfirmModal").modal("toggle");
})
//Single Message Delete Code End


//Group Chat Start Code
const getGroupChatHtml=(curEle,id,iUserIdSelect,senderImageHtml,replyHtml,imageHtml,created_at,isSend,vUserName,isDeleted,isImage="")=>{

    const isImageOrHtml=isImage!=""?imageHtml:`<div class="mb-0 message-text" id="msg_${id}">${htmlDecode(curEle)}</div>`;
    const floatingDropHtml=isImage!=""?floatingDrop(id,curEle,"image",created_at,isSend,curEle):floatingDrop(id,curEle,"text",created_at,isSend);

    let vRecieveHtmlProfile=senderImageHtml;
    if(senderImageHtml==""){
        // const filterData=
        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

            ChatUserListArr.map((curEl3,index3)=>{
                if(curEl3.iUserId==iUserIdSelect){
                    colorOption.map((curEle2,index)=>{
                        if(curEle2.iColorId==curEl3.iColorOption){
                            vRecieveHtmlProfile=curEle2.vColorPick
                        }
                    })
                }
            })
        }
    }
    
    if(isDeleted==1){
        return deleteMessageHtml(created_at,isSend);
    }else{
        return `<div class="chat-message-outer-container ${isSend==1?'send-message':'recieve-message'} message-reply read">
                    <div class="selection">
                        <input class="form-check-input forwardChbx d-none" data-from="0" type="checkbox" value="${curEle}"  id="${id}" data-type="image">
                    </div>
                    <div class="chat-message-inner-container">
                        <div class="chat-message-container">
                            <div class="main-message">
                                <img src="${vRecieveHtmlProfile}" class="chat-message-profile" alt="chat-message-profile">
                                <div>
                                    <div class="chat-message-alignment">
                                        <div class="chat-message">
                                            ${replyHtml}
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    ${isImageOrHtml}
                                                </div>
                                                ${floatingDropHtml}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center message-author">
                                        <p class="message-droper-name">${vUserName}</p>
                                        <p class="message-drop-time">${timestampToAMPM(""+created_at)}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>`
    }
}

function GetGroupMessage(dd, iGroupId, filterDateStrVar, isSecond = 0) {
    const vChatUserListJson = JSON.parse($("#vChatUserListJson").val());

    $.ajax({
        type: 'POST',
        dataType: "JSON",
        async: false,
        url: API_URL+'GetGrpMessage',
        data: {
            tToken: dd.tToken,
            iGroupId: iGroupId,
            filterDateStr: filterDateStrVar
        },
        success: function(data, status, xhr) {
            if (data.status == 200) {

                JSON.parse(data.data).map((curEle2, index) => {

                    if (curEle2.iFromUserId == dd.iLoginId) {

                        let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2.vReplyMsg,curEle2?.vReplyFileName);

                        let senderImageHtml = $("#vProfilePick").attr("xlink:href");

                        if (curEle2.message.includes('vImages =>')) {
                            let removePrefix = curEle2.message;
                            const myImageStr = removePrefix.split("vImages =>");
                            if (myImageStr.length > 0) {
                                const myImageArr = myImageStr[1].split(",");
                                if (myImageArr.length > 0) {
                                    myImageArr.map((curEle, index) => {

                                        let imageHtml = ImageOrFileDipHtml(curEle);

                                        if (isSecond) {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);

                                            let html=getGroupChatHtml(curEle,curEle2.id,dd.iLoginId,senderImageHtml,replyHtml,imageHtml,curEle2.created_at,1,"You",curEle2.iDeleted,curEle);

                                            const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");

                                            $("#" + NewId).after(html);
                                            feather.replace();
                                            dynamicWithlabel();
                                        } else {
                                            dateTimeLineAdd(curEle2.created_at);

                                            let html=getGroupChatHtml(curEle,curEle2.id,dd.iLoginId,senderImageHtml,replyHtml,imageHtml,curEle2.created_at,1,"You",curEle2.iDeleted,curEle);

                                            $("#MessageList").append(html);
                                            feather.replace();
                                            dynamicWithlabel();
                                            scrollToBottom();
                                        }
                                    })
                                }
                            }
                        } else {

                            if (isSecond) {
                                dateTimeLineAdd(curEle2.created_at, isSecond);

                                let html=getGroupChatHtml(curEle2.message,curEle2.id,dd.iLoginId,senderImageHtml,replyHtml,"",curEle2.created_at,1,"You",curEle2.iDeleted);

                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                $("#" + NewId).after(html);
                                feather.replace();
                                dynamicWithlabel();
                            } else {
                                dateTimeLineAdd(curEle2.created_at);

                                let html=getGroupChatHtml(curEle2.message,curEle2.id,dd.iLoginId,senderImageHtml,replyHtml,"",curEle2.created_at,1,"You",curEle2.iDeleted);

                                $("#MessageList").append(html);

                                scrollToBottom();
                                feather.replace();
                                dynamicWithlabel();
                            }
                        }
                    } else {
                        let replyHtml = replyHtmlFunc(curEle2?.vReplyMsg_id, curEle2.vReplyMsg,curEle2?.vReplyFileName);

                        const filterData = vChatUserListJson.filter((curEle, index) => {
                            return curEle.iUserId == curEle2.iFromUserId
                        })

                        let senderImageHtml = "";
                        let vUserName = "";
                        if (filterData.length > 0) {
                            senderImageHtml = filterData[0]['vProfilePic'];
                            vUserName = filterData[0]['vFullName'];
                        }

                        if (curEle2.message.includes('vImages =>')) {
                            let removePrefix = curEle2.message;
                            const myImageStr = removePrefix.split("vImages =>");
                            if (myImageStr.length > 0) {
                                const myImageArr = myImageStr[1].split(",");
                                if (myImageArr.length > 0) {
                                    myImageArr.map((curEle, index) => {

                                        let imageHtml = ImageOrFileDipHtml(curEle);

                                        if (isSecond) {
                                            dateTimeLineAdd(curEle2.created_at, isSecond);

                                            let html=getGroupChatHtml(curEle,curEle2.id,curEle2.iFromUserId,senderImageHtml,replyHtml,imageHtml,curEle2.created_at,0,vUserName,curEle2.iDeleted,curEle);

                                            const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                            $("#" + NewId).after(html);
                                            feather.replace();
                                            dynamicWithlabel();
                                        } else {
                                            dateTimeLineAdd(curEle2.created_at);

                                            let html=getGroupChatHtml(curEle,curEle2.id,curEle2.iFromUserId,senderImageHtml,replyHtml,imageHtml,curEle2.created_at,0,vUserName,curEle2.iDeleted,curEle);
                                                    
                                            $("#MessageList").append(html);

                                            scrollToBottom();
                                            feather.replace();
                                            dynamicWithlabel();
                                        }

                                    })
                                }
                            }
                        } else {

                            if (isSecond) {
                                dateTimeLineAdd(curEle2.created_at, isSecond);

                                let html=getGroupChatHtml(curEle2.message,curEle2.id,curEle2.iFromUserId,senderImageHtml,replyHtml,"",curEle2.created_at,0,vUserName,curEle2.iDeleted);

                                const NewId = dateDispl(curEle2.created_at).replaceAll(" ", "_");
                                $("#" + NewId).after(html);
                                feather.replace();
                                dynamicWithlabel();
                            } else {
                                dateTimeLineAdd(curEle2.created_at);

                                let html=getGroupChatHtml(curEle2.message,curEle2.id,curEle2.iFromUserId,senderImageHtml,replyHtml,"",curEle2.created_at,0,vUserName,curEle2.iDeleted);

                                $("#MessageList").append(html);

                                scrollToBottom();
                                feather.replace();
                                dynamicWithlabel();
                            }

                        }
                    }
                })

                const scrollableDiv = document.getElementById('MessageList');
                const scrollPosition = scrollableDiv.scrollTop;

                if (scrollPosition == 0) {
                    $("#topFilter").removeClass("d-none");
                } else {
                    $("#topFilter").addClass("d-none");
                }
            } else {
                if (isSecond == 0) {
                    $("#MessageList").html("");
                    timeLineDate = "";
                    $("#topFilter").addClass("d-none");
                }
            }
        }
    });
}

socket.on('receive_grp_message', data => {
    const vActiveGroupId=$("#vActiveGroupId").val();

    if(data?.type && data?.type=="DeleteMessage"){
        if(vActiveGroupId==data.iGroupId){
            let html=deleteMessageHtml("",0);
                        
            $("#"+data.content).closest(".chat-message-outer-container").removeClass("select-message");
            $("#"+data.content).closest(".chat-message-outer-container").html(html);
        }
    }else if(data?.type && data?.type=="UpdateMessage"){
        if(vActiveGroupId==data.iGroupId){
            $("#msg_"+data.iMessageId).html(htmlDecode(data.content));
            updateDataInAllHtml(data.iMessageId,data.content);
        }
    }else{
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);
            
            const vActiveGroupId = $("#vActiveGroupId").val();
        
            if(vActiveGroupId>0 || activeTab=="Group"){
                getGroupList();
            }
        
            // EMP => console.log("data",data)
        
            const dataContent = data.content;
        
            const vChatUserListJson = JSON.parse($("#vChatUserListJson").val());
        
            let senderImageHtml = "";
            let senderName = "";
            if (vActiveGroupId > 0) {
                const filterData = vChatUserListJson.filter((curEle, index) => {
                    return curEle.iUserId == data.senderChatID
                })
        
                if (filterData.length > 0) {
                    senderImageHtml = filterData[0]['vProfilePic'];
                    senderName = filterData[0]['vFullName'];
                }
            }
        
            let replyHtml = replyHtmlFunc(data?.vReplyMsg_id, data?.vReplyMsg,data?.vReplyFileName);
        
            if (vActiveGroupId == data.iGroupSenderId) {
                if (dataContent.includes('vImages =>')) {
                    let removePrefix = dataContent;
                    const myImageStr = removePrefix.split("vImages =>");
                    if (myImageStr.length > 0) {
                        const myImageArr = myImageStr[1].split(",");
                        if (myImageArr.length > 0) {
                            myImageArr.map((curEle, index) => {
        
                                const imageHtml=ImageOrFileDipHtml(curEle);
        
                                if (timeLineDate == "") {
                                    dateTimeLineAdd();
                                }
                                
                                const id=data.senderChatID + "_" + vActiveGroupId + "_" + dateToInt();

                                let html = getGroupChatHtml(curEle,id,data.senderChatID,senderImageHtml,replyHtml,imageHtml,timestampToAMPM(),0,senderName,0,curEle);
    
                                // let html = `<div class="message-box friend-message">
                                //                 <p>${senderName} ${replyHtml} ${imageHtml} <span class="msgTime">${timestampToAMPM()}</span></p>
                                //                 ${senderImageHtml}
                                //                 ${forwardHtmlFunc(0,curEle,"image")}
                                //                 ${replyIconHtml(0,curEle,"image")}
                                //         </div>`;
                                $("#MessageList").append(html);
                                feather.replace();
                                dynamicWithlabel();
                                scrollToBottom();
        
                            })
                        }
                    }
                } else {
                    if (timeLineDate == "") {
                        dateTimeLineAdd();
                    }
    
                    const id=data.senderChatID + "_" + vActiveGroupId + "_" + dateToInt();
    
                    let html = getGroupChatHtml(data.content,id,data.senderChatID,senderImageHtml,replyHtml,"",timestampToAMPM(),0,senderName,0,"");
    
                    // let html = `<div class="message-box friend-message">
                    //             <p>${senderName} ${replyHtml} ${data.content} <span class="msgTime">${timestampToAMPM()}</span></p>
                    //             ${senderImageHtml}
                    //             ${forwardHtmlFunc(0,data.content,"text")}
                    //             ${replyIconHtml(0,data.content,"text")}
                    //         </div>`;
                    $("#MessageList").append(html);
                    feather.replace();
                    dynamicWithlabel();
                    scrollToBottom();
                }
            }
        }
    }
})
//Group Chat End Code


function isHTML(str) {
    var a = document.createElement('div');
    a.innerHTML = str;
  
    for (var c = a.childNodes, i = c.length; i--; ) {
      if (c[i].nodeType == 1) return true; 
    }
  
    return false;
}

//Search Message Code Start 
$('#vSearchText').on('input', function(e) {
    const nodeList = document.querySelectorAll(".message-text");
    let searchTextArr=[];
    for (let i = 0; i < nodeList.length; i++) {
        const idName=$(nodeList[i]).attr('id');
        var pos = $("#"+idName).offset();
        const serachString=String(e.target.value).toLowerCase();

        if(e.target.value!=""){
            
            const TextContainStr=String($(nodeList[i]).text()).toLowerCase();
            
            if(String(TextContainStr).includes(serachString)){
                if(!isHTML(nodeList[i].innerHTML)){
                    searchTextArr.push(pos?.top);
                    nodeList[i].style.backgroundColor="yellow";
                }else{
                    if(!isHTML(nodeList[i].innerHTML)){
                        nodeList[i].style.backgroundColor="transparent";
                    }
                }
            }else{
                if(!isHTML(nodeList[i].innerHTML)){
                    nodeList[i].style.backgroundColor="transparent";
                }
            }
        }else{
            if(!isHTML(nodeList[i].innerHTML)){
                nodeList[i].style.backgroundColor="transparent";
            }
        }
    }
    
    if(searchTextArr.length){
        $(".chat-area").scrollTop(Number(searchTextArr[0]))
    }
});
//Search Message Code End



//Edit Message Code Start
let iEditMsgId="";
let vEditMsgText="";
let vEditMsgType="";
let vEditMessageMainId="";
$(document).on("click",".EditMessage",(e)=>{
    const id=$(e.currentTarget).attr("data-id");
    const vMessage=$(e.currentTarget).attr("data-msg");
    const Type=$(e.currentTarget).attr("data-type");
    const MsgTime=$(e.currentTarget).attr("data-time");
    const filename=$(e.currentTarget).attr("data-filename");
    
    iEditMsgId=MsgTime;
    vEditMsgText=vMessage;
    vEditMsgType=Type;
    vEditMessageMainId=id;

    $("#sendMessage").removeClass("disabled");

    if(vEditMsgType=="text"){
        document.querySelector('.editor').focus();
     
        $(".editor").html(htmlDecode(vMessage));

        $(".teatarea-file-upload").removeClass("show");
        $("#fileInput").val("");
        $(".editor").addClass("show");
        $(".type-link").removeClass("d-none");
        $(".emoji-link").removeClass("d-none");
        $('.preview-container').css('display', 'flex');

        updateJson();
    }
})
//Edit Message Code End

//New Chat Start Code
$(document).on("click",".vNewChatStart",(e)=>{
    const id=$(e.currentTarget).attr("data-id");
    $("#MessageList").html("");

    $(".textarea-reply-container").removeClass("show");
    $(".editor").addClass("show");
    $('.file-preview').text("");

    let vChatUserListJsonArr = $("#vChatUserListJson").val();
    $(".add-user-popup").removeClass("active");

    let vConvertionChatArr=$("#vConvertionChatArr").val();

    if (vChatUserListJsonArr != "") {
        const ChatUserListArr = JSON.parse(vChatUserListJsonArr);

        const CheckExistAlread=(idUser)=>{
            return JSON.parse(vConvertionChatArr).filter((curEle,index)=>{
                return curEle.iUserId==idUser
            }).length
        };

        ChatUserListArr.map((curEle,index)=>{
            if(curEle.iUserId==id){
                if(CheckExistAlread(id)){
                    timeLineDate = "";
                    filterDateStr = "";

                    $(".textarea-reply-container").removeClass("show");
                    $(".editor").addClass("show");
                    $('.file-preview').text("");

                    $("#GroupDropDown").addClass("d-none");
                    
                    $(".vUserIdsCls").removeClass("chat-active");

                    $(".vUserIdsCls").each((e2,item)=>{
                        const iUserId=$(item).attr("data-id");
                        if(iUserId==id){
                            $(item).addClass("chat-active");
                            
                            $("#MessageList").html("");
                            $("#vSearchText").val("");
                            $("#vMessage").html('<span class="placeholder">Type your text here...</span>');
        
                            $("#StartChatArea").addClass("d-none");
                            $("#HeaderChatArea").removeClass("d-none");
                            $("#MainChatArea").removeClass("d-none");
                            $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
        
                            iEditMsgId="";
                            vEditMsgText="";
                            vEditMsgType="";
                            vEditMessageMainId="";
        
                            const iUserId = $(item).data('id');
                            const UserStatus = $(item).data('status') == 1 ? 'Online' : 'Offline';
        
                            const vConvertionChatArr = $("#vConvertionChatArr").val();
                            const UserList = JSON.parse(vConvertionChatArr);
        
                            UserList.map((curEle, index) => {
                                if (curEle.iUserId == iUserId) {
                                    if (curEle.vProfilePic != "") {
                                        $("#activeChatProfile").attr("xlink:href", curEle.vProfilePic)
                                    }
        
                                    $("#vActiveUserId").val(iUserId);
                                    $("#vActiveGroupId").val('');
        
                                    if (filterDateStr == "") {
                                        if (curEle?.lastDate && curEle?.lastDate != "") {
                                            filterDateStr = curEle.lastDate;
                                        }
                                    }
        
                                    $("#vUserIdsCls_" + iUserId).removeClass("unread-chat");
                                    if(UserStatus=="Online"){
                                        $("#activeChatSts").removeClass("offline");
                                        $("#activeChatSts").addClass("online");
                                    }else{
                                        $("#activeChatSts").removeClass("online");
                                        $("#activeChatSts").addClass("offline");
                                    }
                                    $("#activeChatName").text(curEle.vFullName);
                                    $("#activeChatStsDisp").text(UserStatus);
        
                                    getMessageFunc(curEle.iUserId, filterDateStr);
                                }
                            })
                        }
                    })

                }else{
                    $("#vActiveUserId").val(curEle.iUserId);
                    $("#MessageList").html("");
                    $("#activeChatName").text(curEle.vFullName);
                    $("#activeChatStsDisp").text(curEle.iStatus==0?'Offline':'Online');
                    if(curEle.iStatus==0){
                        $("#activeChatSts").removeClass("online");
                        $("#activeChatSts").addClass("offline");
                    }else{
                        $("#activeChatSts").removeClass("offline");
                        $("#activeChatSts").addClass("online");
                    }
                    if(curEle.vProfilePic==""){
                        colorOption.map((curEle2,index)=>{
                            if(curEle2.iColorId==curEle.iColorOption){
                                $("#activeChatProfile").attr("xlink:href",curEle2.vColorPick);
                            }
                        })

                    }else{
                        $("#activeChatProfile").attr("xlink:href",curEle.vProfilePic);
                    }
    
                    let profileImage = curEle.vProfilePic;
                    if (profileImage == "") {
                        profileImage = "./image/profile/profile.png";
                    }
    
                    $(".vUserIdsCls").removeClass("chat-active");
    
                    const htmlUser = `<li>
                                        <a href="javascript:;" class="chat-list  vUserIdsCls chat-active" data-id='${curEle.iUserId}' data-status='${curEle.iStatus}' id="vUserIdsCls_${curEle.iUserId}">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-profile-image me-3">
                                                        <svg role="none" viewBox="0 0 96 96">
                                                            <mask id="profile-image">
                                                                <circle fill="white" cx="48" cy="48" r="48"></circle>
                                                                <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                                            </mask>
                                                            <g mask="url(#profile-image)">
                                                                <image x="0" y="0" height="100%"
                                                                    preserveAspectRatio="xMidYMid slice" width="100%"
                                                                    xlink:href="${profileImage}"></image>
                                                            </g>
                                                        </svg>
                                                        <div class="${curEle.iStatus == 1 ? 'online' : 'offline'}"></div>
                                                    </div>
                                                    <div>
                                                        <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                                        <P class="user-profile-activity">${curEle.iStatus == 1 ? 'Online' : 'Offline'}</P>
                                                    </div>
                                                </div>
                                                <div class="unread-message">
                                                    <span><img src="images/profile/unread-message.svg" alt="unread-message"></span>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                `;
                    // $("#chatUserList").
                    $("#chatUserList").prepend(htmlUser);
    
                    if (vConvertionChatArr != "") {
                        const ChatConversionListArr = JSON.parse(vConvertionChatArr);
                        ChatConversionListArr.push(curEle);
    
                        $("#vConvertionChatArr").val(JSON.stringify(ChatConversionListArr));
                    }
                }

            }
        })
    }
})
//New Chat Start Code End

//View Group Modal Code Start
$(document).on("click","#vGroupInfoBtn",()=>{
    $("#groupDetails").modal("toggle");
    $("#group-basic-details").click();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
       
        const vActiveGroupId=$("#vActiveGroupId").val();
        let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatGroupListJsonArr);
            
            const filterData=chatGroupList.filter((curEle,index)=>{
                return curEle.iGroupId==vActiveGroupId
            })
    
            if(filterData.length>0){
                const vGroupName=filterData[0]['vGroupName'];
                const vGroupImage=filterData[0]['vGroupImage'];
                const iCreatedBy=filterData[0]['iCreatedBy'];
                const tDescription=filterData[0]['tDescription'];
                const dCreatedDate=filterData[0]['dCreatedDate'];
    
                $("#vGroupInforName").text(vGroupName);

                const filterColorOption=colorOption.filter((curEle2,index)=>{
                    return curEle2.iColorId==filterData[0]['iColorOption']
                })

                if(vGroupImage!=""){
                    $("#vGroupInforProfile").attr("src",vGroupImage);
                }else{
                    $("#vGroupInforProfile").attr("src",filterColorOption[0]['vColorPick']);
                }

                $("#vGroupInfoDescription").text(tDescription);
                $("#vGroupInfCreateDate").text(formatDateTime(dCreatedDate));
    
                if(dd.iLoginId==iCreatedBy){
                    $("#vGroupOwnerProfile").attr("xlink:href",$("#vProfilePick").attr("xlink:href"));
                    $("#vGroupOwnerName").text($("#vUserName").text());
                    $("#vGroupOwnerSts").text($("#vUserLoggedSts").text());
                    if($("#vUserLoggedSts").text()=="Online"){
                        $("#vGroupOwnerStsCls").removeClass("offline");
                        $("#vGroupOwnerStsCls").addClass("online");
                    }else{
                        $("#vGroupOwnerStsCls").addClass("offline");
                        $("#vGroupOwnerStsCls").removeClass("online");
                    }
                }else{
                    let vChatUserListJsonArr = $("#vChatUserListJson").val();
                    if (vChatUserListJsonArr != "") {
                        const chatGroupList = JSON.parse(vChatUserListJsonArr);

                        const filterUserList=chatGroupList.filter((curEle,index)=>{
                            return curEle.iUserId==filterData[0]['iCreatedBy']
                        })

                        if(filterUserList.length){
                            const UserSts=filterUserList[0]['iStatus'];
                            if(filterUserList[0]['vProfilePic']!=""){
                                $("#vGroupOwnerProfile").attr("xlink:href",filterUserList[0]['vProfilePic']);
                            }else{
                                colorOption.map((curEle2,index)=>{
                                    if(curEle2.iColorId==filterUserList[0]['iColorOption']){
                                        $("#vGroupOwnerProfile").attr("xlink:href",curEle2.vColorPick);
                                    }
                                })

                            }
                            $("#vGroupOwnerName").text(filterUserList[0]['vFullName']);
                            $("#vGroupOwnerSts").text(UserSts==0?'Offline':'Online');
                            if(UserSts==1){
                                $("#vGroupOwnerStsCls").removeClass("offline");
                                $("#vGroupOwnerStsCls").addClass("online");
                            }else{
                                $("#vGroupOwnerStsCls").addClass("offline");
                                $("#vGroupOwnerStsCls").removeClass("online");
                            }
                        }
                    }
                }
            }
        }
    }


})

$(document).on("click","#groupDetailsClose",()=>{
    $("#groupDetails").modal("toggle");
})

const groupMemberHtml=(chatGroupList,isEdit=0,vGroupMemberHtmlId="")=>{
    // $("#vGroupInfoMemeberList").html("");
    $("#"+vGroupMemberHtmlId).html("");
    chatGroupList.map((curEle)=>{
        let isCheckBox="";
        if(isEdit==2){
            const filterChecked=NewSelectMemberGrp.filter((curEle2,index)=>curEle2.iUserId==curEle.iUserId)
            isCheckBox=`<span><input class="form-check-input vEditGroupMembrCls" type="checkbox" value="${curEle.iUserId}" id="flexCheckDefault${curEle.iUserId}" ${filterChecked.length?'checked':''}></span>`;
        }else if(isEdit==1){
            isCheckBox=`<span><input class="form-check-input form-check-cross vEditGroupMembrDelCls" type="checkbox" value="${curEle.iUserId}" id="flexCheckDefault${curEle.iUserId}" ></span>`;
        }

        let vProfileImg=curEle.vProfilePic;
        if(curEle.vProfilePic==""){
            colorOption.map((curEle2,index)=>{
                if(curEle2.iColorId==curEle.iColorOption){
                    vProfileImg=curEle2.vColorPick
                }
            })
        }
        let html=`<li>
                    <a href="javascript:;" class="chat-list ${isEdit==0?'hide-checkbox':''}">
                        <label
                            class="d-flex align-items-center justify-content-between form-check ps-0"
                            for="flexCheckDefault${curEle.iUserId}">
                            <div class="d-flex align-items-center">
                                <div class="user-profile-image me-3">
                                    <svg role="none" viewBox="0 0 96 96">
                                        <mask id="profile-image">
                                            <circle fill="white" cx="48" cy="48" r="48">
                                            </circle>
                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                            </circle>
                                        </mask>
                                        <g mask="url(#profile-image)">
                                            <image x="0" y="0" height="100%"
                                                preserveAspectRatio="xMidYMid slice"
                                                width="100%"
                                                xlink:href="${vProfileImg}">
                                            </image>
                                        </g>
                                    </svg>
                                    <div class="${curEle.iStatus==0?'offline':'online'}"></div>
                                </div>
                                <div>
                                    <h5 class="user-profile-name">${curEle.vFullName}</h5>
                                    <P class="user-profile-activity">${curEle.iStatus==0?'Offline':'Online'}</P>
                                </div>
                            </div>
                            ${isCheckBox}
                        </label>
                    </a>
                </li>`;
        
        $("#"+vGroupMemberHtmlId).append(html);
        // $("#vGroupInfoMemeberList").append(html);
    })
}


$(document).on("click","#groupMembersTab",()=>{
    $("#vGroupInfoSearchMember").val("");

    const vActiveGroupId=$("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);
        
        const filterData=chatGroupList.filter((curEle,index)=>{
            return curEle.iGroupId==vActiveGroupId
        })

        const tGroupUsers=filterData[0]['tGroupUsers'];
        if(tGroupUsers!=""){
            const splitGrpUsr=String(tGroupUsers).split(",");

            let vChatUserListJsonArr = $("#vChatUserListJson").val();
            if (vChatUserListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatUserListJsonArr);

                const filterData=chatGroupList.filter((curEle,index)=>{
                    return splitGrpUsr.includes(''+curEle.iUserId)
                })

                groupMemberHtml(filterData,0,"vGroupInfoMemeberList");
            }
        }
    }
})

$(document).on("input","#vGroupInfoSearchMember",(e)=>{
    const searchStr=String(e.target.value).trim().toLocaleLowerCase();
    const vActiveGroupId=$("#vActiveGroupId").val();

    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);
        
        const filterData=chatGroupList.filter((curEle,index)=>{
            return curEle.iGroupId==vActiveGroupId
        })

        const tGroupUsers=filterData[0]['tGroupUsers'];
        if(tGroupUsers!=""){
            const splitGrpUsr=String(tGroupUsers).split(",");
            
            let vChatUserListJsonArr = $("#vChatUserListJson").val();
            if (vChatUserListJsonArr != "") {
                const chatUserListArr = JSON.parse(vChatUserListJsonArr);
        
                if(searchStr!=""){
                    const filterData=chatUserListArr.filter((curEle,index)=>{
                        return splitGrpUsr.includes(''+curEle.iUserId) && String(curEle.vFullName).toLocaleLowerCase
                        ().includes(searchStr);
                    })
        
                    groupMemberHtml(filterData,0,"vGroupInfoMemeberList");
                }else{
                    const filterData=chatUserListArr.filter((curEle,index)=>{
                        return splitGrpUsr.includes(''+curEle.iUserId) && String(curEle.vFullName).toLocaleLowerCase
                        ().includes(searchStr);
                    })
                    groupMemberHtml(filterData,0,"vGroupInfoMemeberList");
                } 
            }
        }
    }
})
//View Group Modal Code End


//Edit Group Detail Modal Code Start
let editMemberOldData=[];
let isNewMemberTab=0;
let NewSelectMemberGrp=[];

$(document).on("click","#vGroupEditGroup",()=>{
    $("#groupDetailsEdit").modal("toggle");
    isNewMemberTab=0;
    NewSelectMemberGrp=[];
    editMemberOldData=[];
    ColorOptionSelect="";
    finalColorSelection="";
    finalProfilePick="";
    isDeleteFile=0;

    $("#vEditGrupBasicDetBtn").click();

    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
    
        const vActiveGroupId=$("#vActiveGroupId").val();
    
        let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatGroupListJsonArr);
            
            const filterData=chatGroupList.filter((curEle,index)=>{
                return curEle.iGroupId==vActiveGroupId
            })
    
            if(filterData.length>0){
                const vGroupName=filterData[0]['vGroupName'];
                const vGroupImage=filterData[0]['vGroupImage'];
                const iCreatedBy=filterData[0]['iCreatedBy'];
                const tDescription=filterData[0]['tDescription'];
    
                const filterColorOption=colorOption.filter((curEle2,index)=>{
                    return curEle2.iColorId==filterData[0]['iColorOption']
                })

                if(vGroupImage!=""){
                    $("#vGroupEditProfile").attr("src",vGroupImage);
                }else{
                    $("#vGroupEditProfile").attr("src",filterColorOption[0]['vColorPick']);
                }
    
                $("#vEditGrupName").val(vGroupName);
                $("#vEditGroupDesc").val(tDescription);
    
                if(dd.iLoginId==iCreatedBy){
                    $("#vEditGropOwnProfile").attr("xlink:href",$("#vProfilePick").attr("xlink:href"));
                    $("#vEditGroupOwnerName").text($("#vUserName").text());
                    $("#vEditGroupOwnerSts").text($("#vUserLoggedSts").text());
                    if($("#vUserLoggedSts").text()=="Online"){
                        $("#vEditGroupOwnerStsCls").removeClass("offline");
                        $("#vEditGroupOwnerStsCls").addClass("online");
                    }else{
                        $("#vEditGroupOwnerStsCls").addClass("offline");
                        $("#vEditGroupOwnerStsCls").removeClass("online");
                    }
                }else{
                    let vChatUserListJsonArr = $("#vChatUserListJson").val();
                    if (vChatUserListJsonArr != "") {
                        const chatGroupList = JSON.parse(vChatUserListJsonArr);
    
                        const filterUserList=chatGroupList.filter((curEle,index)=>{
                            return curEle.iUserId==filterData[0]['iCreatedBy']
                        })
    
                        if(filterUserList.length){
                            const UserSts=filterUserList[0]['iStatus'];
                            $("#vEditGropOwnProfile").attr("xlink:href",filterUserList[0]['vProfilePic']);
                            $("#vEditGroupOwnerName").text(filterUserList[0]['vFullName']);
                            $("#vEditGroupOwnerSts").text(UserSts==0?'Offline':'Online');
                            if(UserSts==1){
                                $("#vEditGroupOwnerStsCls").removeClass("offline");
                                $("#vEditGroupOwnerStsCls").addClass("online");
                            }else{
                                $("#vEditGroupOwnerStsCls").addClass("offline");
                                $("#vEditGroupOwnerStsCls").removeClass("online");
                            }
                        }
                    }
                }
            }
        }
    }
})

$(document).on("click","#vEditGrupBasicDetBtn",()=>{
    isNewMemberTab=0;
    NewSelectMemberGrp=[];
})

$(document).on("click","#vGroupEditMemberList",()=>{
    $("#vSearchEditMember").val("");

    $("#vEditGrpButtonAdd").addClass("d-none");
    $("#vEditGrpButtonUpd").removeClass("d-none");
    $("#NewUserGrpBtn").removeClass("d-none");

    $("#editGroupModalHeader").addClass("modal-header-custom");
    $("#EditGroupModalBackBtn").addClass("d-none");
    $("#editGroupHeaderTitle").text("Group Members");

    const vActiveGroupId=$("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);
        
        const filterData=chatGroupList.filter((curEle,index)=>{
            return curEle.iGroupId==vActiveGroupId
        })

        const tGroupUsers=filterData[0]['tGroupUsers'];
        if(tGroupUsers!=""){
            const splitGrpUsr=String(tGroupUsers).split(",");

            let vChatUserListJsonArr = $("#vChatUserListJson").val();
            if (vChatUserListJsonArr != "") {
                const chatGroupList = JSON.parse(vChatUserListJsonArr);

                const filterData=chatGroupList.filter((curEle,index)=>{
                    return splitGrpUsr.includes(''+curEle.iUserId)
                })

                editMemberOldData=filterData;

                groupMemberHtml(filterData,1,"vEditGrpMemeberOld");
            }
        }
    }
})

let deleteMemberId="";
$(document).on("change",".vEditGroupMembrDelCls",(e)=>{
    const iSelectdId=Number(e.target.value);
    deleteMemberId=iSelectdId;

    if(editMemberOldData.length==1){
        $("#groupMemberModal").modal("toggle");
        $(e.currentTarget).prop("checked",false);
    }else{
        $("#delGroupMemeberModal").modal("toggle");
    }
})

$(document).on("click","#delGroupMemeberModalSubmit",()=>{
    const filterNewData=editMemberOldData.filter((curEle,index)=>{
        return curEle.iUserId!=deleteMemberId
    })

    editMemberOldData=filterNewData;
    $(".vEditGroupMembrDelCls").each((e,item)=>{
        const id=$(item).val();
        if(id==deleteMemberId){
            $(item).closest("li").remove();
            $("#delGroupMemeberModal").modal("toggle");
        }
    })
})

$(document).on("click","#delGroupMemeberModalCancel",()=>{
    $("#delGroupMemeberModal").modal("toggle");

    $(".vEditGroupMembrDelCls").each((e,item)=>{
        $(item).prop("checked",false)
    })
})

$(document).on("click","#delGroupMemeberModalClose",()=>{
    $("#delGroupMemeberModal").modal("toggle");
    $(".vEditGroupMembrDelCls").each((e,item)=>{
        $(item).prop("checked",false)
    })
})

$(document).on("input","#vSearchEditMember",(e)=>{
    const searchStr=String(e.target.value).toLocaleLowerCase();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    let iAddedUserArr=[];
    editMemberOldData.map((curEle,index)=>{
        iAddedUserArr.push(curEle.iUserId);
    })

    if(isNewMemberTab==0){
        if(searchStr!=""){
            const filterData=editMemberOldData.filter((curEle,index)=>{
                return String(curEle.vFullName).toLocaleLowerCase().includes(''+searchStr)
            })
            groupMemberHtml(filterData,1,"vEditGrpMemeberOld");
        }else{
            groupMemberHtml(editMemberOldData,1,"vEditGrpMemeberOld");
        }
    }else{
        if(searchStr!=""){
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
            
                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);
            
                    const filterUserList=chatGroupList.filter((curEle,index)=>{
                        return curEle.iUserId!=dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId) && String(curEle.vFullName).toLocaleLowerCase().includes(''+searchStr)
                    })
            
                    groupMemberHtml(filterUserList,2,"vEditGrpMemeberOld");
                }    
            }
        }else{
            if (isLocalStorageExist != null) {
                const dd = JSON.parse(isLocalStorageExist);
            
                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);
            
                    const filterUserList=chatGroupList.filter((curEle,index)=>{
                        return curEle.iUserId!=dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId)
                    })
            
                    groupMemberHtml(filterUserList,2,"vEditGrpMemeberOld");
                }    
            }
        }
    }
})

$(document).on("click","#NewUserGrpBtn",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    let iAddedUserArr=[];
    editMemberOldData.map((curEle,index)=>{
        iAddedUserArr.push(curEle.iUserId);
    })

    $("#editGroupModalHeader").removeClass("modal-header-custom");
    $("#editGroupModalHeader").removeClass("modal-header-custom");
    $("#EditGroupModalBackBtn").removeClass("d-none");
    $("#editGroupHeaderTitle").text("Add Group Members");

    $("#NewUserGrpBtn").addClass("d-none");
    isNewMemberTab=1;
    $("#vEditGrpButtonAdd").removeClass("d-none");
    $("#vEditGrpButtonUpd").addClass("d-none");

    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
    
        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatUserListJsonArr);
    
            const filterUserList=chatGroupList.filter((curEle,index)=>{
                return curEle.iUserId!=dd.iLoginId && !iAddedUserArr.includes(curEle.iUserId)
            })
    
            groupMemberHtml(filterUserList,2,"vEditGrpMemeberOld");
        }    
    }
})

$(document).on("click",".vEditGroupMembrCls",(e)=>{
    const iUserIdSelect=Number(e.target.value);

    if(e.target.checked){
        let vChatUserListJsonArr = $("#vChatUserListJson").val();
        if (vChatUserListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatUserListJsonArr);
    
            chatGroupList.map((curEle,index)=>{
                if(Number(curEle.iUserId)==iUserIdSelect){
                    NewSelectMemberGrp.push(curEle);
                }
            })
        } 
    }else{
        const filterData=NewSelectMemberGrp.filter((curEle,index)=>{
            return curEle.iUserId!=iUserIdSelect
        })

        NewSelectMemberGrp=filterData;
    }
})

$(document).on("click","#vEditGrpButtonAdd",()=>{
    if(NewSelectMemberGrp.length){
        editMemberOldData=[...editMemberOldData,...NewSelectMemberGrp];
        groupMemberHtml(editMemberOldData,1,"vEditGrpMemeberOld");
        NewSelectMemberGrp=[];
    }else{
        groupMemberHtml(editMemberOldData,1,"vEditGrpMemeberOld");
    }

    $("#vEditGrpButtonAdd").addClass("d-none");
    $("#vEditGrpButtonUpd").removeClass("d-none");
    isNewMemberTab=0;
    $("#NewUserGrpBtn").removeClass("d-none");
})

$(document).on("click","#EditGroupModalBackBtn",()=>{
    NewSelectMemberGrp=[];
    $("#editGroupModalHeader").addClass("modal-header-custom");
    $("#EditGroupModalBackBtn").addClass("d-none");
    $("#editGroupHeaderTitle").text("Group Members");
    
    if(isNewMemberTab==0){
        $("#groupDetailsEdit").modal("toggle");
    }else{
        $("#vSearchEditMember").val("");

        const vActiveGroupId=$("#vActiveGroupId").val();
        let vChatGroupListJsonArr = $("#vChatGroupListJson").val();
        if (vChatGroupListJsonArr != "") {
            const chatGroupList = JSON.parse(vChatGroupListJsonArr);
            
            const filterData=chatGroupList.filter((curEle,index)=>{
                return curEle.iGroupId==vActiveGroupId
            })

            const tGroupUsers=filterData[0]['tGroupUsers'];
            if(tGroupUsers!=""){
                const splitGrpUsr=String(tGroupUsers).split(",");

                let vChatUserListJsonArr = $("#vChatUserListJson").val();
                if (vChatUserListJsonArr != "") {
                    const chatGroupList = JSON.parse(vChatUserListJsonArr);

                    const filterData=chatGroupList.filter((curEle,index)=>{
                        return splitGrpUsr.includes(''+curEle.iUserId)
                    })

                    editMemberOldData=filterData;

                    groupMemberHtml(filterData,1,"vEditGrpMemeberOld");
                    isNewMemberTab=0;
                    $("#NewUserGrpBtn").removeClass("d-none");
                }
            }
        }
    }
})

$(document).on("click","#vEditGrpButtonUpd",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        
        const memeberList=[];
        editMemberOldData.map((curEle,index)=>{
            memeberList.push(curEle.iUserId);
        })
        const vEditGrupName=$("#vEditGrupName").val();
        const vEditGroupDesc=$("#vEditGroupDesc").val();
        const vActiveGroupId=$("#vActiveGroupId").val();
    
        const vGroupProfilePick=[{fileName:tempFilename,imageData:finalProfilePick}];

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'AddNewGrp',
            data: {
                tToken: dd.tToken,
                vGroupName:vEditGrupName, 
                tDescription:vEditGroupDesc,
                vUsers:memeberList.toString(), 
                vActiveGroupId, 
                vGroupProfile:vGroupProfilePick,
                ColorOptionSelect:finalColorSelection,
                isDeleteFile:isDeleteFile
            },
            success: function (data, status, xhr) {
                if(data.status==200){
                    getGroupList();
                    $("#groupDetailsEdit").modal("toggle");
                    isNewMemberTab=0;
                    $("#NewUserGrpBtn").removeClass("d-none");

                    NewSelectMemberGrp=[];
                    $("#editGroupModalHeader").addClass("modal-header-custom");
                    $("#EditGroupModalBackBtn").addClass("d-none");
                    $("#editGroupHeaderTitle").text("Group Members");

                    tempFilename="";
                    finalProfilePick="";
                    finalColorSelection="";
                }
            }
        });
    }
})


$(document).on("click","#UpdateGroupBasicDetail",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vActiveGroupId=$("#vActiveGroupId").val();

        let memeberList="";

        const vChatGroupListJson = $("#vChatGroupListJson").val();
        if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
            JSON.parse(vChatGroupListJson).map((curEle, index) => {
                if(curEle.iGroupId==vActiveGroupId){
                    memeberList=curEle.tGroupUsers

                    if((tempFilename=="" || tempFilename==undefined)){
                        finalColorSelection=curEle.iColorOption
                    }
                }
            })
        }

        const vEditGrupName=$("#vEditGrupName").val();
        const vEditGroupDesc=$("#vEditGroupDesc").val();
    
        const vGroupProfilePick=[{fileName:tempFilename,imageData:finalProfilePick}];

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'AddNewGrp',
            data: {
                tToken: dd.tToken,
                vGroupName:vEditGrupName, 
                tDescription:vEditGroupDesc,
                vUsers:"", 
                vActiveGroupId, 
                vGroupProfile:vGroupProfilePick,
                ColorOptionSelect:Number(finalColorSelection),
                isDeleteFile:Number(isDeleteFile)
            },
            success: function (data, status, xhr) {
                if(data.status==200){
                    getGroupList();
                    $("#groupDetailsEdit").modal("toggle");
                    isNewMemberTab=0;
                    $("#NewUserGrpBtn").removeClass("d-none");

                    NewSelectMemberGrp=[];
                    $("#editGroupModalHeader").addClass("modal-header-custom");
                    $("#EditGroupModalBackBtn").addClass("d-none");
                    $("#editGroupHeaderTitle").text("Group Members");

                    tempFilename="";
                    finalProfilePick="";
                    finalColorSelection="";
                }
            }
        });
    }
})



//Edit Group Detail Modal Code End

//Delete Group Code Start
$(document).on("click","#vGroupDeleteGroup",()=>{
    $("#groupDeleteModal").modal("toggle")
})

$(document).on("click","#groupDeleteModalClose,#groupDeleteModalCancel",()=>{
    $("#groupDeleteModal").modal("toggle");
})

$(document).on("click","#groupDeleteModalSubmit",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
    
        const vActiveGroupId=$("#vActiveGroupId").val();
    
        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'DeleteGroup',
            data: {
                tToken:dd.tToken,
                vActiveGroupId
            },
            success: function (data, status, xhr) {
                if(data.status==200){
                    $("#groupDeleteModal").modal("toggle");
                    getGroupList();
                    
                    $("#StartChatArea").removeClass("d-none");
                    $("#HeaderChatArea").addClass("d-none");
                    $("#MainChatArea").addClass("d-none");
                    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
                }
            }
        });
    }
})
//Delete Group Code End

//Permission based button display code start
$(document).on("click","#GroupDropDown",()=>{
    const vActiveGroupId=$("#vActiveGroupId").val();
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);

        const vChatGroupListJson = $("#vChatGroupListJson").val();
        if (vChatGroupListJson != "" && JSON.parse(vChatGroupListJson).length) {
            JSON.parse(vChatGroupListJson).map((curEle, index) => {
                if(curEle.iGroupId==vActiveGroupId){
                    if(curEle.iCreatedBy!=dd.iLoginId){
                        $("#vGroupEditGroup").closest("li").addClass("d-none");
                        $("#vGroupDeleteGroup").closest("li").addClass("d-none");
                    }else{
                        $("#vGroupEditGroup").closest("li").removeClass("d-none");
                        $("#vGroupDeleteGroup").closest("li").removeClass("d-none");
                    }
                }
            })
        }
    }
})
//Permission based button display code End


//Edit Profile Modal Code Start

function updateStatus(statusId){
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vUserName=$("#vUserName").text();

        $.ajax({
            type: 'POST',
            dataType: "JSON",
            async: false,
            url: API_URL + 'EditUserProfile',
            data: {
                tToken:dd.tToken,
                eCustStatus:statusId,
                vEditProfileFullName:vUserName
            },
            success: function (data, status, xhr) {
                if(data.status==200){
                    $("#vActiveProfileSts").val(statusId);
                    if(statusId==2){
                        $("#vUserLoggedSts").text("Online");
                        $("#vLoggedSts").removeClass("offline");
                        $("#vLoggedSts").addClass("online");
                    }else{
                        if(statusId==1){
                            $("#vUserLoggedSts").text("Online");
                            $("#vLoggedSts").removeClass("offline");
                            $("#vLoggedSts").addClass("online");
                        }else{
                            $("#vUserLoggedSts").text("Offline");
                            $("#vLoggedSts").addClass("offline");
                            $("#vLoggedSts").removeClass("online");
                        }
                    }

                    $(".changeOnlineStst").each((e,item)=>{
                        const datId=$(item).attr("data-id");
                        if(datId==statusId){
                            $(item).addClass("active");
                        }else{
                            $(item).removeClass("active");
                        }
                    })
                }
            }
        });
    }
}

$(document).on("click",".changeOnlineStst",(e)=>{
    const dataId=$(e.currentTarget).attr("data-id");
    updateStatus(dataId);
})


$(document).on("click","#vEditProfilePickBtn",()=>{
    $("#NewGroupProfilePickSubmit").removeClass("d-none");
    $("#EditUserProfileSubmit").addClass("d-none");

    isGroupProfileEdit=true;
    $("#vGroupProfilePickModal").modal("toggle");
    const vActiveGroupId=$("#vActiveGroupId").val();
    let vChatGroupListJsonArr = $("#vChatGroupListJson").val();

    $("#ImageCropperHeading").text("Create New Group");

    if (vChatGroupListJsonArr != "") {
        const chatGroupList = JSON.parse(vChatGroupListJsonArr);
        
        const filterData=chatGroupList.filter((curEle,index)=>{
            return curEle.iGroupId==vActiveGroupId
        })

        if(filterData.length>0){
            if(finalColorSelection=="" && finalProfilePick==""){
                const iColorOption=filterData[0]['iColorOption'];
                const vGroupImage=filterData[0]['vGroupImage'];
    
                $("#vColorOptionHtml").html("");
                colorOption.map((curEle,index)=>{
                    let html=`<li>
                                <a href="javascript:;" class="profile vProfileColorOptions ${vGroupImage=="" && iColorOption==curEle.iColorId?'active':''}"  data-id="${curEle.iColorId}">
                                    <img src="${curEle.vColorPick}" alt="group-profile">
                                </a>
                            </li>`;
                    $("#vColorOptionHtml").append(html);
                })
    
                if(vGroupImage!=""){
                    $("#item-img-output").removeClass("rounded-circle");
                    $("#item-img-output").addClass("rounded-3");
                    $("#item-img-output").attr("src",vGroupImage);
                    $("#deletGroupProfile").removeClass("d-none");
                    $("#vChooseProfileBtn").addClass("d-none");
                    vCroppingImageBase64=vGroupImage;
                }else{
                    $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
                    $("#deletGroupProfile").addClass("d-none");
                    $("#vChooseProfileBtn").removeClass("d-none");
                    $("#item-img-output").removeClass("rounded-circle");
                    $("#item-img-output").removeClass("rounded-3");
                    vCroppingImageBase64="";
                }
            }else{
                const iColorOption=finalColorSelection;
                const vGroupImage=finalProfilePick;
    
                $("#vColorOptionHtml").html("");
                colorOption.map((curEle,index)=>{
                    let html=`<li>
                                <a href="javascript:;" class="profile vProfileColorOptions ${vGroupImage=="" && iColorOption==curEle.iColorId?'active':''}"  data-id="${curEle.iColorId}">
                                    <img src="${curEle.vColorPick}" alt="group-profile">
                                </a>
                            </li>`;
                    $("#vColorOptionHtml").append(html);
                })
    
                if(vGroupImage!=""){
                    $("#item-img-output").removeClass("rounded-circle");
                    $("#item-img-output").addClass("rounded-3");
                    $("#item-img-output").attr("src",vGroupImage);
                    $("#deletGroupProfile").removeClass("d-none");
                    $("#vChooseProfileBtn").addClass("d-none");
                    vCroppingImageBase64=vGroupImage;
                }else{
                    $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
                    $("#deletGroupProfile").addClass("d-none");
                    $("#vChooseProfileBtn").removeClass("d-none");
                    $("#item-img-output").removeClass("rounded-circle");
                    $("#item-img-output").removeClass("rounded-3");
                    vCroppingImageBase64="";
                }
            }
        }
    }
})

//Edit Profle Modal Code End

//Edit Profile Pick Of Group Code Start
let colorOption=[
    {iColorId:1,vColorPick:"./images/profile/group-profile.svg"},
    {iColorId:2,vColorPick:"./images/profile/group-profile2.svg"},
    {iColorId:3,vColorPick:"./images/profile/group-profile3.svg"},
    {iColorId:4,vColorPick:"./images/profile/group-profile4.svg"},
];

let finalProfilePick="";
let finalColorSelection="";
let isGroupProfileEdit=false;
let isDeleteFile=0;

$(document).on("click","#vGroupPicturePick",()=>{
    $("#vGroupProfilePickModal").modal("toggle");
    $("#NewGroupProfilePickSubmit").removeClass("d-none");
    $("#EditUserProfileSubmit").addClass("d-none");

    isGroupProfileEdit=false;

    $("#ImageCropperHeading").text("Create New Group");

    $("#vColorOptionHtml").html("");
    colorOption.map((curEle,index)=>{
        let html=`<li>
                    <a href="javascript:;" class="profile vProfileColorOptions ${finalProfilePick=="" && finalColorSelection==curEle.iColorId?'active':''}"  data-id="${curEle.iColorId}">
                        <img src="${curEle.vColorPick}" alt="group-profile">
                    </a>
                </li>`;
        $("#vColorOptionHtml").append(html);
    })
    
    $("#item-img-output").removeClass("rounded-3");
    $("#item-img-output").removeClass("rounded-circle");

    if(finalProfilePick!=""){
        $("#item-img-output").attr("src",finalProfilePick);
        $("#deletGroupProfile").removeClass("d-none");
        $("#vChooseProfileBtn").addClass("d-none");
        vCroppingImageBase64=finalProfilePick;
    }else{

        $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");
        vCroppingImageBase64="";
    }
})


let ColorOptionSelect=0;
$(document).on("click",".vProfileColorOptions",(e)=>{
    $(".vProfileColorOptions").removeClass("active");
    $(e.currentTarget).addClass("active");

    ColorOptionSelect=$(e.currentTarget).attr("data-id");
    vCroppingImageBase64="";
    tempFilename="";

    $("#item-img-output").removeClass("rounded-3");
    $("#item-img-output").removeClass("rounded-circle");

    $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
    $("#deletGroupProfile").addClass("d-none");
    $("#vChooseProfileBtn").removeClass("d-none");
})

var $uploadCrop,tempFilename,rawImg,imageId;

function readFile(input) {
    $uploadCrop.croppie('bind', {
        url: ''
    }).then(function () {
        console.log('jQuery bind complete');
    });

    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('.upload-demo').addClass('ready');
            $('#cropImagePop').modal('show');
            rawImg = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    } else {
        swal("Sorry - you're browser doesn't support the FileReader API");
    }
}

$uploadCrop = $('#upload-demo').croppie({
    viewport: {
        width: 100,
        height: 100,
    },
    enforceBoundary: false,
    enableExif: true
});

$('#cropImagePop').on('shown.bs.modal', function () {
    $uploadCrop.croppie('bind', {
        url: rawImg
    }).then(function () {
        console.log('jQuery bind complete');
    });
});

$('.item-img').on('change', function () {
    imageId = $(this).data('id');
    tempFilename = $(this).val();
    $('#cancelCropBtn').data('id', imageId);
    readFile(this);
});

let vCroppingImageBase64="";
$('#cropImageBtn').on('click', function (ev) {
    $uploadCrop.croppie('result', {
        type: 'base64',
        format: 'jpeg',
        size: {
            width: 100,
            height: 100
        }
    }).then(function (resp) {
        vCroppingImageBase64=resp;
        $('#item-img-output').attr('src', resp);
        $('#cropImagePop').modal('hide');
        $("#deletGroupProfile").removeClass("d-none");
        $(".vProfileColorOptions").removeClass("active");
        $("#vChooseProfileBtn").addClass("d-none");
    });
});



$(document).on("click","#deletGroupProfile",()=>{
    ColorOptionSelect=getRandomInt(3);
    
    if(isGroupProfileEdit){
        $("#delGrpProfConfModal").modal("toggle");
    }else{
        vCroppingImageBase64="";
        tempFilename="";

        $("#item-img-output").removeClass("rounded-3");
        $("#item-img-output").removeClass("rounded-circle");

        $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");
    
    
        $(".vProfileColorOptions").each((e,item)=>{
            const id=$(item).attr("data-id");
            if(id==ColorOptionSelect){
                $(item).addClass('active');
            }
        })
    }
})

$(document).on("click","#delGrpProfConfModalClose,#delGrpProfConfModalCancel",()=>{
    $("#delGrpProfConfModal").modal("toggle");
})

$(document).on("click","#delGrpProfConfModalSubmit",()=>{
    vCroppingImageBase64="";
    tempFilename="";
    
    $("#item-img-output").removeClass("rounded-3");
    $("#item-img-output").removeClass("rounded-circle");

    $("#item-img-output").attr("src","./images/profile/custom-group-profile.svg");
    $("#deletGroupProfile").addClass("d-none");
    $("#vChooseProfileBtn").removeClass("d-none");


    $(".vProfileColorOptions").each((e,item)=>{
        const id=$(item).attr("data-id");
        if(id==ColorOptionSelect){
            $(item).addClass('active');
        }
    })
    
    $("#delGrpProfConfModal").modal("toggle");
})


$(document).on("click","#NewGroupProfilePickSubmit",()=>{
    const splitPath=String(tempFilename).split("\\");
    const fileName=tempFilename!=""?splitPath[splitPath.length-1]:"";

    tempFilename=fileName;

    finalProfilePick=vCroppingImageBase64;
    finalColorSelection=ColorOptionSelect;

    if(vCroppingImageBase64==""){
        isDeleteFile=1;
    }else{
        isDeleteFile=0;
    }

    if(isGroupProfileEdit){
        if(vCroppingImageBase64!=""){
            $("#vGroupEditProfile").attr("src",vCroppingImageBase64)
        }else{
            const filterColorOption=colorOption.filter((curEle2,index)=>{
                return curEle2.iColorId==ColorOptionSelect
            })
    
            if(filterColorOption.length>0){
                $("#vGroupEditProfile").attr("src",filterColorOption[0]['vColorPick']);
            }
        }
    }else{
        if(vCroppingImageBase64!=""){
            $("#vGroupPicSelected").attr("src",vCroppingImageBase64);
        }else{
            const filterColorOption=colorOption.filter((curEle2,index)=>{
                return curEle2.iColorId==ColorOptionSelect
            })
    
            if(filterColorOption.length>0){
                $("#vGroupPicSelected").attr("src",filterColorOption[0]['vColorPick']);
            }
        }
    }

    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click","#vBackGroupProfilePick",()=>{
    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click","#vGroupProfilePickClose",()=>{
    $("#vGroupProfilePickModal").modal("toggle");
})

$(document).on("click","#vGroupProfilePickCancel",()=>{
    $("#vGroupProfilePickModal").modal("toggle");
})

//Edit Profile Pick Of Group Code End

//Edit User Profile Code Start
$(document).on("click","#vEditProfilePickDrop",()=>{
    isDeleteFile=0;
    ColorOptionSelect="";
    finalColorSelection="";
    finalProfilePick="";
    $("#editProfilePickModal").modal("toggle");
    $("#vEditUserProfilePick").attr("src",$("#vProfilePick").attr("xlink:href"));
    $("#vEditProfileFullName").val($("#vUserName").text());
})

$(document).on("click","#vEditUserProfilePickBtn",()=>{
    const vLoggedColorOption=Number($("#vLoggedColorOption").val());
    finalColorSelection=vLoggedColorOption;
    isGroupProfileEdit=true;
    $("#NewGroupProfilePickSubmit").addClass("d-none");
    $("#EditUserProfileSubmit").removeClass("d-none");

    $("#vGroupProfilePickModal").modal("toggle");

    $("#ImageCropperHeading").text("Edit User Profile");

    if(vLoggedColorOption==0){
        $("#item-img-output").attr("src",$("#vEditUserProfilePick").attr("src"));
        $("#deletGroupProfile").removeClass("d-none");
        $("#vChooseProfileBtn").addClass("d-none");

        $("#item-img-output").removeClass("rounded-3");
        $("#item-img-output").addClass("rounded-circle");
    }else{

        $("#item-img-output").removeClass("rounded-3");
        $("#item-img-output").removeClass("rounded-circle");

        $("#item-img-output").attr("src",'./images/profile/custom-group-profile.svg');
        $("#deletGroupProfile").addClass("d-none");
        $("#vChooseProfileBtn").removeClass("d-none");
    }


    $("#vColorOptionHtml").html("");
    
    colorOption.map((curEle,index)=>{
        let html=`<li>
                    <a href="javascript:;" class="profile vProfileColorOptions rounded-circle ${finalProfilePick=="" && finalColorSelection==curEle.iColorId?'active':''}"  data-id="${curEle.iColorId}">
                        <img src="${curEle.vColorPick}" class="rounded-circle" alt="group-profile">
                    </a>
                </li>`;
        $("#vColorOptionHtml").append(html);
    })
})

$(document).on("click","#EditUserProfileSubmit",()=>{
    $("#vGroupProfilePickModal").modal("toggle");

    const splitPath=String(tempFilename).split("\\");
    const fileName=tempFilename!=""?splitPath[splitPath.length-1]:"";

    tempFilename=fileName;

    finalProfilePick=vCroppingImageBase64;
    finalColorSelection=ColorOptionSelect;

    if(vCroppingImageBase64==""){
        isDeleteFile=1;
    }else{
        isDeleteFile=0;
    }

    $("#vLoggedColorOption").val(finalColorSelection)

    if(vCroppingImageBase64!=""){
        $("#vEditUserProfilePick").attr("src",vCroppingImageBase64)
    }else{
        const filterColorOption=colorOption.filter((curEle2,index)=>{
            return curEle2.iColorId==ColorOptionSelect
        })

        if(filterColorOption.length>0){
            $("#vEditUserProfilePick").attr("src",filterColorOption[0]['vColorPick']);
        }
    }
})

$(document).on("click","#editProfilePickModalSubmit",()=>{
    const isLocalStorageExist = localStorage.getItem("whatsAppClone");
    if (isLocalStorageExist != null) {
        const dd = JSON.parse(isLocalStorageExist);
        const vEditProfileFullName=$("#vEditProfileFullName").val();
        const vUserProflePick=[{fileName:tempFilename,imageData:finalProfilePick}];

        if(vEditProfileFullName==""){
            $("#vEditProfileFullNameErr").removeClass("d-none"); 
        }else{
            $("#vEditProfileFullNameErr").addClass("d-none"); 
            $.ajax({
                type: 'POST',
                dataType: "JSON",
                async: false,
                url: API_URL + 'ProfileUpdate',
                data: {
                    tToken: dd.tToken,
                    vImage:vUserProflePick,
                    iColorOption:finalColorSelection,
                    isDeleteFile:isDeleteFile,
                    vEditProfileFullName:vEditProfileFullName
                },
                success: function (data, status, xhr) {
                    if(data.status==200){
                        $("#editProfilePickModal").modal("toggle");
                        if(data?.data){
                            $("#vLoggedColorOption").val(data.data.iColorOption);
        
                            if(Number(data.data.iColorOption)>0){
                                colorOption.map((curEl,index)=>{
                                    if(curEl.iColorId==data.data.iColorOption){
                                        $("#vProfilePick").attr("xlink:href", curEl.vColorPick);
                                    }
                                })
                            }else{
                                $("#vProfilePick").attr("xlink:href", API_URL + data.data.vProfilePic);
                            }
                        }
    
                        $("#vUserName").text(vEditProfileFullName);
                    }
                }
            })
        }

    } 
})


$(document).on("click","#editProfilePickModalCancel",()=>{
    $("#editProfilePickModal").modal("toggle");
})

//Edit User Profile Code End



//Scroll Top Position start old record Code Start

const element = document.querySelector("#MainChatArea");
element.addEventListener("scroll", (event) => {
    if(event.target.scrollTop==0){
        const isLocalStorageExist = localStorage.getItem("whatsAppClone");
        if (isLocalStorageExist != null) {
            const dd = JSON.parse(isLocalStorageExist);

            const vActiveGroupId = $("#vActiveGroupId").val();
            const vActiveUserId = $("#vActiveUserId").val();

            if (vActiveGroupId > 0) {
                const BackOneMonthDate = oneMonthBackDateGroup(filterDateStr);

                const StringData = "GROUP_" + vActiveGroupId + "_" + BackOneMonthDate + ".json";

                GetGroupMessage(dd, vActiveGroupId, StringData, 1);

            } else {
                const BackOneMonthDate = oneMonthBackDate(filterDateStr);
                const StringData = dd.iLoginId + "_" + BackOneMonthDate + ".json";
                getMessageFunc(vActiveUserId, StringData, 1);
            }
        }
    }
});

//Scroll Top Position start old record Code End