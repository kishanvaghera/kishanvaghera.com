<?php
    include("config.php");
    @session_start();
?>

<html>   
    <head>
        <title>Chat App</title>
        <link rel="stylesheet" href="./custom.css">
    </head>
    <body>
        <label>User Id</label>
        <input type="text" id="isLoggedUser" /><br/><br/>
        <label>User Name</label>
        <input type="text" id="Cur_Fname" />
        <br/><br/>
        <label>Email Id</label>
        <input type="text" id="vEmail" />
        <span id="errEmail" style="color: red;display:none;">Email is not valid.</span>
        <br/><br/>
        <label>Password</label>
        <input type="password" id="vPassWord" minlength="8" maxlength="15"/>
        <button id="ViewPassword">View</button>

        <div id="passwordErrSuggest" class="d-none mt-3">
            <h6 class="validationTitle mb-2">Password requirements</h6>
            <ul id="passwordErrorList">
            </ul>
        </div>

        <br/><br/>
        <button id="submit">Submit</button>
        <div id="loader" style="display: none;"></div>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="./js/CustomFun.js"></script>
    <script>

        $(document).ready(()=>{
            $("#submit").click(()=>{
                const isLoggedUser=String($("#isLoggedUser").val()).trim();
                const Cur_Fname=String($("#Cur_Fname").val()).trim();
                const vPassWord=String($("#vPassWord").val()).trim();
                const vEmail=String($("#vEmail").val()).trim();

                if(isLoggedUser=="" || Cur_Fname=="" || vPassWord=="" || vEmail==""){
                    alert("Please fill all field!");
                }else{
                    if(!validateEmail(vEmail)){
                        $("#errEmail").css("display","block");
                    }else{
                        if(addErrorPaswordCust(vPassWord,"passwordErrSuggest","passwordErrorList")){
                            $("#submit").css("display","none");
                            $("#loader").css("display","block");

                            $.ajax({
                                type: 'POST',
                                dataType: "JSON",
                                url: '<?=$API_URL?>signup',
                                data: {vUsername:Cur_Fname, vFullName:Cur_Fname, iEngId:isLoggedUser,vPassWord:vPassWord,vEmail:vEmail},
                                success: function(data, status, xhr) {
                                    if(data.status==200){
                                        $.ajax({
                                            type: 'POST',
                                            dataType: "JSON",
                                            url: 'mail.php',
                                            data: {action:"verify_email",isLoggedUser:isLoggedUser,vFullName:Cur_Fname,vEmailAdr:vEmail},
                                            success: function(data2, status2, xhr) {
                                                $("#submit").css("display","block");
                                                $("#loader").css("display","none");
            
                                                if(data2.status==200){
                                                    window.location = "./verify_mail.php?id="+data2.url;
                                                }else{
                                                    alert(data2.message);
                                                }
                                            }
                                        });
                                    }else{
                                        $("#submit").css("display","block");
                                        $("#loader").css("display","none");
                                        alert(data.message);
                                    }
                                }
                            });
                        }
                    }
                }
            })

            $("#vPassWord").on("input",(e)=>{
                const vPassWordStr=String(e.target.value).trim();
                addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
            })

            $("#vEmail").on("input",(e)=>{
                const vEmail=String($("#vEmail").val()).trim();
                if(validateEmail(vEmail)){
                    $("#errEmail").css("display","none");
                }
            })
            

            $("#ViewPassword").on("click",(e)=>{
                const vPassWordtype=$("#vPassWord").attr("type");
                if(vPassWordtype=="password"){
                    $("#vPassWord").attr("type","text");
                }else{
                    $("#vPassWord").attr("type","password");
                }
            })

            $("#vPassWord").on("click",(e)=>{
                const htmlChild=String($('#passwordErrorList').html()).trim();
                if (htmlChild==""){
                    const vPassWordStr=$("#vPassWord").val();
                    addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
                }
            })
        })

    </script>
    </body>
</html>