<?php
    include("config.php");
    @session_start();
?>
<html>
<head>
    <title>Chat App</title>
    <link rel="stylesheet" href="./custom.css">
</head>
<body>
    <?php
        if(isset($_SESSION['verfiy_email_msg']) && $_SESSION['verfiy_email_msg']!=""){
            echo "<span style='color: green;'>".$_SESSION['verfiy_email_msg']."</span>";
            $_SESSION['verfiy_email_msg']="";
        }
    ?>
    <label>User Id</label>
    <input type="text" id="isLoggedUser" /><br /><br />
    <label>User Name</label>
    <input type="text" id="Cur_Fname" value="" readonly/>
    <br /><br />
    <label>Password</label>
    <input type="password" id="vPassword" />
    <button id="ViewPassword">View</button>
    <br /><br />
    <div id="loaderSubmit" style="display: none;"></div>
    <button id="submit">Submit</button>

    <br />
    <br />
    <a href="javascript:void(0);" id="forgotPassword">Forgot password</a>
    <div id="loader" style="display: none;"></div>
    <span id="vForgotPasswordSend" style="color: green;display:none;">Your forgot password link has been sent to your email address.</span>
    <br />
    <br />
    <a href="signup.php">Signup Page</a>

    <script src="plugins/socket/socket.io.min.js"></script>
    <script src="plugins/jquery/jquery.min.js"></script>
    <script>
    $(document).ready(() => {
        function submitData(){
            const isLoggedUser = $("#isLoggedUser").val();
            const Cur_Fname = $("#Cur_Fname").val();
            const vPassword = $("#vPassword").val();
    
            if (isLoggedUser == "" || Cur_Fname == "" || vPassword == "") {
                alert("Please fill all field!");
            } else {
                localStorage.removeItem("whatsAppClone");
    
                $("#loaderSubmit").css("display","block");
                $("#submit").css("display","none");
                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    async: false,
                    url: '<?=$API_URL?>login',
                    data: {
                        iUserId: isLoggedUser,
                        Cur_Fname: Cur_Fname,
                        vPassword: vPassword
                    },
                    success: function(data, status, xhr) {
                        if (data.status == 200) {
                            localStorage.setItem("whatsAppClone", JSON.stringify({
                                tToken: data.tToken,
                                iLoginId: data.iUserId
                            }));
                            window.location = "./index_copy_2.php";
                        }else if(data.status == 411){
                            if(data.type=="already_login"){
                                let text = data.message;
                                if (confirm(text) == true) {
                                    var socket = io('http://192.168.1.35:9000', {
                                        transports: ['websocket']
                                    });

                                    socket.emit('login', {
                                        iLoggedId:isLoggedUser
                                    });
    
                                    setTimeout(() => {
                                        submitData();
                                    }, 500);
                                }else{
                                    $("#loaderSubmit").css("display","none");
                                    $("#submit").css("display","block");
                                }
                            }else{
                                $.ajax({
                                        type: 'POST',
                                        dataType: "JSON",
                                        async: false,
                                        url: 'mail.php',
                                        data: {action:"verify_email",isLoggedUser:isLoggedUser,vFullName:Cur_Fname,vEmailAdr:vEmailAdr},
                                        success: function(data2, status2, xhr) {
                                            if(data2.status==200){
                                                window.location = "./verify_mail.php?id="+data2.url;
                                            }else{
                                                alert(data2.message);
                                                $("#loaderSubmit").css("display","none");
                                                $("#submit").css("display","block");
                                            }
                                        }
                                });
                            }
                        }else {
                            alert(data.message)
                            $("#loaderSubmit").css("display","none");
                            $("#submit").css("display","block");
                        }
                    }
                });
            }
        }

        //Submit login form
        $("#submit").click(() => {
            submitData();
        })

        //Get Username from User Id
        let vEmailAdr="";
        $("#isLoggedUser").on("input", (e) => {
            vEmailAdr="";
            const iUserId = e.target.value;
            if (iUserId != "") {
                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    async: false,
                    url: '<?=$API_URL?>getUserName',
                    data: {
                        iUserId
                    },
                    success: function(data, status, xhr) {
                        if (data.status == 200) {
                            $("#Cur_Fname").val(data.message);
                            if(data?.vEmail){
                                vEmailAdr=data?.vEmail;
                            }
                        } else {
                            $("#Cur_Fname").val("");
                        }
                    }
                });
            } else {
                $("#Cur_Fname").val("");
            }
        })

        //Forgot Password
        $("#forgotPassword").on("click",(e)=>{
            e.preventDefault();
            const isLoggedUser = $("#isLoggedUser").val();
            const Cur_Fname = $("#Cur_Fname").val();

            if(isLoggedUser=="" || Cur_Fname==""){
                if(isLoggedUser==""){
                    alert("please enter user Id.");
                }else{
                    alert("user is not exist");
                }
            }else{
                
                $("#forgotPassword").css("display","none");
                $("#loader").css("display","block");

                $.ajax({
                    type: 'POST',
                    dataType: "JSON",
                    url: 'mail.php',
                    data: {
                        action:"forgot_password",
                        vFullName:Cur_Fname,
                        isLoggedUser:isLoggedUser,
                        vEmailAdr:vEmailAdr
                    },
                    success: function(data, status, xhr) {
                        
                        if(data.status==200){
                            $("#forgotPassword").css("display","block");
                            $("#loader").css("display","none");
                            $("#vForgotPasswordSend").css("display","block");
                        }else{
                            $("#forgotPassword").css("display","block");
                            $("#loader").css("display","none");
                            alert("some network issue.");
                        }
                    }
                });
            }
        })

        $("#ViewPassword").on("click",()=>{
            const vPassWordtype=$("#vPassword").attr("type");
            if(vPassWordtype=="password"){
                $("#vPassword").attr("type","text");
            }else{
                $("#vPassword").attr("type","password");
            }
        })
    })
    </script>
</body>

</html>