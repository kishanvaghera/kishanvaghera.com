const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcrypt');
const sha1 = require('sha1');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
var cors = require('cors');
const http = require("http");
const path = require("path");
const fs = require('fs');
const request = require('request');

const app = express();
const server = http.createServer(app);

const io = require('socket.io')(server, {
  maxHttpBufferSize: 1e8
});

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header("Cache-Control", "public, max-age=3600");
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// const corsOptions = {
//   origin: 'http://192.168.1.35',
//   optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
// };

app.use(cors())
app.use(express.json({ limit: '1000mb' }));
app.use(bodyParser.json({ limit: '1000mb', extended: true }));
app.use(bodyParser.urlencoded({ limit: "1000mb", extended: true }));
app.use(bodyParser.text({ limit: '1000mb' }));

const mainUrl = "http://192.168.1.35:9000/";

// Create a connection pool for the MySQL database
const pool = mysql.createPool({
  host: '192.168.1.35',
  user: 'root',
  password: '123456',
  database: 'chatapp',
});

//Get Current Date in 12_01_2024 format
const currentDate = (dateStr = "") => {
  let date = dateStr == "" ? new Date() : new Date(dateStr);
  let year = date.getFullYear();
  let month = ('0' + (date.getMonth() + 1)).slice(-2);
  let day = ('0' + date.getDate()).slice(-2);

  let formattedDate = day + "_" + month + "_" + year;

  return formattedDate;
}

//Convert Date Time To Date for file only
const ConvertDateForFile = (dateStr) => {
  const newSplitStr = String(dateStr).split(" ");
  const DateSplitStr = String(newSplitStr[0]).split("-");

  let year = DateSplitStr[0];
  let month = DateSplitStr[1];
  let day = DateSplitStr[2];

  let formattedDate = day + "_" + month + "_" + year;

  return formattedDate;
}

//Get Last file of user conversion
const getLastFileOfUser = (iUserId, iToUserId) => {
  if (fs.existsSync("DB/COMMONDB.json")) {
    var content = fs.readFileSync('DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const filterData = dd.array.filter((curEle, index) => {
      return (curEle.senderId == iUserId && curEle.recieverId == iToUserId) || (curEle.senderId == iToUserId && curEle.recieverId == iUserId)
    })

    return filterData.length > 0 ? filterData[0]['created_at'] : "";
  } else {
    return "";
  }

};

//Get Last file of user group conversion
const getLastFileOfUserGroup = (iGroupId) => {
  const dbFolderPath = "DB/";

  const NewArr = fs.readdirSync(dbFolderPath);

  const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;

  let newDateArr = [];
  const fileExist = dd.length ? dd.filter((curEle, index) => {
    const splitStr = String(curEle).split("_");

    if (splitStr[0] == "GROUP" && splitStr[1] == iGroupId) {
      const day = splitStr[2];
      const month = splitStr[3];
      const year = String(splitStr[4]).split(".")[0];

      const DateString = year + "-" + month + "-" + day;
      newDateArr.push(DateString);
    }

    return splitStr[1] == iGroupId;
  }) : []

  if (fileExist.length > 0) {
    const sortingArr = newDateArr.length ? newDateArr.sort((a, b) => (a ?? '').localeCompare(b ?? '')) : []
    const dateSplit = String(sortingArr[sortingArr.length - 1]).split("-");
    const finalDate = dateSplit[2] + "_" + dateSplit[1] + "_" + dateSplit[0];

    const dateString = "GROUP_" + iGroupId + "_" + finalDate + ".json";

    if (dd.includes(dateString)) {
      var content = fs.readFileSync('./DB/' + dateString, 'utf8');
      const fileDD = typeof content == "string" ? JSON.parse(content) : content;

      const lastDate = fileDD.array ? fileDD.array[Number(fileDD.array.length) - 1]['created_at'] : "";

      return { date: finalDate, time: lastDate };
    } else {
      return { date: "", time: "" };
    }
  } else {
    // return "GROUP_"+iGroupId+"_"+currentDate()+".json";
    return { date: "", time: "" };
  }
};

//Get Before Weak Date
const oneMonthBackDate = (givenDateStr = "") => {
  var givenDate = new Date();
  if (givenDateStr != "") {
    // Split the given date string into day, month, and year
    var parts = givenDateStr.split("_");

    var day = parseInt(parts[1], 10);
    var month = parseInt(parts[2], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[3], 10);
    givenDate = new Date(year, month, day);
  }

  // Calculate the date before by subtracting the number of milliseconds in a day
  var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
  var daysBefore = 7; // Number of days before
  var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

  // Format the target date as dd_mm_yyyy
  var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

  return targetDateString;
}

//Get Before Weak Date
const oneMonthBackDateGroup = (givenDateStr = "") => {
  var givenDate = new Date();
  if (givenDateStr != "") {
    // Split the given date string into day, month, and year
    var parts = givenDateStr.split("_");

    var day = parseInt(parts[2], 10);
    var month = parseInt(parts[3], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[4], 10);
    givenDate = new Date(year, month, day);
  }

  // Calculate the date before by subtracting the number of milliseconds in a day
  var millisecondsInADay = 1000 * 60 * 60 * 24; // 1 day = 24 hours * 60 minutes * 60 seconds * 1000 milliseconds
  var daysBefore = 7; // Number of days before
  var targetDate = new Date(givenDate.getTime() - daysBefore * millisecondsInADay);

  // Format the target date as dd_mm_yyyy
  var targetDateString = targetDate.getDate().toString().padStart(2, '0') + "_" + (targetDate.getMonth() + 1).toString().padStart(2, '0') + "_" + targetDate.getFullYear();

  return targetDateString;
}

//get Two Date Array List
const GetMonthArrayDate = (startDateStr, endDateStr, vPrefix = "") => {
  // Given dates in the format dd_mm_yyyy

  // Function to convert date string to Date object
  function stringToDate(dateStr) {
    var parts = dateStr.split("_");
    var day = parseInt(parts[0], 10);
    var month = parseInt(parts[1], 10) - 1; // Month is zero-indexed
    var year = parseInt(parts[2], 10);
    return new Date(year, month, day);
  }

  // Convert date strings to Date objects
  var startDate = stringToDate(startDateStr);
  var endDate = stringToDate(endDateStr);

  // Array to store the list of dates
  var dateList = [];

  // Loop to generate the list of dates between startDate and endDate
  var currentDate = new Date(startDate);
  while (currentDate <= endDate) {
    // Format the current date as dd_mm_yyyy
    var dateString = currentDate.getDate().toString().padStart(2, '0') + "_" + (currentDate.getMonth() + 1).toString().padStart(2, '0') + "_" + currentDate.getFullYear();

    // Push the formatted date string into the dateList array
    dateList.push(vPrefix + "_" + dateString + ".json");

    // Move to the next day
    currentDate.setDate(currentDate.getDate() + 1);
  }

  return dateList;
}

const saveBlobFile = (file, uploadFolder) => {
  var base64Data = file.split("base64,");

  fs.writeFile(uploadFolder, base64Data[1], 'base64', (err) => {
    if (err) throw err;
  })
}

function getUnreadMsg(date, iUserId, receverId) {
  if (fs.existsSync('./DB/' + iUserId + '_' + currentDate(date) + '.json')) {
    var content = fs.readFileSync('./DB/' + iUserId + '_' + currentDate(date) + '.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const totalUnreadMsg = dd.array.filter((curEle, index) => {
      return curEle.iRead == 0 && curEle.iFromUserId == receverId
    })

    return totalUnreadMsg.length
  } else {
    return 0
  }
}

function isCommunicate(iUserId, receverId) {
  if (fs.existsSync('./DB/COMMONDB.json')) {
    var content = fs.readFileSync('./DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const isMsgExist = dd.array.filter((curEle, index) => {
      return curEle.senderId == iUserId && curEle.recieverId == receverId
    })

    return isMsgExist.length
  } else {
    return 0
  }
}

function isStartChatMsg(iUserId, receverId){
  // isStartChat
  if (fs.existsSync('./DB/COMMONDB.json')) {
    var content = fs.readFileSync('./DB/COMMONDB.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const isMsgExist = dd.array.filter((curEle, index) => {
      return curEle.senderId == iUserId && curEle.recieverId == receverId && curEle.isStartChat
    })

    return isMsgExist.length
  } else {
    return 0
  }
}

function getGroupUnreadMsg(date, iGroupId, iUserId) {
  if (fs.existsSync('./DB/GROUP_' + iGroupId + '_' + date + '.json')) {
    var content = fs.readFileSync('./DB/GROUP_' + iGroupId + '_' + date + '.json', 'utf8');

    const dd = typeof content == "string" ? JSON.parse(content) : content;

    const totalUnreadMsg = dd.array.filter((curEle, index) => {
      return !String(curEle.tReadUsers).split(",").includes("" + iUserId);
    })
    return totalUnreadMsg.length
  } else {
    return 0
  }
}

const datFunction = () => {
  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1; // Months start at 0!
  let dd = today.getDate();

  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;

  const formattedToday = dd + '_' + mm + '_' + yyyy;

  return formattedToday;
}

const currentDateTime = () => {
  return new Date(new Date().toString().split('GMT')[0] + ' UTC').toISOString().split('.')[0].replace('T', ' ')
}

const dateToInt = () => {
  return Date.parse(new Date());
}

const lastChatUpdate = (senderChatID, receiverChatID,isStartChat="") => {

  if (fs.existsSync("DB/COMMONDB.json")) {

    const data = fs.readFileSync('DB/COMMONDB.json', 'utf8');

    const db = typeof data == "string" ? JSON.parse(data) : data;

    let ikeyUpdate = "";
    const filterData = db?.array.filter((curEle, index) => {
      const checkCondi = curEle.senderId == senderChatID && curEle.recieverId == receiverChatID;
      if (checkCondi) {
        ikeyUpdate = index;
      }
      return checkCondi
    })

    if (filterData.length) {
      db.array[ikeyUpdate] = {
        senderId: senderChatID,
        recieverId: receiverChatID,
        created_at: currentDateTime(),
        isStartChat:isStartChat==""?db.array[ikeyUpdate]['isStartChat']:isStartChat
      }

      fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));

    } else {
      db.array.push({
        senderId: senderChatID,
        recieverId: receiverChatID,
        created_at: currentDateTime(),
        isStartChat:isStartChat
      })

      fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));
    }
  } else {
    let db = {
      array: [
        {
          senderId: senderChatID,
          recieverId: receiverChatID,
          created_at: currentDateTime(),
          isStartChat:isStartChat
        }
      ]
    }

    fs.writeFileSync('DB/COMMONDB.json', JSON.stringify(db));
  }
}

const JsonFileGenerate = (senderJsonFile, senderChatID, receiverChatID, content, isSend, vReplyMsg, vReplyMsg_id,id,vReplyFileName,isGroup=0,isThumb="",isGreetingMsg=0,iRequestMsg=0,vMemeberList="",vGroupMessageType="",isForwardMsg=0,isDeleteprofile=0,vDeleteMemberId=0,vNewAdminId="",RequestMemberId="") => {
  if (fs.existsSync('DB/' + senderJsonFile)) {
    const data = fs.readFileSync('DB/' + senderJsonFile, 'utf8');

    const db = data == "" ? { array: [] } : JSON.parse(data);

    let vReplyMsg_idFinal = vReplyMsg_id;
    let vReplyMsgFinal = vReplyMsg;

    if (vReplyMsg_idFinal!="") {
      let explodeId=String(vReplyMsg_idFinal).split("_");
      let readableDate = new Date(Number(explodeId[2])).toLocaleString();

      const dataOld =isGroup==1?fs.readFileSync('DB/' + "GROUP_"+explodeId[1]+"_"+currentDate(readableDate)+".json", 'utf8'):fs.readFileSync('DB/' + explodeId[0]+"_"+currentDate(readableDate)+".json", 'utf8');
      const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);

      if (dbOld.array.length) {
          const filterData=dbOld?.array.filter((curEle,index)=>{
            return curEle.id==vReplyMsg_idFinal
          })
          if(filterData.length>0){
            vReplyMsgFinal = filterData[0]['message'];
          }
      }
    }

    db.array.push({
      id: id,
      iFromUserId: senderChatID,
      iToUserId: receiverChatID,
      iRead: isSend == 1 ? 1 : 0,
      iReadTo: 0,
      message: content,
      created_at: currentDateTime(),
      vReplyMsg: vReplyMsgFinal,
      vReplyMsg_id: vReplyMsg_idFinal,
      tReadUsers: senderChatID,
      vReplyFileName:vReplyFileName,
      iDeleted: 0,
      iEdited:0,
      vImageThumb:isThumb,
      isGreetingMsg:isGreetingMsg,
      iRequestMsg:iRequestMsg,
      vMemeberList:vMemeberList,
      vGroupMessageType:vGroupMessageType,
      isForwardMsg:isForwardMsg,
      isDeleteprofile:isDeleteprofile,
      vDeleteMemberId:vDeleteMemberId,
      vNewAdminId:vNewAdminId,
      RequestMemberId:RequestMemberId
    });

    let jsonData = JSON.stringify(db);

    fs.writeFileSync('DB/' + senderJsonFile, jsonData);
  } else {
    const db = { array: [] }

    db.array.push({
      id: id,
      iFromUserId: senderChatID,
      iToUserId: receiverChatID,
      iRead: 0,
      iReadTo: 0,
      message: content,
      created_at: currentDateTime(),
      vReplyMsg,
      vReplyMsg_id,
      tReadUsers: senderChatID,
      vReplyFileName:vReplyFileName,
      iDeleted: 0,
      iEdited:0,
      vImageThumb:isThumb,
      isGreetingMsg:isGreetingMsg,
      iRequestMsg:iRequestMsg,
      vMemeberList:vMemeberList,
      vGroupMessageType:vGroupMessageType,
      isForwardMsg:isForwardMsg,
      isDeleteprofile:isDeleteprofile,
      vDeleteMemberId:vDeleteMemberId,
      vNewAdminId:vNewAdminId,
      RequestMemberId:RequestMemberId
    });

    let jsonData = JSON.stringify(db);

    fs.writeFileSync('DB/' + senderJsonFile, jsonData);
  }
}

// Sign up Api
app.post('/signup', (req, res) => {
  const { vUsername, vFullName, iEngId,vPassWord,vEmail } = req.body;

  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iEngId =?', [iEngId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 1' });
    }

    if (results.length == 0) {
      // Insert the user into the database
      const randProfile=Math.floor(Math.random() * 4) + 1;
      const vNewPassword=sha1(vPassWord);

      pool.query(
        'INSERT INTO chat_users (vUsername, vFullName, iColorOption,iEngId,vPassWord,vEmail) VALUES (?,?,?,?,?,?)',
        [vUsername, vFullName, randProfile,iEngId,vNewPassword,vEmail],
        (error, results, fields) => {
          if (error) {
            return res.status(500).send({ error: 'Internal Server Error 3' });
          }

          res.send({ message: 'User created successfully', status: 200 });
        }
      );
      
    } else {
      res.send({ message: 'User Id  is already exist!', status: 412 });
    }
  })
});

// Login Api
app.post('/login', (req, res) => {
  const { iUserId, vPassword } = req.body;

  // Find the user in the database
  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iEngId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if (results.length === 0) {
      res.send({ message: 'Please check username or password.', status: 412});
    } else {

      if(results[0].iStatus==1){
        res.send({ message: 'You are logged in on another PC. Simultaneous logins are not allowed. If you want to log in on this PC, the other session will be logged out.',type:"already_login", status: 411});
      }else{
        const currentTimeString = Math.floor(Date.now() / 1000) * 60;
        const token = jwt.sign({ vUsername: results[0].vUsername, vFullName: results[0].vFullName, LoginTime: currentTimeString }, 'chatApp001');
  
        const vNewPassword=sha1(vPassword);
        if(vNewPassword==results[0]['vPassword']){
          if(results[0].iEmailVerified==0){
            res.send({ message: 'Please verify email address',type:"verify_email", status: 411});
          }else{
            pool.query(
              'UPDATE chat_users SET dLoginDateTime=NOW(),tToken = ? WHERE iUserId = ?',
              [token, results[0].iUserId],
              (error, results2, fields) => {
                if (error) {
                  return res.status(500).send({ error: 'Internal Server Error 7', errorStatus: "Test3" });
                }
      
                if (results2.changedRows === 0) {
                  return res.status(404).send({ error: 'User not found' });
                } else {
                  res.send({ message: 'Logged in successfully', status: 200, tToken: token, iUserId: results[0].iUserId });
                }
              }
            );
          }
        }else{
          res.send({ message: 'Please check username or password.', status: 412});
        }
      }
    }
  });
});

//Get Username from user id Api
app.post('/getUserName', (req, res) => {
  const { iUserId } = req.body;
  
  pool.query('SELECT * FROM chat_users WHERE iEngId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if(results.length==0){
      res.send({ message: 'User not found.', status: 412});
    }else{
      res.send({ message: results[0]['vUsername'],vEmail:results[0]['vEmail'], status: 200});
    }
  })
})

//Change Password Api
app.post('/change_password', (req, res) => {
  const { iUserId,vPassWord } = req.body;
  
  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iEngId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if(results.length==0){
      res.send({ message: 'User not found.', status: 412});
    }else{
      pool.query(
        'UPDATE chat_users SET vPassword = ? WHERE iEngId = ?',
        [sha1(vPassWord), iUserId],
        (error, results2, fields) => {
          if (error) {
            return res.status(500).send({ error: 'Internal Server Error 7', errorStatus: "Test3" });
          }

          res.send({ message: "Your password has been changed successfully.", status: 200});
        }
      );
    }
  })
})

//Check password Api
app.post('/checkPassword', (req, res) => {
  const { iUserId,vPassWord } = req.body;
  
  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iUserId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if(results.length==0){
      res.send({ message: 'User not found.', status: 412});
    }else{
      const vOldPassword=sha1(vPassWord);
      if(results[0]['vPassword']==vOldPassword){
        res.send({ message: 'Old Password is correct!', status: 200});
      }else{
        res.send({ message: 'Old Password is not correct!', status: 411});
      }
    }
  })
})

//Change Email Address Api
app.post('/change_email', (req, res) => {
  const { iUserId,vEmail } = req.body;
  
  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iUserId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if(results.length==0){
      res.send({ message: 'User not found.', status: 412});
    }else{
      pool.query(
        'UPDATE chat_users SET vEmail = ? WHERE iUserId = ?',
        [vEmail, iUserId],
        (error, results2, fields) => {
          if (error) {
            return res.status(500).send({ error: 'Internal Server Error 7', errorStatus: "Test3" });
          }

          res.send({ message: "Your email has been changed successfully.", status: 200});
        }
      );
    }
  })
})


//New Password Change Api
app.post('/new_password', (req, res) => {
  const { iUserId,vPassWord,vOldPassword } = req.body;
  
  const vOldPaswrd=sha1(vOldPassword);

  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND iUserId =?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 4', errorStatus: "Test1" });
    }

    if(results.length==0){
      res.send({ message: 'User not found.', status: 412});
    }else{
      if(vOldPaswrd==results[0]['vPassword']){
        const vNewPassword=sha1(vPassWord);
        pool.query('UPDATE chat_users SET vPassword = ? WHERE iUserId = ?',[vNewPassword, iUserId],
          (error, results2, fields) => {
            if (error) {
              return res.status(500).send({ error: 'Internal Server Error 7', errorStatus: "Test3" });
            }
            
            res.send({ message: "Your password has been changed successfully.", status: 200});
          }
        );
      }else{
        res.send({ message: "The old password is not correct. Please check it.", status: 411});
      }
    }
  })
})

//Get Profile Data Api
app.post('/GetProfileData', (req, res) => {
  const { tToken } = req.body;

  // Find the user in the database
  pool.query('SELECT iUserId,vFullName,vProfilePic,eCustStatus,iStatus,IF(iStatus=1,IF(eCustStatus="2",iStatus,eCustStatus),0) as vStatus,iColorOption,iEmailVerified,vEmail,iEngId FROM chat_users WHERE tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 8' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      res.send({ data: results[0], status: 200 });
    }

  });
});

// Profile Update Api
app.post('/ProfileUpdate', (req, res) => {
  const { tToken, vImage,iColorOption,isDeleteFile,vEditProfileFullName } = req.body;

  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND tToken =?', ['' + tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 9' });
    }

    if (results.length > 0) {

      const uploadFolder = './public/images/uploads/profiles/';

      if (!fs.existsSync(uploadFolder)) {
        fs.mkdirSync(uploadFolder);
      }

      if(isDeleteFile==1){
        pool.query(
          'UPDATE chat_users SET vProfilePic = ?,iColorOption=?,vFullName=?  WHERE iUserId = ?',
          ['', iColorOption, vEditProfileFullName, results[0].iUserId],
          (error, results2, fields) => {
            if (error) {
              return res.status(500).send({ error: 'Internal Server Error 10', errorStatus: "Test3" });
            }
            res.send({ message: 'Profile picture has been updated successfully.', status: 200,data:{ vProfilePic:"",iColorOption:iColorOption } });
          }
        );
      }else{
        if(vImage[0].fileName && vImage[0].fileName!="undefined" && vImage[0].fileName!=""){
          const fileName = `${Date.now()}_${vImage[0].fileName}`;
          const filePath = `${uploadFolder}${fileName}`;
          var base64Data = vImage[0].imageData.split("base64,");
    
          fs.writeFile(filePath, base64Data[1], 'base64', (err) => {
            if (err) throw err;
    
            pool.query(
              'UPDATE chat_users SET vProfilePic = ?,iColorOption=?,vFullName=? WHERE iUserId = ?',
              ['images/uploads/profiles/' + fileName, 0, vEditProfileFullName ,results[0].iUserId],
              (error, results2, fields) => {
                if (error) {
                  return res.status(500).send({ error: 'Internal Server Error 10', errorStatus: "Test3" });
                }
                res.send({ message: 'Profile picture has been updated successfully.', status: 200,data:{ vProfilePic:'images/uploads/profiles/' + fileName,iColorOption:0 } });
              }
            );
          })
        }else{
          pool.query(
            'UPDATE chat_users SET vFullName=? WHERE iUserId = ?',
            [vEditProfileFullName ,results[0].iUserId],
            (error, results2, fields) => {
              if (error) {
                return res.status(500).send({ error: 'Internal Server Error 10', errorStatus: "Test3" });
              }
              res.send({ message: 'Profile picture has been updated successfully.', status: 200 });
            }
          );
        }
      }

    }
  })
});

// Message Delete Api
app.post('/MessageDelete', (req, res) => {
  const { tToken, MultipleSelectDel, vActiveGroupId, vActiveUserId,isAdmin } = req.body;

  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND tToken =?', ['' + tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 9' });
    }

    if (results.length > 0) {
      const iFileId = vActiveGroupId > 0 ? Number(vActiveGroupId) : Number(results[0]['iUserId']);

      // console.log("MultipleSelectDel",MultipleSelectDel)

      MultipleSelectDel.map((curEle, index) => {
        const msgDate = String(curEle).split("_");
        const dateFormate = currentDate(new Date(Number(msgDate[2])));

        const fileName = (vActiveGroupId > 0 ? "GROUP_" : "")+ iFileId + "_" + dateFormate + ".json";

        // console.log("fileName==>",fileName)

        if (fs.existsSync("DB/" + fileName)) {
          const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
          if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);

            const newDataUpdateArr = dd.array.map((curEle2, index) => {
              const iOldDeltedSts = curEle2?.iDeleted ? curEle2.iDeleted : 0;
              const iRequestMsg=curEle2?.iRequestMsg && curEle2?.iRequestMsg>0?1:0;
              return {
                ...curEle2,
                ['iDeleted']: curEle2.id == curEle && iRequestMsg==0 ? 1 : iOldDeltedSts,
                ['isAdmin']:isAdmin
              }
            })


            fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

            if (vActiveGroupId == 0) {
              const fileNameReciver = vActiveUserId + "_" + dateFormate + ".json";

              if (fs.existsSync("DB/" + fileNameReciver)) {
                const contentReadRecFile = fs.readFileSync("DB/" + fileNameReciver, 'utf8');

                if (contentReadRecFile != "") {
                  const dd = JSON.parse(contentReadRecFile);

                  const newDataUpdateArr = dd.array.map((curEle2, index) => {
                    const iOldDeltedSts = curEle2?.iDeleted ? curEle2.iDeleted : 0;
                    const iRequestMsg=curEle2?.iRequestMsg && curEle2?.iRequestMsg>0?1:0;
                    return {
                      ...curEle2,
                      ['iDeleted']: curEle2.id == curEle && iRequestMsg==0 ? 1 : iOldDeltedSts,
                      ['isAdmin']:isAdmin
                    }
                  })

                  fs.writeFileSync("DB/" + fileNameReciver, JSON.stringify({ array: newDataUpdateArr }));
                }
              }
            }
          }
        }
      })

      res.send({ message: 'Message has been deleted successfully.', status: 200 });
    } else {
      res.send({ message: 'User is not exist!', status: 412 });
    }
  })
})

//Message Update Api
app.post('/MessageUpdate', (req, res) => {
  const { tToken, msg, msgId, vActiveGroupId, vActiveUserId,id } = req.body;

  pool.query('SELECT * FROM chat_users WHERE eStatus="y" AND tToken =?', ['' + tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 9' });
    }

    if (results.length > 0) {
      const iFileId = vActiveGroupId > 0 ? Number(vActiveGroupId) : Number(results[0]['iUserId']);

      const msgDate = String(msgId).split(" ");
      const dateFormate = msgDate[0].split("-");

      const fileName = (vActiveGroupId > 0 ? "GROUP_" : "")+ iFileId + "_" + dateFormate[2] + "_" + dateFormate[1] + "_" + dateFormate[0] + ".json";

      if (fs.existsSync("DB/" + fileName)) {
        const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
        if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);

          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            const isEdited=curEle2?.iEdited === undefined || curEle2?.iEdited === null?0:curEle2?.iEdited;
            
            return {
              ...curEle2,
              ['message']: curEle2.id == id ? msg : curEle2.message,
              ['iEdited']:curEle2.id == id ? 1 : isEdited
            }
          })


          fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

          if (vActiveGroupId == 0) {
            const fileNameReciver = vActiveUserId + "_" + dateFormate[2] + "_" + dateFormate[1] + "_" + dateFormate[0] + ".json";

            if (fs.existsSync("DB/" + fileNameReciver)) {
              const contentReadRecFile = fs.readFileSync("DB/" + fileNameReciver, 'utf8');

              if (contentReadRecFile != "") {
                const dd = JSON.parse(contentReadRecFile);

                const newDataUpdateArr = dd.array.map((curEle2, index) => {
                  const isEdited=curEle2?.iEdited === undefined || curEle2?.iEdited === null?0:curEle2?.iEdited;

                  return {
                    ...curEle2,
                    ['message']: curEle2.id == id ? msg : curEle2.message,
                    ['iEdited']: curEle2.id == id ? 1 : isEdited
                  }
                })

                fs.writeFileSync("DB/" + fileNameReciver, JSON.stringify({ array: newDataUpdateArr }));
              }
            }
          }
        }
      }

      res.send({ message: 'Message has been updated successfully.', status: 200 });
    } else {
      res.send({ message: 'User is not exist!', status: 412 });
    }
  })
})

//Get User List Api
app.post('/GetUserList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 11' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // user list in the database
      const LoginUserId = results[0]['iUserId'];

      pool.query('SELECT iUserId,vFullName,vProfilePic,IF(iStatus=1,IF(eCustStatus="2",iStatus,eCustStatus),0) as iStatus,iColorOption,eStatus FROM chat_users WHERE tToken!=?', [tToken], (error, results2, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 12' });
        }

        if (results2.length === 0) {
          res.send({ message: 'User is not exist!', status: 401 });
        } else {
          let newDataArr = results2.map((curEle, index) => {

            const lastDate = getLastFileOfUser(results[0]['iUserId'], curEle.iUserId);

            const totalUnreadMsg = lastDate != "" ? getUnreadMsg(lastDate, LoginUserId, curEle.iUserId) : 0;

            const isMessageExist=isCommunicate(results[0]['iUserId'], curEle.iUserId);

            const isStartChat=isStartChatMsg(results[0]['iUserId'], curEle.iUserId);

            return {
              ...curEle,
              ['isStartChat']:isStartChat,
              ['isMessageExist']:isMessageExist,
              ['iTotalUnReadMsg']: totalUnreadMsg,
              ['lastMessage']: "No Message",
              ['lastTime']: lastDate,
              ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
              ['lastDate']: lastDate != "" ? curEle.iUserId + "_" + ConvertDateForFile(lastDate) + ".json" : curEle.iUserId + "_" + currentDate() + ".json"
            }
          })
          
          const filterData=newDataArr.filter((curEle,index)=>{
            return  curEle.isMessageExist>0
          })

          res.send({ data: filterData, status: 200 });
        }

      });
    }
  });
});

//Get Chat User List Api
app.post('/GetChatUserList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 13' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      pool.query('SELECT iUserId,vFullName,vProfilePic,IF(iStatus=1,IF(eCustStatus="2",iStatus,eCustStatus),0) as iStatus,iColorOption,eStatus FROM chat_users WHERE iUserId!=?', [results[0]['iUserId']], (error2, results2, fields) => {
        if (error2) {
          return res.status(500).send({ error2: 'Internal Server Error 13' });
        }else{
          let newDataArr = results2.map((curEle, index) => {
            return {
              ...curEle,
              ['iTotalUnReadMsg']: 0,
              ['lastMessage']: "No Message",
              ['lastTime']: "",
              ['vProfilePic']: curEle['vProfilePic'] == "" ? "" : mainUrl + curEle['vProfilePic'],
              ['lastDate']: ""
            }
          })

          res.send({ data: newDataArr, status: 200 });
        }
      })
    }
  })

})

//Get Message List Api
app.post('/GetMessage', (req, res) => {
  const { tToken, iUserId, filterDateStr } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,(SELECT IF(iStatus=1,IF(eCustStatus="2",iStatus,eCustStatus),0) as iStatus FROM chat_users WHERE iUserId=' + iUserId + ') as ChatUserSts FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 13' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {

      const isMessageExist=isCommunicate(results[0]['iUserId'], iUserId);

      // Function to check if a file exists
      function fileExists(filepath, callback) {
        fs.access(filepath, fs.constants.F_OK, (err) => {
          if (err) {
            callback(false);
          } else {
            callback(true);
          }
        });
      }

      // Function to read files concurrently
      function readFilesConcurrently(filepaths, callback) {
        const existingFiles = [];
        let completed = 0;

        filepaths.forEach((filepath, index) => {
          fileExists(filepath, (exists) => {
            if (exists) {
              existingFiles.push(filepath);
            } else {
              // console.error(`File not found: ${filepath}`);
            }
            completed++;

            if (completed === filepaths.length) {
              let data = [];
              let readCompleted = 0;

              if (existingFiles.length > 0) {
                existingFiles.forEach((file) => {
                  const content = fs.readFileSync(file, 'utf8');

                  if (content != "") {
                    const dd = JSON.parse(content);

                    let newDataUpdateArr = dd.array.map((curEle, index) => {
                      return {
                        ...curEle,
                        ['iRead']: curEle.iFromUserId == iUserId ? 1 : curEle.iRead
                      }
                    })


                    fs.writeFileSync(file, JSON.stringify({ array: newDataUpdateArr }));

                    const filterDataArr = dd.array.filter((curEle, index) => {
                      const isPermDelete=curEle?.iPermDelete == undefined ? 0 :curEle.iPermDelete;

                      // console.log("isPermDelete=>",isPermDelete)

                      return ((curEle.iFromUserId == results[0]['iUserId'] && curEle.iToUserId == iUserId) || (curEle.iFromUserId == iUserId && curEle.iToUserId == results[0]['iUserId'])) && isPermDelete==0
                    })

                    data = [...data, ...filterDataArr]
                  }

                  const newReadStr = String(file).split("_");
                  const newReadFile = iUserId + "_" + newReadStr[1] + "_" + newReadStr[2] + "_" + newReadStr[3];

                  if (fs.existsSync("DB/" + newReadFile)) {
                    const contentReadFile = fs.readFileSync("DB/" + newReadFile, 'utf8');
                    if (contentReadFile != "") {
                      const dd = JSON.parse(contentReadFile);

                      let newDataUpdateArr = dd.array.map((curEle, index) => {
                        return {
                          ...curEle,
                          ['iReadTo']: curEle.iFromUserId == results[0]['iUserId'] ? 1 : curEle.iReadTo
                        }
                      })

                      fs.writeFileSync("DB/" + newReadFile, JSON.stringify({ array: newDataUpdateArr }));
                    }
                  }

                  readCompleted++;
                  if (readCompleted === existingFiles.length) {
                    callback(data);
                  }
                });
              } else {
                callback([]);
              }
            }
          });
        });
      }

      const startDate = oneMonthBackDate(filterDateStr);
      const splitString = String(filterDateStr).split("_");
      let endDateStr = (splitString[1] + "_" + splitString[2] + "_" + splitString[3]);
      const weakArray = GetMonthArrayDate(startDate, endDateStr.split(".")[0], "DB/" + results[0]['iUserId']);

      // Example usage
      const filepaths = weakArray;

      readFilesConcurrently(filepaths, (data) => {
        if (data.length > 0) {

          const sortingArr = data.length ? data.sort((a, b) =>
            (('created_at' in b) - ('created_at' in a))
            || (a.created_at ?? '').localeCompare(b.created_at ?? '')
          ) : []

          res.send({
            data: JSON.stringify(sortingArr), status: 200,
            userStatus: results[0]['ChatUserSts'],
            dLastDate: sortingArr.length ? iUserId + "_" + ConvertDateForFile(sortingArr[0]['created_at']) + ".json" : "",
            isMessageExist
          });
        } else {
          res.send({ data: [], status: 412, userStatus: results[0]['ChatUserSts'],isMessageExist });
        }
      });

      return false;
    }
  });
});

//Get Group Message Api
app.post('/GetGrpMessage', (req, res) => {
  const { tToken, iGroupId, filterDateStr,isAdmin } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 14' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {

      // Function to check if a file exists
      function fileExists(filepath, callback) {
        fs.access(filepath, fs.constants.F_OK, (err) => {
          if (err) {
            callback(false);
          } else {
            callback(true);
          }
        });
      }

      // Function to read files concurrently
      function readFilesConcurrently(filepaths, callback) {
        const existingFiles = [];
        let completed = 0;

        filepaths.forEach((filepath, index) => {
          fileExists(filepath, (exists) => {
            if (exists) {
              existingFiles.push(filepath);
            } else {
              // console.error(`File not found: ${filepath}`);
            }
            completed++;

            if (completed === filepaths.length) {
              let data = [];
              let readCompleted = 0;

              if (existingFiles.length > 0) {
                existingFiles.forEach((file) => {
                  const content = fs.readFileSync(file, 'utf8');

                  if (content != "") {
                    const dd = JSON.parse(content);

                    const dataFilterData=dd.array.filter((curEle,index)=>{
                      const vDeleteMsgUser=curEle.vDeleteMsgUser==undefined?"":curEle.vDeleteMsgUser;
                      const vDeleteUserSplit=vDeleteMsgUser!=""?String(vDeleteMsgUser).split(","):[];
                      const vMemeberListMsg=curEle?.vMemeberList!=undefined?String(curEle?.vMemeberList).split(","):[];
                      return !vDeleteUserSplit.includes(""+results[0]['iUserId']) && (vMemeberListMsg.includes(""+results[0]['iUserId']) || isAdmin==1)
                    })

                    data = [...data, ...dataFilterData]

                    let newDataUpdateArr = dd.array.map((curEle, index) => {
                      const tReadUsers = curEle.tReadUsers!=""?String(curEle.tReadUsers).split(","):[];

                      return {
                        ...curEle,
                        ['tReadUsers']: tReadUsers.includes("" + results[0]['iUserId']) ? curEle.tReadUsers : curEle.tReadUsers + "," + results[0]['iUserId']
                      }
                    })

                    fs.writeFileSync(file, JSON.stringify({ array: newDataUpdateArr }));
                  }

                  readCompleted++;
                  if (readCompleted === existingFiles.length) {
                    callback(data);
                  }

                });
              } else {
                callback([]);
              }
            }
          });
        });
      }

      const startDate = oneMonthBackDateGroup(filterDateStr);
      const splitString = String(filterDateStr).split("_");
      let endDateStr = (splitString[2] + "_" + splitString[3] + "_" + splitString[4]);
      const weakArray = GetMonthArrayDate(startDate, endDateStr.split(".")[0], "DB/GROUP_" + iGroupId);

      // Example usage
      const filepaths = weakArray;

      readFilesConcurrently(filepaths, (data) => {
        if (data.length > 0) {

          const sortingArr = data.length ? data.sort((a, b) =>
            (('created_at' in b) - ('created_at' in a))
            || (a.created_at ?? '').localeCompare(b.created_at ?? '')
          ) : []

          res.send({
            data: JSON.stringify(sortingArr), status: 200,
            dLastDate: sortingArr.length ? "GROUP_" + iGroupId + "_" + ConvertDateForFile(sortingArr[0]['created_at']) + ".json" : ""
          });
        } else {
          res.send({ data: [], status: 412, userStatus: results[0]['ChatUserSts'] });
        }
      });

    }
  });
});

// Add New Group Api
app.post('/AddNewGrp', (req, res) => {
  const { vGroupName, vUsers, tToken, vActiveGroupId, vGroupProfile,tDescription,ColorOptionSelect,isDeleteFile,deleteMemeberStr,iUpdateBasic,cancelRequest } = req.body;

  const uploadFolder = './public/images/uploads/GroupProfile/';
  if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
  }

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 15' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // Check Group name exist
      pool.query('SELECT * FROM chat_broadcast_grp WHERE eGroupStatus="y" AND vGroupName="'+vGroupName+'"', [], (error, results2, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 16' });
        }
      
        const FilterNameCheck=results2.filter((curEle,index)=>{
            return curEle.iCreatedBy==results[0]['iUserId']
        })

        if(FilterNameCheck.length==0 || vActiveGroupId > 0 || results2.length==0){
            let filePathForDb = "";
            if (vGroupProfile && vGroupProfile?.length && vGroupProfile[0]['fileName'] && vGroupProfile[0]['fileName']!="" && vGroupProfile[0]['fileName']!="undefined") {
              const fileName = `${Date.now()}_${vGroupProfile[0]['fileName']}`;
              const filePath = `${uploadFolder}${fileName}`;
  
              saveBlobFile(vGroupProfile[0]['imageData'], filePath);
          
              filePathForDb = "images/uploads/GroupProfile/" + fileName;
            }
  
            if (vActiveGroupId > 0) {
              pool.query('SELECT iCreatedBy,vGroupImage,tGroupJoinMemb,tGroupUsers,tLeftMembers FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error, results3, fields) => {
                if (error) {
                  return res.status(500).send({ error: 'Internal Server Error 17' });
                }
  
                if (results3.length > 0 && results3[0]['iCreatedBy'] == results[0]['iUserId']) {
                  if(iUpdateBasic==1){
                    pool.query(
                      'UPDATE chat_broadcast_grp SET vGroupName=?,vGroupImage=?,tDescription=?,iColorOption=? WHERE iGroupId = ?',
                      [vGroupName, (filePathForDb == "" && isDeleteFile==0) ? results3[0]['vGroupImage'] : filePathForDb, tDescription,ColorOptionSelect,vActiveGroupId],
                      (error, results2, fields) => {
                        if (error) {
                          return res.status(500).send({ error: 'Internal Server Error 18' });
                        } else {
                          res.send({ message: 'Group detail has been updated successfully.', status: 200 });
                        }
                      }
                    );
                  }else{
                    //Cancel Request Code
                    const tGroupUsersArr=results3[0]['tGroupUsers']!=""?String(results3[0]['tGroupUsers']).split(","):[];
                    const deleteMemeberStrArr=deleteMemeberStr!=""?String(deleteMemeberStr).split(","):[];
                    const finalGrpUser=tGroupUsersArr.filter((curEle)=>{
                      return !deleteMemeberStrArr.includes(""+curEle);
                    })

                    const tLeftMembers=results3[0]['tLeftMembers']!=""?String(results3[0]['tLeftMembers']).split(",").filter(c=>c):[];
                    const filterLeftMemeber=[...tLeftMembers,...deleteMemeberStrArr]

                    const dbFolderPath = "DB/";
                    const NewArr = fs.readdirSync(dbFolderPath);
                    const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;

                    const cancelRequestArr=cancelRequest!=""?String(cancelRequest).split(","):[];
                    cancelRequestArr.map((CurEle,ind)=>{
                      dd.map((curElee, index) => {
                        const splitStr = String(curElee).split("_");
                        
                        if(splitStr[0]=="GROUP" && splitStr[1]==vActiveGroupId){
                          if (fs.existsSync("DB/" + curElee)) {

                            const contentReadFile = fs.readFileSync("DB/" + curElee, 'utf8');
                            if (contentReadFile != "") {
                              const dd = JSON.parse(contentReadFile);
                  
                              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                                const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";
                                const vCancelUserId = curEle2?.vCancelUserId ? curEle2.vCancelUserId : "";
                
                                return {
                                  ...curEle2,
                                  ['vMemeberList']: curEle2.vMemeberList == CurEle && curEle2.iRequestMsg==1 ? "" : vOldMemebers,
                                  ['vCancelUserId']: curEle2.vMemeberList == CurEle && curEle2.iRequestMsg==1 ? vOldMemebers : vCancelUserId,
                                }
                              })  
                  
                              fs.writeFileSync("DB/" + curElee, JSON.stringify({ array: newDataUpdateArr }));
                            }

                          }
                        }

                      });
                    })

                    //New Member Add And Delete Member Remove
                    pool.query(
                      'UPDATE chat_broadcast_grp SET tGroupJoinMemb=?,tGroupUsers=?,tLeftMembers=? WHERE iGroupId = ?',
                      [vUsers,finalGrpUser.toString(),filterLeftMemeber.toString(),vActiveGroupId],
                      (error, results5, fields) => {
                        if (error) {
                          return res.status(500).send({ error: 'Internal Server Error 18' });
                        } else {
                          const vGroupUsrList=results3[0]['tGroupJoinMemb']!=""?String(results3[0]['tGroupJoinMemb']).split(","):[];
                          const vNewGroupUser=vUsers!=""?String(vUsers).split(","):[];
  
                          vNewGroupUser.map((curEle,index)=>{
                              if(!vGroupUsrList.includes(""+curEle)){
                                pool.query('SELECT tGroupIds FROM chat_users WHERE iUserId=?', [Number(curEle.trim())], (error, results4, fields) => {
                                  if (results4.length > 0) {
                                    const splitGroupIds=results4[0]['tGroupIds']!=""?String(results4[0]['tGroupIds']).split(","):[];
                                    if(!splitGroupIds.includes(vActiveGroupId)){
                                      splitGroupIds.push(vActiveGroupId);
                                      pool.query(
                                        'UPDATE chat_users SET tGroupIds=? WHERE iUserId = ?',
                                        [splitGroupIds.toString(),Number(curEle.trim())]
                                      )
                                    }
                                  }
                                })
                              }
                          })         
  
                          res.send({ message: 'Group detail has been updated successfully.', status: 200 });
                        }
                      }
                    );
                  }
  
                } else {
                  res.send({ message: 'You dont have permission to update detail for this group.', status: 412 });
                }
              })
            } else {
              // Insert the group into the database
              pool.query(
                'INSERT INTO chat_broadcast_grp (vGroupName, vGroupImage, tGroupJoinMemb,dCreatedDate,iCreatedBy,tDescription,iColorOption) VALUES (?,?,?,NOW(),?,?,?)',
                [vGroupName, filePathForDb, vUsers, results[0]['iUserId'],tDescription,ColorOptionSelect],
                (error, results3, fields) => {
                  if (error) {
                    return res.status(500).send({ error: error });
                  }
  
                  const vSplitUsrArr=vUsers!=""?String(vUsers).split(","):[];
                  vSplitUsrArr.map((curEle,index)=>{
                    pool.query('SELECT tGroupIds FROM chat_users WHERE iUserId=?', [Number(curEle.trim())], (error, results4, fields) => {
                      if (results4.length > 0) {
                        const splitGroupIds=results4[0]['tGroupIds']!=""?String(results4[0]['tGroupIds']).split(","):[];
                        splitGroupIds.push(results3.insertId);
                        pool.query(
                          'UPDATE chat_users SET tGroupIds=? WHERE iUserId = ?',
                          [splitGroupIds.toString(),Number(curEle.trim())]
                        )
                      }
                    })
                  })
  
                  res.send({ message: 'Group has been added successfully.', status: 200,id:results3.insertId });
                }
              );
            }
        }else{
          res.send({ message: 'Group name already exist!', status: 412 });
        }
      })
    }
  })
});

//Group Member Join Request Accept Api
app.post('/GrpJoinRequestAccept', (req, res) => {
  const { iUserId,iMessageId,vActiveGroupId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,vFullName FROM chat_users WHERE eStatus="y" AND iUserId=?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 15' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      
      //Group Exist or not check
      pool.query('SELECT * FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error2, results2, fields) => {
        if (error2) {
          return res.status(500).send({ error2: 'Internal Server Error 15' });
        }
    
        if (results2.length === 0) {
          res.send({ message: 'Group is not exist!', status: 401 });
        } else {

          const tGroupUsers=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(","):[];
          tGroupUsers.push(iUserId);

          const tGroupJoinMemb=results2[0]['tGroupJoinMemb']!=""?String(results2[0]['tGroupJoinMemb']).split(","):[];
          const filterJoinMember=tGroupJoinMemb.filter((curEle,index)=>{
            return curEle!=iUserId;
          })

          const tLeftMembers=results2[0]['tLeftMembers']!=""?String(results2[0]['tLeftMembers']).split(",").filter(c=>c):[];
          const filterLeftMemeber=tLeftMembers.filter(cr=>cr!=iUserId)

          pool.query(
            'UPDATE chat_broadcast_grp SET tGroupUsers=?,tGroupJoinMemb=?,tLeftMembers=? WHERE iGroupId = ?',
            [tGroupUsers.toString(),filterJoinMember.toString(),filterLeftMemeber.toString(),vActiveGroupId],
            (error, results2, fields) => {
              if (error) {
                return results2.status(500).send({ error: 'Internal Server Error 24' });
              }
            }
          );

          const msgDate = String(iMessageId).split("_");
          const dateFormate = currentDate(Number(msgDate[2]));
          const fileName = "GROUP_"+vActiveGroupId + "_" + dateFormate + ".json";

          if (fs.existsSync("DB/" + fileName)) {
            const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
            if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
  
              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";

                return {
                  ...curEle2,
                  ['vMemeberList']: curEle2.vMemeberList == iUserId && curEle2.iRequestMsg==1 ? "" : vOldMemebers,
                }
              })  
  
              fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

              res.send({ data: "You are join in the group.", status: 200 });
            }
          }else{
            res.send({ data: "You are join in the group.", status: 200 });
          }

        }
      })

    }
  })
})

//Group Member Request Decline Api
app.post('/GrpJoinRequestDecline', (req, res) => {
  const { iUserId,iMessageId,vActiveGroupId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,vFullName FROM chat_users WHERE eStatus="y" AND iUserId=?', [iUserId], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 15' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      
      //Group Exist or not check
      pool.query('SELECT * FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error2, results2, fields) => {
        if (error2) {
          return res.status(500).send({ error2: 'Internal Server Error 15' });
        }
    
        if (results2.length === 0) {
          res.send({ message: 'Group is not exist!', status: 401 });
        } else {

          const tGroupUsers=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(","):[];
          const filterGrpUsr=tGroupUsers.filter((curEle,ind)=>{
            return curEle!=iUserId
          })

          const tGroupJoinMemb=results2[0]['tGroupJoinMemb']!=""?String(results2[0]['tGroupJoinMemb']).split(","):[];
          const filterJoinMember=tGroupJoinMemb.filter((curEle,ind)=>{
            return curEle!=iUserId
          })

          pool.query(
            'UPDATE chat_broadcast_grp SET tGroupUsers=?,tGroupJoinMemb=? WHERE iGroupId = ?',
            [filterGrpUsr.toString(),filterJoinMember.toString(),vActiveGroupId],
            (error, results2, fields) => {
              if (error) {
                return results2.status(500).send({ error: 'Internal Server Error 24' });
              }
            }
          );

          const msgDate = String(iMessageId).split("_");
          const dateFormate = currentDate(Number(msgDate[2]));
          const fileName = "GROUP_"+vActiveGroupId + "_" + dateFormate + ".json";

          if (fs.existsSync("DB/" + fileName)) {
            const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');
            if (contentReadFile != "") {
              const dd = JSON.parse(contentReadFile);
  
              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const vOldMemebers = curEle2?.vMemeberList ? curEle2.vMemeberList : "";

                return {
                  ...curEle2,
                  ['vMemeberList']: curEle2.vMemeberList == iUserId && curEle2.iRequestMsg==1 ? "" : vOldMemebers,
                }
              })  
  
              fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

              res.send({ data: "You decline the group request.", status: 200 });
            }
          }else{
            res.send({ data: "You decline the group request.", status: 200 });
          }

        }
      })
    }
  })
})

//Get Group List Api
app.post('/GetGroupList', (req, res) => {
  const { tToken } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,tGroupIds FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 20' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // Group list in the database
      const LoginUserId = results[0]['iUserId'];
      const tGroupIdsList=results[0]['tGroupIds']!=""?String(results[0]['tGroupIds']).split(","):[];

      pool.query('SELECT iGroupId,vGroupName,vGroupImage,tGroupUsers,iCreatedBy,tDescription,dCreatedDate,iColorOption,tGroupJoinMemb,tLeftMembers FROM chat_broadcast_grp WHERE eGroupStatus="y" ', [], (error, results2, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 21' });
        }

        if (results2.length === 0) {
          res.send({ message: 'Group is not exist!', status: 401 });
        } else {
          const filterUserList=results2.filter((curEle,index)=>{
            return curEle.iCreatedBy==LoginUserId || tGroupIdsList.includes(""+curEle.iGroupId)
          })

          let newDataArr = filterUserList.map((curEle, index) => {
            const lastDate = getLastFileOfUserGroup(curEle.iGroupId);

            const totalUnreadMsg = lastDate.date != "" ? getGroupUnreadMsg(lastDate.date, curEle.iGroupId, LoginUserId) : 0;

            return {
              ...curEle,
              iTotalUnReadMsg: totalUnreadMsg,
              ['vGroupImage']: curEle['vGroupImage']!=""?mainUrl + curEle['vGroupImage']:"",
              ['lastTime']: lastDate.time,
              lastDate: lastDate.date != "" ? "GROUP_" + curEle.iGroupId + "_" + lastDate.date + ".json" : "GROUP_" + curEle.iGroupId + "_" + currentDate() + ".json"
            }
          })
          res.send({ data: newDataArr, status: 200 });
        }

      });
    }
  });
});

//Delete Group Api
app.post('/DeleteGroup', (req, res) => {
  const { tToken, vActiveGroupId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // Group list in the database
      const LoginUserId = results[0]['iUserId'];

      pool.query('SELECT iCreatedBy FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error, results2, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 23' });
        }

        if (results2.length === 0) {
          res.send({ message: 'Group is not exist!', status: 412 });
        } else {
          if (results2[0]['iCreatedBy'] != LoginUserId) {
            res.send({ message: 'You are not owner of the group!', status: 412 });
          } else {


            pool.query(
              'UPDATE chat_broadcast_grp SET eGroupStatus="d" WHERE iGroupId = ?',
              [vActiveGroupId],
              (error, results2, fields) => {
                if (error) {
                  return results2.status(500).send({ error: 'Internal Server Error 24' });
                }
              }
            );
            res.send({ message: 'Group has been deleted successfully.', status: 200 });
          }
        }
      });
    }
  });
});

//Exit Group Api
app.post('/ExitGroup', (req, res) => {
  const { tToken, vActiveGroupId,iNewUserId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,tGroupIds FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // Group list in the database
      const LoginUserId = results[0]['iUserId'];

      pool.query('SELECT iCreatedBy,tGroupUsers,tLeftMembers FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error, results2, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 23' });
        }

        if (results2.length === 0) {
          res.send({ message: 'Group is not exist!', status: 412 });
        } else {
          
          if (results2[0]['iCreatedBy'] == LoginUserId) {
            const tGroupIds=results[0]['tGroupIds']+","+vActiveGroupId;
            const tLeftMembers=results2[0]['tLeftMembers']+","+LoginUserId;

            pool.query(
              'UPDATE chat_broadcast_grp SET tLeftMembers=? WHERE iGroupId = ?',
              [tLeftMembers,vActiveGroupId],
              (error, results2, fields) => {
                if (error) {
                  return results2.status(500).send({ error: 'Internal Server Error 24' });
                }
              }
            );

            pool.query(
              'UPDATE chat_users SET tGroupIds=? WHERE iUserId = ?',
              [tGroupIds,LoginUserId],
              (error, results2, fields) => {
                if (error) {
                  return results2.status(500).send({ error: 'Internal Server Error 24' });
                }
              }
            );

            const totalMemberAr=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(",").filter(e=>e):[];
            if(totalMemberAr.length==0){
              pool.query(
                'UPDATE chat_broadcast_grp SET eGroupStatus="d" WHERE iGroupId = ?',
                [vActiveGroupId],
                (error, results2, fields) => {
                  if (error) {
                    return results2.status(500).send({ error: 'Internal Server Error 24' });
                  }
                }
              );
            }else{
              const filterRemoveMember=totalMemberAr.filter((curEle,index)=>{ return curEle!=iNewUserId });

              pool.query(
                'UPDATE chat_broadcast_grp SET tGroupUsers=?,iCreatedBy=? WHERE iGroupId = ?',
                [filterRemoveMember.toString(),iNewUserId,vActiveGroupId],
                (error, results2, fields) => {
                  if (error) {
                    return results2.status(500).send({ error: 'Internal Server Error 24' });
                  }
                }
              );
            }

            res.send({ message: 'You are exist from group.', status: 200 });

          } else {
            const totalMemberAr=results2[0]['tGroupUsers']!=""?String(results2[0]['tGroupUsers']).split(",").filter(e=>e):[];
            const filterRemoveMember=totalMemberAr.filter((curEle,index)=>{ return curEle!=LoginUserId });

            const tLeftMembers=results2[0]['tLeftMembers']+","+LoginUserId;

            pool.query(
              'UPDATE chat_broadcast_grp SET tGroupUsers=?,tLeftMembers=? WHERE iGroupId = ?',
              [filterRemoveMember.toString(),tLeftMembers.toString(),vActiveGroupId],
              (error, results2, fields) => {
                if (error) {
                  return results2.status(500).send({ error: 'Internal Server Error 24' });
                }
              }
            );
            res.send({ message: 'You are exist from group.', status: 200 });
          }
        }
      });
    }
  });
});

//Delete Group For Me
app.post('/DeleteGroupForMe', (req, res) => {
  const { tToken, vActiveGroupId } = req.body;
  
  // Check Token Exist
  pool.query('SELECT iUserId,tGroupIds FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {

      const dbFolderPath = "DB/";
      const NewArr = fs.readdirSync(dbFolderPath);
      const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
    
      const fileExist = dd.length ? dd.filter((curEle, index) => {
        const splitStr = String(curEle).split("_");
        return splitStr[0] == "GROUP" && splitStr[1] == vActiveGroupId;
      }) : []

      if(fileExist){
        fileExist.map((curEle,index)=>{
          if (fs.existsSync("DB/" + curEle)) {
            const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');

            if (contentReadRecFile != "") {
              const dd = JSON.parse(contentReadRecFile);

              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const isPermDelete=curEle2?.vDeleteMsgUser == undefined ? '' : curEle2.vDeleteMsgUser;

                let splitStr=isPermDelete!=""?String(isPermDelete).split(","):[];
                const isCheckUserExist=splitStr.includes(Number(results[0]['iUserId']));
                const vUserDeleteList=isCheckUserExist?isPermDelete:isPermDelete+","+Number(results[0]['iUserId']);
                
                return {
                  ...curEle2,
                  ['vDeleteMsgUser']: vUserDeleteList
                }
              })

              fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
            }
          }
        })
      }

      const tGroupIds=results[0]['tGroupIds']!=""?String(results[0]['tGroupIds']).split(",").filter(c=>c):[];

      const filterGroup=tGroupIds.filter((curEle,index)=>{
        return curEle!=vActiveGroupId
      })

      pool.query(
        'UPDATE chat_users SET tGroupIds=? WHERE iUserId = ?',
        [[...filterGroup].toString(),results[0]['iUserId']],
        (error, results2, fields) => {
          if (error) {
            return results2.status(500).send({ error: 'Internal Server Error 24' });
          }
        }
      );

      res.send({ message: 'Group is now delete for you.', status: 200 });
    }
  })
})

//Edit User Profile Api
app.post('/EditUserProfile', (req, res) => {
  const { tToken, eCustStatus,vEditProfileFullName } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      // Group list in the database
      const LoginUserId = results[0]['iUserId'];

      pool.query(
        'UPDATE chat_users SET eCustStatus=?,vFullName=? WHERE iUserId = ?',
        [eCustStatus,vEditProfileFullName,LoginUserId],
        (error, results2, fields) => {
          if (error) {
            return results2.status(500).send({ error: 'Internal Server Error 31' });
          }
        }
      );
      res.send({ message: 'User profile has been updated successfully.', status: 200 });
    }
  });
});

//Request Accept Feature Api
app.post('/RequestAcceptSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,vChatId as senderchatId,(SELECT vChatId FROM chat_users WHERE iUserId=' + vActiveUserId + ') as receverChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      const iFileId = Number(vActiveUserId);

      const msgDate = String(msgId).split("_");
      const dateFormate = currentDate(Number(msgDate[2]));

      const fileName = iFileId + "_" + dateFormate + ".json";

      // if (fs.existsSync("DB/" + fileName)) {
      //   const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');

      //   if (contentReadFile != "") {
      //     const dd = JSON.parse(contentReadFile);

      //     const newDataUpdateArr = dd.array.map((curEle2, index) => {
      //       return {
      //         ...curEle2,
      //         ['iRequestMsg']: curEle2.id == msgId ? 2 : curEle2.iRequestMsg,
      //         ['iRead']:0
      //       }
      //     })

      //     fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

      //     lastChatUpdate(results[0]['iUserId'], vActiveUserId,1);
      //     lastChatUpdate(vActiveUserId, results[0]['iUserId'],1);

      //   }
      // }

      const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

      if (fs.existsSync("DB/" + fileNameSend)) {
        const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');

        if (contentReadFile2 != "") {
          const dd2 = JSON.parse(contentReadFile2);

          const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2.iPermDelete,
            }
          })

          fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));

          lastChatUpdate(results[0]['iUserId'], vActiveUserId,1);
          lastChatUpdate(vActiveUserId, results[0]['iUserId'],1);
        }
      }

      res.send({ message: 'Your chat request has been accepted successfully.', status: 200, });
    }
  })
})

//Request Decline Feature Api
app.post('/RequestDeclineSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId,isDelete } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,vChatId as senderchatId,(SELECT vChatId FROM chat_users WHERE iUserId=' + vActiveUserId + ') as receverChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      const iFileId = Number(vActiveUserId);

      const msgDate = String(msgId).split("_");
      const dateFormate = currentDate(Number(msgDate[2]));

      const fileName = iFileId + "_" + dateFormate + ".json";

      // if (fs.existsSync("DB/" + fileName)) {
      //   const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');

      //   if (contentReadFile != "") {
      //     const dd = JSON.parse(contentReadFile);

      //     const newDataUpdateArr = dd.array.map((curEle2, index) => {
      //       return {
      //         ...curEle2,
      //         ['iRequestMsg']: curEle2.id == msgId ? 3 : curEle2.iRequestMsg,
      //         ['iRead']:0
      //       }
      //     })

      //     fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

      //     if(isDelete==0){
      //       lastChatUpdate(results[0]['iUserId'], vActiveUserId,0);
      //       lastChatUpdate(vActiveUserId, results[0]['iUserId'],0);
      //     }
      //   }
      // }

      const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

      if (fs.existsSync("DB/" + fileNameSend)) {
        const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');

        if (contentReadFile2 != "") {
          const dd2 = JSON.parse(contentReadFile2);

          const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2.iPermDelete,
            }
          })

          fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));

          if(isDelete==0){
            lastChatUpdate(results[0]['iUserId'], vActiveUserId,0);
            lastChatUpdate(vActiveUserId, results[0]['iUserId'],0);
          }
        }
      }

      res.send({ message: 'Your chat request has been accepted successfully.', status: 200, });
    }
  })
})

//Request Delete Connections
// app.post('/RequestDeleteConn', (req, res) => {
//   const { tToken, vActiveUserId,msgId,isDelete } = req.body;

//   // Check Token Exist
//   pool.query('SELECT iUserId,vChatId as senderchatId,(SELECT vChatId FROM chat_users WHERE iUserId=' + vActiveUserId + ') as receverChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
//     if (error) {
//       return res.status(500).send({ error: 'Internal Server Error 22' });
//     }

//     if (results.length === 0) {
//       res.send({ message: 'User is not exist!', status: 401 });
//     } else {
//       const iFileId = Number(vActiveUserId);

//       const msgDate = String(msgId).split("_");
//       const dateFormate = currentDate(Number(msgDate[2]));

//       const fileName = iFileId + "_" + dateFormate + ".json";

//       if (fs.existsSync("DB/" + fileName)) {
//         const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');

//         if (contentReadFile != "") {
//           const dd = JSON.parse(contentReadFile);

//           const newDataUpdateArr = dd.array.map((curEle2, index) => {
//             return {
//               ...curEle2,
//               ['iRequestMsg']: curEle2.id == msgId ? 5 : curEle2.iRequestMsg,
//               ['iRead']:0
//             }
//           })

//           fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

//           if(isDelete==0){
//             lastChatUpdate(results[0]['iUserId'], vActiveUserId,0);
//             lastChatUpdate(vActiveUserId, results[0]['iUserId'],0);
//           }
//         }
//       }

//       const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

//       if (fs.existsSync("DB/" + fileNameSend)) {
//         const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');

//         if (contentReadFile2 != "") {
//           const dd2 = JSON.parse(contentReadFile2);

//           const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
//             return {
//               ...curEle2,
//               ['iRequestMsg']: curEle2.id == msgId ? 5 : curEle2.iRequestMsg,
//             }
//           })

//           fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));
//         }
//       }

//       res.send({ message: 'Your connection deleted successfully.', status: 200, });
//     }
//   })
// })


//Request Cancel Feature Api
app.post('/RequestCancelSubmit', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  // Check Token Exist
  pool.query('SELECT iUserId,vChatId as senderchatId,(SELECT vChatId FROM chat_users WHERE iUserId=' + vActiveUserId + ') as receverChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      const iFileId = Number(vActiveUserId);

      const msgDate = String(msgId).split("_");
      const dateFormate = currentDate(Number(msgDate[2]));

      const fileName = iFileId + "_" + dateFormate + ".json";

      console.log("fileName=>",fileName)

      if (fs.existsSync("DB/" + fileName)) {
        const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');

        if (contentReadFile != "") {
          const dd = JSON.parse(contentReadFile);

          const newDataUpdateArr = dd.array.map((curEle2, index) => {
            return {
              ...curEle2,
              ['iPermDelete']: curEle2.id == msgId ? 1 : curEle2?.iPermDelete,
            }
          })

          fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));

          lastChatUpdate(results[0]['iUserId'], vActiveUserId);
          lastChatUpdate(vActiveUserId, results[0]['iUserId']);
        }
      }

      // const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

      // if (fs.existsSync("DB/" + fileNameSend)) {
      //   const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');

      //   if (contentReadFile2 != "") {
      //     const dd2 = JSON.parse(contentReadFile2);

      //     const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
      //       return {
      //         ...curEle2,
      //         ['iRequestMsg']: curEle2.id == msgId ? 4 : curEle2.iRequestMsg,
      //       }
      //     })

      //     fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));
      //   }
      // }

      res.send({ message: 'Your chat request has been cancelled successfully.', status: 200, });
    }
  })
})

//Delete All User Chat Api
app.post('/DeleteAllChatUser', (req, res) => {
  const { tToken, vActiveUserId,msgId } = req.body;

  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
    
      const dbFolderPath = "DB/";

      const NewArr = fs.readdirSync(dbFolderPath);
    
      const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
    
      const fileExist = dd.length ? dd.filter((curEle, index) => {
        const splitStr = String(curEle).split("_");
        return splitStr[0] == results[0]['iUserId'];
      }) : [];

      const fileExistReceiver = dd.length ? dd.filter((curEle, index) => {
        const splitStr = String(curEle).split("_");
        return splitStr[0] == vActiveUserId;
      }) : [];

      const iFileId = Number(vActiveUserId);

      const msgDate = String(msgId).split("_");
      const dateFormate = currentDate(Number(msgDate[2]));

      const fileName = iFileId + "_" + dateFormate + ".json";

      // if (fs.existsSync("DB/" + fileName)) {
      //   const contentReadFile = fs.readFileSync("DB/" + fileName, 'utf8');

      //   if (contentReadFile != "") {
      //     const dd = JSON.parse(contentReadFile);

      //     const newDataUpdateArr = dd.array.map((curEle2, index) => {
      //       const iPermDelete=curEle2?.iPermDelete && curEle2?.iPermDelete>0?curEle2?.iPermDelete:0;
      //       return {
      //         ...curEle2,
      //         ['iPermDelete']: curEle2.iToUserId == vActiveUserId && curEle2?.iRequestMsg==2 ? 1 : iPermDelete,
      //       }
      //     })

      //     fs.writeFileSync("DB/" + fileName, JSON.stringify({ array: newDataUpdateArr }));
      //   }
      // }

      const fileNameSend = results[0]['iUserId'] + "_" + dateFormate + ".json";

      // if (fs.existsSync("DB/" + fileNameSend)) {
      //   const contentReadFile2 = fs.readFileSync("DB/" + fileNameSend, 'utf8');

      //   if (contentReadFile2 != "") {
      //     const dd2 = JSON.parse(contentReadFile2);

      //     const newDataUpdateArr2 = dd2.array.map((curEle2, index) => {
      //       return {
      //         ...curEle2,
      //         ['iRequestMsg']: curEle2.id == msgId ? 5 : curEle2.iRequestMsg,
      //       }
      //     })

      //     fs.writeFileSync("DB/" + fileNameSend, JSON.stringify({ array: newDataUpdateArr2 }));
      //   }
      // }

      if(fileExist.length){
        fileExist.map((curEle,index)=>{
          
          if (fs.existsSync("DB/" + curEle)) {
            const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');

            if (contentReadRecFile != "") {
              const dd = JSON.parse(contentReadRecFile);

              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const isPermDelete=curEle2?.iPermDelete == undefined ? 0 :curEle2.iPermDelete;

                const isPermDeleteFlag = (curEle2?.iFromUserId==results[0]['iUserId'] && curEle2?.iToUserId==vActiveUserId) || (curEle2?.iFromUserId==vActiveUserId && curEle2?.iToUserId==results[0]['iUserId']) ? 1 : isPermDelete;

                return {
                  ...curEle2,
                  ['iPermDelete']: isPermDeleteFlag
                }
              })

              fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
            }
          }
        })

        fileExistReceiver.map((curEle,index)=>{
          if (fs.existsSync("DB/" + curEle)) {
            const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');

            if (contentReadRecFile != "") {
              const dd = JSON.parse(contentReadRecFile);
              
              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const iRequestMsg=curEle2?.iRequestMsg == undefined ? 0 :curEle2.iRequestMsg;

                const isLastMatchRequest=curEle2.iFromUserId==results[0]['iUserId'] && curEle2.iToUserId==vActiveUserId && iRequestMsg==1

                const iPermDelete=curEle2?.iPermDelete && curEle2?.iPermDelete>0?curEle2?.iPermDelete:0;

                return {
                  ...curEle2,
                  ['iPermDelete']: isLastMatchRequest?1:iPermDelete
                }
              })

              fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
            }
          }
        })

        if (fs.existsSync("DB/COMMONDB.json")) {

          const data = fs.readFileSync('DB/COMMONDB.json', 'utf8');
      
          const db = typeof data == "string" ? JSON.parse(data) : data;

          const filterData = db.array.filter((curEle, index) => {
            return curEle.senderId != results[0]['iUserId'] || (curEle.senderId == results[0]['iUserId'] && curEle.recieverId != vActiveUserId)
          })

          const newMapData=filterData.map((curEle2,index2)=>{
            const isStartChat=curEle2.isStartChat==undefined?0:curEle2.isStartChat;

            return {
                    ...curEle2,
                    ['isStartChat']:curEle2.senderId == vActiveUserId && curEle2.recieverId == results[0]['iUserId']?0:isStartChat
                  }
          })

          fs.writeFileSync('DB/COMMONDB.json', JSON.stringify({array:newMapData}));
        }


        const checkMsgConnExist=isCommunicate(vActiveUserId,results[0]['iUserId']);
        
        res.send({ message: 'Your chat history deleted successfully.', status: 200,checkMsgConnExist:checkMsgConnExist});
      }else{

        const checkMsgConnExist=isCommunicate(vActiveUserId,results[0]['iUserId']);
        res.send({ message: 'Your chat history deleted successfully.', status: 200,checkMsgConnExist:checkMsgConnExist });
      }
    }
  })
})
 
//Delete Group Chat Api
app.post('/DeleteGroupAllChat', (req, res) => {
  const { tToken, vActiveGroupId,isMember } = req.body;

  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length === 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {
      
      const dbFolderPath = "DB/";
      const NewArr = fs.readdirSync(dbFolderPath);
      const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;
    
      const fileExist = dd.length ? dd.filter((curEle, index) => {
        const splitStr = String(curEle).split("_");
        return splitStr[0] == "GROUP" && splitStr[1] == vActiveGroupId;
      }) : []

      if(fileExist){
        fileExist.map((curEle,index)=>{
          if (fs.existsSync("DB/" + curEle)) {
            const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');

            if (contentReadRecFile != "") {
              const dd = JSON.parse(contentReadRecFile);

              const newDataUpdateArr = dd.array.map((curEle2, index) => {
                const isPermDelete=curEle2?.vDeleteMsgUser == undefined ? '' : curEle2.vDeleteMsgUser;

                let splitStr=isPermDelete!=""?String(isPermDelete).split(","):[];
                const isCheckUserExist=splitStr.includes(Number(results[0]['iUserId']));
                const vUserDeleteList=isCheckUserExist?isPermDelete:isPermDelete+","+Number(results[0]['iUserId']);
                
                return {
                  ...curEle2,
                  ['vDeleteMsgUser']: vUserDeleteList
                }
              })

              fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
            }
          }
        })

        // if(isMember==0){
        //   pool.query('SELECT tGroupIds FROM chat_users WHERE iUserId=?', [results[0]['iUserId']], (error, results4, fields) => {
        //     if (results4.length > 0) {
        //       const splitGroupIds=String(results4[0]['tGroupIds']).split(",");

        //       const filterGroupIds=splitGroupIds.filter((curEle,index)=>{
        //           return curEle!=vActiveGroupId
        //       })
              
        //       pool.query(
        //         'UPDATE chat_users SET tGroupIds=? WHERE iUserId = ?',
        //         [filterGroupIds.toString(),results[0]['iUserId']]
        //       )
        //     }
        //   })
        // }

        res.send({ message: 'Your chat history deleted successfully.', status: 200, });
      }else{
        res.send({ message: 'Your chat history deleted successfully.', status: 200, });
      }
    }
  })
})

//Delete Profile Api
app.post('/DeleteProfile', (req, res) => {
  const { tToken } = req.body;

  pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
    if (error) {
      return res.status(500).send({ error: 'Internal Server Error 22' });
    }

    if (results.length == 0) {
      res.send({ message: 'User is not exist!', status: 401 });
    } else {

      pool.query('SELECT iGroupId,tGroupUsers,tGroupJoinMemb,tLeftMembers FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iCreatedBy=?', [results[0]['iUserId']], (error2, results2, fields) => {
        if(results2.length){
          results2.map((curEle,index)=>{
            const splitGrpMembArr=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(",").filter(i => i):[];

            const filterData=splitGrpMembArr.filter((curEle2,index)=>{
              return curEle2!=splitGrpMembArr[0]
            })

            const splitJoinMemb=curEle.tGroupJoinMemb!=""?String(curEle.tGroupJoinMemb).split(",").filter(i => i):[];
            const filterDataJoinMemb=splitJoinMemb.filter((curEle2,index)=>{
              return curEle2!=splitGrpMembArr[0]
            })

            const groupJoinMembeList=filterDataJoinMemb?.length && filterDataJoinMemb.length>0?filterDataJoinMemb.toString():"";
            const filterDataList=filterData?.length && filterData.length>0?filterData.toString():"";

            if(splitGrpMembArr.length==0){
              pool.query('UPDATE chat_broadcast_grp SET eGroupStatus="d" WHERE iGroupId = ?', [curEle.iGroupId], (error3, results3, fields) => {
              })
            }else{
              const tLeftMembers=results2[0]['tLeftMembers']+","+results[0]['iUserId'];

              pool.query('UPDATE chat_broadcast_grp SET iCreatedBy=?,tGroupUsers=?,tGroupJoinMemb=?,tLeftMembers=? WHERE iGroupId = ?', [splitGrpMembArr[0],filterDataList,groupJoinMembeList,tLeftMembers.toString(),curEle.iGroupId], (error3, results3, fields) => {
              })
            }
          })
        }
      })

      pool.query('SELECT iGroupId,tGroupUsers,tGroupJoinMemb,tLeftMembers FROM chat_broadcast_grp WHERE eGroupStatus="y" AND FIND_IN_SET(?,tGroupUsers)', [results[0]['iUserId']], (error2, results2, fields) => {
        if(results2.length){
          results2.map((curEle,index)=>{
            const splitGrpMembArr=curEle.tGroupUsers!=""?String(curEle.tGroupUsers).split(",").filter(i => i):[];
            const filterData=splitGrpMembArr.filter((curEle2,index)=>{
              return curEle2!=results[0]['iUserId']
            })

            const splitJoinMemb=curEle.tGroupJoinMemb!=""?String(curEle.tGroupJoinMemb).split(",").filter(i => i):[];
            const filterDataJoinMemb=splitJoinMemb.filter((curEle2,index)=>{
              return curEle2!=results[0]['iUserId']
            })

            const groupJoinMembeList=filterDataJoinMemb?.length && filterDataJoinMemb.length>0?filterDataJoinMemb.toString():"";
            const filterDataList=filterData?.length && filterData.length>0?filterData.toString():"";

            const tLeftMembers=results2[0]['tLeftMembers']+","+results[0]['iUserId'];

            pool.query('UPDATE chat_broadcast_grp SET tGroupUsers=?,tGroupJoinMemb=?,tLeftMembers=? WHERE iGroupId = ?', [filterDataList,groupJoinMembeList,tLeftMembers.toString(),curEle.iGroupId], (error3, results3, fields) => {
            })
          })
        }
      })

      pool.query('UPDATE chat_users SET eStatus="d" WHERE iUserId = ?', [results[0]['iUserId']], (error, results, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 22' });
        }

        pool.query('SELECT iGroupId,tGroupUsers FROM chat_broadcast_grp WHERE eGroupStatus="y"', [], (error2, results2, fields) => {
          if(results2.length){
            res.send({ message: 'Profile has been deleted successfull.', status: 200,data:results2 });
          }else{
            res.send({ message: 'Profile has been deleted successfull.', status: 200,data:[] });
          }
        })
      })

    }
  })
})

//Socket Code Start here
io.on('connection', (socket) => {
  
  socket.on('login',message=>{
    const { iLoggedId } = message;

    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iEngId=?', [iLoggedId], (error2, results2, fields) => {
      if (error2) {
        return res.status(500).send({ error2: 'Internal Server Error 31' });
      }

      if (results2.length > 0) {
        results2.map((curEle2,index2)=>{
          socket.in('' + curEle2['vChatId']).emit('receive_message', {
            type:"logout",
            isDeleteProfile:0
          });
        })
      }
    })
  })

  socket.on('logout',message=>{
    const { iLoggedId } = message;

    pool.query('SELECT vChatId,iUserId,vFullName FROM chat_users WHERE iUserId=?', [iLoggedId], (error2, results2, fields) => {
      if (error2) {
        return res.status(500).send({ error2: 'Internal Server Error 31' });
      }

      if (results2.length > 0) {
        results2.map((curEle2,index2)=>{
          socket.in('' + curEle2['vChatId']).emit('receive_message', {
            type:"logout",
          });
        })
      }
    })
  })

  socket.on('join_msg', message => {
    socket.join(socket.id);

    pool.query(
      'UPDATE chat_users SET vChatId=?,iStatus=1 WHERE tToken = ?',
      [socket.id, message.token],
      (error, results2, fields) => {
      }
    );

    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y"', [], (error2, results2, fields) => {
      if (error2) {
        return res.status(500).send({ error2: 'Internal Server Error 31' });
      }

      if (results2.length > 0) {
        results2.map((curEle2,index2)=>{
          socket.in('' + curEle2['vChatId']).emit('receive_message', {
            type:"RefreshUserList",
          });
        })
      }
    })
  })

  // Handle incoming messages
  socket.on('message', (data) => {
    console.log("message");
  });

  //MessageTyping
  socket.on('MessageTyping', (message) => {
    const { iFromUserId, iToUserId, msg } = message;

    pool.query('SELECT vChatId FROM chat_users WHERE iUserId=?', [iToUserId], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 26' });
      }

      if (results.length > 0) {
        if (msg == "") {
          socket.in(results[0]['vChatId']).emit('MessageTypingEnd', {
            iFromUserId: iFromUserId,
          });
        } else {
          socket.in(results[0]['vChatId']).emit('MessageTypingStart', {
            iFromUserId: iFromUserId,
          });
        }
      }

    })
  })

  //MessageReadUpdate
  socket.on('messageReadUpdate', (message) => {
    const { iFromUserId, iToUserId } = message;

    pool.query('SELECT vChatId FROM chat_users WHERE iUserId=?', [iToUserId], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 27' });
      }

      if (results.length > 0) {
        socket.in(results[0]['vChatId']).emit('readSuccessMsg', {
          iFromUserId: iFromUserId,
        });

        const newReadFile = iToUserId + "_" + datFunction() + ".json";
        const MyJsonFile = iFromUserId + "_" + datFunction() + ".json";

        if (fs.existsSync("DB/" + newReadFile)) {
          const contentReadFile = fs.readFileSync("DB/" + newReadFile, 'utf8');
          if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);

            let newDataUpdateArr = dd.array.map((curEle, index) => {
              return {
                ...curEle,
                ['iRead']: curEle.iToUserId == iFromUserId ? 1 : curEle.iRead,
                ['iReadTo']: curEle.iToUserId == iFromUserId ? 1 : curEle.iReadTo
              }
            })

            fs.writeFileSync("DB/" + newReadFile, JSON.stringify({ array: newDataUpdateArr }));
          }
        }

        if (fs.existsSync("DB/" + MyJsonFile)) {
          const contentReadFile = fs.readFileSync("DB/" + MyJsonFile, 'utf8');
          if (contentReadFile != "") {
            const dd = JSON.parse(contentReadFile);

            let newDataUpdateArr = dd.array.map((curEle, index) => {
              return {
                ...curEle,
                ['iRead']: curEle.iFromUserId == iToUserId ? 1 : curEle.iRead,
              }
            })

            fs.writeFileSync("DB/" + MyJsonFile, JSON.stringify({ array: newDataUpdateArr }));
          }
        }


      }
    })

  })

  //Chat Request Accept
  socket.on('chatRequestAccept', (message) => {
    const { iToUserId,status,tToken,iDelete} = message;

    pool.query('SELECT iUserId,vChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 31' });
      }

      if (results.length > 0) {
        pool.query('SELECT vChatId FROM chat_users WHERE iUserId=?', [iToUserId], (error2, results2, fields) => {
          if (error2) {
            return res.status(500).send({ error2: 'Internal Server Error 31' });
          }
    
          if (results2.length > 0) {
            socket.in(results2[0]['vChatId']).emit('receive_message', {
              type:"ChatRequestAccept",
              status:status,
              iSenderId: results[0]['iUserId'],
              iDelete:iDelete
            });
          }
        })
      }
    })
  })

  // Handle disconnection
  socket.on('disconnect', () => {
    pool.query(
      'UPDATE chat_users SET iStatus=0 WHERE vChatId = ?',
      [socket.id],
      (error, results2, fields) => {
        if (error) {
          return results2.status(500).send({ error: 'Internal Server Error 29' });
        }
      }
    );

    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y"', [], (error2, results2, fields) => {
      if (error2) {
        return res.status(500).send({ error2: 'Internal Server Error 31' });
      }

      if (results2.length > 0) {
        results2.map((curEle2,index2)=>{
          socket.in('' + curEle2['vChatId']).emit('receive_message', {
            type:"RefreshUserList",
          });
        })
      }
    })
    console.log("user disconnected");
  });

  //Group List Refresh
  socket.on('GroupRefreshUpdate', (message) => {
    const { vActiveGroupId,vUsers,isDelete } = message;

    socket.in('' + vActiveGroupId).emit('receive_grp_message', {
      type:"refreshGroup",
      vActiveGroupId:vActiveGroupId,
      vUsers:vUsers,
      isDelete:isDelete
    });
  })

  //Group List Refresh
  socket.on('GroupNewMembRefresh', (message) => {
    const { vUsers } = message;

    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId IN(?)', [vUsers], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 30' });
      }

      if (results.length > 0) {
        results.map((curEle,index)=>{
          socket.in('' + curEle.vChatId).emit('receive_message', {
            type:"refreshGroupList",
          });
        })
      }
    })
  })

  //All My Connection My Status Change
  socket.on('AllUserGetMyNewSts', (message) => {
    const { tToken,vUsers  } = message;

    pool.query('SELECT iUserId,vChatId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 31' });
      }

      if (results.length > 0) {
        String(vUsers).split(",").map((curEle,index)=>{
          pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=?', [curEle], (error2, results2, fields) => {
            if (error2) {
              return res.status(500).send({ error2: 'Internal Server Error 31' });
            }
      
            if (results2.length > 0) {
              results2.map((curEle2,index2)=>{
                socket.in('' + curEle2['vChatId']).emit('receive_message', {
                  type:"RefreshUserList",
                });
              })
            }
          })
          // RefreshUserList
        })
      }
    })
  })

  const uploadFolder = './public/images/uploads/';
  if (!fs.existsSync(uploadFolder)) {
    fs.mkdirSync(uploadFolder);
  }

  //Send Message
  socket.on('send_message', (message) => {
    const { receiverChatID, senderChatID, content, ImageDataArr, vReplyMsg, vReplyMsg_id,id,vReplyFileName,iRequestMsg,isForwardMsg,isDeleteprofile } = message;

    if (ImageDataArr.length > 0) {
      ImageDataArr.map((curEle, index) => {

        const fileName = `${Date.now()}_${curEle.fileName}`;
        const filePath = `${uploadFolder}${fileName}`;
        const fileType = curEle.type;

        // Write the image data to a file
        // var base64Data = curEle.imageData.split("base64,");

        var base64Data = curEle.imageData.split("base64,");

        const base64DataWithoutHeader = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
        const fileBuffer = Buffer.from(base64DataWithoutHeader, 'base64');

        //Image Thumbnail Store
        let fileNameThumb = "";
        if(curEle.imageDataThumb!=""){
          fileNameThumb = `${Date.now()}_thumb_${curEle.fileName}`;
          const filePathThumb = `${uploadFolder}${fileNameThumb}`;
          var base64Data = curEle.imageDataThumb.split("base64,");
          const base64DataWithoutHeaderThumb = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
          const fileBufferThumb = Buffer.from(base64DataWithoutHeaderThumb, 'base64');
  
          fs.writeFile(filePathThumb, fileBufferThumb, (err) => {
            console.log("err", err)
            if (err) throw err;
          })
        }

        //Original Image store
        fs.writeFile(filePath, fileBuffer, (err) => {
          console.log("err", err)
          if (err) throw err;

          pool.query('SELECT vChatId as receiverChatID,(SELECT vChatId FROM chat_users WHERE iUserId=' + senderChatID + ') as senderChatID FROM chat_users WHERE eStatus="y" AND iUserId=?', [receiverChatID], (error, results, fields) => {
            if (error) {
              return res.status(500).send({ error: 'Internal Server Error 30' });
            }

            if (results.length > 0) {
              // Send message to only that particular room
              let ContentData = "vImages => images/uploads/" + fileName;
              let ContentDataThumb = fileNameThumb!=""?"vImages => images/uploads/" + fileNameThumb:"";

              const senderJsonFile = senderChatID + '_' + datFunction() + '.json';
              const receverJsonFile = receiverChatID + '_' + datFunction() + '.json';

              let vReplyMsg_idFinal = vReplyMsg_id;
              let vReplyMsgFinal = vReplyMsg;

              if (vReplyMsg_id == "LastId") {
                if (fs.existsSync('DB/' + senderJsonFile)) {
                  const dataOld = fs.readFileSync('DB/' + senderJsonFile, 'utf8');
                  const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);

                  if (dbOld.array.length) {
                    vReplyMsg_idFinal = dbOld.array[dbOld.array.length - 1]['id'];
                    vReplyMsgFinal = dbOld.array[dbOld.array.length - 1]['message'];
                  }
                }
              }

              socket.in(results[0]['receiverChatID']).emit('receive_message', {
                content: ContentData,
                senderChatID: results[0]['senderChatID'],
                receiverChatID: results[0]['receiverChatID'],
                iSenderId: senderChatID,
                vReplyMsg: vReplyMsgFinal,
                vReplyMsg_id: vReplyMsg_idFinal,
                vReplyFileName:vReplyFileName,
                id:id,
                ContentDataThumb:ContentDataThumb,
                iRequestMsg:iRequestMsg,
                isForwardMsg:isForwardMsg,
                isDeleteprofile:isDeleteprofile
              });

              if(iRequestMsg!=5){
                JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id,id,vReplyFileName,0,ContentDataThumb,0,iRequestMsg,"","",isForwardMsg,isDeleteprofile,0,"","");
              }

              JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id,id,vReplyFileName,0,ContentDataThumb,0,iRequestMsg,"","",isForwardMsg,isDeleteprofile,0,"","");
        
              lastChatUpdate(senderChatID, receiverChatID);
              lastChatUpdate(receiverChatID, senderChatID);
            }
          })
        })
        // saveBlobFile(curEle.imageData,filePath);
      })
    } else {
      pool.query('SELECT vChatId as receiverChatID,(SELECT vChatId FROM chat_users WHERE iUserId=' + senderChatID + ') as senderChatID FROM chat_users WHERE eStatus="y" AND iUserId=?', [receiverChatID], (error, results, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 31' });
        }

        if (results.length > 0) {
          // Send message to only that particular room
          let ContentData = content;

          const senderJsonFile = senderChatID + '_' + datFunction() + '.json';
          const receverJsonFile = receiverChatID + '_' + datFunction() + '.json';

          let vReplyMsg_idFinal = vReplyMsg_id;
          let vReplyMsgFinal = vReplyMsg;

          if (vReplyMsg_id == "LastId") {
            if (fs.existsSync('DB/' + senderJsonFile)) {
              const dataOld = fs.readFileSync('DB/' + senderJsonFile, 'utf8');
              const dbOld = dataOld == "" ? { array: [] } : JSON.parse(dataOld);

              if (dbOld.array.length) {
                vReplyMsg_idFinal = dbOld.array[dbOld.array.length - 1]['id'];
                vReplyMsgFinal = dbOld.array[dbOld.array.length - 1]['message'];
              }
            }
          }

          if(isDeleteprofile==1){
            const dbFolderPath = "DB/";
            const NewArr = fs.readdirSync(dbFolderPath);
            const dd = typeof NewArr == "string" ? JSON.parse(NewArr) : NewArr;

            const fileExist = dd.length ? dd.filter((curEle, index) => {
              const splitStr = String(curEle).split("_");
              return splitStr[0] == receiverChatID;
            }) : [];

            if (fileExist.length) {
              fileExist.map((curEle, index) => {

                if (fs.existsSync("DB/" + curEle)) {
                  const contentReadRecFile = fs.readFileSync("DB/" + curEle, 'utf8');

                  if (contentReadRecFile != "") {
                    const dd = JSON.parse(contentReadRecFile);

                    const newDataUpdateArr = dd.array.map((curEle2, index) => {
                      const isPermDelete = curEle2?.iPermDelete == undefined ? 0 : curEle2.iPermDelete;
                      const iRequestMsg = curEle2?.iRequestMsg == undefined ? 0 : curEle2.iRequestMsg;
                      const isPermDeleteFlag = iRequestMsg == 1 ? 1 : isPermDelete;

                      return {
                        ...curEle2,
                        ['iPermDelete']: isPermDeleteFlag
                      }
                    })

                    fs.writeFileSync("DB/" + curEle, JSON.stringify({ array: newDataUpdateArr }));
                  }
                }

              })
            }
          }

          if(iRequestMsg==5){
            const isMessageExist=isCommunicate(receiverChatID,senderChatID);
            if(isMessageExist>0){
              socket.in(results[0]['receiverChatID']).emit('receive_message', {
                content: ContentData,
                senderChatID: results[0]['senderChatID'],
                receiverChatID: results[0]['receiverChatID'],
                iSenderId: senderChatID,
                vReplyMsg: vReplyMsgFinal,
                vReplyMsg_id: vReplyMsg_idFinal,
                vReplyFileName:vReplyFileName,
                id:id,
                iRequestMsg:iRequestMsg,
                isForwardMsg:isForwardMsg,
                isDeleteprofile:isDeleteprofile
              });
              
              JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id,id,vReplyFileName,0,"",0,iRequestMsg,"","",isForwardMsg,isDeleteprofile,0,"","");
    
              lastChatUpdate(receiverChatID, senderChatID);
            }
          }else{
            socket.in(results[0]['receiverChatID']).emit('receive_message', {
              content: ContentData,
              senderChatID: results[0]['senderChatID'],
              receiverChatID: results[0]['receiverChatID'],
              iSenderId: senderChatID,
              vReplyMsg: vReplyMsgFinal,
              vReplyMsg_id: vReplyMsg_idFinal,
              vReplyFileName:vReplyFileName,
              id:id,
              iRequestMsg:iRequestMsg,
              isForwardMsg:isForwardMsg,
              isDeleteprofile:isDeleteprofile
            });
  
            JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id,id,vReplyFileName,0,"",0,iRequestMsg,"","",isForwardMsg,isDeleteprofile,0,"","");
            
            JsonFileGenerate(receverJsonFile, senderChatID, receiverChatID, ContentData, 0, vReplyMsg, vReplyMsg_id,id,vReplyFileName,0,"",0,iRequestMsg,"","",isForwardMsg,isDeleteprofile,0,"","");
  
            lastChatUpdate(senderChatID, receiverChatID);
            lastChatUpdate(receiverChatID, senderChatID);
          }

        }
      })
    }
  });


  //Join_group
  socket.on('join_group', message => {
    const { iGroupId } = message;
    socket.join("" + iGroupId);
  })

  socket.on('send_grp_message', (message) => {
    const { receiverChatID, senderChatID, content, ImageDataArr, vReplyMsg, vReplyMsg_id,id,vReplyFileName,isGreetingMsg,vMembersList,vGroupMessageType,isForwardMsg,isDeleteprofile,iRequestMsg,vDeleteMemberId,vNewAdminId,RequestMemberId } = message;

    if (ImageDataArr.length > 0) {
      ImageDataArr.map((curEle, index) => {
        const fileName = `${Date.now()}_${curEle.fileName}`;
        const filePath = `${uploadFolder}${fileName}`;
        const fileType = curEle.type;

        // Write the image data to a file
        // var base64Data = curEle.imageData.split("base64,");

        saveBlobFile(curEle.imageData, filePath);

        let ContentData = "vImages => images/uploads/" + fileName;

        let fileNameThumb = "";
        if(curEle.imageDataThumb!=""){
          fileNameThumb = `${Date.now()}_thumb_${curEle.fileName}`;
          const filePathThumb = `${uploadFolder}${fileNameThumb}`;
          var base64Data = curEle.imageDataThumb.split("base64,");
          const base64DataWithoutHeaderThumb = base64Data[1].replace(/^data:image\/\w+;base64,/, '');
          const fileBufferThumb = Buffer.from(base64DataWithoutHeaderThumb, 'base64');

          fs.writeFile(filePathThumb, fileBufferThumb, (err) => {
            console.log("err", err)
            if (err) throw err;
          })
        }

        let ContentDataThumb = fileNameThumb!=""?"vImages => images/uploads/" + fileNameThumb:"";

        socket.in('' + receiverChatID).emit('receive_grp_message', {
          content: ContentData,
          iGroupSenderId: receiverChatID,
          senderChatID: senderChatID,
          vReplyMsg,
          vReplyMsg_id,
          ContentDataThumb:ContentDataThumb,
          isGreetingMsg:isGreetingMsg,
          vGroupMessageType:vGroupMessageType,
          isForwardMsg:isForwardMsg,
          isDeleteprofile:isDeleteprofile,
          iRequestMsg:iRequestMsg,
          vMembersList:vMembersList,
          vDeleteMemberId:vDeleteMemberId,
          id:id
        });

        const senderJsonFile = 'GROUP_' + receiverChatID + '_' + datFunction() + '.json';

        // vDeleteMemberId
        let vMembersListNew=vDeleteMemberId!=""?vMembersList+","+vDeleteMemberId:vMembersList;

        JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id,id,vReplyFileName,1,ContentDataThumb,isGreetingMsg,iRequestMsg,vMembersListNew,vGroupMessageType,isForwardMsg,isDeleteprofile,vDeleteMemberId,"",RequestMemberId);
      })
    } else {
      let ContentData = content;
      pool.query('SELECT tGroupUsers,iCreatedBy,tGroupJoinMemb FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [receiverChatID], (error, results, fields) => {
        if (error) {
          return res.status(500).send({ error: 'Internal Server Error 32' });
        }
        
        // console.log("results", results[0])
        if (results.length > 0) {
          
          let SplitGroupUsr = results[0]['tGroupUsers']!=""?String(results[0]['tGroupUsers']).split(","):[];
          if(iRequestMsg==1 || iRequestMsg==3 || iRequestMsg==4){
            const splitMemeberListArr=vMembersList!=""?String(vMembersList).split(","):[];
            SplitGroupUsr = [...splitMemeberListArr];
          }

          if (results[0]['iCreatedBy'] != senderChatID) {
            SplitGroupUsr.push(results[0]['iCreatedBy']);
          }

          SplitGroupUsr.map((curEle, index) => {
            if (curEle != "") {

              pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=? ', [curEle], (error2, results2, fields) => {
                if (error2) {
                  return res.status(500).send({ error: 'Internal Server Error 33' });
                }

                if (results2.length > 0) {
                  socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                    content: ContentData,
                    iGroupSenderId: receiverChatID,
                    senderChatID: senderChatID,
                    vReplyMsg,
                    vReplyMsg_id,
                    isGreetingMsg:isGreetingMsg,
                    vGroupMessageType:vGroupMessageType,
                    isForwardMsg:isForwardMsg,
                    isDeleteprofile:isDeleteprofile,
                    iRequestMsg:iRequestMsg,
                    vMembersList:vMembersList,
                    vDeleteMemberId:vDeleteMemberId,
                    id:id,
                    vNewAdminId:vNewAdminId
                  });
                }
              })

            }
          })
        }
      })

      const senderJsonFile = 'GROUP_' + receiverChatID + '_' + datFunction() + '.json';

      let vMembersListNew=vDeleteMemberId!=""?vMembersList+","+vDeleteMemberId:vMembersList;

      JsonFileGenerate(senderJsonFile, senderChatID, receiverChatID, ContentData, 1, vReplyMsg, vReplyMsg_id,id,vReplyFileName,1,"",isGreetingMsg,iRequestMsg,vMembersListNew,vGroupMessageType,isForwardMsg,isDeleteprofile,vDeleteMemberId,vNewAdminId,RequestMemberId);
    }
  })

  //Delete Message
  socket.on('delete_message', message => {
    const { content,vActiveGroupId,vActiveUserId,tToken,isAdmin } = message;

    pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 31' });
      }

      if (results.length > 0) {
        if(vActiveGroupId>0){
          pool.query('SELECT tGroupUsers,iCreatedBy FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error3, results3, fields) => {
            if (error3) {
              return res.status(500).send({ error3: 'Internal Server Error 32' });
            }
    
            // console.log("results", results[0])
            if (results3.length > 0) {
              if (results3[0]['tGroupUsers'] != "") {
                const SplitGroupUsr = results3[0]['tGroupUsers']!=""?String(results3[0]['tGroupUsers']).split(","):[];
                if (results3[0]['iCreatedBy'] != results[0]['iUserId']) {
                  SplitGroupUsr.push(results3[0]['iCreatedBy']);
                }
    
                SplitGroupUsr.map((curEle, index) => {
                  if (curEle != "" && curEle!=results[0]['iUserId']) {
    
                    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=? ', [curEle], (error2, results2, fields) => {
                      if (error2) {
                        return res.status(500).send({ error: 'Internal Server Error 33' });
                      }
    
                      if (results2.length > 0) {
                        socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                          content: content,
                          type:"DeleteMessage",
                          iGroupId:vActiveGroupId,
                          isAdmin:isAdmin
                        });
                      }
                    })
    
                  }
                })
              }
            }
          })
    
        }else{
          pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=?', [vActiveUserId], (error2, results2, fields) => {
            if (error2) {
              return res.status(500).send({ error2: 'Internal Server Error 31' });
            }
      
            if (results2.length > 0) {
              socket.in(results2[0]['vChatId']).emit('receive_message', {
                content: content,
                type:"DeleteMessage",
                iSenderId:results[0]['iUserId']
              });
            }
          })
        }
      }
    })


  })

  //Update Message
  socket.on('update_message', message => {
    const { content,iMessageId,vActiveGroupId,vActiveUserId,tToken } = message;

    pool.query('SELECT iUserId FROM chat_users WHERE eStatus="y" AND tToken=?', [tToken], (error, results, fields) => {
      if (error) {
        return res.status(500).send({ error: 'Internal Server Error 31' });
      }

      if (results.length > 0) {
        if(Number(vActiveGroupId)>0){
          pool.query('SELECT tGroupUsers,iCreatedBy FROM chat_broadcast_grp WHERE eGroupStatus="y" AND iGroupId=?', [vActiveGroupId], (error3, results3, fields) => {
            if (error3) {
              return res.status(500).send({ error3: 'Internal Server Error 32' });
            }
    
            // console.log("results", results[0])
            if (results3.length > 0) {
              if (results3[0]['tGroupUsers'] != "") {
                const SplitGroupUsr = results3[0]['tGroupUsers']!=""?String(results3[0]['tGroupUsers']).split(","):[];
                if (results3[0]['iCreatedBy'] != results[0]['iUserId']) {
                  SplitGroupUsr.push(results3[0]['iCreatedBy']);
                }
    
                SplitGroupUsr.map((curEle, index) => {
                  if (curEle != "" && curEle!=results[0]['iUserId']) {
    
                    pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=? ', [curEle], (error2, results2, fields) => {
                      if (error2) {
                        return res.status(500).send({ error: 'Internal Server Error 33' });
                      }
    
                      if (results2.length > 0) {
                        socket.in('' + results2[0]['vChatId']).emit('receive_grp_message', {
                          content: content,
                          type:"UpdateMessage",
                          iMessageId:iMessageId,
                          iGroupId:vActiveGroupId
                        });
                      }
                    })
    
                  }
                })
              }
            }
          })
    
        }else{
          pool.query('SELECT vChatId FROM chat_users WHERE eStatus="y" AND iUserId=?', [vActiveUserId], (error2, results2, fields) => {
            if (error2) {
              return res.status(500).send({ error2: 'Internal Server Error 31' });
            }
      
            if (results2.length > 0) {
              socket.in(results2[0]['vChatId']).emit('receive_message', {
                content: content,
                type:"UpdateMessage",
                iMessageId:iMessageId,
                iSenderId:results[0]['iUserId']
              });
            }
          })
        }
      }
    })
  })
  
});

app.use(express.static('public'));
app.use('/images/uploads', express.static('images'));
app.use(express.static('DB'))

server.listen(9000, '192.168.1.35', () => {
  console.log('Server started on port 9000');
  pool.query(
    'UPDATE chat_users SET iStatus=0',
    [],
    (error, results2, fields) => {
    }
  );
});

server.on('close', function() {
  console.log("server close");
});