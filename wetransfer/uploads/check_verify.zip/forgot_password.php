<?php
include("config.php");
@session_start();

function decryptString($str)
{
    $ciphering = "AES-128-CTR";
    $options = 0;
    $decryption_iv = '1234567891011121';
    $decryption_key = "ChatApp001";
    $decryption = openssl_decrypt($str, $ciphering, $decryption_key, $options, $decryption_iv);
    return $decryption;
}


if(empty($_GET) && !isset($_GET['id'])){
    header('Location: login');
}else{
    $id = $_GET['id'];
    $Data = decryptString($id);
    $Data = json_decode($Data, true);
    
    $id = $Data['isLoggedUser'];

    if($id==""){
        header('Location: login');
    }
}

?>
<html>
    <head>
        <title>Chat App</title>
        <link rel="stylesheet" href="./custom.css">
    </head>
<body>

    <label>New Password</label>
    <input type="password" id="vPassWord" minlength="8" maxlength="15" />
    <button id="ViewPassword">View</button>
    
    <div id="passwordErrSuggest" class="d-none mt-3">
        <h6 class="validationTitle mb-2">Password requirements</h6>
        <ul id="passwordErrorList">
        </ul>
    </div>

    <br /><br />

    <button id="submit">Submit</button>

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="./js/CustomFun.js"></script>
    <script>

        $("#vPassWord").on("input", (e) => {
            const vPassWordStr = String(e.target.value).trim();
            addErrorPaswordCust(vPassWordStr,"passwordErrSuggest","passwordErrorList");
        })

        $("#submit").click(()=>{
            const vPassWord=String($("#vPassWord").val()).trim();
            
            if(vPassWord==""){
                alert("Please fill all field!");
            }else{
                if(addErrorPaswordCust(vPassWord,"passwordErrSuggest","passwordErrorList")){
                    $.ajax({
                        type: 'POST',
                        dataType: "JSON",
                        async: false,
                        url: '<?=$API_URL?>change_password',
                        data: {vPassWord:vPassWord,iUserId:'<?=$id?>'},
                        success: function(data, status, xhr) {
                            if(data.status==200){
                                window.location = "./login.php";
                            }else{
                                alert(data.message);
                            }
                        }
                    });
                }
            }
        })

        $("#ViewPassword").on("click",(e)=>{
            const vPassWordtype=$("#vPassWord").attr("type");
            if(vPassWordtype=="password"){
                $("#vPassWord").attr("type","text");
            }else{
                $("#vPassWord").attr("type","password");
            }
        })


    </script>
</body>

</html>