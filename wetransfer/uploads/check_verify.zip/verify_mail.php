<?php
    include("config.php");
    @session_start();
    
    function decryptString($str)
    {
        $ciphering = "AES-128-CTR";
        $options = 0;
        $decryption_iv = '1234567891011121';
        $decryption_key = "ChatApp001";
        $decryption = openssl_decrypt($str, $ciphering, $decryption_key, $options, $decryption_iv);
        return $decryption;
    }

    $_SESSION['error']="";
    if(isset($_POST['submit'])){
        if($_POST['vOtp']==""){
            $_SESSION['error']="Please enter otp.";
        }else{
            $_SESSION['error']="";
            if(isset($_GET['id'])){
                $id = $_GET['id'];
                $Data = decryptString($id);
                $Data = json_decode($Data, true);
            
                $id = $Data['isLoggedUser'];

                if(trim($_POST['vOtp'])==trim($_SESSION['vOtp'])){
                    $conn = new mysqli("localhost","root","123456","chatapp");
                    if ($conn -> connect_errno) {
                        header('Location: login');
                    }else{
                        $sql = "UPDATE chat_users SET iEmailVerified = '1' WHERE iEngId = '".$id."' AND eStatus='y'"; 
                        $result = mysqli_query($conn, $sql);
                        if(!$result){ 
                            header('Location: login');
                        } else{ 
                            header('Location: login');
                        } 
                    }
                }else{
                    $_SESSION['error']="The OTP you entered does not match the OTP sent to your email.";
                }
            }else{
                header('Location: login');
            }

        }
    }

?>
<html>
    <body>
        <form method="post" action="">
            <?php
                if($_SESSION['error']!=""){
                    echo "<span style='color:red;'>".$_SESSION['error']."</span><br/><br/>";
                }
            ?>
            <label>OTP</label>
            <input type="text" id="vOtp" name="vOtp"/>
            <br/><br/>
            <input type="submit" name="submit" />
            <br/><br/>
            <span>Or Link</span>
            <p>If you want to confirm via link, please check your email address. We have sent you a link, click it to confirm.</p>
            <a href="login">Back To Login</a>
        </form>
    <script src="plugins/jquery/jquery.min.js"></script>
    </body>
</html>