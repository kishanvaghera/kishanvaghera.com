<?php 
session_start();
include "functions.php";

function encrpytString($str){
    $ciphering = "AES-128-CTR";
    $options = 0;
    $encryption_iv = '1234567891011121';
    $encryption_key = "ChatApp001";
    $encryption = openssl_encrypt($str,$ciphering,$encryption_key, $options, $encryption_iv);
    return $encryption;
}

$mainUrl="http://192.168.1.35/chat-app/";

if(!empty($_POST)){
    if($_POST['action']=="forgot_password"){
        $isLoggedUser=trim($_POST['isLoggedUser']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);
        
        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$vFullName."</b></p> <p>Forgot password link:- </p> ".$mainUrl."forgot_password.php?id=".$encrptStr;
            
            if(NewSMTPMailSend($vEmailAdr,"forgot password",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="verify_email"){
        $isLoggedUser=trim($_POST['isLoggedUser']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);

        $randomNumber = rand(100000, 999999);

        $_SESSION['vOtp']=$randomNumber;
        
        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$vFullName."</b> <br/>OTP Code :- ".$randomNumber."</p> <br/> <p>Verify email with link:-</p> <br/> ".$mainUrl."check_verify.php?id=".$encrptStr;
            
            if(NewSMTPMailSend($vEmailAdr,"Verify Email",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="send_verify_email"){
        $isLoggedUser=trim($_POST['iUserId']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);

        $randomNumber = rand(100000, 999999);

        $_SESSION['vVerfiyEmailOtp']=$randomNumber;
        
        if($vEmailAdr!=""){
            $encrptStr=encrpytString(json_encode(array("isLoggedUser"=>$isLoggedUser,"vFullName"=>$vFullName)));
            $encrptStr=urlencode($encrptStr);

            $html="<p>User Id:- <b>".$isLoggedUser."</b> <br/> User Name:- <b>".$vFullName."</b> <br/>OTP Code :- ".$randomNumber."</p> <br/> <br/>";
            
            if(NewSMTPMailSend($vEmailAdr,"Verify Email",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully.","url"=>$encrptStr));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }else if($_POST['action']=="verfication_check"){
        if($_SESSION['vVerfiyEmailOtp']==$_POST['vEmailChangeVerfCode']){
            echo json_encode(array("status"=>200,"msg"=>"Verification is correct."));
            exit;
        }else{
            echo json_encode(array("status"=>412,"msg"=>"mail error."));
            exit;
        }
    }else if($_POST['action']=="delete_profile"){
        $isLoggedUser=trim($_POST['iUserId']);
        $vFullName=trim($_POST['vFullName']);
        $vEmailAdr=trim($_POST['vEmailAdr']);
        
        if($vEmailAdr!=""){

            $html="<p>Your profile is deleted. Below are the details of your account for your reference:</p><p>Username: ".$isLoggedUser."<br/>Email Address: ".$vEmailAdr."<br/>Full Name: ".$vFullName."</p>";
            
            if(NewSMTPMailSend($vEmailAdr,"Profile Deletion",$html)){
                echo json_encode(array("status"=>200,"msg"=>"mail sent successfully."));
                exit;
            }else{
                echo json_encode(array("status"=>412,"msg"=>"mail error."));
                exit;
            }
        }
    }
}

?>
