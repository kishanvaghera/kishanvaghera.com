<?php
session_start();
// print_r($_SESSION);exit;

function decryptString($str){
    $ciphering = "AES-128-CTR";
    $options = 0;
    $decryption_iv = '1234567891011121';
    $decryption_key = "ChatApp001";
    $decryption = openssl_decrypt($str, $ciphering, $decryption_key, $options, $decryption_iv);
    return $decryption;
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $Data = decryptString($id);
    $Data = json_decode($Data, true);

    $id = $Data['isLoggedUser'];
    $_SESSION['verfiy_email_msg']="";
    
    $conn = new mysqli("localhost","root","123456","chatapp");
    if ($conn -> connect_errno) {
        header('Location: login');
    }else{
        $sql = "UPDATE chat_users SET iEmailVerified = '1' WHERE iEngId = '".$id."' AND eStatus='y'"; 
        $result = mysqli_query($conn, $sql);
        if(!$result){ 
            header('Location: login');
        } else{ 
            header('Location: login');
        } 

        $_SESSION['verfiy_email_msg']="Your email is verified; now you can log in.";
    }

}else{
    header('Location: login');
}

?>