-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.1.35:3306
-- Generation Time: Jun 28, 2024 at 04:36 AM
-- Server version: 11.0.3-MariaDB-log
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_broadcast_grp`
--

CREATE TABLE `chat_broadcast_grp` (
  `iGroupId` int(11) NOT NULL,
  `vGroupName` varchar(255) NOT NULL,
  `vGroupImage` varchar(255) NOT NULL,
  `tGroupUsers` text NOT NULL,
  `tGroupJoinMemb` text NOT NULL,
  `tDescription` text NOT NULL,
  `iColorOption` int(11) NOT NULL,
  `tLeftMembers` text NOT NULL,
  `dCreatedDate` datetime NOT NULL,
  `iCreatedBy` int(11) NOT NULL,
  `eGroupStatus` enum('y','n','d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_broadcast_grp`
--

INSERT INTO `chat_broadcast_grp` (`iGroupId`, `vGroupName`, `vGroupImage`, `tGroupUsers`, `tGroupJoinMemb`, `tDescription`, `iColorOption`, `tLeftMembers`, `dCreatedDate`, `iCreatedBy`, `eGroupStatus`) VALUES
(15, 'new group', '', '37,39', '', '', 1, '', '2024-04-22 12:03:08', 40, 'd'),
(16, 'Yes Man', 'images/uploads/GroupProfile/1716533783178_solen-feyissa-fBfE9zjTkKw-unsplash.jpg', '40,41,42,43,44', '', 'hello! To all', 1, '', '2024-04-22 15:48:01', 37, 'y'),
(17, 'Stock suggestions', '', '41,42,40,37,39', '', '', 1, '', '2024-04-22 16:03:03', 38, 'y'),
(18, 'Group - 01', 'images/uploads/GroupProfile/1714108185722_IMG-20180608-WA0020.jpg', '37,39,44', '', '', 1, '', '2024-04-22 16:23:46', 43, 'y'),
(19, 'Share Bazar Tips', 'images/uploads/1713783483463_Screenshot 2023-12-21 190358.png', '43,44,40', '', '', 1, '', '2024-04-22 16:28:03', 37, 'y'),
(20, 'Hello...!', 'images/uploads/GroupProfile/1714108106689_IMG_20181203_053924.jpg', '37', '', '', 1, '', '2024-04-22 16:43:03', 43, 'y'),
(21, 'Test New', '', '44', '', '', 1, '', '2024-04-25 12:14:12', 37, 'y'),
(22, 'Test3', '', '43', '', '', 1, '', '2024-04-25 12:17:29', 37, 'y'),
(23, 'Enliven Family....', '', '37,38,39,40,41,42,44', '', '', 1, '', '2024-04-25 12:18:53', 43, 'd'),
(24, 'Knowledge Bank', 'images/uploads/GroupProfile/1714107674197_IMG_20180525_220131.jpg', '37', '', '', 1, '', '2024-04-25 12:38:31', 43, 'y'),
(25, 'Test', '', '37', '', '', 1, '', '2024-04-25 14:38:01', 42, 'd'),
(26, 'Test2', '', '37', '', '', 1, '', '2024-04-25 14:40:38', 42, 'd'),
(27, 'Finix Dev', '', '37,39', '', '', 1, '', '2024-04-26 09:35:29', 41, 'y'),
(28, 'yes ', 'images/uploads/GroupProfile/1714208353915_heart-beat-8112920-6497228.png', '41,40', '', '', 1, '', '2024-04-27 14:29:13', 37, 'y'),
(29, 'Safari', '', '37,39,40', '', '', 1, '', '2024-05-13 10:08:18', 38, 'y'),
(30, 'Chromium', '', '37,39,40,41,43,42,44', '', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is available.', 2, '', '2024-05-13 10:11:29', 38, 'y'),
(31, 'Google', '', '37,40', '', '', 1, '', '2024-05-13 10:13:20', 38, 'y'),
(32, 'Nokia', '', '37,39,40,41,42', '', '', 2, '', '2024-05-13 10:30:18', 38, 'y'),
(33, 'Microsoft', 'images/uploads/GroupProfile/1715580952023_unnamed.jpg', '37', '', '', 1, '', '2024-05-13 11:45:52', 38, 'y'),
(34, '14-5-24', 'images/uploads/GroupProfile/1715666290041_profile avatar-picture.png', '37', '', '', 1, '', '2024-05-14 11:28:10', 42, 'd'),
(38, 'Comet', 'images/uploads/GroupProfile/1716363142821_comet-wallpaper.jpeg', '37', '', '', 0, '', '2024-05-22 10:02:05', 42, 'y'),
(39, 'MSN', '', '37', '', '', 2, '', '2024-05-22 10:02:53', 42, 'y'),
(40, 'aaa', 'images/uploads/GroupProfile/1716529849403_1715678932318_comet-wallpaper.jpeg', '37,38,44', '', 'aaa', 0, '', '2024-05-24 11:19:46', 42, 'y'),
(45, 'Stock Exchange', '', '37,38,39', '', '', 3, '', '2024-05-24 11:53:17', 42, 'y'),
(46, '25', '', '37', '', '', 1, '', '2024-05-24 16:04:54', 44, 'd'),
(47, 'dasasf', '', '37', '', '', 2, '', '2024-05-24 16:05:07', 44, 'd'),
(48, 'MERA GROUP', '', '41,42,43', '41,42,43,37,38,39,40,45,46,48,50,49,51,52,53,54,55,60,61,62,63,64,65,68,69,71,73,75,76,77,81,82,83,85,92,87,90,91,86,96,97,98,99,102,103,104,101,100,105,106,107,108,109,110', 'Hello', 4, '', '2024-05-24 17:18:25', 44, 'y'),
(49, 'New Group', 'images/uploads/GroupProfile/1716553042086_comet-wallpaper.jpeg', '37,39,40', '', 'fsdfdsfdsfdfsdffsfsdfdfddd', 0, '', '2024-05-24 17:40:29', 38, 'y'),
(50, 'MNC', '', '39', '', 'Test message for this group ', 3, '', '2024-05-29 10:03:33', 38, 'd'),
(51, 'MD Test - 01', '', '37,38,42,44,45,46,49', '', 'Finix App Test', 2, '', '2024-05-29 11:50:14', 43, 'y'),
(52, 'dhiren test all ', '', '38,43,40', '', 'dhiren test all ', 3, '', '2024-05-29 11:54:26', 37, 'y'),
(53, 'dhiren test i to 1', '', '43', '', 'dhiren test i to 1', 1, '', '2024-05-29 11:55:04', 37, 'y'),
(54, 'new new', '', '38,43,44', '', 'new new', 4, '', '2024-05-29 15:44:43', 37, 'y'),
(55, 'OK', 'images/uploads/GroupProfile/1717053766943_1713783483463_Screenshot 2023-12-21 190358.png', '40,41', '', 'OK', 2, '', '2024-05-30 12:52:00', 44, 'd'),
(56, 'abc234', '', '38', '', 'Wikis are enabled by wiki software, otherwise known as wiki engines. A wiki engine, being a form of a content management system, differs from other web-based systems such as blog software or static site generators, in that the content is created without any defined owner or leader, and wikis have little inherent structure...', 4, '', '2024-06-03 14:54:37', 37, 'y'),
(57, 'new 1 group', '', '38,43', '', 'yes no', 4, '', '2024-06-04 11:07:24', 37, 'y'),
(63, 'Furiosa', '', '39,44,48', '', '', 2, '', '2024-06-04 12:25:27', 38, 'y'),
(64, 'MD-02', '', '37,38,39,40,45,46', '', 'Need to create new group for test between Groups and Chats...\n', 2, '', '2024-06-05 08:53:03', 43, 'y'),
(65, 'yes no', '', '38,43', '', 'hmmm', 3, '', '2024-06-05 15:08:57', 37, 'y'),
(66, 'TESTDDD', '', '37,38', '', 'SDSGDFHSDFHSDFD', 2, '', '2024-06-05 17:38:15', 40, 'y'),
(69, 'Rango', '', '44', '', 'Test Description', 3, '', '2024-06-06 11:12:33', 38, 'y'),
(70, 'a-c', '', '51', '', '', 4, '', '2024-06-07 15:57:04', 49, 'd'),
(71, 'c-a', '', '50', '', '', 3, '', '2024-06-07 15:58:55', 49, 'y'),
(72, 'b-c', '', '37,51', '', '', 2, '', '2024-06-07 16:12:19', 50, 'y'),
(73, 'D-A', '', '37,40,41,42,49,38', '', 'adkadakas\n', 3, '', '2024-06-08 09:06:43', 52, 'y'),
(74, 'Hunter', '', '39', '', 'Test Group Detail.', 2, '', '2024-06-08 09:18:58', 38, 'y'),
(75, 'cg-KV-a', '', '38,49', '', '', 1, '', '2024-06-08 12:17:57', 37, 'd'),
(76, 'Group Testing', '', '49,52', '', 'Group Testing\nGroup Testing', 2, '', '2024-06-08 12:27:09', 51, 'y'),
(77, 'GT', '', '49,52', '', 'jkjkl', 3, '', '2024-06-08 12:31:23', 51, 'y'),
(78, 'del grp', '', '49,51', '', '54654', 3, '', '2024-06-08 12:58:54', 52, 'y'),
(79, 'Victor', '', '39,48', '', 'Test Group', 2, '', '2024-06-08 15:19:51', 38, 'y'),
(80, 'A-F', '', '50,51,52,54,53', '', 'kjlsvbjxklv', 3, '', '2024-06-08 16:35:25', 49, 'y'),
(81, 'New Group - 10-06-2024', '', '56,58', '', '10-06-2024\n', 3, '', '2024-06-10 12:15:49', 57, 'y'),
(82, 'Group Testing-10-06-2024', '', '59,58,60,56,46,43,40,37', '', 'Group TestingGroup Testing\nGroup Testing', 1, '', '2024-06-10 12:27:28', 57, 'd'),
(83, 'll-mm', '', '68,56,57', '', '', 4, '', '2024-06-10 15:17:38', 67, 'd'),
(90, 'Furiosa', '', '38', '', 'Furiosa', 1, '', '2024-06-11 08:49:31', 48, 'y'),
(91, 'Balaji Industries', '', '48', '', 'Balaji Industries', 1, '', '2024-06-11 11:04:19', 38, 'd'),
(92, 'CDF', '', '37,38,43,45,56,57,59', '', 'Check Delete Functionalities', 1, '', '2024-06-11 16:27:21', 58, 'd'),
(93, 'CDF', '', '37,38,43,45,57,58,59,60,61', '', 'Check Delete Funtionality', 3, '', '2024-06-11 17:08:51', 56, 'y'),
(94, 'AABBCC', '', '37,38,43,57,58,67,68', '', 'Group Testing', 2, '', '2024-06-12 09:52:18', 56, 'y'),
(95, 'Delete Group', '', '37,38,39,40,57,58', '', 'Delete Group funtionality', 1, '', '2024-06-12 10:04:49', 56, 'd'),
(96, 'II-LL(a)-MM', '', '68,64', '', '', 2, '', '2024-06-12 12:26:13', 67, 'd'),
(97, 'II-LL(a)-mm', '', '64,68', '', '', 4, '', '2024-06-12 12:27:21', 67, 'y'),
(98, 'Group By BB', '', '56,58', '', 'asdsadasasd', 4, '', '2024-06-12 12:57:32', 57, 'y'),
(99, 'KV1-KV2-KV3', '', '70', '', '', 2, '', '2024-06-12 15:32:50', 69, 'd'),
(100, 'IJK-Group', '', '64,65', '', 'Group Utility Testing', 3, '', '2024-06-12 17:07:49', 66, 'y'),
(101, 'KV3-KV1', '', '', '', '', 2, '', '2024-06-13 08:52:47', 69, 'd'),
(102, 'ABC-XYZ', '', '39,42,44,45,77,82,84', '', 'Check Duplication for Group Name....', 2, '', '2024-06-13 10:26:58', 65, 'y'),
(103, 'ABC-XYZ', '', '37,38,39,107', '', 'Duplication Check', 4, '', '2024-06-13 10:30:27', 84, 'y'),
(104, 'ABC-XYZ', '', '37,38,39,84,46', '', 'jfkjfksjklsd', 3, '', '2024-06-13 10:43:26', 82, 'y'),
(105, 'Evan & Dustin', '', '', 'undefined', 'Evan & Dustin', 4, '', '2024-06-13 11:35:51', 86, 'y'),
(106, 'ABC-BBC', '', '41,43,44,46,107', '', 'afjaf', 2, '', '2024-06-13 17:23:15', 82, 'y'),
(107, 'Group Image', '', '38,46,37,44', '', 'Testing Group Image Shape', 2, '', '2024-06-14 09:48:09', 43, 'y'),
(108, 'ABC', '', '37', '', '', 4, '', '2024-06-14 11:47:15', 94, 'y'),
(109, 'MM-KK', '', '43,46,63,66', '', 'test group', 2, '', '2024-06-14 14:54:20', 68, 'y'),
(110, 'Group - 14-06-2024', '', '68,66,82', '', '4444\n', 3, '', '2024-06-14 16:02:28', 96, 'y'),
(111, 'Safari', '', '38', '', 'dasdsadsa', 4, '', '2024-06-15 15:12:59', 94, 'y'),
(112, 'new new one', '', '96,38', '38', '', 1, '', '2024-06-15 16:06:17', 104, 'y'),
(113, 'testtttttttttttt', '', '37', '', '', 1, '', '2024-06-19 18:02:13', 104, 'y'),
(114, 'da grp', '', '', '', '', 2, '', '2024-06-20 11:29:17', 104, 'y'),
(115, 'KV2-KV1', '', '', '', '', 2, '', '2024-06-20 16:44:01', 69, 'y'),
(116, 'KV4-KV1', '', '69', '', '', 1, '', '2024-06-21 09:04:15', 81, 'd'),
(117, 'KV4-KV1', '', '69', '', '', 3, '', '2024-06-21 09:16:27', 81, 'd'),
(118, 'KV4-KV1', '', '69', '', '', 2, '', '2024-06-21 09:50:53', 81, 'd'),
(119, 'KV4-KV1', '', '69', '', '', 3, '', '2024-06-21 09:51:56', 81, 'd'),
(120, 'KV4-KV1', '', '69', '', '', 1, '', '2024-06-21 09:53:01', 81, 'd'),
(121, 'KV4-KV1', '', '69', '', '', 3, '', '2024-06-21 09:54:12', 81, 'd'),
(122, 'KV4-KV1', '', '69', '', '', 4, '', '2024-06-21 09:55:38', 81, 'd'),
(123, 'KV4-KV1', '', '', '69', '', 3, '', '2024-06-21 10:31:24', 81, 'd'),
(124, 'del-grp', '', '', '109', '', 0, '', '2024-06-21 12:36:25', 110, 'd'),
(125, 'dhiren adesara - del admin', '', '', '', '', 2, '', '2024-06-21 14:57:21', 110, 'd'),
(126, 'KV4-KV1', '', '', '69', '', 2, '', '2024-06-21 16:15:02', 81, 'd'),
(127, 'KV4-KV3-KV1', '', '69', '69,71', '', 4, '', '2024-06-21 16:16:27', 81, 'd'),
(128, 'KV4-KV3-KV1', '', '69', '69,71', '', 3, '', '2024-06-21 16:22:57', 81, 'd'),
(129, 'KV4-KV3-KV1', '', '69', '71,69', '', 3, '', '2024-06-21 16:26:26', 81, 'd'),
(130, 'KV4-KV3-KV1', '', '', '69,71', '', 4, '', '2024-06-21 16:31:08', 81, 'd'),
(131, 'KV4-KV3-KV1', '', '69', '69,71', '', 3, '', '2024-06-21 16:45:08', 81, 'd'),
(132, 'KV4-KV3-KV1', '', '69', '69,71', '', 1, '', '2024-06-21 17:12:41', 81, 'd'),
(133, 'KV4-KV3-KV1', '', '69,71', '69,71', '', 1, '', '2024-06-21 17:18:38', 81, 'd'),
(134, 'KV4-KV3-KV1', '', '69', '69,71', '', 3, '', '2024-06-22 10:07:59', 81, 'd'),
(135, 'KV1-KV3-KV4', '', '81,71', '71,81', '', 4, '', '2024-06-22 10:26:24', 69, 'd'),
(136, 'KV1-KV4-KV3', '', '81', '38,71', '', 1, '', '2024-06-22 10:34:34', 69, 'd'),
(137, 'Chat Application Test', '', '109', '38,37,46,75,71,69,104', 'Group Request functionality testing', 4, '', '2024-06-22 11:13:00', 96, 'y'),
(138, '22-6-24', '', '', '', 'asdfg', 3, '', '2024-06-22 16:05:19', 110, 'd'),
(139, 'KV1-KV3-KV4', '', '', '81,71', '', 1, '', '2024-06-24 08:59:30', 69, 'd'),
(140, 'KV1-KV3-KV4', '', '', '71,81', '', 1, '', '2024-06-24 09:08:48', 69, 'd'),
(141, 'KV1-KV3-KV4', '', '', '71,81', '', 3, '', '2024-06-24 09:13:24', 69, 'd'),
(142, 'KV1-KV3-KV4', '', '', '71,81', '', 1, '', '2024-06-24 09:15:54', 69, 'd'),
(143, 'KV1-KV3-KV4', '', '', '71,81', '', 2, '', '2024-06-24 09:19:00', 69, 'd'),
(144, 'KV1-KV3-KV4', '', '', '71,81', '', 4, '', '2024-06-24 09:25:37', 69, 'd'),
(145, 'KV1-KV3-KV4', '', '', '71,81', '', 3, '', '2024-06-24 09:28:00', 69, 'd'),
(146, 'KV1-KV3-KV4', '', '', '', '', 1, '', '2024-06-24 09:29:51', 71, 'd'),
(147, 'KV1-KV3-KV4', '', '', '', '', 3, '', '2024-06-24 09:54:18', 69, 'd'),
(148, 'KV1-KV3-KV4', '', '', '', '', 3, '', '2024-06-24 11:01:04', 69, 'd'),
(153, 'M-KV1-KV3', '', '69', 'undefined', '', 2, '', '2024-06-24 15:03:01', 81, 'y'),
(154, 'M-KV1-KV4', '', '69', 'undefined', '', 3, '', '2024-06-24 15:31:07', 81, 'y'),
(155, 'My Space', '', '', '', '', 3, '', '2024-06-24 16:05:12', 69, 'd'),
(156, 'My Space 2', '', '', '', '', 4, '', '2024-06-24 16:09:57', 69, 'd'),
(157, 'My Space', '', '', '', '', 2, '', '2024-06-24 16:11:40', 69, 'd'),
(158, 'My Space', '', '', '', '', 1, '', '2024-06-24 16:12:42', 69, 'd'),
(159, 'My Space', '', '', '', '', 2, '', '2024-06-24 16:13:23', 69, 'y'),
(160, '24-06-24', '', '', '109,104', '', 2, '', '2024-06-24 16:23:55', 110, 'd'),
(161, 'KV1-KV4', '', '81', '', '', 4, '', '2024-06-24 16:33:43', 69, 'y'),
(162, 'New Delete Profile Group', '', '', 'undefined', '', 2, '', '2024-06-24 16:45:48', 113, 'd'),
(163, 'My Space', '', '', '', '', 2, '', '2024-06-25 12:21:14', 116, 'y'),
(164, 'my space', '', '', '', '', 4, '', '2024-06-25 15:37:58', 109, 'y'),
(165, 'no accept request', '', '', '104', '', 1, '', '2024-06-25 15:39:07', 109, 'y'),
(166, 'Live Indecation Test', '', '116', '69', '', 3, '', '2024-06-25 16:15:08', 81, 'y'),
(167, 'Request don\'t Accept (MD)', '', '', '84,104,109,110', 'Don\'t Accept Request', 4, '', '2024-06-25 16:17:36', 96, 'y'),
(168, 'accept req', '', '104,109', 'undefined', '', 2, '', '2024-06-25 16:18:29', 96, 'y'),
(169, 'only accept by Dhiren P. Adesara', '', '', 'undefined', 'only accept by Dhiren P. Adesara', 4, '', '2024-06-25 16:19:28', 96, 'y'),
(170, 'MD Space', '', '109,104', '82,84', 'Greeting message only for me...', 4, '', '2024-06-25 16:22:29', 96, 'y'),
(171, 'Horizon', '', '118', '110,96', '', 3, '', '2024-06-25 16:29:48', 106, 'y'),
(172, 'Admin Left Group', '', '109', '104,82,84', 'Next member will be admin, check rights for new admin....', 4, '', '2024-06-25 16:30:10', 96, 'y'),
(173, 'Despicable', 'images/uploads/GroupProfile/1719313958461_i100minions.avif', '106,96', '110', 'Minions', 3, '', '2024-06-25 16:36:04', 118, 'y'),
(174, 'One Member(ABC) Accept Request', '', '82', '104,109,84,110', 'If only member accept the request then that member become admin... ', 3, '', '2024-06-25 16:36:34', 96, 'y'),
(175, '123', '', '', '', '????', 1, '', '2024-06-25 16:52:03', 104, 'd'),
(176, 'My Space 1', '', '', '', '', 1, '', '2024-06-25 16:56:18', 116, 'y'),
(177, 'Don\'t Accept Request - XYZ', '', '', '82,96', 'Check tomorrow ', 1, '', '2024-06-25 16:58:22', 84, 'y'),
(178, 'New Test', '', '109', '69,81', '', 2, '', '2024-06-25 17:08:46', 116, 'y'),
(179, 'all accept', '', '104,96', '82,84', '', 2, '', '2024-06-25 17:40:09', 109, 'y'),
(180, 'mdaccept-xyzdecline-abc,pending', '', '', '96', 'md - accept  xyz-decline abc- pending\nda-del-accept dhiren adesara-decline, vv cancel by admin', 2, '', '2024-06-25 17:43:50', 109, 'y'),
(181, 'kv grp', '', '', '69,81', '', 1, '', '2024-06-25 18:05:45', 110, 'd'),
(182, 'One Member Accept Request', '', '123,122', 'undefined', 'Admin Left', 4, '', '2024-06-26 09:17:41', 120, 'y'),
(183, 'Delete Group', '', '123,122,121', '', 'After communication with group members group deleted by group admin.', 1, '', '2024-06-26 10:21:10', 120, 'd'),
(184, 'Task Group', '', '121', '', '', 4, '131', '2024-06-26 10:23:15', 130, 'd'),
(185, 'Admin Left', '', '123,122,121', 'undefined', 'All Members are accepted request.\nAdmin Left the group.\nVery next member become Admin. Working.', 2, '', '2024-06-26 10:36:19', 120, 'y'),
(186, 'Don\'t Accept Request Today', '', '123,121', '122', 'Accept Request tomorrow.', 2, '', '2024-06-26 10:53:49', 120, 'y'),
(187, 'bar del', '', '', '125', '', 4, '', '2024-06-26 12:17:35', 110, 'd'),
(188, 'test real time', '', '109', 'undefined', '', 1, '', '2024-06-26 13:06:49', 104, 'y'),
(189, '1-1 grp', '', '', '', '', 4, '', '2024-06-26 13:14:39', 109, 'y'),
(190, '3mem', '', '109', '', '', 1, '', '2024-06-26 13:15:50', 104, 'y'),
(191, 'Real Time Message', '', '', '121,123,96', 'Group testing for real time messages...', 4, '', '2024-06-26 14:32:34', 120, 'y'),
(192, 'ad-ad', '', '109', '69', '', 2, '', '2024-06-26 15:12:32', 96, 'y'),
(193, 'Multiple delete - Admin', '', '123', '', '', 2, ',109', '2024-06-26 15:24:56', 96, 'y'),
(194, 'A Grp by Arya', '', '120,121', '', '', 1, '', '2024-06-26 15:39:32', 104, 'y'),
(195, 'chat test by Aditya', '', '104,109,132,96,123', '125,130', '', 2, '', '2024-06-26 15:46:31', 133, 'y'),
(196, 'My New Group', '', '', '130', '', 3, 'undefined', '2024-06-26 16:19:02', 131, 'd'),
(197, 'me only', '', '', '', '', 3, '', '2024-06-27 12:45:49', 109, 'd'),
(198, 'Larry + Nicholas', '', '', '130', '', 4, '', '2024-06-27 16:21:34', 131, 'd'),
(199, 'Larry + Nicholas', '', '', '138', '', 4, '131,134,135,81,138,139,69', '2024-06-27 16:23:39', 140, 'y'),
(200, 'test admin', '', '', '', '', 4, '109,69,132,133,104', '2024-06-27 17:41:31', 81, 'y');

-- --------------------------------------------------------

--
-- Table structure for table `chat_users`
--

CREATE TABLE `chat_users` (
  `iUserId` int(11) NOT NULL,
  `iEngId` varchar(255) NOT NULL,
  `vUsername` varchar(255) NOT NULL,
  `vFullName` varchar(255) NOT NULL,
  `vPassword` varchar(255) NOT NULL,
  `vProfilePic` varchar(255) NOT NULL,
  `vEmail` varchar(255) NOT NULL,
  `tToken` text NOT NULL,
  `vChatId` varchar(255) NOT NULL,
  `eCustStatus` enum('0','1','2') NOT NULL DEFAULT '2' COMMENT '0=Offline 1=Online 2=Automatic',
  `iColorOption` int(11) NOT NULL,
  `tGroupIds` text NOT NULL,
  `iStatus` int(11) NOT NULL COMMENT '	0=Offline 1=Online',
  `dLoginDateTime` datetime NOT NULL,
  `iEmailVerified` int(11) NOT NULL,
  `vOtp` varchar(50) NOT NULL,
  `eStatus` enum('y','n','d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_users`
--

INSERT INTO `chat_users` (`iUserId`, `iEngId`, `vUsername`, `vFullName`, `vPassword`, `vProfilePic`, `vEmail`, `tToken`, `vChatId`, `eCustStatus`, `iColorOption`, `tGroupIds`, `iStatus`, `dLoginDateTime`, `iEmailVerified`, `vOtp`, `eStatus`) VALUES
(37, '6286', 'abc', 'Chetan Ghadiya', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDaGV0YW4gR2hhZGl5YSIsInZGdWxsTmFtZSI6IkNoZXRhbiBHaGFkaXlhIiwiTG9naW5UaW1lIjoxMDMwODA3MjI2NDAsImlhdCI6MTcxODAxMjA0NH0.QbC5EmlhLYcgyPVCQMH3PaIDljtIBmqg0PL0fNF0ZwQ', 'BdcSLZjDPcSLQFLNAAAd', '1', 2, '15,18,20,23,24,25,26,27,29,30,31,32,33,34,38,39,40,45,46,47,49,51,64,66,72,73,82,85,92,93,94,95,103,104,107,108,112,113,125,48,137', 0, '2024-06-10 15:04:04', 0, '', 'y'),
(38, '6288', 'Kishan', 'Kishan Vaghera', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/uploads/profiles/1716611907390_comet-wallpaper.jpeg', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLaXNoYW4iLCJ2RnVsbE5hbWUiOiJLaXNoYW4gVmFnaGVyYSIsIkxvZ2luVGltZSI6MTAzMTMyMDM1ODQwLCJpYXQiOjE3MTg4NjcyNjR9.hwHT9q81qWhHDIeXTZ0v2YPLSxxIcdeJZVtQ2-9FKIA', '7kzhPd-nWVsz-_yvAABx', '1', 0, '52,54,56,57,65,73,75,84,90,92,93,94,95,103,104,107,111,112,125,48,137,136', 0, '2024-06-20 12:37:44', 1, '', 'y'),
(39, '6285', 'cnp', 'cnp', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJjbnAiLCJ2RnVsbE5hbWUiOiJjbnAiLCJMb2dpblRpbWUiOjEwMzA2OTMxMDE2MCwiaWF0IjoxNzE3ODIxODM2fQ.FRc9KBnBUd1qOzyDZ0LTUGzqwMqxRrPVViD3jDQgZ5I', 'dTmq8h6Dw_MRCRqnAABV', '2', 1, '50,63,74\n,79,95,102,103,104,48', 0, '2024-06-08 10:13:56', 0, '', 'y'),
(40, '6284', 'Vinayak Vekariya', 'Vinayak Vekariya', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJzZHNhZCIsInZGdWxsTmFtZSI6IlZpbmF5YWsgVmVrYXJpeWEiLCJMb2dpblRpbWUiOjEwMzA5MTI2MjkwMCwiaWF0IjoxNzE4MTg3NzE1fQ.xszbERd-_yw14lCK96UWGl1u73KcBF2Zo6b5c1QO2eA', '9J7X_GCEEg1eC6LhAAHd', '0', 3, '16,55,82,95,48', 0, '2024-06-12 15:51:55', 0, '', 'y'),
(41, '6287', 'Brijesh Doshi', 'Brijesh Doshi', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/uploads/profiles/1717588404833_istockphoto-528415533-612x612.jpg', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCcmlqZXNoIERvc2hpIiwidkZ1bGxOYW1lIjoiQnJpamVzaCBEb3NoaSIsIkxvZ2luVGltZSI6MTAzMDU1MzAxNjAwLCJpYXQiOjE3MTc1ODgzNjB9.Lvq-62CgzDYdv0F25fD32DDY3qy-zgOh71wrMbEer5M', '7q2GnP4vAjnOzb-lAAFH', '0', 0, '17,28,48,73,106', 0, '2024-06-05 17:22:40', 0, '', 'y'),
(42, '2154', 'FINIX FINIX', 'FINIX FINIX', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJGSU5JWCBGSU5JWCIsInZGdWxsTmFtZSI6IkZJTklYIEZJTklYIiwiTG9naW5UaW1lIjoxMDMwOTY0NDg0NjAsImlhdCI6MTcxODI3NDE0MX0.DjPDSVo3wbfqjGUq4bFRd8iGh3Z2EqxxT_njqMNoeGw', '5b7MiNjFK57xVtF-AAMt', '2', 3, ',102,48', 0, '2024-06-13 15:52:21', 0, '', 'y'),
(43, '6290', 'Meghdip Doshi', 'Meghdip Doshi', '192b5ad8f883586df72f80588edf211b1308d2c4', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNZWdoZGlwIERvc2hpIiwidkZ1bGxOYW1lIjoiTWVnaGRpcCBEb3NoaSIsIkxvZ2luVGltZSI6MTAzMTA1MzMxMDQwLCJpYXQiOjE3MTg0MjIxODR9.x1MuMghV1YByK9Zjo4vo_hdhcjpjPiXU1qmAfAyR8tA', 'R6isovCBDGhxgDnrAAAI', '1', 1, '19,22,53,82,92,93,94,106,109,48,200', 0, '2024-06-15 08:59:44', 0, '', 'y'),
(44, '6291', ' Deep Javiya', 'Deep Javiya', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/uploads/profiles/1717669955220_3f6f818d-03a1-463f-b944-cc3ce52aca6c.jpg', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEZWVwIiwidkZ1bGxOYW1lIjoiRGVlcCBKYXZpeWEiLCJMb2dpblRpbWUiOjEwMzA5NTA1NDE4MCwiaWF0IjoxNzE4MjUwOTAzfQ.cT-GRDklMkLIQZZ131JSQuXVxN066GGclFfa0j5Ghe4', 'KIFq_8YEZdVYiR7aAACc', '2', 0, '21,69\n,63,79,102,106,107', 0, '2024-06-13 09:25:03', 0, '', 'y'),
(45, '5385', 'cp', 'cp', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTM4NSIsInZVc2VybmFtZSI6ImNwIiwidkZ1bGxOYW1lIjoiY3AiLCJMb2dpblRpbWUiOjEwMjk5ODIxNTE0MCwiaWF0IjoxNzE2NjM2OTE5fQ.MKm-TqozvhN0WyIBfVVw3e8umB3vfxjsbymYWCjVyjo', 'tVQOoSwsrqd1nTRHAABR', '2', 0, ',92,93,102,48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(46, '6000', 'KC Gohel', 'KC Gohel', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLQyBHb2hlbCIsInZGdWxsTmFtZSI6IktDIEdvaGVsIiwiTG9naW5UaW1lIjoxMDMwOTY2NDAwNDAsImlhdCI6MTcxODI3NzMzNH0.xIOC_MhDZC3rfwybwFFhVEX3lortLRYX2fxMtbmogJI', 'fmSr3UgQ4bhw8xa4AAAR', '2', 1, ',82,104,106,107,109,48,137', 0, '2024-06-13 16:45:34', 1, '', 'y'),
(48, '6700', 'Jacob', 'Jacob', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKYWNvYiIsInZGdWxsTmFtZSI6IkphY29iIiwiTG9naW5UaW1lIjoxMDMxNDI5MDA5NDAsImlhdCI6MTcxOTA0ODM0OX0.kigCMpRmJA4a38ppXmVny8HmZO0BPCUQAG6hcbXXybw', 'TaW9mFD3ENn9H8fpAAAx', '1', 2, ',63,79,86,87,88,89,91,48,136', 0, '2024-06-22 14:55:49', 1, '', 'y'),
(49, '6001', 'f', 'A', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJmIiwidkZ1bGxOYW1lIjoiQSIsIkxvZ2luVGltZSI6MTAzMTAxMzcxMjgwLCJpYXQiOjE3MTgzNTYxODh9.Na2f3xPYNcs4HGoSeiL2C-oymmxFOt9PF02Ma8IlvjQ', 'g2NWGzcdKD3oxd5VAABb', '1', 1, ',73,75,51,76,77,78,48', 0, '2024-06-14 14:39:48', 0, '', 'y'),
(50, '6002', 'b', 'B', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCIiwidkZ1bGxOYW1lIjoiQiIsIkxvZ2luVGltZSI6MTAzMDY1NDA5MDgwLCJpYXQiOjE3MTc3NTY4MTh9.Poa-Bq4EfJqDmu7k14cVSzCeOwpfOf90DZJNpXr30A0', 'zufCX433tNgQzisPAAMw', '2', 1, '71,80,48', 0, '2024-06-07 16:10:18', 0, '', 'y'),
(51, '6003', 'C', 'C', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDIiwidkZ1bGxOYW1lIjoiQyIsIkxvZ2luVGltZSI6MTAzMDY5Nzc5MDAwLCJpYXQiOjE3MTc4Mjk2NTB9.fAX1YU_1WNq4Vab3sjfABClphxlIYQjfR5-mIUmMvMM', 'fdMA1UrKF2gPiiC2AAAp', '2', 1, '70,78,80,48', 0, '2024-06-08 12:24:10', 0, '', 'y'),
(52, '6004', 'd', 'D', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEIiwidkZ1bGxOYW1lIjoiRCIsIkxvZ2luVGltZSI6MTAzMDcwNTA2NDQwLCJpYXQiOjE3MTc4NDE3NzR9.9K5UUzVy1bz_tNLKufXOqjOmd1lLGAT6J9ZpcIz41rk', '12J79jr42a0DPgJIAADp', '1', 2, ',77,76,80,48', 0, '2024-06-08 15:46:14', 0, '', 'y'),
(53, '6005', 'E', 'E', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJFIiwidkZ1bGxOYW1lIjoiRSIsIkxvZ2luVGltZSI6MTAzMDgwMTUxMDIwLCJpYXQiOjE3MTgwMDI1MTd9.ouvjkyxzpW1xQ-yO0_AmwVbRy4mEkvd_3BTUXxIj6KY', 'fGmMuCEZXyjltmpFAAAx', '2', 1, ',80,48', 0, '2024-06-10 12:25:17', 0, '', 'y'),
(54, '6006', 'F', 'F', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', '', '', '2', 1, ',80,48', 0, '2024-06-07 14:36:04', 0, '', 'y'),
(55, '48', 'Jamson', 'Jamson', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNDgiLCJ2VXNlcm5hbWUiOiJKYW1zb24iLCJ2RnVsbE5hbWUiOiJKYW1zb24iLCJMb2dpblRpbWUiOjEwMzA2OTA1NTQwMCwiaWF0IjoxNzE3ODE3NTkwfQ.P29FUVkKeMgoIoVUj0sqJUHHXTJPJsXyJ-cxz0zAUJk', '7kGLr7MWvY0LoT1yAAAd', '0', 0, ',48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(56, '6007', 'AA', 'AA', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBQSIsInZGdWxsTmFtZSI6IkFBIiwiTG9naW5UaW1lIjoxMDMwOTA5NTI1MjAsImlhdCI6MTcxODE4MjU0Mn0.3yxR8eschuX2Bg3zdAsUNV3QdFk4d3IqymgEqnLipmE', 'yCViRjIOW62eUVfzAAGV', '1', 3, ',81,82,83,92,98', 0, '2024-06-12 14:25:42', 0, '', 'y'),
(57, '6008', 'BB', 'BB', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCQiIsInZGdWxsTmFtZSI6IkJCIiwiTG9naW5UaW1lIjoxMDMwOTA5NjE1ODAsImlhdCI6MTcxODE4MjY5M30.vCPvzZpUsv0pZX3vo5gf9S_30KBFyiE8kzpUBQqoYSc', 'r_ldzMHfT4dpUaQEAAGz', '1', 2, ',83,92,93,94,95', 0, '2024-06-12 14:28:13', 0, '', 'y'),
(58, '6009', 'CC', 'CC', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiIgIiwidkZ1bGxOYW1lIjoiQ0MiLCJMb2dpblRpbWUiOjEwMzA5MDk2NDQ2MCwiaWF0IjoxNzE4MTgyNzQxfQ.Xo93pNxAUnKkoTjrnFiCaH5oSr7JLtcaywIuQn_JleI', 'UCT1fRnLnzp7UGHjAAFM', '1', 1, ',81,82,93,94,95,98', 0, '2024-06-12 14:29:01', 0, '', 'y'),
(59, '6010', 'DD', 'DD', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJERCIsInZGdWxsTmFtZSI6IkREIiwiTG9naW5UaW1lIjoxMDMwOTAxNjk0NjAsImlhdCI6MTcxODE2OTQ5MX0.fXxFEG5bhcLy1fVAjT0I9-vEpX-ZfpDG5QBm2ZyRu3s', '65981-U2MJryX6LJAACq', '2', 1, ',82,92,93', 0, '2024-06-12 10:48:11', 0, '', 'y'),
(60, '6011', 'EE', 'EE', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', '', '', '2', 1, ',82,92,93,109,48', 0, '2024-06-07 14:36:04', 0, '', 'y'),
(61, '6012', 'ff', 'FF', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJGRiIsInZGdWxsTmFtZSI6IkZGIiwiTG9naW5UaW1lIjoxMDMwOTE0MDEzMjAsImlhdCI6MTcxODE5MDAyMn0._KJzlnuw7QfXHgIe_uWKPNwylfffRmTPHxFNhmZle7w', 'BIdIlIsgbcmaweWDAAJA', '2', 1, ',93,109,48', 0, '2024-06-12 16:30:22', 0, '', 'y'),
(62, '6013', 'GG', 'GG', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', '', '', '2', 1, ',109,48', 0, '2024-06-07 14:36:04', 0, '', 'y'),
(63, '6014', 'dszafs', 'HH', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJISCIsInZGdWxsTmFtZSI6IkhIIiwiTG9naW5UaW1lIjoxMDMwOTEzOTA1ODAsImlhdCI6MTcxODE4OTg0M30.e8ChfuxyQQaiO8qc3MmnqNpBXQQwZQe0qqGq6pz5udI', 'o6MmyYvd2u7I6rVRAAI6', '2', 1, ',109,48', 0, '2024-06-12 16:27:23', 0, '', 'y'),
(64, '6015', 'II', 'II', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJJSSIsInZGdWxsTmFtZSI6IklJIiwiTG9naW5UaW1lIjoxMDMxMDU3MTc3NDAsImlhdCI6MTcxODQyODYyOX0.V878WD9mtrKLSdeee7FRx6vuE8Deou3Go7jPJ7gziFM', 'iIVvjxba2wMDpJ5gAAAM', '2', 1, ',94,96,97,100,109,48', 0, '2024-06-15 10:47:09', 1, '', 'y'),
(65, '6016', 'JJ', 'JJ', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKSiIsInZGdWxsTmFtZSI6IkpKIiwiTG9naW5UaW1lIjoxMDMxMDY1NDcwNjAsImlhdCI6MTcxODQ0MjQ1MX0.CDtySf5dlM_NLDJWp77wlrcaXvwniDzcccLKRA1JLAQ', 'ZDZkxVyc6qt0x2kmAAAS', '2', 1, ',100,109,48', 0, '2024-06-15 14:37:31', 1, '', 'y'),
(66, '6017', 'II', 'KK', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJJSSIsInZGdWxsTmFtZSI6IktLIiwiTG9naW5UaW1lIjoxMDMxMDU0MjU0ODAsImlhdCI6MTcxODQyMzc1OH0.0ykwdbkDT4ywKHLpIUfsf3CA5T3MHCukWEqnrDCz62E', 'e2zWxrZxAvQJwkNsAAAM', '2', 1, ',109,110', 0, '2024-06-15 09:25:58', 0, '', 'y'),
(67, '6018', 'l', 'LL', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJsIiwidkZ1bGxOYW1lIjoiTEwiLCJMb2dpblRpbWUiOjEwMzEwMTc3MjYyMCwiaWF0IjoxNzE4MzYyODc3fQ.lWtM62xeQ9GpJ2iWKBIdPIclSROx8NTsQ4asKMT-JUI', 'aCAcS0ywKAQxGXG6AACH', '2', 1, ',94,109', 0, '2024-06-14 16:31:17', 0, '', 'y'),
(68, '6019', 'JJ', 'MM', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKSiIsInZGdWxsTmFtZSI6Ik1NIiwiTG9naW5UaW1lIjoxMDMxMDE3NzA0NjAsImlhdCI6MTcxODM2Mjg0MX0.Iv6MLGWKrVppl-MySoCAWC-VnB_MNQayDm3MT9nyeB4', 'H9lX8K1lTonyu-FUAAB5', '2', 1, ',83,94,96,97,110,48', 0, '2024-06-14 16:30:41', 0, '', 'y'),
(69, '6020', 'KV1', 'KV1', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjEiLCJ2RnVsbE5hbWUiOiJLVjEiLCJMb2dpblRpbWUiOjEwMzE2OTQ2NDI2MCwiaWF0IjoxNzE5NDkxMDcxfQ.vPQZRW9VLKQt6vQvRmW6xJMObfg-AR-_lIQI_ddYaHY', 'iumcbYAyKqpSnY34AABD', '2', 1, ',101,115,116,117,118,119,120,121,122,123,126,127,128,129,130,131,132,133,48,134,137,146,149,150,151,152,153,154,162,166,178,181,176,192,199,199,200,200', 0, '2024-06-27 17:54:31', 1, '', 'y'),
(70, '6021', 'KV2', 'KV2', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjIiLCJ2RnVsbE5hbWUiOiJLVjIiLCJMb2dpblRpbWUiOjEwMzEzMjQ4NTcyMCwiaWF0IjoxNzE4ODc0NzYyfQ.H3WcVs6jtR7UwUUlLxmBp4vGRpOcNuF71d4sYada4es', 'ruPdCXEXDbPKmTGDAAAf', '2', 1, ',99', 0, '2024-06-20 14:42:42', 1, '', 'd'),
(71, '6022', 'KV3', 'KV3', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjMiLCJ2RnVsbE5hbWUiOiJLVjMiLCJMb2dpblRpbWUiOjEwMzE1MzA1NTE2MCwiaWF0IjoxNzE5MjE3NTg2fQ.6T5ifnIM_pe_FBYcIIjurqGoRuhaKV_GX8ydeP_-KGs', 'tqSh_kkx_6SpUCrxAAAP', '1', 1, ',99,127,128,129,130,131,132,133,48,134,135,136,137,139,140,141,142,143,144,145,147,148', 0, '2024-06-24 13:56:26', 1, '', 'd'),
(72, '6120', 'NN', 'sd', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJzZCIsInZGdWxsTmFtZSI6InNkIiwiTG9naW5UaW1lIjoxMDMwOTEyNTM4NDAsImlhdCI6MTcxODE4NzU2NH0.BlMocUUDotTYHcbBtLZC8D0EOgzZ-8NEaoDzlkd2U2U', 'VlUauhgitqkFW5EeAAHN', '0', 0, '', 0, '2024-06-12 15:49:24', 0, '', 'y'),
(73, '3021', 'OO', 'OO', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJPTyIsInZGdWxsTmFtZSI6Ik9PIiwiTG9naW5UaW1lIjoxMDMwOTEyNTcwMjAsImlhdCI6MTcxODE4NzYxN30._yAdGqk-roOLCb2s7YbnxYo9Gm5XlwtF6-5ikjg9MmY', 'lhtdzX94amFLhQu4AAHV', '0', 0, ',48', 0, '2024-06-12 15:50:17', 0, '', 'y'),
(74, '1234', 'KA', 'KA', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLQSIsInZGdWxsTmFtZSI6IktBIiwiTG9naW5UaW1lIjoxMDMwOTEyNjgzNjAsImlhdCI6MTcxODE4NzgwNn0.rPbpxapsgQRCSpVZQlGX3Rk9vb6mrbOSa9JHYKi3cjM', 'JIzeo6nmHhAtDApBAAIv', '0', 0, '', 0, '2024-06-12 15:53:26', 0, '', 'y'),
(75, '4567', 'DA', 'DA', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNDU2NyIsInZVc2VybmFtZSI6IkRBIiwidkZ1bGxOYW1lIjoiREEiLCJMb2dpblRpbWUiOjEwMzA5MTI2Nzg4MCwiaWF0IjoxNzE4MTg3Nzk4fQ._37h633SMgbVxc7OyujA_1LhB_nh8yWk6CNj6MnIhm4', 'P3Q6TEONMuSiMM5mAAEs', '0', 0, ',48,137', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(76, '7890', 'AK', 'AK', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNzg5MCIsInZVc2VybmFtZSI6IkFLIiwidkZ1bGxOYW1lIjoiQUsiLCJMb2dpblRpbWUiOjEwMzA5MTI3MjE0MCwiaWF0IjoxNzE4MTg3ODY5fQ.vbC0dRRJWDA8yKMYE_IGhPwtcCmxf13SwY0lLzRf7z4', 'p4TEmFUIEOqfTYr0AAHt', '0', 0, ',48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(77, '5252', 'ABC', 'ABC', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTI1MiIsInZVc2VybmFtZSI6IkFCQyIsInZGdWxsTmFtZSI6IkFCQyIsIkxvZ2luVGltZSI6MTAzMDkxMzU5NTAwLCJpYXQiOjE3MTgxODkzMjV9.gCpcgfBcZ2txb4WjClZkYV8WcYQYC0SSnhBXZ6FXxHc', 'RG6vaIYm64NaTCdUAAIj', '0', 0, ',102,48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(78, '5253', 'BCA', 'BCA', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTI1MyIsInZVc2VybmFtZSI6IkJDQSIsInZGdWxsTmFtZSI6IkJDQSIsIkxvZ2luVGltZSI6MTAzMDkxMzYxMjQwLCJpYXQiOjE3MTgxODkzNTR9.SJ4KZ1Wnpqvq6BtkrTZohxj1_CRZoOJnXy0yDtSmZHY', 'EjK82fQpN_KJiBG1AAAl', '0', 0, '', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(79, '5551', 'Terry', 'Terry', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/profile/profile.png', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJUZXJyeSIsInZGdWxsTmFtZSI6IlRlcnJ5IiwiTG9naW5UaW1lIjoxMDMxMzI3MzYwNDAsImlhdCI6MTcxODg3ODkzNH0.cXQ5W6EisBgxo-sEu0Jqzyje9ULARtFf-HAPj_WeJvY', 'xXVtotpc9uaH3J-cAAAT', '1', 0, '', 0, '2024-06-20 15:52:14', 1, '', 'y'),
(81, '6023', 'KV4', 'KV4', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjQiLCJ2RnVsbE5hbWUiOiJLVjQiLCJMb2dpblRpbWUiOjEwMzE2OTQ4MDM0MCwiaWF0IjoxNzE5NDkxMzM5fQ.UJZ1asgPvbXxHrObP8nDXSTv2cPRVRfTsOOmmaCPcOE', '9jDb-Fszsog39qPSAAAD', '2', 3, '48,135,136,139,140,141,142,143,144,145,146,147,148,149,151,152,153,154,161,162,178,181,176,199,200', 0, '2024-06-27 17:58:59', 1, '', 'y'),
(82, '6025', 'ABC', 'ABC', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBQkMiLCJ2RnVsbE5hbWUiOiJBQkMiLCJMb2dpblRpbWUiOjEwMzE1ODY4MjUwMCwiaWF0IjoxNzE5MzExMzc1fQ.OSSMOui1OUXdfroMojiebqCzGhIZ3QHAhi3sIs5XMBQ', 'dJRv1IkDyMNCpdZjAACu', '0', 1, ',102,110,48,167,172,174,170,177,179', 0, '2024-06-25 15:59:35', 1, '', 'y'),
(83, '6024', 'Jordan', 'Jordan', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKb3JkYW4iLCJ2RnVsbE5hbWUiOiJKb3JkYW4iLCJMb2dpblRpbWUiOjEwMzEwMDQwOTQyMCwiaWF0IjoxNzE4MzQwMTU3fQ.6b3Oq9JZVAuhFjPFTXdazcatqoMwxXG_ry7JE3itsKo', 'X1PmsJXyRo9ti8LIAAAL', '0', 3, ',48', 0, '2024-06-14 10:12:37', 0, '', 'y'),
(84, '6026', 'xyz', 'XYZ', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJ4eXoiLCJ2RnVsbE5hbWUiOiJYWVoiLCJMb2dpblRpbWUiOjEwMzE1ODczNzg4MCwiaWF0IjoxNzE5MzEyMjk4fQ.HkRHBZkVl7EFJ5fBt9gVhUeVuadzLateQUpNZR2eHaI', 'cPTFOE9BFrUNCLZ4AAC3', '1', 1, ',102,104,167,172,174,170,179', 0, '2024-06-25 16:14:58', 1, '', 'y'),
(85, '6027', 'Dustine', 'Dustin', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'images/uploads/profiles/1718258539165_e-21-09-23.jpg', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEdXN0aW5lIiwidkZ1bGxOYW1lIjoiRHVzdGluIiwiTG9naW5UaW1lIjoxMDMxNTMxMzM3MDAsImlhdCI6MTcxOTIxODg5NX0.W5gQ8mTaV88F99gzD9prlBDh9XUP8XuPxDgXpiY6qhA', 'W3Y1M2v1vVeuZegEAAAr', '2', 0, ',105,48,136', 0, '2024-06-24 14:18:15', 1, '', 'd'),
(86, '6028', 'Evan', 'Evan', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJFdmFuIiwidkZ1bGxOYW1lIjoiRXZhbiIsIkxvZ2luVGltZSI6MTAzMTMxNDU0MzgwLCJpYXQiOjE3MTg4NTc1NzN9.VQMbOvg-oBkW_7Zg6gte3LRJgIvRKvyprg60Kgcgs60', 'F24aiuEWXp8WALGyAABD', '0', 3, ',48', 0, '2024-06-20 09:56:13', 1, '', 'y'),
(87, '123456', 'DA', 'DA', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEQSIsInZGdWxsTmFtZSI6IkRBIiwiTG9naW5UaW1lIjoxMDMwOTY1MDU0MDAsImlhdCI6MTcxODI3NTA5MH0.xKzBQQQp6nzaMMh6DqLI56q97y0x0qePlkMRpEwx61E', 'ruNEGYxFTpwE8h-LAAAM', '0', 1, ',48', 0, '2024-06-13 16:08:10', 0, '', 'y'),
(90, '6029', 'Christian', 'Christian', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDaHJpc3RpYW4iLCJ2RnVsbE5hbWUiOiJDaHJpc3RpYW4iLCJMb2dpblRpbWUiOjEwMzA5NjgyNTQ0MCwiaWF0IjoxNzE4MjgwNDI0fQ.3iSeL2XYIDpP6xFnsbwkH4hqmCScbLqRPx4LUrDneO0', 'XIX0JPvfFQDPvBquAAAD', '2', 2, ',48', 0, '2024-06-13 17:37:04', 0, '', 'y'),
(91, '6030', 'Kevin', 'Kevin', '3e8131b7a466d5198e6e6f272e8b1ce92119be09', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLZXZpbiIsInZGdWxsTmFtZSI6IktldmluIiwiTG9naW5UaW1lIjoxMDMxMDAxMDEwODAsImlhdCI6MTcxODMzNTAxOH0.7-lrjjugUrUkB2QWJQlaaSYtMQ-Wq4gmGp8KzozwC6M', 'zShwYcvlPz_X9cmaAAAB', '2', 2, ',48', 0, '2024-06-14 08:46:58', 0, '', 'y'),
(92, '6031', 'Roberto', 'Roberto', '3e8131b7a466d5198e6e6f272e8b1ce92119be09', '', 'enliventest.chatapp@gmail.com', '', '', '2', 1, ',48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(94, '6032', 'Taylor', 'Taylor', 'f5e255b6610e57e7353f5b5c09676277c7a3552a', 'images/uploads/profiles/1718434847358_point-normal-LAsBMFrH_WY-unsplash.jpg', 'kishanvaghera8219@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJUYXlsb3IiLCJ2RnVsbE5hbWUiOiJUYXlsb3IiLCJMb2dpblRpbWUiOjEwMzEzMTk4NzcyMCwiaWF0IjoxNzE4ODY2NDYyfQ.cU01im5FWH9VpcDAlXJpYIe3AuEG5EPzYD-FriNY9dA', 'dZCAu7hUQxsNkA39AABf', '2', 0, '', 0, '2024-06-20 12:24:22', 1, '', 'd'),
(95, '0', 'ACBD', 'ACBD', '27a655dc1e3d02d4f798b48bd8fb4491b918f4f2', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBQ0JEIiwidkZ1bGxOYW1lIjoiQUNCRCIsIkxvZ2luVGltZSI6MTAzMTAwNzkxMTQwLCJpYXQiOjE3MTgzNDY1MTl9.C3pvHsRO0k1zUiDZCNAgThhfdJ5f6S1S2GMXiV7wVxA', 'gFNoIQLigujWAM9ZAAAX', '2', 3, '', 0, '2024-06-14 11:58:39', 0, '', 'y'),
(96, '159', 'MD', 'MD', '8a0dac3ccc72d00fe22bc364875f31a635408ce6', 'images/uploads/profiles/1718349951109_Test Image.jpg', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNRCIsInZGdWxsTmFtZSI6Ik1EIiwiTG9naW5UaW1lIjoxMDMxNjgwODQwODAsImlhdCI6MTcxOTQ2ODA2OH0.M6FKmukSkon038Y_rglJK2jxKkv6Jy6YUi3Fq5AUalg', 'ItxVnauqyhrWJQ7vAADL', '2', 0, ',112,48,168,169,171,173,177,179,180,192,195,191', 0, '2024-06-27 11:31:08', 1, '', 'y'),
(97, '6033', 'Greg', 'Greg', '86d8f819258cf5058efd9001011b6e90dc7b37d0', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJHcmVnIiwidkZ1bGxOYW1lIjoiR3JlZyIsIkxvZ2luVGltZSI6MTAzMTAxMDM1NzYwLCJpYXQiOjE3MTgzNTA1OTZ9.6tuxOSTIRHLPKj12Kks4FAjXaxj_F8xF7CDEIHVjQng', 'qTKdiDTJNHeujmxHAAAv', '2', 2, ',48', 0, '2024-06-14 13:06:36', 0, '', 'y'),
(98, '6034', 'Jeff', 'Jeff', '25bb1480664b46977a253a80e2c2f958890df3f3', '', 'enliventest.chatapp@gmail.com', '', '', '2', 2, ',48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(99, '6035', 'Johnni', 'Johnni', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKb2hubmkiLCJ2RnVsbE5hbWUiOiJKb2hubmkiLCJMb2dpblRpbWUiOjEwMzE1MzIxMjkwMCwiaWF0IjoxNzE5MjIwMjE1fQ.qXkfecNykJsetBKR8Y2floDVbmIHyLEii_zDo1nFqgc', 'pnV9XS2iKjzLjxTEAACM', '2', 4, ',48', 0, '2024-06-24 14:40:15', 1, '', 'd'),
(100, '6036', 'Douglas', 'Douglas', '46830d790ea5b8388cd2c3b9769bc9c8265fb301', '', 'enliventest.chatapp@gmail.com', '', '', '2', 2, ',48', 0, '0000-00-00 00:00:00', 0, '', 'y'),
(101, '6037', 'Elmer', 'Elmer', 'b6758c68dde20a19ae7777467b0d560bd4af53d6', '', 'enliventest.chatapp@gmail.com', '', '', '2', 2, ',48', 0, '0000-00-00 00:00:00', 1, '', 'y'),
(102, '111', 'MDD', 'MDD', '4cf9b040faff2394d3ec3efb866f9d74c58f2ecc', '', 'enliventest.chatapp@gmail.com', '', '', '2', 1, ',48', 0, '0000-00-00 00:00:00', 1, '', 'y'),
(103, '6038', 'Walter', 'Walter', 'da18c702a8c518190b539a4c73546d60c0d8d17e', '', 'kishanvaghera8219@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJXYWx0ZXIiLCJ2RnVsbE5hbWUiOiJXYWx0ZXIiLCJMb2dpblRpbWUiOjEwMzEwNTc4MjA2MCwiaWF0IjoxNzE4NDI5NzAxfQ.g2yLMyHuzIx-RARjM7EG_bN2PAk_lgEsgRgf2aeHLZg', 'CKMJnSbcI0Ti9TLZAAAQ', '2', 3, ',48', 0, '2024-06-15 11:05:01', 1, '', 'y'),
(104, 'Dhiren.A', 'Dhiren Adesara', 'Dhiren Adesara', '5f9186a05d127195fce0531520e179cab83fede3', 'images/uploads/profiles/1718607657052_alexandra-nicolae-6elNtGvY2S0-unsplash.jpg', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEaGlyZW4gQWRlc2FyYSIsInZGdWxsTmFtZSI6IkRoaXJlbiBBZGVzYXJhIiwiTG9naW5UaW1lIjoxMDMxNjk1ODYzMDAsImlhdCI6MTcxOTQ5MzEwNX0.kmvGwD2c0Dx5qHjsF1ibwFpMg8ZAgIxZBdw0R7PJBmo', 'uVkzxAO0giuFRnJkAAAL', '0', 0, '125,48,137,160,165,167,168,169,172,174,170,178,179,180,188,192,193,194,195', 0, '2024-06-27 18:28:25', 1, '', 'y'),
(105, '189', 'Meghdip Jain', 'Meghdip Jain', '8a3d7c218912301608180ccb24dbcd0f86e2f695', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNZWdoZGlwIEphaW4iLCJ2RnVsbE5hbWUiOiJNZWdoZGlwIEphaW4iLCJMb2dpblRpbWUiOjEwMzExNTcyNTYyMCwiaWF0IjoxNzE4NTk1NDI3fQ.G3dM4YGMU8YVIgi7hYxUF7sAiDPZYcjhTEYj9AWe9wU', 'Fm3URABdBOowZUlOAAAY', '2', 3, ',48,138', 0, '2024-06-17 09:07:07', 1, '', 'y'),
(106, 'Vinayak', 'Vinayak Vekariya', 'Vinayak Vekariya', '9e60c41dddaf622339c24e44b8d4e3946dd1d272', 'images/uploads/profiles/1718607887046_IMG_4523.jpg', 'vinayak@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJWaW5heWFrIFZla2FyaXlhIiwidkZ1bGxOYW1lIjoiVmluYXlhayBWZWthcml5YSIsIkxvZ2luVGltZSI6MTAzMTU4NzgzNDIwLCJpYXQiOjE3MTkzMTMwNTd9.Dt8ERaJRrQHdQ0yklBwtQIPqhbLOepsI0frnxOc0BbI', 'a1NylZdLqmKX3GIMAADT', '2', 0, ',48,138,173,180', 0, '2024-06-25 16:27:37', 1, '', 'y'),
(107, '6077', '7th sense', '7th sense', '733e036c3ca8a6273878cf339d0b03b24ca53c7a', '', '7thsense@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiI3dGggc2Vuc2UiLCJ2RnVsbE5hbWUiOiI3dGggc2Vuc2UiLCJMb2dpblRpbWUiOjEwMzExNjE2ODk2MCwiaWF0IjoxNzE4NjAyODE2fQ.5j_nOhe5VovtJFCKlcuQmP0MAchzOT22LIRI_7mCOa4', 'qN4Svn_que-YOLNlAABg', '2', 2, ',103,106,48', 0, '2024-06-17 11:10:16', 1, '', 'y'),
(108, 'HR', 'HR Admin', 'HR Admin', 'c1c175febf47d1dac2b854eaacbd83535f087e3e', '', 'hr@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJIUiBBZG1pbiIsInZGdWxsTmFtZSI6IkhSIEFkbWluIiwiTG9naW5UaW1lIjoxMDMxMTYyODgyNDAsImlhdCI6MTcxODYwNDgwNH0.AUgIYD8_7StIREl1YrnlD2QlGASUOmUx2O1iimXuXpE', '14ifSktMNlIQwrmzAABm', '2', 4, ',48', 0, '2024-06-17 11:43:24', 1, '', 'y'),
(109, 'DPA', 'Dhiren P. Adesara', 'Dhiren P. Adesara', '5f9186a05d127195fce0531520e179cab83fede3', '', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEaGlyZW4gUC4gQWRlc2FyYSIsInZGdWxsTmFtZSI6IkRoaXJlbiBQLiBBZGVzYXJhIiwiTG9naW5UaW1lIjoxMDMxNjgzMTk0MDAsImlhdCI6MTcxOTQ3MTk5MH0.FjT9XNZQ3gDU14AP3NWVtwH-qYkGPVY-bHT7tz9Gyfw', 'G7-ofSSmp3TgtjxaAAAq', '2', 2, '114,124,125,48,137,160,167,168,169,172,171,174,173,170,178,188,190,192,194,195,169,197,200', 0, '2024-06-27 12:36:30', 1, '', 'y'),
(110, 'da-del', 'da-del', 'da-del', '5f9186a05d127195fce0531520e179cab83fede3', '', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJkYS1kZWwiLCJ2RnVsbE5hbWUiOiJkYS1kZWwiLCJMb2dpblRpbWUiOjEwMzE2MzY0ODUyMCwiaWF0IjoxNzE5Mzk0MTQyfQ.xsizdeewLPbgD0EiPGBP8VQsIJSOen7Fm9JN3zh27ww', 'zIDyWK5PRUZ-DWLEAABF', '2', 1, ',48,137,165,167,172,171,174,173,178,179,180,189,190', 0, '2024-06-26 14:59:02', 1, '', 'd'),
(111, 'Matthew', 'Matthew', 'Matthew', 'dc0b4383432da2683e5a9afd9d33e9600a779290', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNYXR0aGV3IiwidkZ1bGxOYW1lIjoiTWF0dGhldyIsIkxvZ2luVGltZSI6MTAzMTUzMjkyOTQwLCJpYXQiOjE3MTkyMjE1NDl9.qxOSoMtLqfJRRFb3J-9Oi-6GSUbOKvm4IrJN09SjfH8', 'U7uVazCLf2t0tDoxAAAN', '2', 3, '', 0, '2024-06-24 15:02:29', 1, '', 'd'),
(112, 'Marcus', 'Marcus', 'Marcus', '9ed67796a273402c77092356fc7b9368c87373c9', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNYXJjdXMiLCJ2RnVsbE5hbWUiOiJNYXJjdXMiLCJMb2dpblRpbWUiOjEwMzE1MzM5NDgyMCwiaWF0IjoxNzE5MjIzMjQ3fQ.KElXKGoVhLcrxdpEHa3B5VOgngxGoQT5mO8j1R-_0SA', 'Oy7st3fgt8Py9aW6AABJ', '2', 4, '', 0, '2024-06-24 15:30:47', 1, '', 'd'),
(113, 'Eddie', 'Eddie', 'Eddie', '896e80fc3f29564f35627baf7e60adc85f2f8d3c', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJFZGRpZSIsInZGdWxsTmFtZSI6IkVkZGllIiwiTG9naW5UaW1lIjoxMDMxNTM2Njc4MjAsImlhdCI6MTcxOTIyNzc5N30.DKhauL7SjZzJ3Tfgy4yIOWLr3Yg-94O3BAVB1Ko62uA', 'cN0LubukurOAE0EXAAAV', '2', 4, ',162', 0, '2024-06-24 16:46:37', 1, '', 'd'),
(114, 'Milton', 'Milton', 'Milton', '9504c06472961ddfb852743078042d73f762835d', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNaWx0b24iLCJ2RnVsbE5hbWUiOiJNaWx0b24iLCJMb2dpblRpbWUiOjEwMzE1MzY2MzI2MCwiaWF0IjoxNzE5MjI3NzIxfQ.lg4WMOX0l075sHnXHpd5tWjiCu_pUNCwuVrsTZ2yF5E', 'dnwDeXx3zYS_4twvAAAR', '2', 1, '', 0, '2024-06-24 16:45:21', 1, '', 'd'),
(115, 'Carole', 'Carole', 'Carole', '8e66c8f8231c2a01f782f1b2579358d3360f937a', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDYXJvbGUiLCJ2RnVsbE5hbWUiOiJDYXJvbGUiLCJMb2dpblRpbWUiOjEwMzE1MzgxMzA4MCwiaWF0IjoxNzE5MjMwMjE4fQ.nsQpW9yR4ARECpQSb5vzOcm4KhEPA3p4S4wdWmUMo7c', '5acWADllFtcOVussAAA7', '2', 1, '', 0, '2024-06-24 17:26:58', 1, '', 'd'),
(116, 'Lorraine', 'Lorraine', 'Lorraine', '45c5b71d4038ba4f1d99fd4b082d162b8ad9c96e', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJMb3JyYWluZSIsInZGdWxsTmFtZSI6IkxvcnJhaW5lIiwiTG9naW5UaW1lIjoxMDMxNTg4ODU4NDAsImlhdCI6MTcxOTMxNDc2NH0.dVzKPgPelkmxEh_fyhcdkMT2pjmG142tHwugW8Mnelw', 'lTrkqMwl_ke_57NqAAAP', '2', 3, ',166,180', 0, '2024-06-25 16:56:04', 1, '', 'y'),
(117, 'Isobel', 'Isobel', 'Isobel', '96fa0228272c038a7a2a6b5b6eae750a552b67a6', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJJc29iZWwiLCJ2RnVsbE5hbWUiOiJJc29iZWwiLCJMb2dpblRpbWUiOjEwMzE1Nzk5NjM0MCwiaWF0IjoxNzE5Mjk5OTM5fQ.NbnUXDZnbVbeeHf4FSI5dTGa35LxGhyJJraOfjN9kH0', 'iT52Tv39F2hBIXleAAAJ', '2', 2, '', 0, '2024-06-25 12:48:59', 1, '', 'd'),
(118, 'Vicky', 'Vicky', 'Vicky', '839ac7f89b5fce7369ec06b151fba842643ee599', 'images/uploads/profiles/1719313864365_minion-1357223_640.jpg', 'vinayak@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJWaWNreSIsInZGdWxsTmFtZSI6IlZpY2t5IiwiTG9naW5UaW1lIjoxMDMxNTg3NjY5MjAsImlhdCI6MTcxOTMxMjc4Mn0.Bw9RpWHsKM2zQ-NdIsV16JfxoAfodK_T61DEkGfHTV0', 'cOeuZjD6QXJwZEr5AADV', '2', 0, ',171', 0, '2024-06-25 16:23:02', 1, '', 'y'),
(119, 'del', 'del', 'del', '5f9186a05d127195fce0531520e179cab83fede3', '', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJkZWwiLCJ2RnVsbE5hbWUiOiJkZWwiLCJMb2dpblRpbWUiOjEwMzE1ODk1NTkyMCwiaWF0IjoxNzE5MzE1OTMyfQ.p0l4B_OV_SAUH9upWkC3Vqg7CmlbZq6ScR51yiaOonM', 'JDjza3xRpOtwXqVsAAFF', '2', 4, '', 0, '2024-06-25 17:15:32', 1, '', 'd'),
(120, '150780', 'Meghdip D. Doshi', 'Meghdip D. Doshi', 'c05e928c8e96fa6058d1c988f8cb0bd1c16b6a0e', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNZWdoZGlwIEQuIERvc2hpIiwidkZ1bGxOYW1lIjoiTWVnaGRpcCBELiBEb3NoaSIsIkxvZ2luVGltZSI6MTAzMTY3NTUwNzQwLCJpYXQiOjE3MTk0NTkxNzl9.M1-o57Y_FTJdSdEiVr20TpVH0JzEcKZgOcD4l_tizTA', 'PGrtOfC-9-rTbkBeAACo', '2', 3, ',182,185,194', 0, '2024-06-27 09:02:59', 1, '', 'y'),
(121, '15071980', 'Meghdeep Doshi', 'Meghdeep Doshi', '7aae773e349cf9cccd9543c59e35a0d6f2c134e6', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNZWdoZGVlcCBEb3NoaSIsInZGdWxsTmFtZSI6Ik1lZ2hkZWVwIERvc2hpIiwiTG9naW5UaW1lIjoxMDMxNjM5NTk2ODAsImlhdCI6MTcxOTM5OTMyOH0.OmIQ-KgelH3s1KpfUNjCLetAr2jB0Id_Q_2PJ90-DkE', 'VIO7f48-uXtEYUHuAABI', '0', 3, ',182,183,185,186,194,191', 0, '2024-06-26 16:25:28', 1, '', 'y'),
(122, '1507', 'MD1', 'MD1', '7aae773e349cf9cccd9543c59e35a0d6f2c134e6', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNRDEiLCJ2RnVsbE5hbWUiOiJNRDEiLCJMb2dpblRpbWUiOjEwMzE2MzU0MzE2MCwiaWF0IjoxNzE5MzkyMzg2fQ.d02Fu_S6Par5MB-xaiNwOlGq_zyaUC5-F42YNn8j1FE', 'tBh39jTknNVLqJkYAABw', '2', 3, ',182,183,185,186,191', 0, '2024-06-26 14:29:46', 1, '', 'd'),
(123, '8934', 'MD2', 'MD2', '7aae773e349cf9cccd9543c59e35a0d6f2c134e6', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNRDIiLCJ2RnVsbE5hbWUiOiJNRDIiLCJMb2dpblRpbWUiOjEwMzE2ODE2MzA0MCwiaWF0IjoxNzE5NDY5Mzg0fQ._dq_9pOrKeNtxvi17In-j5PlIH7Bdukids4VE1XrDAI', 'JbUWyzPfMYLv-pb6AABa', '2', 1, ',182,183,185,186,191,193,194,195', 0, '2024-06-27 11:53:04', 1, '', 'y'),
(124, '5742', 'MD3', 'MD3', '7aae773e349cf9cccd9543c59e35a0d6f2c134e6', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNRDMiLCJ2RnVsbE5hbWUiOiJNRDMiLCJMb2dpblRpbWUiOjEwMzE2MjMzNDQ2MCwiaWF0IjoxNzE5MzcyMjQxfQ.mIIzMld9P2EDkIKhmZpn-MZlYE24qMBH-t1aGt8DzCE', 'l5tjZ8vW70anssNHAABb', '2', 1, '', 0, '2024-06-26 08:54:01', 1, '', 'd'),
(125, 'Bernard', 'Bernard', 'Bernard', '9e69909a32d73de829d91632cec726a3ebdbee47', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCZXJuYXJkIiwidkZ1bGxOYW1lIjoiQmVybmFyZCIsIkxvZ2luVGltZSI6MTAzMTY0MDczODAwLCJpYXQiOjE3MTk0MDEyMzB9.RzgsMRKyDP_Ln9vH_cgWQzSNhtqOx-_0Fna4CQaaAgM', 'qepWl6o0ZhglCF2gAACd', '2', 3, ',187,190,195', 0, '2024-06-26 16:57:10', 1, '', 'd'),
(126, 'Gene', 'Gene', 'Gene', '76f4c3db68aca6fcf9fd6bc62bedfa07fa49b46c', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJHZW5lIiwidkZ1bGxOYW1lIjoiR2VuZSIsIkxvZ2luVGltZSI6MTAzMTYzNDYxOTgwLCJpYXQiOjE3MTkzOTEwMzN9.hUTuSIEz5fEjk_xfB9k_9xTBtMF8gd_wBCNE24jcObw', 'GUSz3JMr-zUWragZAAAX', '2', 1, ',184,196', 0, '2024-06-26 14:07:13', 1, '', 'd'),
(127, 'Ashley', 'Ashley', 'Ashley', 'dd6d79319f9ff647a13ec5da97909c8b22b622df', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBc2hsZXkiLCJ2RnVsbE5hbWUiOiJBc2hsZXkiLCJMb2dpblRpbWUiOjEwMzE2MjQ0NTgyMCwiaWF0IjoxNzE5Mzc0MDk3fQ.2aSBeQ-iTK7zGlxv9Pxs02c6UFP_PoR0COC__5Y-S4M', 'rqSjR1kdk5HAnA0zAACF', '1', 1, '', 0, '2024-06-26 09:24:57', 1, '', 'd'),
(128, 'Jesse', 'Jesse', 'Jesse', '78e3c56995c10d50590387e6e45ab4504647d1af', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJKZXNzZSIsInZGdWxsTmFtZSI6Ikplc3NlIiwiTG9naW5UaW1lIjoxMDMxNjI1NDAwODAsImlhdCI6MTcxOTM3NTY2OH0.scvwPvFEexf1nrggWEax2CMhb4WigyiRCFuCV5lY-Z4', 'aHBIiyckHiMag3tKAABj', '2', 3, '', 0, '2024-06-26 09:51:08', 1, '', 'd'),
(129, '150780A', 'MD3', 'MD3', '7aae773e349cf9cccd9543c59e35a0d6f2c134e6', '', 'meghdip@enlivendc.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNRDMiLCJ2RnVsbE5hbWUiOiJNRDMiLCJMb2dpblRpbWUiOjEwMzE2MjY3NzkwMCwiaWF0IjoxNzE5Mzc3OTY1fQ.LmoX3YFgUbhcNSL1exSGSSr_KH7paWXBUGdiC4NEI6Q', 'TRiS84j-9lTTcEeaAACM', '2', 1, '', 0, '2024-06-26 10:29:25', 1, '', 'd'),
(130, 'Larry', 'Larry', 'Larry', 'b93069031f6ddb5177741820150504260f46b8e6', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJMYXJyeSIsInZGdWxsTmFtZSI6IkxhcnJ5IiwiTG9naW5UaW1lIjoxMDMxNjc0ODQwMjAsImlhdCI6MTcxOTQ1ODA2N30.75a7vY2MurL4brap-DyreZmD7SsSHI_GvXbaOY0qVaI', 'DUYqFAplaglf4_PxAAAT', '2', 2, ',184,195,196,198,199', 0, '2024-06-27 08:44:27', 1, '', 'y'),
(131, 'Nicholas', 'Nicholas Ortiz', 'Nicholas Ortiz', '0e0937cffbe5478788b90251d3757efa984b57e3', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJOaWNob2xhcyBPcnRpeiIsInZGdWxsTmFtZSI6Ik5pY2hvbGFzIE9ydGl6IiwiTG9naW5UaW1lIjoxMDMxNjg3NTQ5NDAsImlhdCI6MTcxOTQ3OTI0OX0.Wca1aVrl2S8nZBaFKYi7wEnbqXyVA936l0OFQMzyvuY', 'E686wwnsJ9L-syoZAAAR', '2', 3, ',184,196', 0, '2024-06-27 14:37:29', 1, '', 'd'),
(132, 'Arya', 'Arya Anand', 'Arya Anand', '5f9186a05d127195fce0531520e179cab83fede3', 'images/uploads/profiles/1719397520930_trooper_by_bastienald-d6pbcr7 copy.jpg', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBcnlhIEFuYW5kIiwidkZ1bGxOYW1lIjoiQXJ5YSBBbmFuZCIsIkxvZ2luVGltZSI6MTAzMTY5NDIzNDYwLCJpYXQiOjE3MTk0OTAzOTF9.c1shlPwFi_8q53ZvpASkRBdJQxEvWNJ0SY9kBO0CleY', 'bkCosRzAWiwA5qQVAABR', '2', 0, ',195,200', 0, '2024-06-27 17:43:11', 1, '', 'y'),
(133, 'Aditya', 'Aditya', 'Aditya', '5f9186a05d127195fce0531520e179cab83fede3', 'images/uploads/profiles/1719397469649_eso1624b.jpg', 'dhirenadesara@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBZGl0eWEiLCJ2RnVsbE5hbWUiOiJBZGl0eWEiLCJMb2dpblRpbWUiOjEwMzE2OTQyMTQ4MCwiaWF0IjoxNzE5NDkwMzU4fQ.p5bETs-yCjQrDk4Tg2zwEqbpo7cHmuOmgZOHHULLXiI', 'mqIOhjpMJ8o_gEy5AABf', '2', 0, '200,200', 0, '2024-06-27 17:42:38', 1, '', 'y'),
(134, 'Serenity', 'Serenity', 'Serenity', '1ab68291ce3adde9c918e93f0c266c9f3696a287', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJTZXJlbml0eSIsInZGdWxsTmFtZSI6IlNlcmVuaXR5IiwiTG9naW5UaW1lIjoxMDMxNjkyMDQ0MDAsImlhdCI6MTcxOTQ4Njc0MH0.eNQPq-29uZIXo-mWwK_HDwlqJroe2QVEoEE45vN-_ys', '8jZ9gsg6PxNrkVJOAAAZ', '2', 3, '199', 0, '2024-06-27 16:42:20', 1, '', 'd'),
(135, 'Milton', 'Milton', 'Milton', '9504c06472961ddfb852743078042d73f762835d', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNaWx0b24iLCJ2RnVsbE5hbWUiOiJNaWx0b24iLCJMb2dpblRpbWUiOjEwMzE2OTI1MTc0MCwiaWF0IjoxNzE5NDg3NTI5fQ.9csjY_R8UFIb9Q9ZJr6BX0mlENFKT42CbvCxhzaoZRM', 'sEqZQsiTfuWSCqHFAAAh', '2', 1, '199', 0, '2024-06-27 16:55:29', 1, '', 'd'),
(136, 'Kathy', 'Kathy', 'Kathy', '22627720fbc5a1945cf19b7ada97bf0706b60c45', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLYXRoeSIsInZGdWxsTmFtZSI6IkthdGh5IiwiTG9naW5UaW1lIjoxMDMxNjkyNjgzNjAsImlhdCI6MTcxOTQ4NzgwNn0.5GOLu68g6ensUljoEj8SsYsayEgcQGvHkMDPM4EOt3A', '0TIQ9Edld_v4n2tsAAAX', '2', 3, '199', 0, '2024-06-27 17:00:06', 1, '', 'd'),
(137, 'Vickie', 'Vickie', 'Vickie', 'e185914d1173cf6abf74c9a6c32f4c91314f16a5', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJWaWNraWUiLCJ2RnVsbE5hbWUiOiJWaWNraWUiLCJMb2dpblRpbWUiOjEwMzE2OTMwMTA2MCwiaWF0IjoxNzE5NDg4MzUxfQ.FSpZT6OPrLapBMvMGBTONIaTXr7bMR1_k0vPLw4jvHI', 'XJVGGGJrzug1DC6EAAAx', '2', 2, '199', 0, '2024-06-27 17:09:11', 1, '', 'd'),
(138, 'Wayne', 'Wayne', 'Wayne', '99f386da0ad281e2aeea9364fbd59362133843b3', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJXYXluZSIsInZGdWxsTmFtZSI6IldheW5lIiwiTG9naW5UaW1lIjoxMDMxNjkzMDc2NjAsImlhdCI6MTcxOTQ4ODQ2MX0.UrYZ27ljRTWPKfvYr0ebq3nE4Q36Vy0PaMmTrA_7dQA', 'TDg2j7z5YxJcV5BfAAAZ', '2', 4, '199', 0, '2024-06-27 17:11:01', 1, '', 'y'),
(139, 'Roberta', 'Roberta', 'Roberta', 'e411a4e1712a0b3ed68e56b0baa65715a7078609', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJSb2JlcnRhIiwidkZ1bGxOYW1lIjoiUm9iZXJ0YSIsIkxvZ2luVGltZSI6MTAzMTY5MzEzMzYwLCJpYXQiOjE3MTk0ODg1NTZ9.IbTWbwqyuyFnx75mF3b2rcfJ_NIry3IFS4EZ5lRo1KE', '7IWkunLy1sQaAe4ZAAAP', '2', 4, '199', 0, '2024-06-27 17:12:36', 1, '', 'd'),
(140, 'Stacey', 'Stacey', 'Stacey', 'e7bbf7225e437874d20eeee4545549e4ba2c432e', '', 'enliventest.chatapp@gmail.com', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJTdGFjZXkiLCJ2RnVsbE5hbWUiOiJTdGFjZXkiLCJMb2dpblRpbWUiOjEwMzE2OTM5MTI0MCwiaWF0IjoxNzE5NDg5ODU0fQ.bDJWeJ_zPZPPJL8Rd_Wa0VcRfEhSBQM7u9EJfqtfiwM', 'UQHHqihT6RDHevfMAAAb', '2', 3, '199', 0, '2024-06-27 17:34:14', 1, '', 'y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_broadcast_grp`
--
ALTER TABLE `chat_broadcast_grp`
  ADD PRIMARY KEY (`iGroupId`);

--
-- Indexes for table `chat_users`
--
ALTER TABLE `chat_users`
  ADD PRIMARY KEY (`iUserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_broadcast_grp`
--
ALTER TABLE `chat_broadcast_grp`
  MODIFY `iGroupId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `chat_users`
--
ALTER TABLE `chat_users`
  MODIFY `iUserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
