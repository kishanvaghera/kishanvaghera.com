<?php
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat App</title>
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://foliotek.github.io/Croppie/croppie.css">
</head>

<body>
    <div class="body-wrapper">
        <!-- Sidebar Start -->
        <aside class="sidebar">
            <div class="logo-box"></div>
            <div class="main-user-profile">
                <div class="user-profile-image-box justify-content-between mb-3 pb-1">
                    <div class="d-flex align-items-center">
                        <div class="user-profile-image me-3">
                            <svg role="none" viewBox="0 0 96 96">
                                <mask id="profile-image">
                                    <circle fill="white" cx="48" cy="48" r="48"></circle>
                                    <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                </mask>
                                <g mask="url(#profile-image)">
                                    <image x="0" y="0" id="vProfilePick" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="images/profile/user-profile.svg"></image>
                                </g>
                            </svg>
                            <div class="online" id="vLoggedSts"></div>
                        </div>
                        <div>
                            <h5 class="user-profile-name" id="vUserName">ABC</h5>
                            <P class="user-profile-activity" id="vUserLoggedSts">Online</P>
                        </div>
                    </div>
                    <div class="dropdown">
                        <span data-bs-toggle="dropdown" class="cursor-pointer">
                            <i data-feather="more-vertical" class="feather-20"></i>
                        </span>
                        <!-- <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="vEditProfilePickDrop">Edit Profile Picture</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="vEditProfile">Edit Profile</a></li>
                        </ul> -->
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="javascript:;" id="vEditProfilePickDrop">Edit Profile</a></li>
                            <li>
                                <a class="dropdown-item" href="javascript:;" id="vEditProfile">Profile Status</a>
                                <ul class="dropdown-menu dropdown-submenu">
                                    <li>
                                        <a class="dropdown-item changeOnlineStst" data-id="2" href="javascript:void(0)"><span class="auto"></span> Automatic</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item changeOnlineStst" data-id="1" href="javascript:void(0)"><span class="online"></span> Online</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item changeOnlineStst" data-id="0" href="javascript:void(0)"><span class="offline"></span> Offline</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>

                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="userChat" data-bs-toggle="tab" data-bs-target="#nav-chat" type="button" role="tab" aria-controls="nav-chat" aria-selected="true">Chats</button>
                        <button class="nav-link" id="userGroup" data-bs-toggle="tab" data-bs-target="#nav-group" type="button" role="tab" aria-controls="nav-group" aria-selected="false">Groups</button>
                    </div>
                </nav>
            </div>

            <input type="hidden" id="vConvertionChatArr" name="vConvertionChatArr" value="[]" />
            <input type="hidden" id="vChatUserListJson" name="vChatUserListJson" value="[]" />
            <input type="hidden" id="vActiveUserId" name="vActiveUserId" value="" />
            <input type="hidden" id="vChatGroupListJson" name="vChatGroupListJson" value="[]" />
            <input type="hidden" id="vActiveGroupId" name="vActiveGroupId" value="" />
            <input type="hidden" id="vReplyMsg" name="vReplyMsg" value="" />
            <input type="hidden" id="vReplyMsg_id" name="vReplyMsg_id" value="" />
            <input type="hidden" id="vReplyMsg_type" name="vReplyMsg_type" value="" />
            <input type="hidden" id="vReplyFileName" name="vReplyFileName" value="" />
            <input type="hidden" id="vNewGrpUserSelect" name="vNewGrpUserSelect" value="" />
            <input type="hidden" id="vActiveProfileSts" name="vActiveProfileSts" value="" />
            <input type="hidden" id="vLoggedColorOption" name="vLoggedColorOption" value="" />

            <div class="users-list-container">
                <div class="tab-content" id="nav-tabContent">
                    <!-- Chats Start -->
                    <div class="tab-pane fade show active" id="nav-chat" role="tabpanel" aria-labelledby="userChat" tabindex="0">
                        <div class="search-add py-3">
                            <div class="searchBar me-2">
                                <span><i data-feather="search" class="feather-20"></i></span>
                                <input type="text" class="form-control" id="vSearchUser">
                            </div>
                            <div class="new-chat" id="addNewChatModal">
                                <button><span><i data-feather="plus" class="feather-20"></i></span></button>
                            </div>
                        </div>

                        <ul id="chatUserList">
                        </ul>
                    </div>
                    <!-- Chats End -->

                    <!-- Groups Start -->
                    <div class="tab-pane fade position-relative" id="nav-group" role="tabpanel" aria-labelledby="userGroup" tabindex="0">
                        <div class="search-add py-3">
                            <div class="searchBar me-2">
                                <span><i data-feather="search" class="feather-20"></i></span>
                                <input type="text" class="form-control" id="searchGroupName">
                            </div>
                            <div class="new-chat new-chat-group" id="NewChatGroup">
                                <button id="CreateNewGroup"><span><i data-feather="plus" class="feather-20"></i></span></button>
                            </div>
                        </div>

                        <ul id="ChatGroupList">
                        </ul>
                    </div>
                    <!-- Groups End -->
                </div>
            </div>


            <!-- Add User Popup Start -->
            <div class="add-user-popup">
                <div class="add-user-popup-container">
                    <div class="add-user-popup-header position-relative">
                        <p>New Chat</p>
                        <a href="javascript:;" id="CloseNewChat" class="close-new-chat"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="add-user-popup-search">
                        <div class="searchBar">
                            <span><i data-feather="search" class="feather-20"></i></span>
                            <input type="text" class="form-control" id="SearchUserAllInp">
                        </div>
                    </div>
                    <div class="add-user-popup-users">
                        <ul id="vChatUserListAll">
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Add User Popup End -->

            <!-- Add Group Popup Start -->
            <div class="add-group-popup">
                <div class="add-group-popup-container">
                    <div class="add-group-popup-header position-relative">
                        <p>Create New Group</p>
                        <a href="javascript:;" class="close-new-chat" id="CloseNewGroupUserModal"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="add-group-popup-search">
                        <div class="searchBar">
                            <span><i data-feather="search" class="feather-20"></i></span>
                            <input type="text" class="form-control" id="SeachNewGroupUser">
                        </div>
                    </div>
                    <div class="add-group-popup-users">
                        <ul id="NewGroupUserList"></ul>
                    </div>

                    <div class="add-group-popup-btn-container">
                        <button type="button" id="vCreateNewGroupNext" class="add-group-popup-btn d-none">Next</button>
                    </div>
                </div>
            </div>
            <!-- Add Group Popup End -->

            <!-- Create New Group Popup Start -->
            <div class="create-group-popup">
                <div class="create-group-popup-container">
                    <div class="create-group-popup-header position-relative">
                        <a href="javascript:;" class="close-new-group"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p>Create New Group</p>
                        <a href="javascript:;" class="close-new-group"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="create-group-popup-users">
                        <div class="create-group-profile">
                            <div class="text-center">
                                <p class="title">Group Picture</p>
                                <div class="d-flex justify-content-center mb-3">
                                    <div class="group-profile-container">
                                        <img src="images/profile/group-profile.svg" id="vGroupPicSelected" class="rounded-3" alt="Group Profile">
                                        <a href="javascript:;" class="edit-icon" id="vGroupPicturePick">
                                            <i data-feather="edit-3" class="feather-20"></i>
                                        </a>
                                        <input type="file" class="d-none" id="vGroupPicture" />
                                    </div>
                                </div>
                            </div>

                            <div class="create-group-form">
                                <div class="mb-3" data-error="Required">
                                    <label class="form-label">Group Name<span>*</span></label>
                                    <input type="text" class="form-control" id="vGroupName">
                                    <!-- <span class="alert alert-danger d-none" id="vGroupNameErr">This field is required</span> -->
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" rows="2" id="tDescription"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="create-group-admin">
                            <ul>
                                <li>
                                    <p class="title">Group Admin</p>
                                    <a href="javascript:;" class="chat-list">
                                        <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3">
                                                    <svg role="none" viewBox="0 0 96 96">
                                                        <mask id="profile-image">
                                                            <circle fill="white" cx="48" cy="48" r="48">
                                                            </circle>
                                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                                            </circle>
                                                        </mask>
                                                        <g mask="url(#profile-image)">
                                                            <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="images/profile/user-profile.svg" id="vNewGrpOwnImg">
                                                            </image>
                                                        </g>
                                                    </svg>
                                                    <div class="online" id="vNewGroupOwnStsBadge"></div>
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name" id="vNewGroupOwnName">ABC </h5>
                                                    <P class="user-profile-activity" id="vNewGroupOwnSts">Online</P>
                                                </div>
                                            </div>

                                            <span><input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2"></span>
                                        </label>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="create-group-added-users">
                            <p class="title">Group Members<span>*</span></p>
                            <span class="alert alert-danger d-none" id="vGroupUserErr">Please add atleast one user.</span>
                            <ul id="newGroupMember"></ul>
                        </div>
                    </div>

                    <div class="add-group-popup-btn-container">
                        <button type="button" id="AddNewGroup" class="add-group-popup-btn">Create</button>
                    </div>
                </div>
            </div>
            <!-- Create New Group Popup End -->
        </aside>
        <!-- Sidebar End -->

        <div class="page-wrapper">
            <!-- Header Start -->
            <div class="d-flex align-items-center justify-content-center h-100" id="StartChatArea">
                <div class="text-center">
                    <h1 class="start-chat-title">Welcome to Chat App</h1>
                    <p class="start-chat-subtitle">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae repellendus similique?
                    </p>
                </div>
            </div>

            <header class="header pb-1 d-none" id="HeaderChatArea">
                <div class="border-bottom pb-3 main-header" id="topHeaderActiveArea">
                    <div class=" d-flex align-items-center justify-content-between position-relative">
                        <div>
                            <ul class="mb-0">
                                <li>
                                    <a href="javascript:;" class="chat-list">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3" id="vUseTabActive">
                                                    <svg role="none" viewBox="0 0 96 96">
                                                        <mask id="profile-image">
                                                            <circle fill="white" cx="48" cy="48" r="48">
                                                            </circle>
                                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                                            </circle>
                                                        </mask>
                                                        <g mask="url(#profile-image)">
                                                            <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="activeChatProfile" xlink:href="images/profile/user-profile.svg">
                                                            </image>
                                                        </g>
                                                    </svg>
                                                    <div class="online" id="activeChatSts"></div>
                                                </div>
                                                <div class="user-profile-image me-3 d-none" id="vGroupTabActive">
                                                    <img src="images/profile/group-profile.svg" alt="group-profile" id="activeGroupProfile">
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name" id="activeChatName">Viktorya Daniel</h5>
                                                    <P class="user-profile-activity" id="activeChatStsDisp">Online</P>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <div class="header-searchBar">
                            <div class="searchBar me-2">
                                <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search feather-20">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                    </svg></span>
                                <input type="text" class="form-control" id="vSearchText">
                            </div>
                        </div>

                        <div id="GroupDropDown" class="d-none">
                            <div class="dropdown">
                                <span data-bs-toggle="dropdown" class="cursor-pointer">
                                    <i data-feather="more-vertical" class="feather-20"></i>
                                </span>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="javascript:void(0)" id="vGroupInfoBtn">Group info</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)" id="vGroupEditGroup">Edit Group</a></li>
                                    <li><a class="dropdown-item" href="javascript:void(0)" id="vGroupDeleteGroup">Delete Group</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Multiple Selected Message Code Start -->
                <div class="border-bottom pb-3 d-flex align-items-center justify-content-between select-action d-none" id="MultipleSelectDiv">
                    <div>
                        <p class="select-count mb-0" id="iTotalMessageSelect">1 Selected</p>
                    </div>
                    <div class="d-flex align-items-center">
                        <ul class="mb-0">
                            <li><a href="javascript:;" id="forwardMultiple" class="header-link" data-bs-toggle="modal" data-bs-target="#forwardModal"><i data-feather="corner-up-right" class="feather-20"></i> Forward</a></li>
                            <li><a href="javascript:;" id="MultipleMsgDelete" class="header-link"><i data-feather="trash-2" class="feather-20"></i> Delete</a></li>
                        </ul>
                        <div class="vr"></div>
                        <ul class="mb-0">
                            <li><a href="javascript:;" id="MultipleMsgCancel" class="header-link">Cancel</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Multiple Selected Message Code End -->

            </header>
            <!-- Header End -->

            <!-- Chat Area Start -->
            <section class="chat-area position-relative d-none" id="MainChatArea">
                <div class="chat-area-bottom-space" id="MessageList">
                    <!-- recieve-message -->
                    <!-- send-message -->
                    <!-- unread -->
                    <!-- read -->
                    <!-- message-deleted -->
                    <!-- select-message -->
                    <!-- message-reply -->
                </div>

                <div class="textarea-outer-container">
                    <div class="typing-preview d-none">
                        <div class="typing-dot"></div>
                        <p class="mb-0">typing...</p>
                    </div>
                    <div class="textarea-inner-container">
                        <div class="textarea-reply-container">
                            <!-- <div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">You <a href="javascript:;" class="close-reply"><i data-feather="x" class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-file-preview">
                                        <img src="./images/svgs/file.svg" alt="File">
                                    </div>
                                    <p class="mb-0 message">Master_image_preview.png</p>
                                </div>
                            </div> -->
                        </div>

                        <div class="main-container">
                            <div class="teatarea-file-upload" id="fileUploadDiv">

                            </div>
                            <div class="form-control editor show" id="vMessage" contenteditable="true"></div>
                            <div class="d-flex align-items-center justify-content-between toolbar">
                                <ul class="mb-0 type-functions">
                                    <li class="d-inline-block">
                                        <a href="javascript:;" class="bold textarea-functions-icon textEditorSpecial"><i data-feather="bold" class="feather-20"></i></a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="javascript:;" class="italic textarea-functions-icon textEditorSpecial"><i data-feather="italic" class="feather-20"></i></a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="javascript:;" class="underline textarea-functions-icon textEditorSpecial"><i data-feather="underline" class="feather-20"></i></a>
                                    </li>
                                    <li class="d-inline-block">
                                        <div class="dropdown dropup">
                                            <button class="dummy-button textarea-functions-icon" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <div class="color-circle"></div>
                                            </button>
                                            <div class="dropdown-menu color-dd">
                                                <ul class="colors-list">
                                                    <li class="color_picker" data-color="#EA3843"><button class="color-button dummy-button" style="background-color: #EA3843" data-color="#EA3843"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FF8A00"><button class="color-button dummy-button" style="background-color: #FF8A00" data-color="#FF8A00"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FFB800"><button class="color-button dummy-button" style="background-color: #FFB800" data-color="#FFB800"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#49BA14"><button class="color-button dummy-button" style="background-color: #49BA14" data-color="#49BA14"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#398415"><button class="color-button dummy-button" style="background-color: #398415" data-color="#398415"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#00A3EF"><button class="color-button dummy-button" style="background-color: #00A3EF" data-color="#00A3EF"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#263DB8"><button class="color-button dummy-button" style="background-color: #263DB8" data-color="#263DB8"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FF5BA0"><button class="color-button dummy-button" style="background-color: #FF5BA0" data-color="#FF5BA0"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#212121"><button class="color-button dummy-button" style="background-color: #212121" data-color="#212121"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#808080"><button class="color-button dummy-button" style="background-color: #808080" data-color="#808080"></button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="javascript:;" class="strikethrough textarea-functions-icon textEditorSpecial"><i data-feather="minus" class="feather-20"></i></a>
                                    </li>
                                    <li class="d-inline-block">
                                        <a href="javascript:;" class="bulleted-list textarea-functions-icon textEditorSpecial"><i data-feather="list" class="feather-20"></i></a>
                                    </li>
                                    <li class="d-inline-block">
                                        <div class="dropdown">
                                            <button class="dummy-button textarea-functions-icon" type="button" data-bs-toggle="dropdown">
                                                <i data-feather="link-2" class="feather-20"></i>
                                            </button>
                                            <div class="dropdown-menu add-link-dd">
                                                <form action="">
                                                    <div class="mb-3">
                                                        <label class="form-label">Text<span>*</span></label>
                                                        <input type="email" class="form-control">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Link<span>*</span></label>
                                                        <input type="email" class="form-control">
                                                    </div>
                                                    <!-- <input type="text" class="form-control mb-3" placeholder="Text"> -->
                                                    <!-- <input type="url" class="form-control" placeholder="Link"> -->
                                                    <button class="btn btn-primary mt-2 w-100">Apply</button>
                                                </form>
                                            </div>
                                        </div>

                                        <!-- <a href="javascript:;" class="textarea-functions-icon"><i data-feather="link-2"
                                                class="feather-20"></i></a> -->
                                    </li>
                                </ul>

                                <ul class="mb-0 textarea-functions">
                                    <li class="type-link">
                                        <a href="javascript:;" class="type textarea-functions-icon textEditorSpecial"><i data-feather="type" class="feather-20"></i></a>
                                    </li>
                                    <li class="emoji-link">
                                        <div class="dropdown emoji-dropdown">
                                            <a href="javascript:;" class="dummy-button textarea-functions-icon" type="button" id="emojiDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i data-feather="smile" class="feather-20"></i>
                                            </a>
                                            <ul class="dropdown-menu" aria-labelledby="emojiDropdown">
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😁"><img src="./images/emojis/beaming-face-with-smiling-eyes.png" alt="😁"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😀"><img src="./images/emojis/grinning-face.png" alt="😀"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😇"><img src="./images/emojis/smiling-face-with-halo.png" alt="😇"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👉🏻"><img src="./images/emojis/backhand-index-pointing-right.png" alt="👉🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👇🏻"><img src="./images/emojis/backhand-index-pointing-down.png" alt="👇🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👈🏻"><img src="./images/emojis/backhand-index-pointing-left.png" alt="👈🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👆🏻"><img src="./images/emojis/backhand-index-pointing-up.png" alt="👆🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☝🏻"><img src="./images/emojis/index-pointing-up.png" alt="☝🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✌🏻"><img src="./images/emojis/victory-hand.png" alt="✌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👌🏻"><img src="./images/emojis/ok-hand.png" alt="👌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👍🏻"><img src="./images/emojis/thumbs-up.png" alt="👍🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👎🏻"><img src="./images/emojis/thumbs-down.png" alt="👎🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🙌🏻"><img src="./images/emojis/raising-hands.png" alt="🙌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👏🏻"><img src="./images/emojis/clapping-hands.png" alt="👏🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🙏🏻"><img src="./images/emojis/folded-hands.png" alt="🙏🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✉️"><img src="./images/emojis/envelope.png" alt="✉️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☕"><img src="./images/emojis/hot-beverage.png" alt="☕"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🍽️"><img src="./images/emojis/fork-and-knife-with-plate.png" alt="🍽️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🌏"><img src="./images/emojis/globe-showing-asia-australia.png" alt="🌏"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="⛳"><img src="./images/emojis/flag-in-hole.png" alt="⛳"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🎯"><img src="./images/emojis/bullseye.png" alt="🎯"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="💡"><img src="./images/emojis/light-bulb.png" alt="💡"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✅"><img src="./images/emojis/check-mark-button.png" alt="✅"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☑️"><img src="./images/emojis/check-box-with-check.png" alt="☑️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✔️"><img src="./images/emojis/check-mark.png" alt="✔️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❎"><img src="./images/emojis/cross-mark-button.png" alt="❎"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❌"><img src="./images/emojis/cross-mark.png" alt="❌"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❓"><img src="./images/emojis/red-question-mark.png" alt="❓"></button></li>
                                            </ul>
                                        </div>
                                        <!-- <a href="javascript:;"><i data-feather="smile" class="feather-20"></i></a> -->
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="textarea-functions-icon upload-file"><i data-feather="upload" class="feather-20"></i></a>
                                        <input type="file" class="d-none upload-file-input" id="fileInput" multiple>
                                        <!-- <p class="file-preview"></p> -->
                                    </li>
                                    <li>
                                        <div class="line"></div>
                                    </li>
                                    <li>
                                        <a href="javascript:;" class="textarea-functions-icon disabled" id="sendMessage"><img src="./images/svgs/send.svg" alt="Send"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Chat Area End -->
        </div>
    </div>


    <!-- Forward Modal Form Code Start -->
    <div class="modal fade forwardModal" id="forwardModal" tabindex="-1" aria-labelledby="forwardModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-base">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-6 p-0">
                            <div class="modal-left">
                                <div class="fixed-content">
                                    <div class="modal-header-custom">
                                        <p class="title">Forward To...</p>
                                        <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                    </div>

                                    <div class="searchBar mt-2">
                                        <span><i data-feather="search" class="feather-20"></i></span>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>

                                <input type="hidden" name="iActiveMessageId" id="iActiveMessageId" value="" />
                                <input type="hidden" name="vActiveMessage" id="vActiveMessage" value="" />
                                <input type="hidden" name="vForwardDataType" id="vForwardDataType" value="" />

                                <ul class="mb-0 mt-2 list" id="forwrdModalGrpMembList">
                                </ul>

                            </div>
                        </div>
                        <div class="col-lg-6 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="list user-selected">
                                        <ul id="ForwardSelTags">
                                        </ul>
                                    </div>

                                    <div class="add-group-popup-btn-container">
                                        <button type="button" class="group-popup-btn d-none" id="submitForwardForm">Forward</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Forward Modal Form Code Ednd -->

    <!-- Group Info Modal Start -->
    <div class="modal fade groupDetails" id="groupDetails" tabindex="-1" aria-labelledby="groupDetailsLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-4 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="d-flex align-items-start">
                                        <div class="nav flex-column nav-pills" id="grouep-details" role="tablist" aria-orientation="vertical">
                                            <button class="nav-link active" id="group-basic-details" data-bs-toggle="pill" data-bs-target="#group-basic-details-pill" type="button" role="tab" aria-controls="group-basic-details-pill" aria-selected="true">Basic Details</button>
                                            <button class="nav-link" id="groupMembersTab" data-bs-toggle="pill" data-bs-target="#group-members-pill" type="button" role="tab" aria-controls="group-members-pill" aria-selected="false">Members</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 p-0">
                            <div class="modal-left">
                                <div class="tab-content" id="grouep-details">
                                    <!-- Group Basic Details Start -->
                                    <div class="tab-pane fade show active" id="group-basic-details-pill" role="tabpanel" aria-labelledby="group-basic-details" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Basic Details</p>
                                                <button type="button" class="modal-close-btn" id="groupDetailsClose"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <div class="d-flex mb-3">
                                                        <div class="group-profile-container">
                                                            <img src="images/profile/group-profile.svg" class="rounded-3" alt="Group Profile" id="vGroupInforProfile">
                                                        </div>
                                                    </div>

                                                    <p class="profile-view-title mb-3" id="vGroupInforName">Acme Corp.</p>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Created</p>
                                                        <p class="profile-view-disc mb-0" id="vGroupInfCreateDate">13 May 2024 12:52PM</p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Discription</p>
                                                        <p class="profile-view-disc mb-0" id="vGroupInfoDescription">Duis aute irure dolor in
                                                            reprehenderit in voluptate velit esse cillum dolore eu
                                                            fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                                            proident, sunt in culpa qui officia deserunt mollit anim id
                                                            ... </p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Group Admin</p>
                                                        <ul>
                                                            <li>
                                                                <a href="javascript:;" class="chat-list">
                                                                    <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="user-profile-image me-3">
                                                                                <svg role="none" viewBox="0 0 96 96">
                                                                                    <mask id="profile-image">
                                                                                        <circle fill="white" cx="48" cy="48" r="48">
                                                                                        </circle>
                                                                                        <circle fill="black" cx="86%" cy="86%" r="18">
                                                                                        </circle>
                                                                                    </mask>
                                                                                    <g mask="url(#profile-image)">
                                                                                        <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="vGroupOwnerProfile" xlink:href="images/profile/user-profile.svg">
                                                                                        </image>
                                                                                    </g>
                                                                                </svg>
                                                                                <div class="online" id="vGroupOwnerStsCls"></div>
                                                                            </div>
                                                                            <div>
                                                                                <h5 class="user-profile-name" id="vGroupOwnerName">Abhay A.
                                                                                    Achariya </h5>
                                                                                <p class="user-profile-activity" id="vGroupOwnerSts">Online
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </label>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Group Basic Details End -->

                                    <!-- Group Members Start -->
                                    <div class="tab-pane fade" id="group-members-pill" role="tabpanel" aria-labelledby="group-members" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Members</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>

                                            <div class="searchBar mt-2">
                                                <span><i data-feather="search" class="feather-20"></i></span>
                                                <input type="text" class="form-control" id="vGroupInfoSearchMember">
                                            </div>
                                        </div>

                                        <ul class="mb-0 mt-2 list" id="vGroupInfoMemeberList">
                                        </ul>
                                    </div>
                                    <!-- Group Members End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Group Info Modal End -->

    <!-- Group Info Modal Edit Start -->
    <div class="modal fade groupDetails" id="groupDetailsEdit" tabindex="-1" aria-labelledby="groupDetailsEditLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-4 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="d-flex align-items-start">
                                        <div class="nav flex-column nav-pills" id="grouep-details-edit" role="tablist" aria-orientation="vertical">
                                            <button class="nav-link active" id="vEditGrupBasicDetBtn" data-bs-toggle="pill" data-bs-target="#group-basic-details-edit-pill" type="button" role="tab" aria-controls="group-basic-details-edit-pill" aria-selected="true">Basic Details</button>
                                            <button class="nav-link" id="vGroupEditMemberList" data-bs-toggle="pill" data-bs-target="#group-members-edit-pill" type="button" role="tab" aria-controls="group-members-edit-pill" aria-selected="false">Members</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 p-0">
                            <div class="modal-left">
                                <div class="tab-content" id="grouep-details-edit">
                                    <!-- Group Basic Details Start -->
                                    <div class="tab-pane fade show active" id="group-basic-details-edit-pill" role="tabpanel" aria-labelledby="group-basic-details-edit" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Basic Details</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <p class="title">Group Picture</p>
                                                    <div class="d-flex mb-3">
                                                        <div class="group-profile-container">
                                                            <img src="images/profile/group-profile.svg" class="rounded-3" alt="Group Profile" id="vGroupEditProfile">
                                                            <a href="javascript:;" id="vEditProfilePickBtn" class="edit-icon">
                                                                <i data-feather="edit-3" class="feather-20"></i>
                                                            </a>
                                                        </div>
                                                    </div>

                                                    <div class="create-group-form">
                                                        <div class="mb-3">
                                                            <label class="form-label">Group Name<span>*</span></label>
                                                            <input type="text" class="form-control" id="vEditGrupName">
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label">Description</label>
                                                            <textarea class="form-control" rows="4" id="vEditGroupDesc"></textarea>
                                                            <span class="max-car-length text-end w-100 d-block pt-2">0/350</span>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Group Admin</p>
                                                        <ul>
                                                            <li>
                                                                <a href="javascript:;" class="chat-list">
                                                                    <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="user-profile-image me-3">
                                                                                <svg role="none" viewBox="0 0 96 96">
                                                                                    <mask id="profile-image">
                                                                                        <circle fill="white" cx="48" cy="48" r="48">
                                                                                        </circle>
                                                                                        <circle fill="black" cx="86%" cy="86%" r="18">
                                                                                        </circle>
                                                                                    </mask>
                                                                                    <g mask="url(#profile-image)">
                                                                                        <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="vEditGropOwnProfile" xlink:href="images/profile/user-profile.svg">
                                                                                        </image>
                                                                                    </g>
                                                                                </svg>
                                                                                <div class="online" id="vEditGroupOwnerStsCls"></div>
                                                                            </div>
                                                                            <div>
                                                                                <h5 class="user-profile-name" id="vEditGroupOwnerName">Abhay A.
                                                                                    Achariya </h5>
                                                                                <p class="user-profile-activity" id="vEditGroupOwnerSts">Online
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </label>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn" id="UpdateGroupBasicDetail">Save</button>
                                        </div>
                                    </div>
                                    <!-- Group Basic Details End -->

                                    <!-- Group Members Start -->
                                    <div class="tab-pane fade" id="group-members-edit-pill" role="tabpanel" aria-labelledby="group-members-edit" tabindex="0">
                                        <div class="fixed-content">
                                            <div id="editGroupModalHeader" class="create-group-popup-header position-relative modal-header-custom">
                                                <a href="javascript:;" id="EditGroupModalBackBtn" class="close-new-group d-none"><i data-feather="arrow-left" class="feather-20"></i></a>
                                                <p id="editGroupHeaderTitle">Group Members</p>
                                                <a href="javascript:;" id="EditGroupModalCloseBtn" data-bs-dismiss="modal" class="close-new-group"><i data-feather="x" class="feather-20"></i></a>
                                            </div>

                                            <div class="search-add pt-2">
                                                <div class="searchBar me-2">
                                                    <span><i data-feather="search" class="feather-20"></i></span>
                                                    <input type="text" class="form-control" id="vSearchEditMember">
                                                </div>
                                                <div class="new-chat">
                                                    <button id="NewUserGrpBtn"><span><i data-feather="plus" class="feather-20"></i></span></button>
                                                </div>
                                            </div>
                                        </div>

                                        <ul class="mb-0 mt-2 list" id="vEditGrpMemeberOld">
                                        </ul>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn" id="vEditGrpButtonUpd">Save</button>
                                            <button type="button" class="group-popup-btn d-none" id="vEditGrpButtonAdd">Add</button>
                                        </div>
                                    </div>
                                    <!-- Group Members End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Group Info Modal Edit End -->


    <!-- Member Required Information Modal -->
    <div class="modal fade groupMemberModal" id="groupMemberModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a href="javascript:;" class="close-new-group"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Information</p>
                        <a href="javascript:;" data-bs-dismiss="modal" id="groupMemberModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="text-center">
                            <h4 class="title">At least one member is required for the group.</h4>
                        </div>
                        <div class="d-flex justify-content-center mt-3">
                            <button class="btn btn-primary" id="groupMemberModalSubmit">OK</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Member Required Information Modal -->

    <!-- Delete Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="groupDeleteModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a href="javascript:;" class="close-new-group"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Delete Confirm</p>
                        <a href="javascript:;" data-bs-dismiss="modal" id="groupDeleteModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="text-center">
                            <h4 class="title">Are you sure you want to delete group!</h4>
                        </div>
                        <div class="d-flex modal-btn-combine">
                            <button class="btn btn-danger" id="groupDeleteModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="groupDeleteModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Confirmation Modal -->

    <!-- Edit Profile Modal -->
    <div class="modal fade groupMemberModal" id="editProfileModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Edit Profile</p>
                        <a href="javascript:;" data-bs-dismiss="modal" id="editProfileModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>


                    <div class="groupMemberModalContainer">
                        <div class="create-group-form">
                            <div class="mb-3" data-error="Required">
                                <label class="form-label">Name<span>*</span></label>
                                <input type="text" class="form-control" id="vEditProfileFullName" value="">
                                <span class="alert alert-danger mt-2 d-none" id="vEditProfileFullNameErr">This field is required.</span>
                            </div>

                            <div class="mb-3" data-error="Required">
                                <label class="form-label">Status<span>*</span></label>
                                <div class="d-flex gap-3">
                                    <div class="form-check">
                                        <input class="form-check-input vEditPrflSts" type="radio" name="vEditProfileSts" id="vEditProfileStsAutomatic" value="2" checked>
                                        <label class="form-check-label" for="vEditProfileStsAutomatic">
                                            Automatic
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input vEditPrflSts" type="radio" name="vEditProfileSts" id="vEditProfileStsOnline" value="1">
                                        <label class="form-check-label" for="vEditProfileStsOnline">
                                            Online
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input vEditPrflSts" type="radio" name="vEditProfileSts" id="vEditProfileStsOffline" value="0">
                                        <label class="form-check-label" for="vEditProfileStsOffline">
                                            Offline
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- <div class="d-flex ">
                            <button class="btn btn-primary" id="editGroupProfileSubmit">Submit</button>
                            <button class="btn btn-secondary mx-3" id="editGroupProfileCancel">Cancel</button>
                        </div> -->

                        <div class="d-flex justify-content-end mt-3 gap-2">
                            <button class="btn btn-secondary" id="editGroupProfileCancel">Cancel</button>
                            <button class="btn btn-primary" id="editGroupProfileSubmit">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Profile Modal -->

    <!-- Edit Profile Picture Modal Start -->
    <div class="modal fade groupMemberModal" id="editProfilePickModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Edit Profile</p>
                        <a href="javascript:;" data-bs-dismiss="modal" id="editProfilePickModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>


                    <div class="groupMemberModalContainer">
                        <div class="create-group-profile">
                            <div>
                                <p class="title">Profile Picture</p>
                                <div class="d-flex justify-content-center mb-3">
                                    <div class="group-profile-container">
                                        <img src="images/profile/group-profile.svg" class="rounded-circle" alt="Group Profile" id="vEditUserProfilePick">
                                        <a href="javascript:;" id="vEditUserProfilePickBtn" class="edit-icon">
                                            <i data-feather="edit-3" class="feather-20"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end mt-3 gap-2">
                            <button class="btn btn-secondary" id="editProfilePickModalCancel">Cancel</button>
                            <button class="btn btn-primary" id="editProfilePickModalSubmit">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Profile Picture Modal End -->

    <!-- Edit Group Profile -->
    <div class="modal fade changeProfile" id="vGroupProfilePickModal" tabindex="-1" aria-labelledby="changeProfileLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <a href="javascript:;" id="vBackGroupProfilePick"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p id="ImageCropperHeading">Create New Group</p>
                        <a href="javascript:;" id="vGroupProfilePickClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="system-default">
                        <p class="title">Custom Profile</p>
                        <ul class="mb-0">
                            <li>
                                <div class="d-flex align-items-center">
                                    <label class="cabinet profile">
                                        <figure>
                                            <img src="./images/profile/custom-group-profile.svg" class="gambar img-responsive img-thumbnail" alt="custom-group-profile" id="item-img-output">
                                        </figure>
                                        <input type="file" class="item-img file center-block" id="file_photo" name="file_photo" />
                                        <div class="add-group-popup-btn-container ms-2">
                                            <button type="button" style="pointer-events: none;" id="vChooseProfileBtn" class="group-popup-btn">Choose Profile</button>
                                        </div>
                                    </label>
                                    <div class="add-group-popup-btn-container ms-2">
                                        <button type="button" class="btn btn-danger d-none" id="deletGroupProfile">Delete Profile</button>
                                    </div>
                                </div>
                                <!-- <div style="display: flex;">
                                </div> -->
                            </li>
                        </ul>
                    </div>

                    <div class="chat-time-line">
                        <p>OR</p>
                    </div>

                    <div class="system-default">
                        <p class="title">System Default</p>
                        <ul id="vColorOptionHtml">
                        </ul>
                    </div>

                    <div class="system-default">
                        <button type="button" class="btn btn-primary" id="NewGroupProfilePickSubmit">Save</button>
                        <button type="button" class="btn btn-primary d-none" id="EditUserProfileSubmit">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Profile End -->

    <!-- Crop Profile Start -->
    <div class="modal fade cropImagePop" id="cropImagePop" tabindex="-1" aria-labelledby="cropImagePopLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <a href="javascript:;" class="close-new-group"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p>Move & Scale Profile</p>
                        <a href="javascript:;" data-bs-dismiss="modal" class="close-new-group"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="d-flex justify-content-center">
                        <div id="upload-demo" class="center-block"></div>
                    </div>
                    <div class="d-flex justify-content-center" style="padding: 12px;">
                        <div class="add-group-popup-btn-container mt-2">
                            <button type="button" id="cropImageBtn" class="group-popup-btn">Choose</button>
                        </div>
                    </div>
                    <!-- <button type="button" id="cropImageBtn" class="btn btn-primary">Crop Profile</button> -->
                </div>
            </div>
        </div>
    </div>
    <!-- Crop Profile End -->


    <!-- Delete Single Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="msgDelConfirmModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a href="javascript:;" id="msgDelConfirmModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="text-center">
                            <h4 class="title">Are you sure you want to delete message!</h4>
                        </div>
                        <div class="d-flex modal-btn-combine">
                            <button class="btn btn-danger" id="msgDelConfirmModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="msgDelConfirmModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Single Message Confirmation Modal -->


    <!-- Delete Multiple Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="msgMultiDelConfirmModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a href="javascript:;" id="msgMultiDelConfirmModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="text-center">
                            <h4 class="title">Are you sure you want to delete message!</h4>
                        </div>
                        <div class="d-flex modal-btn-combine">
                            <button class="btn btn-danger" id="msgMultiDelConfirmModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="msgMultiDelConfirmModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Multiple Message Confirmation Modal -->


    <!-- Delete Multiple Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="delGrpProfConfModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a href="javascript:;" id="delGrpProfConfModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="text-center">
                            <h4 class="title">Are you sure you want to delete profile picture!</h4>
                        </div>
                        <div class="d-flex modal-btn-combine">
                            <button class="btn btn-danger" id="delGrpProfConfModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="delGrpProfConfModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Multiple Message Confirmation Modal -->

    <script src="plugins/jquery/jquery.min.js"></script>
    <script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="https://foliotek.github.io/Croppie/croppie.js"></script>
    <script src="plugins/feather-icon/feather.min.js"></script>
    <script src="plugins/socket/socket.io.min.js"></script>

    <script>
        const API_URL = "<?= $API_URL ?>";
    </script>
    <script src="js/custom2.js"></script>
    <script src="js/CustomFun.js"></script>
    <script src="js/main.js"></script>
</body>

</html>