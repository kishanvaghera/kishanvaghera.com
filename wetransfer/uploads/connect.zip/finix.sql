-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 192.168.1.35:3306
-- Generation Time: Jun 12, 2024 at 11:59 AM
-- Server version: 11.0.3-MariaDB-log
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_broadcast_grp`
--

CREATE TABLE `chat_broadcast_grp` (
  `iGroupId` int(11) NOT NULL,
  `vGroupName` varchar(255) NOT NULL,
  `vGroupImage` varchar(255) NOT NULL,
  `tGroupUsers` text NOT NULL,
  `tDescription` text NOT NULL,
  `iColorOption` int(11) NOT NULL,
  `dCreatedDate` datetime NOT NULL,
  `iCreatedBy` int(11) NOT NULL,
  `eGroupStatus` enum('y','n','d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_broadcast_grp`
--

INSERT INTO `chat_broadcast_grp` (`iGroupId`, `vGroupName`, `vGroupImage`, `tGroupUsers`, `tDescription`, `iColorOption`, `dCreatedDate`, `iCreatedBy`, `eGroupStatus`) VALUES
(15, 'new group', '', '37,39', '', 1, '2024-04-22 12:03:08', 40, 'd'),
(16, 'Yes Man', 'images/uploads/GroupProfile/1716533783178_solen-feyissa-fBfE9zjTkKw-unsplash.jpg', '40,41,42,43,44', 'hello! To all', 1, '2024-04-22 15:48:01', 37, 'y'),
(17, 'Stock suggestions', '', '41,42,40,37,39', '', 1, '2024-04-22 16:03:03', 38, 'y'),
(18, 'Group - 01', 'images/uploads/GroupProfile/1714108185722_IMG-20180608-WA0020.jpg', '37,39,44', '', 1, '2024-04-22 16:23:46', 43, 'y'),
(19, 'Share Bazar Tips', 'images/uploads/1713783483463_Screenshot 2023-12-21 190358.png', '43,44,40', '', 1, '2024-04-22 16:28:03', 37, 'y'),
(20, 'Hello...!', 'images/uploads/GroupProfile/1714108106689_IMG_20181203_053924.jpg', '37', '', 1, '2024-04-22 16:43:03', 43, 'y'),
(21, 'Test New', '', '44', '', 1, '2024-04-25 12:14:12', 37, 'y'),
(22, 'Test3', '', '43', '', 1, '2024-04-25 12:17:29', 37, 'y'),
(23, 'Enliven Family....', '', '37,38,39,40,41,42,44', '', 1, '2024-04-25 12:18:53', 43, 'd'),
(24, 'Knowledge Bank', 'images/uploads/GroupProfile/1714107674197_IMG_20180525_220131.jpg', '37', '', 1, '2024-04-25 12:38:31', 43, 'y'),
(25, 'Test', '', '37', '', 1, '2024-04-25 14:38:01', 42, 'd'),
(26, 'Test2', '', '37', '', 1, '2024-04-25 14:40:38', 42, 'd'),
(27, 'Finix Dev', '', '37,39', '', 1, '2024-04-26 09:35:29', 41, 'y'),
(28, 'yes ', 'images/uploads/GroupProfile/1714208353915_heart-beat-8112920-6497228.png', '41,40', '', 1, '2024-04-27 14:29:13', 37, 'y'),
(29, 'Safari', '', '37,39,40', '', 1, '2024-05-13 10:08:18', 38, 'y'),
(30, 'Chromium', '', '37,39,40,41,43,42,44', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before the final copy is available.', 2, '2024-05-13 10:11:29', 38, 'y'),
(31, 'Google', '', '37,40', '', 1, '2024-05-13 10:13:20', 38, 'y'),
(32, 'Nokia', '', '37,39,40,41,42', '', 2, '2024-05-13 10:30:18', 38, 'y'),
(33, 'Microsoft', 'images/uploads/GroupProfile/1715580952023_unnamed.jpg', '37', '', 1, '2024-05-13 11:45:52', 38, 'y'),
(34, '14-5-24', 'images/uploads/GroupProfile/1715666290041_profile avatar-picture.png', '37', '', 1, '2024-05-14 11:28:10', 42, 'd'),
(38, 'Comet', 'images/uploads/GroupProfile/1716363142821_comet-wallpaper.jpeg', '37', '', 0, '2024-05-22 10:02:05', 42, 'y'),
(39, 'MSN', '', '37', '', 2, '2024-05-22 10:02:53', 42, 'y'),
(40, 'aaa', 'images/uploads/GroupProfile/1716529849403_1715678932318_comet-wallpaper.jpeg', '37,38,44', 'aaa', 0, '2024-05-24 11:19:46', 42, 'y'),
(45, 'Stock Exchange', '', '37,38,39', '', 3, '2024-05-24 11:53:17', 42, 'y'),
(46, '25', '', '37', '', 1, '2024-05-24 16:04:54', 44, 'd'),
(47, 'dasasf', '', '37', '', 2, '2024-05-24 16:05:07', 44, 'd'),
(48, 'MERA GROUP', '', '41,42,43', 'Hello', 4, '2024-05-24 17:18:25', 44, 'y'),
(49, 'New Group', 'images/uploads/GroupProfile/1716553042086_comet-wallpaper.jpeg', '37,39,40', 'fsdfdsfdsfdfsdffsfsdfdfddd', 0, '2024-05-24 17:40:29', 38, 'y'),
(50, 'MNC', '', '39', 'Test message for this group ', 3, '2024-05-29 10:03:33', 38, 'd'),
(51, 'MD Test - 01', '', '37,38,42,44,45,46,49', 'Finix App Test', 2, '2024-05-29 11:50:14', 43, 'y'),
(52, 'dhiren test all ', '', '38,43,40', 'dhiren test all ', 3, '2024-05-29 11:54:26', 37, 'y'),
(53, 'dhiren test i to 1', '', '43', 'dhiren test i to 1', 1, '2024-05-29 11:55:04', 37, 'y'),
(54, 'new new', '', '38,43,44', 'new new', 4, '2024-05-29 15:44:43', 37, 'y'),
(55, 'OK', 'images/uploads/GroupProfile/1717053766943_1713783483463_Screenshot 2023-12-21 190358.png', '40,41', 'OK', 2, '2024-05-30 12:52:00', 44, 'd'),
(56, 'abc234', '', '38', 'Wikis are enabled by wiki software, otherwise known as wiki engines. A wiki engine, being a form of a content management system, differs from other web-based systems such as blog software or static site generators, in that the content is created without any defined owner or leader, and wikis have little inherent structure...', 4, '2024-06-03 14:54:37', 37, 'y'),
(57, 'new 1 group', '', '38,43', 'yes no', 4, '2024-06-04 11:07:24', 37, 'y'),
(63, 'Furiosa', '', '39,44,48', '', 2, '2024-06-04 12:25:27', 38, 'y'),
(64, 'MD-02', '', '37,38,39,40,45,46', 'Need to create new group for test between Groups and Chats...\n', 2, '2024-06-05 08:53:03', 43, 'y'),
(65, 'yes no', '', '38,43', 'hmmm', 3, '2024-06-05 15:08:57', 37, 'y'),
(66, 'TESTDDD', '', '37,38', 'SDSGDFHSDFHSDFD', 2, '2024-06-05 17:38:15', 40, 'y'),
(69, 'Rango', '', '44', 'Test Description', 3, '2024-06-06 11:12:33', 38, 'y'),
(70, 'a-c', '', '51', '', 4, '2024-06-07 15:57:04', 49, 'd'),
(71, 'c-a', '', '50', '', 3, '2024-06-07 15:58:55', 49, 'y'),
(72, 'b-c', '', '37,51', '', 2, '2024-06-07 16:12:19', 50, 'y'),
(73, 'D-A', '', '37,40,41,42,49,38', 'adkadakas\n', 3, '2024-06-08 09:06:43', 52, 'y'),
(74, 'Hunter', '', '39', 'Test Group Detail.', 2, '2024-06-08 09:18:58', 38, 'y'),
(75, 'cg-KV-a', '', '38,49', '', 1, '2024-06-08 12:17:57', 37, 'y'),
(76, 'Group Testing', '', '49,52', 'Group Testing\nGroup Testing', 2, '2024-06-08 12:27:09', 51, 'y'),
(77, 'GT', '', '49,52', 'jkjkl', 3, '2024-06-08 12:31:23', 51, 'y'),
(78, 'del grp', '', '49,51', '54654', 3, '2024-06-08 12:58:54', 52, 'y'),
(79, 'Victor', '', '39,48', 'Test Group', 2, '2024-06-08 15:19:51', 38, 'y'),
(80, 'A-F', '', '50,51,52,54,53', 'kjlsvbjxklv', 3, '2024-06-08 16:35:25', 49, 'y'),
(81, 'New Group - 10-06-2024', '', '56,58', '10-06-2024\n', 3, '2024-06-10 12:15:49', 57, 'y'),
(82, 'Group Testing-10-06-2024', '', '59,58,60,56,46,43,40,37', 'Group TestingGroup Testing\nGroup Testing', 1, '2024-06-10 12:27:28', 57, 'd'),
(83, 'll-mm', '', '68,56,57', '', 4, '2024-06-10 15:17:38', 67, 'd'),
(90, 'Furiosa', '', '38', 'Furiosa', 1, '2024-06-11 08:49:31', 48, 'y'),
(91, 'Balaji Industries', '', '48', 'Balaji Industries', 1, '2024-06-11 11:04:19', 38, 'd'),
(92, 'CDF', '', '37,38,43,45,56,57,59', 'Check Delete Functionalities', 1, '2024-06-11 16:27:21', 58, 'd'),
(93, 'CDF', '', '37,38,43,45,57,58,59,60,61', 'Check Delete Funtionality', 3, '2024-06-11 17:08:51', 56, 'y'),
(94, 'AABBCC', '', '37,38,43,57,58,67,68', 'Group Testing', 2, '2024-06-12 09:52:18', 56, 'y'),
(95, 'Delete Group', '', '37,38,39,40,57,58', 'Delete Group funtionality', 1, '2024-06-12 10:04:49', 56, 'd'),
(96, 'II-LL(a)-MM', '', '68,64', '', 2, '2024-06-12 12:26:13', 67, 'd'),
(97, 'II-LL(a)-mm', '', '64,68', '', 4, '2024-06-12 12:27:21', 67, 'y'),
(98, 'Group By BB', '', '56,58', 'asdsadasasd', 4, '2024-06-12 12:57:32', 57, 'y'),
(99, 'KV1-KV2-KV3', '', '71', '', 2, '2024-06-12 15:32:50', 69, 'y'),
(100, 'IJK-Group', '', '64,65', 'Group Utility Testing', 3, '2024-06-12 17:07:49', 66, 'y');

-- --------------------------------------------------------

--
-- Table structure for table `chat_users`
--

CREATE TABLE `chat_users` (
  `iUserId` int(11) NOT NULL,
  `iEngId` int(11) NOT NULL,
  `vUsername` varchar(255) NOT NULL,
  `vFullName` varchar(255) NOT NULL,
  `vPassword` varchar(255) NOT NULL,
  `vProfilePic` varchar(255) NOT NULL,
  `tToken` text NOT NULL,
  `vChatId` varchar(255) NOT NULL,
  `eCustStatus` enum('0','1','2') NOT NULL COMMENT '0=Offline 1=Online 2=Automatic',
  `iColorOption` int(11) NOT NULL,
  `tGroupIds` text NOT NULL,
  `iStatus` int(11) NOT NULL COMMENT '	0=Offline 1=Online',
  `dLoginDateTime` datetime NOT NULL,
  `eStatus` enum('y','n','d') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_users`
--

INSERT INTO `chat_users` (`iUserId`, `iEngId`, `vUsername`, `vFullName`, `vPassword`, `vProfilePic`, `tToken`, `vChatId`, `eCustStatus`, `iColorOption`, `tGroupIds`, `iStatus`, `dLoginDateTime`, `eStatus`) VALUES
(37, 6286, 'abc', 'Chetan Ghadiya', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDaGV0YW4gR2hhZGl5YSIsInZGdWxsTmFtZSI6IkNoZXRhbiBHaGFkaXlhIiwiTG9naW5UaW1lIjoxMDMwODA3MjI2NDAsImlhdCI6MTcxODAxMjA0NH0.QbC5EmlhLYcgyPVCQMH3PaIDljtIBmqg0PL0fNF0ZwQ', 'BdcSLZjDPcSLQFLNAAAd', '1', 2, '15,18,20,23,24,25,26,27,29,30,31,32,33,34,38,39,40,45,46,47,49,51,64,66,72,73,82,85,92,93,94,95', 0, '2024-06-10 15:04:04', 'y'),
(38, 6288, 'Kishan', 'Kishan Vaghera', '', 'images/uploads/profiles/1716611907390_comet-wallpaper.jpeg', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLaXNoYW4gVmFnaGVyYSIsInZGdWxsTmFtZSI6Iktpc2hhbiBWYWdoZXJhIiwiTG9naW5UaW1lIjoxMDMwOTExMDk5NjAsImlhdCI6MTcxODE4NTE2Nn0.Fel3EGhcaHG2m35JJlJoR_ULUCNW8OeoOZYsZXCfHKs', 'kkX4vWOICT617AjrAAGA', '1', 0, '52,54,56,57,65,73,75,84,90,92,93,94,95', 0, '2024-06-12 15:09:26', 'y'),
(39, 6285, 'cnp', 'cnp', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJjbnAiLCJ2RnVsbE5hbWUiOiJjbnAiLCJMb2dpblRpbWUiOjEwMzA2OTMxMDE2MCwiaWF0IjoxNzE3ODIxODM2fQ.FRc9KBnBUd1qOzyDZ0LTUGzqwMqxRrPVViD3jDQgZ5I', 'dTmq8h6Dw_MRCRqnAABV', '2', 1, '50,63,74\n,79,95', 0, '2024-06-08 10:13:56', 'y'),
(40, 6284, 'Vinayak Vekariya', 'Vinayak Vekariya', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJzZHNhZCIsInZGdWxsTmFtZSI6IlZpbmF5YWsgVmVrYXJpeWEiLCJMb2dpblRpbWUiOjEwMzA5MTI2MjkwMCwiaWF0IjoxNzE4MTg3NzE1fQ.xszbERd-_yw14lCK96UWGl1u73KcBF2Zo6b5c1QO2eA', '9J7X_GCEEg1eC6LhAAHd', '0', 3, '16,55,82,95', 0, '2024-06-12 15:51:55', 'y'),
(41, 6287, 'Brijesh Doshi', 'Brijesh Doshi', '', 'images/uploads/profiles/1717588404833_istockphoto-528415533-612x612.jpg', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCcmlqZXNoIERvc2hpIiwidkZ1bGxOYW1lIjoiQnJpamVzaCBEb3NoaSIsIkxvZ2luVGltZSI6MTAzMDU1MzAxNjAwLCJpYXQiOjE3MTc1ODgzNjB9.Lvq-62CgzDYdv0F25fD32DDY3qy-zgOh71wrMbEer5M', '7q2GnP4vAjnOzb-lAAFH', '0', 0, '17,28,48,73', 0, '2024-06-05 17:22:40', 'y'),
(42, 2154, 'FINIX FINIX', 'FINIX FINIX', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJGSU5JWCBGSU5JWCIsInZGdWxsTmFtZSI6IkZJTklYIEZJTklYIiwiTG9naW5UaW1lIjoxMDMwOTEzMjc3NjAsImlhdCI6MTcxODE4ODc5Nn0.qDfaVZ1CtmlYMFvJYKGsYSip9nlfJENoNcmt2oo3Y0g', 'nLjwWG4yeh7k_YGVAAIP', '2', 3, '', 0, '2024-06-12 16:09:56', 'y'),
(43, 6290, 'Meghdip Doshi', 'Meghdip Doshi', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJNZWdoZGlwIERvc2hpIiwidkZ1bGxOYW1lIjoiTWVnaGRpcCBEb3NoaSIsIkxvZ2luVGltZSI6MTAzMDgwMDYxMjYwLCJpYXQiOjE3MTgwMDEwMjF9.eczS1zVhXaizwp3ZcUwP6-bJDdZjfIv0qtHHQycTDas', 'T3I7QC6MFq-AmAIuAAA1', '1', 1, '19,22,53,82,92,93,94', 0, '2024-06-10 12:00:21', 'y'),
(44, 6291, 'Deep', 'Deep Javiya', '', 'images/uploads/profiles/1717669955220_3f6f818d-03a1-463f-b944-cc3ce52aca6c.jpg', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEZWVwIiwidkZ1bGxOYW1lIjoiRGVlcCBKYXZpeWEiLCJMb2dpblRpbWUiOjEwMzA5MTA5MTU0MCwiaWF0IjoxNzE4MTg0ODU5fQ.GEaB1t26ocRNVbt9nDVH8z5izOq9TbMSHiWjcKK8vcE', 'r3dnXGENZbJ_XSV2AAFs', '0', 0, '21,69\n,63,79', 0, '2024-06-12 15:04:19', 'y'),
(45, 5385, 'cp', 'cp', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTM4NSIsInZVc2VybmFtZSI6ImNwIiwidkZ1bGxOYW1lIjoiY3AiLCJMb2dpblRpbWUiOjEwMjk5ODIxNTE0MCwiaWF0IjoxNzE2NjM2OTE5fQ.MKm-TqozvhN0WyIBfVVw3e8umB3vfxjsbymYWCjVyjo', 'tVQOoSwsrqd1nTRHAABR', '2', 0, ',92,93', 0, '0000-00-00 00:00:00', 'y'),
(46, 6000, 'KC Gohel', 'KC Gohel', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLQyBHb2hlbCIsInZGdWxsTmFtZSI6IktDIEdvaGVsIiwiTG9naW5UaW1lIjoxMDMwNjQwMzI2MjAsImlhdCI6MTcxNzczMzg3N30.Sb5T5g0J5zn46-go-NVj_YGZFo8cNlXRwLLWHStSFIA', '2XYIEuy8v-PfQcziAAAR', '2', 1, ',63,82', 0, '2024-06-07 09:47:57', 'y'),
(48, 6700, 'Jacob', 'Jacob', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJkZnNkZnNkZiIsInZGdWxsTmFtZSI6IkphY29iIiwiTG9naW5UaW1lIjoxMDMwOTA5MjQwODAsImlhdCI6MTcxODE4MjA2OH0.oYwdF2lTrAG70QK5vIngLiCy6r73gy3PG6McRuEZqyc', 'QgZL0kbgo-MFSIsyAAGE', '1', 2, ',63,79,86,87,88,89,91', 0, '2024-06-12 14:17:48', 'y'),
(49, 6001, 'A', 'A', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBIiwidkZ1bGxOYW1lIjoiQSIsIkxvZ2luVGltZSI6MTAzMDgwMTU5ODQwLCJpYXQiOjE3MTgwMDI2NjR9.of6nCGIIhspV-IQ0yoPQ4uqHCzy_HL_0Qpt1BLIk3o4', 'uWzIL-MN4dHL9lJgAAAx', '1', 1, ',73,75,51,76,77,78', 0, '2024-06-10 12:27:44', 'y'),
(50, 6002, 'b', 'B', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCIiwidkZ1bGxOYW1lIjoiQiIsIkxvZ2luVGltZSI6MTAzMDY1NDA5MDgwLCJpYXQiOjE3MTc3NTY4MTh9.Poa-Bq4EfJqDmu7k14cVSzCeOwpfOf90DZJNpXr30A0', 'zufCX433tNgQzisPAAMw', '2', 1, '71,80', 0, '2024-06-07 16:10:18', 'y'),
(51, 6003, 'C', 'C', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJDIiwidkZ1bGxOYW1lIjoiQyIsIkxvZ2luVGltZSI6MTAzMDY5Nzc5MDAwLCJpYXQiOjE3MTc4Mjk2NTB9.fAX1YU_1WNq4Vab3sjfABClphxlIYQjfR5-mIUmMvMM', 'fdMA1UrKF2gPiiC2AAAp', '2', 1, '70,78,80', 0, '2024-06-08 12:24:10', 'y'),
(52, 6004, 'd', 'D', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJEIiwidkZ1bGxOYW1lIjoiRCIsIkxvZ2luVGltZSI6MTAzMDcwNTA2NDQwLCJpYXQiOjE3MTc4NDE3NzR9.9K5UUzVy1bz_tNLKufXOqjOmd1lLGAT6J9ZpcIz41rk', '12J79jr42a0DPgJIAADp', '1', 2, ',77,76,80', 0, '2024-06-08 15:46:14', 'y'),
(53, 6005, 'E', 'E', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJFIiwidkZ1bGxOYW1lIjoiRSIsIkxvZ2luVGltZSI6MTAzMDgwMTUxMDIwLCJpYXQiOjE3MTgwMDI1MTd9.ouvjkyxzpW1xQ-yO0_AmwVbRy4mEkvd_3BTUXxIj6KY', 'fGmMuCEZXyjltmpFAAAx', '2', 1, ',80', 0, '2024-06-10 12:25:17', 'y'),
(54, 6006, 'F', 'F', '', '', '', '', '2', 1, ',80', 1, '2024-06-07 14:36:04', 'y'),
(55, 48, 'Jamson', 'Jamson', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNDgiLCJ2VXNlcm5hbWUiOiJKYW1zb24iLCJ2RnVsbE5hbWUiOiJKYW1zb24iLCJMb2dpblRpbWUiOjEwMzA2OTA1NTQwMCwiaWF0IjoxNzE3ODE3NTkwfQ.P29FUVkKeMgoIoVUj0sqJUHHXTJPJsXyJ-cxz0zAUJk', '7kGLr7MWvY0LoT1yAAAd', '0', 0, '', 0, '0000-00-00 00:00:00', 'y'),
(56, 6007, 'AA', 'AA', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJBQSIsInZGdWxsTmFtZSI6IkFBIiwiTG9naW5UaW1lIjoxMDMwOTA5NTI1MjAsImlhdCI6MTcxODE4MjU0Mn0.3yxR8eschuX2Bg3zdAsUNV3QdFk4d3IqymgEqnLipmE', 'yCViRjIOW62eUVfzAAGV', '1', 3, ',81,82,83,92,98', 0, '2024-06-12 14:25:42', 'y'),
(57, 6008, 'BB', 'BB', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJCQiIsInZGdWxsTmFtZSI6IkJCIiwiTG9naW5UaW1lIjoxMDMwOTA5NjE1ODAsImlhdCI6MTcxODE4MjY5M30.vCPvzZpUsv0pZX3vo5gf9S_30KBFyiE8kzpUBQqoYSc', 'r_ldzMHfT4dpUaQEAAGz', '1', 2, ',83,92,93,94,95', 0, '2024-06-12 14:28:13', 'y'),
(58, 6009, 'CC', 'CC', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiIgIiwidkZ1bGxOYW1lIjoiQ0MiLCJMb2dpblRpbWUiOjEwMzA5MDk2NDQ2MCwiaWF0IjoxNzE4MTgyNzQxfQ.Xo93pNxAUnKkoTjrnFiCaH5oSr7JLtcaywIuQn_JleI', 'UCT1fRnLnzp7UGHjAAFM', '1', 1, ',81,82,93,94,95,98', 0, '2024-06-12 14:29:01', 'y'),
(59, 6010, 'DD', 'DD', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJERCIsInZGdWxsTmFtZSI6IkREIiwiTG9naW5UaW1lIjoxMDMwOTAxNjk0NjAsImlhdCI6MTcxODE2OTQ5MX0.fXxFEG5bhcLy1fVAjT0I9-vEpX-ZfpDG5QBm2ZyRu3s', '65981-U2MJryX6LJAACq', '2', 1, ',82,92,93', 0, '2024-06-12 10:48:11', 'y'),
(60, 6011, 'EE', 'EE', '', '', '', '', '2', 1, ',82,92,93', 1, '2024-06-07 14:36:04', 'y'),
(61, 6012, 'ff', 'FF', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJGRiIsInZGdWxsTmFtZSI6IkZGIiwiTG9naW5UaW1lIjoxMDMwOTE0MDEzMjAsImlhdCI6MTcxODE5MDAyMn0._KJzlnuw7QfXHgIe_uWKPNwylfffRmTPHxFNhmZle7w', 'BIdIlIsgbcmaweWDAAJA', '2', 1, ',93', 0, '2024-06-12 16:30:22', 'y'),
(62, 6013, 'GG', 'GG', '', '', '', '', '2', 1, '', 1, '2024-06-07 14:36:04', 'y'),
(63, 6014, 'dszafs', 'HH', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJISCIsInZGdWxsTmFtZSI6IkhIIiwiTG9naW5UaW1lIjoxMDMwOTEzOTA1ODAsImlhdCI6MTcxODE4OTg0M30.e8ChfuxyQQaiO8qc3MmnqNpBXQQwZQe0qqGq6pz5udI', 'o6MmyYvd2u7I6rVRAAI6', '2', 1, '', 0, '2024-06-12 16:27:23', 'y'),
(64, 6015, 'II', 'II', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiIxMSIsInZGdWxsTmFtZSI6IklJIiwiTG9naW5UaW1lIjoxMDMwOTE1MDA1MDAsImlhdCI6MTcxODE5MTY3NX0.hsLqYlcKawe53mgkz6WXwxg5AChjoOdNqtSdSSs_Cq0', 'YF8-yOFOQ4e0Q8pRAAAT', '2', 1, ',94,96,97,100', 1, '2024-06-12 16:57:55', 'y'),
(65, 6016, 'JJ', 'JJ', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJJSSIsInZGdWxsTmFtZSI6IkpKIiwiTG9naW5UaW1lIjoxMDMwOTE1MDU4NDAsImlhdCI6MTcxODE5MTc2NH0.PytsJ3BhTKfAuzwsq8jn_0uUwudYAX2kvcBJBJcigSo', 'BCV5lky2ER-U2mOTAAJx', '2', 1, ',100', 1, '2024-06-12 16:59:24', 'y'),
(66, 6017, 'KK', 'KK', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLSyIsInZGdWxsTmFtZSI6IktLIiwiTG9naW5UaW1lIjoxMDMwOTE1ODE1MDAsImlhdCI6MTcxODE5MzAyNX0.s8p7mfhbDXnHPDZFiGDQGFbqH9YejTqdCcpET4TuxII', 'TjIlNaR0ZVsKHRMEAAAZ', '2', 1, '', 1, '2024-06-12 17:20:25', 'y'),
(67, 6018, 'DFGSDFFG', 'LL', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJTREZTREYiLCJ2RnVsbE5hbWUiOiJMTCIsIkxvZ2luVGltZSI6MTAzMDkwNTE2MzgwLCJpYXQiOjE3MTgxNzUyNzN9.gAVdKAvB5mDEhn3onHxgCy57HJKufkfYBfgoTDhKm4o', 'qUtgVYE5VVoFN7TPAAHf', '2', 1, ',94', 0, '2024-06-12 12:24:33', 'y'),
(68, 6019, 'JJ', 'MM', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJsbCIsInZGdWxsTmFtZSI6Ik1NIiwiTG9naW5UaW1lIjoxMDMwOTE1MDMwODAsImlhdCI6MTcxODE5MTcxOH0.bC7EAoryZlP3XExNny6hpDPDhePuV28Eaqrb8n5ue_I', 'fMI-Q8VGKDWLqDodAAJv', '2', 1, ',83,94,96,97', 0, '2024-06-12 16:58:38', 'y'),
(69, 6020, 'KV1', 'KV1', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjEiLCJ2RnVsbE5hbWUiOiJLVjEiLCJMb2dpblRpbWUiOjEwMzA5MTEzNjQyMCwiaWF0IjoxNzE4MTg1NjA3fQ.w2xzCx2RjCxACbKT8tI0terOUNbdgKW62cI0MdV-kUI', 'Sxo9VoEjfOLWJSeqAAJK', '2', 1, '', 0, '2024-06-12 15:16:47', 'y'),
(70, 6021, 'KV2', 'KV2', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJkcyIsInZGdWxsTmFtZSI6IktWMiIsIkxvZ2luVGltZSI6MTAzMDkxNDU0OTYwLCJpYXQiOjE3MTgxOTA5MTZ9.KGpvOeDRsDb909lgiREMw0E6Ou-M_vhFINoZyV81Tkg', '_HX6xZ6rf4TCMNuCAAJM', '2', 1, ',99', 0, '2024-06-12 16:45:16', 'y'),
(71, 6022, 'KV3', 'KV3', '', '', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLVjMiLCJ2RnVsbE5hbWUiOiJLVjMiLCJMb2dpblRpbWUiOjEwMzA5MTQ2NTcwMCwiaWF0IjoxNzE4MTkxMDk1fQ.RIMr9E_7YADOuRbuTQzgbCJ7PzyZrOcaEoxsrGFnFgc', 'SEQYpP1ib7F35ccXAAAf', '2', 1, ',99', 1, '2024-06-12 16:48:15', 'y'),
(72, 6120, 'NN', 'sd', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJzZCIsInZGdWxsTmFtZSI6InNkIiwiTG9naW5UaW1lIjoxMDMwOTEyNTM4NDAsImlhdCI6MTcxODE4NzU2NH0.BlMocUUDotTYHcbBtLZC8D0EOgzZ-8NEaoDzlkd2U2U', 'VlUauhgitqkFW5EeAAHN', '0', 0, '', 0, '2024-06-12 15:49:24', 'y'),
(73, 3021, 'OO', 'OO', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJPTyIsInZGdWxsTmFtZSI6Ik9PIiwiTG9naW5UaW1lIjoxMDMwOTEyNTcwMjAsImlhdCI6MTcxODE4NzYxN30._yAdGqk-roOLCb2s7YbnxYo9Gm5XlwtF6-5ikjg9MmY', 'lhtdzX94amFLhQu4AAHV', '0', 0, '', 0, '2024-06-12 15:50:17', 'y'),
(74, 1234, 'KA', 'KA', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJLQSIsInZGdWxsTmFtZSI6IktBIiwiTG9naW5UaW1lIjoxMDMwOTEyNjgzNjAsImlhdCI6MTcxODE4NzgwNn0.rPbpxapsgQRCSpVZQlGX3Rk9vb6mrbOSa9JHYKi3cjM', 'JIzeo6nmHhAtDApBAAIv', '0', 0, '', 0, '2024-06-12 15:53:26', 'y'),
(75, 4567, 'DA', 'DA', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNDU2NyIsInZVc2VybmFtZSI6IkRBIiwidkZ1bGxOYW1lIjoiREEiLCJMb2dpblRpbWUiOjEwMzA5MTI2Nzg4MCwiaWF0IjoxNzE4MTg3Nzk4fQ._37h633SMgbVxc7OyujA_1LhB_nh8yWk6CNj6MnIhm4', 'Diz3iwuif2Yy5ssHAAI-', '0', 0, '', 0, '0000-00-00 00:00:00', 'y'),
(76, 7890, 'AK', 'AK', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNzg5MCIsInZVc2VybmFtZSI6IkFLIiwidkZ1bGxOYW1lIjoiQUsiLCJMb2dpblRpbWUiOjEwMzA5MTI3MjE0MCwiaWF0IjoxNzE4MTg3ODY5fQ.vbC0dRRJWDA8yKMYE_IGhPwtcCmxf13SwY0lLzRf7z4', 'p4TEmFUIEOqfTYr0AAHt', '0', 0, '', 0, '0000-00-00 00:00:00', 'y'),
(77, 5252, 'ABC', 'ABC', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTI1MiIsInZVc2VybmFtZSI6IkFCQyIsInZGdWxsTmFtZSI6IkFCQyIsIkxvZ2luVGltZSI6MTAzMDkxMzU5NTAwLCJpYXQiOjE3MTgxODkzMjV9.gCpcgfBcZ2txb4WjClZkYV8WcYQYC0SSnhBXZ6FXxHc', 'RG6vaIYm64NaTCdUAAIj', '0', 0, '', 0, '0000-00-00 00:00:00', 'y'),
(78, 5253, 'BCA', 'BCA', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpVXNlcklkIjoiNTI1MyIsInZVc2VybmFtZSI6IkJDQSIsInZGdWxsTmFtZSI6IkJDQSIsIkxvZ2luVGltZSI6MTAzMDkxMzYxMjQwLCJpYXQiOjE3MTgxODkzNTR9.SJ4KZ1Wnpqvq6BtkrTZohxj1_CRZoOJnXy0yDtSmZHY', 'WkyYLZ8yHYspntziAAIf', '0', 0, '', 1, '0000-00-00 00:00:00', 'y'),
(79, 5551, 'Terry', 'Terry', '', 'images/profile/profile.png', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2VXNlcm5hbWUiOiJUZXJyeSIsInZGdWxsTmFtZSI6IlRlcnJ5IiwiTG9naW5UaW1lIjoxMDMwOTE1ODQ0NDAsImlhdCI6MTcxODE5MzA3NH0.8Wz2yF5Lfyot0xqnLH3dDfywuqi_nw79GISyLmTmgc8', 'g8rVhcG5QYFDcbauAAAh', '1', 0, '', 0, '2024-06-12 17:21:14', 'y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_broadcast_grp`
--
ALTER TABLE `chat_broadcast_grp`
  ADD PRIMARY KEY (`iGroupId`);

--
-- Indexes for table `chat_users`
--
ALTER TABLE `chat_users`
  ADD PRIMARY KEY (`iUserId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_broadcast_grp`
--
ALTER TABLE `chat_broadcast_grp`
  MODIFY `iGroupId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `chat_users`
--
ALTER TABLE `chat_users`
  MODIFY `iUserId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
