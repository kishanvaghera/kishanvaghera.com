// Sidebar users-list-container Calculation
function setNewTop() {
    var userListContainerTop = $('.users-list-container').offset().top;
    var newTop = $(window).height() - userListContainerTop;
    $('.users-list-container').css('height', newTop + 'px');
}
$(window).on('resize', setNewTop);
setNewTop();


// Feather Icon
$(document).ready(function () {
    feather.replace();
});


// New Chat Open Popup
$(document).ready(function () {
    $('.new-chat').click(function () {
        $('.add-user-popup').addClass('active');
        adjustUserPopupHeight();
        $(window).resize(adjustUserPopupHeight);
    });

    $('.close-new-chat').click(function () {
        $('.add-user-popup').removeClass('active');
    });

    function adjustUserPopupHeight() {
        var containerOffset = $('.add-user-popup-container').offset();
        var userPopupOffset = $('.add-user-popup-users').offset();
        var topOfferBannerHeight = userPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 22;

        $('.add-user-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }
});

// New Add Group Popup
$(document).ready(function () {
    function adjustGroupPopupHeight() {
        var containerOffset = $('.add-group-popup-container').offset();
        var groupPopupOffset = $('.add-group-popup-users').offset();
        var topOfferBannerHeight = groupPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 57;

        $('.add-group-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
        $('.add-group-popup-users').css('min-height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }

    $('.new-chat-group').click(function () {
        $('.add-group-popup').addClass('active');
        adjustGroupPopupHeight();
        $(window).resize(adjustGroupPopupHeight);
    });

    $('.close-new-chat').click(function () {
        $('.add-group-popup').removeClass('active');
    });
});

// New Create Group Popup
$(document).ready(function () {
    function adjustGroupPopupHeight() {
        var containerOffset = $('.create-group-popup-container').offset();
        var groupPopupOffset = $('.create-group-popup-users').offset();
        var topOfferBannerHeight = groupPopupOffset.top - containerOffset.top;
        var windowHeight = $(window).height();
        var adjustedHeight = windowHeight * 0.14;
        var totalAdjustedHeight = adjustedHeight + topOfferBannerHeight + 57;

        $('.create-group-popup-users').css('height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
        $('.create-group-popup-users').css('min-height', 'calc(100dvh - ' + totalAdjustedHeight + 'px)');
    }

    $('.add-group-popup-btn').click(function () {
        $('.create-group-popup').addClass('active');
        adjustGroupPopupHeight();
        $(window).resize(adjustGroupPopupHeight);
    });

    $('.close-new-group').click(function () {
        $('.create-group-popup').removeClass('active');
    });
});


// New Add Group Popup - Chat List Checkbox
$(document).ready(function () {
    $('#flexCheckDefault').change(function () {
        var groupUsersCheck = $(this).closest('.chat-list');
        if ($(this).is(':checked')) {
            groupUsersCheck.addClass('active');
        } else {
            groupUsersCheck.removeClass('active');
        }
    });
});

// Chat Area Calculate Height
$(window).resize(function () {
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
});

$(document).ready(function () {
    $(".chat-area").css("height", "calc(100dvh - " + $(".chat-area").offset().top + "px)");
});

$(document).ready(function () {
    // Check on page load if the checkbox is checked initially
    $('.chat-message-outer-container.select-message .selection .form-check-input').each(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        }
    });

    // Listen for changes in the checkbox state
    $('.chat-message-outer-container.select-message .selection .form-check-input').change(function () {
        if ($(this).is(':checked')) {
            $(this).closest('.chat-message-outer-container').addClass('selected');
        } else {
            $(this).closest('.chat-message-outer-container').removeClass('selected');
        }
    });
});



$('.message-droper-name').each(function () {
    if ($(this).text().length < 8) {
        $(this).css('width', 'auto');
    }
});


function scrollBottom() {
    var div = document.getElementById('MessageList');
    div.scrollTop = div.scrollHeight;
}

$(document).ready(function () {
    scrollBottom()
})



$(".type").click(function (event) {
    event.stopPropagation(); // Prevents the click event from propagating to parent elements
    $(".type-functions").toggleClass("show");
});

// $(window).on('load', function () {
//     // Wait for all content to be loaded
//     var height = $('.textarea-reply-container').outerHeight();
//     var toolHeight = $('.toolbar').outerHeight();
//     var totalHeight = height + toolHeight;
//     var remainingHeight = 240 - totalHeight;

//     // Set max-height of .editor
//     $('.editor').css('max-height', '0px');
//     $('.editor.show').css('max-height', remainingHeight + 'px');

//     $('.teatarea-file-uploadeditor').css('max-height', '0px');
//     $('.teatarea-file-upload.show').css('max-height', remainingHeight + 'px');

//     console.log(remainingHeight);
// });


var outerheight = $('.textarea-outer-container').outerHeight() + 32 + 24;
// console.log(outerheight);
$(".chat-area-bottom-space").css("padding-bottom", outerheight + 'px');

$(".type.textarea-functions-icon").on("click",()=>{
    $(".placeholder").remove();
})
