<?php

$conn = new mysqli("192.168.1.35","root","123456","chatapp-dev");