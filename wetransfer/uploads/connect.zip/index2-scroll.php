<?php
include("config.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <title>Chat App</title>
    <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="./plugins/scrollbar/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://foliotek.github.io/Croppie/croppie.css">
</head>

<body>
    <div class="body-wrapper">
        <!-- Sidebar Start -->
        <aside class="sidebar">
            <div class="logo-box">
                <div class="h-100 d-flex align-items-center justify-content-between">
                    <img src="./images/logo.svg" width="48" height="48" alt="SPOT" id="logo">
                    <img src="./images/spot-logo.svg" alt="SPOT" id="logoTitle">
                </div>
            </div>
            <div class="main-user-profile">
                <div class="user-profile-image-box justify-content-between mb-3 pb-1">
                    <div class="d-flex align-items-center">
                        <div class="user-profile-image me-3">
                            <svg role="none" viewBox="0 0 96 96">
                                <mask id="profile-image">
                                    <circle fill="white" cx="48" cy="48" r="48"></circle>
                                    <circle fill="black" cx="86%" cy="86%" r="18"></circle>
                                </mask>
                                <g mask="url(#profile-image)">
                                    <image x="0" y="0" id="vProfilePick" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="images/profile/user-profile.svg"></image>
                                </g>
                            </svg>
                            <div class="online" id="vLoggedSts"></div>
                        </div>
                        <div>
                            <h5 class="user-profile-name" id="vUserName"></h5>
                            <P class="user-profile-activity" id="vUserLoggedSts">Online</P>
                        </div>
                    </div>
                    <div class="dropdown">
                        <span data-bs-toggle="dropdown" class="cursor-pointer">
                            <i data-feather="more-vertical" class="feather-20"></i>
                        </span>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <div class="dropdown-item cursor-pointer" id="vEditProfilePickDrop">Edit Profile</div>
                            </li>
                            <li>
                                <div class="dropdown-item cursor-pointer">Profile Status</div>
                                <ul class="dropdown-menu dropdown-submenu">
                                    <li>
                                        <div class="dropdown-item changeOnlineStst cursor-pointer" data-id="2"><span class="status-auto"></span> Automatic</div>
                                    </li>
                                    <li>
                                        <div class="dropdown-item changeOnlineStst cursor-pointer" data-id="1"><span class="status-online"></span> Online</div>
                                    </li>
                                    <li>
                                        <div class="dropdown-item changeOnlineStst cursor-pointer" data-id="0"><span class="status-offline"></span> Offline</div>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <div class="dropdown-item cursor-pointer" id="vLogoutBtn">Logout</div>
                            </li>
                        </ul>
                    </div>
                </div>

                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link sidebar-chat-group-tabs active" id="userChat" data-bs-toggle="tab" data-bs-target="#nav-chat" type="button" role="tab" aria-controls="nav-chat" aria-selected="true"><span id="newUserMsgindc" class="d-none"></span> Chats</button>
                        <button class="nav-link sidebar-chat-group-tabs" id="userGroup" data-bs-toggle="tab" data-bs-target="#nav-group" type="button" role="tab" aria-controls="nav-group" aria-selected="false"><span id="newGroupMsgindc" class="d-none"></span> Groups</button>
                    </div>
                </nav>
            </div>

            <input type="hidden" id="vConvertionChatArr" name="vConvertionChatArr" value="[]" />
            <input type="hidden" id="vChatUserListJson" name="vChatUserListJson" value="[]" />
            <input type="hidden" id="vActiveUserId" name="vActiveUserId" value="" />
            <input type="hidden" id="vChatGroupListJson" name="vChatGroupListJson" value="[]" />
            <input type="hidden" id="vActiveGroupId" name="vActiveGroupId" value="" />
            <input type="hidden" id="vReplyMsg" name="vReplyMsg" value="" />
            <input type="hidden" id="vReplyMsg_id" name="vReplyMsg_id" value="" />
            <input type="hidden" id="vReplyMsg_type" name="vReplyMsg_type" value="" />
            <input type="hidden" id="vReplyFileName" name="vReplyFileName" value="" />
            <input type="hidden" id="vNewGrpUserSelect" name="vNewGrpUserSelect" value="" />
            <input type="hidden" id="vActiveProfileSts" name="vActiveProfileSts" value="" />
            <input type="hidden" id="vLoggedColorOption" name="vLoggedColorOption" value="" />

            <div class="users-list-container mCustomScrollbar" data-mcs-theme="minimal">
                <div class="tab-content" id="nav-tabContent">
                    <!-- Chats Start -->
                    <div class="tab-pane fade show active" id="nav-chat" role="tabpanel" aria-labelledby="userChat" tabindex="0">
                        <div class="search-add py-3">
                            <div class="searchBar me-2">
                                <span><i data-feather="search" class="feather-20"></i></span>
                                <input type="text" class="form-control" id="vSearchUser">
                            </div>
                            <div class="new-chat" id="addNewChatModal">
                                <button><span><i data-feather="plus" class="feather-20"></i></span></button>
                            </div>
                        </div>

                        <ul id="chatUserList">
                        </ul>
                    </div>
                    <!-- Chats End -->

                    <!-- Groups Start -->
                    <div class="tab-pane fade position-relative" id="nav-group" role="tabpanel" aria-labelledby="userGroup" tabindex="0">
                        <div class="search-add py-3">
                            <div class="searchBar me-2">
                                <span><i data-feather="search" class="feather-20"></i></span>
                                <input type="text" class="form-control" id="searchGroupName">
                            </div>
                            <div class="new-chat new-chat-group" id="NewChatGroup">
                                <button id="CreateNewGroup"><span><i data-feather="plus" class="feather-20"></i></span></button>
                            </div>
                        </div>

                        <ul id="ChatGroupList">
                        </ul>
                    </div>
                    <!-- Groups End -->
                </div>
            </div>


            <!-- Add User Popup Start -->
            <div class="add-user-popup">
                <div class="add-user-popup-container">
                    <div class="add-user-popup-header position-relative">
                        <p>New Chat</p>
                        <a id="CloseNewChat" class="close-new-chat cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="add-user-popup-search">
                        <div class="searchBar">
                            <span><i data-feather="search" class="feather-20"></i></span>
                            <input type="text" class="form-control" id="SearchUserAllInp">
                        </div>
                    </div>
                    <div class="add-user-popup-users">
                        <ul id="vChatUserListAll"></ul>
                    </div>
                </div>
            </div>
            <!-- Add User Popup End -->

            <!-- Add Group Popup Start -->
            <div class="add-group-popup">
                <div class="add-group-popup-container">
                    <div class="add-group-popup-header position-relative">
                        <p>Create New Group</p>
                        <a class="close-new-chat cursor-pointer" id="CloseNewGroupUserModal"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="add-group-popup-search">
                        <div class="searchBar">
                            <span><i data-feather="search" class="feather-20"></i></span>
                            <input type="text" class="form-control" id="SeachNewGroupUser">
                        </div>
                    </div>
                    <div class="add-group-popup-users">
                        <ul id="NewGroupUserList"></ul>
                    </div>

                    <div class="add-group-popup-btn-container">
                        <button type="button" id="vCreateNewGroupNext" class="add-group-popup-btn">Next</button>
                    </div>
                </div>
            </div>
            <!-- Add Group Popup End -->

            <!-- Create New Group Popup Start -->
            <div class="create-group-popup">
                <div class="create-group-popup-container">
                    <div class="create-group-popup-header position-relative">
                        <a class="close-new-group cursor-pointer"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p>Create New Group</p>
                        <a class="close-new-group cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="create-group-popup-users">
                        <div class="create-group-profile">
                            <div class="text-center">
                                <p class="title">Group Picture</p>
                                <div class="d-flex justify-content-center mb-3">
                                    <div class="group-profile-container">
                                        <img src="images/profile/group-profile.svg" id="vGroupPicSelected" class="rounded-3" alt="Group Profile">
                                        <div class="edit-icon cursor-pointer" id="vGroupPicturePick">
                                            <i data-feather="edit-3" class="feather-20"></i>
                                        </div>
                                        <input type="file" class="d-none" id="vGroupPicture" />
                                    </div>
                                </div>
                            </div>

                            <div class="create-group-form">
                                <div class="mb-3" data-error="Required" id="vMessgErr">
                                    <label class="form-label">Group Name<span>*</span></label>
                                    <input type="text" class="form-control" id="vGroupName">
                                    <!-- <span class="alert alert-danger d-none" id="vGroupNameErr">This field is required</span> -->
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea class="form-control" rows="2" id="tDescription" maxlength="350"></textarea>
                                    <span class="max-car-length text-end w-100 d-block pt-2" id="totalCharDispCrtGrp">0/350</span>
                                </div>
                            </div>
                        </div>
                        <div class="create-group-admin">
                            <ul>
                                <li>
                                    <p class="title">Group Admin</p>
                                    <div class="chat-list cursor-pointer">
                                        <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3">
                                                    <svg role="none" viewBox="0 0 96 96">
                                                        <mask id="profile-image">
                                                            <circle fill="white" cx="48" cy="48" r="48">
                                                            </circle>
                                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                                            </circle>
                                                        </mask>
                                                        <g mask="url(#profile-image)">
                                                            <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" xlink:href="images/profile/user-profile.svg" id="vNewGrpOwnImg">
                                                            </image>
                                                        </g>
                                                    </svg>
                                                    <div class="online" id="vNewGroupOwnStsBadge"></div>
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name" id="vNewGroupOwnName">ABC </h5>
                                                    <P class="user-profile-activity" id="vNewGroupOwnSts">Online</P>
                                                </div>
                                            </div>

                                            <span><input class="form-check-input" type="checkbox" value="" id="flexCheckDefault2"></span>
                                        </label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="create-group-added-users">
                            <p class="title">Group Members</p>
                            <span class="alert alert-danger d-none" id="vGroupUserErr">Please add atleast one user.</span>
                            <ul id="newGroupMember"></ul>
                        </div>
                    </div>

                    <div class="add-group-popup-btn-container">
                        <button type="button" id="AddNewGroup" class="add-group-popup-btn">Create</button>
                    </div>
                </div>
            </div>
            <!-- Create New Group Popup End -->
        </aside>
        <!-- Sidebar End -->

        <div class="page-wrapper">
            <!-- Header Start -->
            <div class="d-flex align-items-center justify-content-center h-100" id="StartChatArea">
                <div class="text-center">
                    <h1 class="start-chat-title">Welcome to Chat App</h1>
                    <!-- <p class="start-chat-subtitle">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae repellendus similique?
                    </p> -->
                </div>
            </div>

            <header class="header pb-0 d-none" id="HeaderChatArea">
                <div class="border-bottom pb-3 main-header" id="topHeaderActiveArea">
                    <div class=" d-flex align-items-center justify-content-between position-relative">
                        <div>
                            <ul class="mb-0">
                                <li>
                                    <a class="chat-list cursor-pointer">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="d-flex align-items-center">
                                                <div class="user-profile-image me-3" id="vUseTabActive">
                                                    <svg role="none" viewBox="0 0 96 96">
                                                        <mask id="profile-image">
                                                            <circle fill="white" cx="48" cy="48" r="48">
                                                            </circle>
                                                            <circle fill="black" cx="86%" cy="86%" r="18">
                                                            </circle>
                                                        </mask>
                                                        <g mask="url(#profile-image)">
                                                            <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="activeChatProfile" xlink:href="images/profile/user-profile.svg">
                                                            </image>
                                                        </g>
                                                    </svg>
                                                    <div class="online" id="activeChatSts"></div>
                                                </div>
                                                <div class="user-profile-image me-3 d-none" id="vGroupTabActive">
                                                    <img src="images/profile/group-profile.svg" alt="group-profile" id="activeGroupProfile">
                                                </div>
                                                <div>
                                                    <h5 class="user-profile-name" id="activeChatName">Viktorya Daniel</h5>
                                                    <P class="user-profile-activity" id="activeChatStsDisp">Online</P>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- <div id="vRequestChatDiv" class="d-none">
                            <button id="vRequestChatBtn" class="btn btn-primary btn-sm d-flex align-items-center justify-content-center"><span class="d-flex align-items-center justify-content-center">Request Chat</button>
                        </div> -->

                        <div class="header-searchBar d-flex align-items-center">
                            <div class="searchBar me-2">
                                <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search feather-20">
                                        <circle cx="11" cy="11" r="8"></circle>
                                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                                    </svg></span>
                                <input type="text" class="form-control" id="vSearchText">
                                <div class="hide" id="dispSearchBox"><span id="activeSearchIndex">0</span><span>/</span><span id="totalSearchRecord">0</span></div>
                                <div class="d-flex align-items-center hide" id="vSearchNextBtn">
                                    <a class="cursor-pointer d-flex align-items-center feather-search-arrow"><i data-feather="arrow-right" class="feather feather-16"></i></a>
                                </div>
                            </div>
                            <div id="vCancelSearch"><i data-feather="x" class="feather feather-16"></i></div>
                        </div>

                        <div class="d-flex align-items-center">
                            <div id="vRequestChatDiv" class="d-none me-3">
                                <button id="vRequestChatBtn" class="btn btn-primary btn-sm d-flex align-items-center justify-content-center"><span class="d-flex align-items-center justify-content-center">Request Chat</button>
                            </div>
                            <div id="GroupDropDown">
                                <div class="dropdown">
                                    <span data-bs-toggle="dropdown" class="cursor-pointer">
                                        <i data-feather="more-vertical" class="feather-20"></i>
                                    </span>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li><a class="dropdown-item cursor-pointer" id="vGroupInfoBtn">Group Info</a></li>
                                        <li><a class="dropdown-item cursor-pointer" id="vGroupEditGroup">Edit Group</a></li>
                                        <li><a class="dropdown-item cursor-pointer" id="vGroupDeleteChat">Delete All Chat For Me</a></li>
                                        <li><a class="dropdown-item cursor-pointer" id="vExitGroup">Exit Group</a></li>
                                        <li><a class="dropdown-item cursor-pointer" id="vDeleteGroup">Delete group for me</a></li>

                                        <li><a class="dropdown-item cursor-pointer" id="vUserDeleteChat">Delete Chat</a></li>
                                        <li class="d-none"><a class="dropdown-item cursor-pointer" id="vCancelRequest">Cancel Chat Request</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- Multiple Selected Message Code Start -->
                <div class="border-bottom pb-3 d-flex align-items-center justify-content-between select-action d-none" id="MultipleSelectDiv">
                    <div>
                        <p class="select-count mb-0" id="iTotalMessageSelect">1 Selected</p>
                    </div>
                    <div class="d-flex align-items-center">
                        <ul class="mb-0">
                            <li><a id="forwardMultiple" class="header-link cursor-pointer" data-bs-toggle="modal" data-bs-target="#forwardModal"><i data-feather="corner-up-right" class="feather-20"></i> Forward</a></li>
                            <li><a id="downloadFiles" class="header-link cursor-pointer"><i data-feather="download" class="feather-20"></i> Download Files</a></li>
                            <li><a id="MultipleMsgDelete" class="header-link cursor-pointer"><i data-feather="trash-2" class="feather-20"></i> Delete</a></li>
                        </ul>
                        <div class="vr"></div>
                        <ul class="mb-0">
                            <li><a id="MultipleMsgCancel" class="header-link cursor-pointer">Cancel</a></li>
                        </ul>
                    </div>
                </div>
                <!-- Multiple Selected Message Code End -->

            </header>
            <!-- Header End -->

            <!-- Chat Area Start -->
            <section class="chat-area position-relative d-none scrollable" id="MainChatArea">
                <div class="chat-area-bottom-space" id="MessageList">
                    <!-- recieve-message -->
                    <!-- send-message -->
                    <!-- unread -->
                    <!-- read -->
                    <!-- message-deleted -->
                    <!-- select-message -->
                    <!-- message-reply -->
                </div>

                <div class="textarea-outer-container" id="TextEditorArea">
                    <div class="gradient-blur">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>

                    <div class="typing-preview d-none">
                        <div class="typing-dot"></div>
                        <p class="mb-0">typing...</p>
                    </div>
                    <div class="textarea-inner-container">
                        <div class="textarea-reply-container">
                            <!-- <div class="textarea-reply-inner-container">
                                <p class="mb-0 name d-flex align-items-center justify-content-between">You <a class="cursor-pointer close-reply"><i data-feather="x" class="feather-16"></i></a></p>
                                <div class="d-flex align-items-center">
                                    <div class="message-file-preview">
                                        <img src="./images/svgs/file.svg" alt="File">
                                    </div>
                                    <p class="mb-0 message">Master_image_preview.png</p>
                                </div>
                            </div> -->
                        </div>

                        <div class="main-container">
                            <div class="position-relative overflow-hidden rounded-3">
                                <div class="file-upload-loader-container d-none" id="fileUploadLoader">
                                    <div data-loader="circle-side" class="file-upload-loader"></div>
                                </div>
                                <div class="teatarea-file-upload scrollable2" id="fileUploadDiv">
                                    <div class="d-flex align-items-center justify-content-between teatarea-file-upload-data">
                                        <div class="d-flex align-items-center">
                                            <div class="position-relative">
                                                <img class="preview-image" src="./images/imagethumb2.png">
                                            </div>
                                            <div class="file-preview mb-0">No file selected</div>
                                        </div>
                                        <!-- <a class="close-reply cursor-pointer"><i data-feather="x" class="feather-16"></i></a> -->
                                    </div>
                                </div>
                            </div>
                            <div class="position-relative" id="texAreaEditorDiv">
                                <div class="plc-holder">Type your text here...</div>
                                <div class="form-control editor show" id="vMessage" contenteditable="true" autocomplete="off" spellcheck="false"></div>
                                <div class="editor-close d-none"><a class="close-reply cursor-pointer"><i data-feather="x" class="feather-16"></i></a></div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between toolbar">
                                <ul class="mb-0 type-functions">
                                    <li class="d-inline-block">
                                        <button type="button" class="bold textarea-functions-icon textEditorSpecial tip-top border-0 bg-transparent" title="Bold"><i data-feather="bold" class="feather-20"></i></button>
                                    </li>
                                    <li class="d-inline-block">
                                        <button type="button" class="italic textarea-functions-icon textEditorSpecial tip-top border-0 bg-transparent" title="Italic"><i data-feather="italic" class="feather-20"></i></button>
                                    </li>
                                    <li class="d-inline-block">
                                        <button type="button" class="underline textarea-functions-icon textEditorSpecial tip-top border-0 bg-transparent" title="Underline"><i data-feather="underline" class="feather-20"></i></button>
                                    </li>
                                    <li class="d-inline-block">
                                        <div class="dropdown dropup">
                                            <div data-bs-toggle="dropdown">
                                                <button class="dummy-button textarea-functions-icon" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Text Color" type="button">
                                                    <div class="color-circle"></div>
                                                </button>
                                            </div>
                                            <!-- <span class="d-block" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Text Color">
                                        </span> -->
                                            <div class="dropdown-menu color-dd">
                                                <ul class="colors-list">
                                                    <li class="color_picker" data-color="#EA3843"><button class="color-button dummy-button" style="background-color: #EA3843" data-color="#EA3843"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FF8A00"><button class="color-button dummy-button" style="background-color: #FF8A00" data-color="#FF8A00"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FFB800"><button class="color-button dummy-button" style="background-color: #FFB800" data-color="#FFB800"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#49BA14"><button class="color-button dummy-button" style="background-color: #49BA14" data-color="#49BA14"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#398415"><button class="color-button dummy-button" style="background-color: #398415" data-color="#398415"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#00A3EF"><button class="color-button dummy-button" style="background-color: #00A3EF" data-color="#00A3EF"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#263DB8"><button class="color-button dummy-button" style="background-color: #263DB8" data-color="#263DB8"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#FF5BA0"><button class="color-button dummy-button" style="background-color: #FF5BA0" data-color="#FF5BA0"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#212121"><button class="color-button dummy-button" style="background-color: #212121" data-color="#212121"></button>
                                                    </li>
                                                    <li class="color_picker" data-color="#808080"><button class="color-button dummy-button" style="background-color: #808080" data-color="#808080"></button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="d-inline-block">
                                        <button type="button" class="strikethrough textarea-functions-icon textEditorSpecial tip-top border-0 bg-transparent" title="Strikethrough"><i data-feather="minus" class="feather-20"></i></button>
                                    </li>
                                    <li class="d-inline-block">
                                        <button type="button" class="bulleted-list textarea-functions-icon textEditorSpecial tip-top border-0 bg-transparent" title="Bulleted List"><i data-feather="list" class="feather-20"></i></button>
                                    </li>
                                    <li class="d-inline-block">
                                        <div class="dropdown ">
                                            <div data-bs-toggle="dropdown">
                                                <button class="dummy-button textarea-functions-icon tip-top" title="Insert Link" id="vLinkFeatureOption" type="button" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Insert Link">
                                                    <i data-feather="link-2" class="feather-20"></i>
                                                </button>
                                            </div>
                                            <div class="dropdown-menu add-link-dd" id="addLinkFeature">
                                                <div class="mb-3" id="vTextLinkDisp">
                                                    <label class="form-label">Text<span>*</span></label>
                                                    <input type="text" class="form-control" id="vLinkText">
                                                </div>
                                                <div class="mb-3">
                                                    <label class="form-label d-flex align-items-center justify-content-between">
                                                        <div>Link<span>*</span></div> <span id="vUnlinkTag" class="d-none p-1 cursor-pointer"><img src="./images/svgs/unlink2.svg" width="18px" alt=""></span>
                                                    </label>
                                                    <input type="text" class="form-control" id="vLinkFetLink">
                                                </div>
                                                <!-- <input type="text" class="form-control mb-3" placeholder="Text"> -->
                                                <!-- <input type="url" class="form-control" placeholder="Link"> -->
                                                <button class="btn btn-primary mt-2 w-100" id="ApplyLinkTag">Apply</button>
                                                <!-- <div class="d-flex gap-3">
                                                    <button class="btn btn-danger mt-2 w-100 d-none" id="vUnlinkTag">Unlink</button>
                                                </div> -->
                                            </div>
                                        </div>

                                        <!-- <a class="textarea-functions-icon cursor-pointer"><i data-feather="link-2"
                                                class="feather-20"></i></a> -->
                                    </li>
                                </ul>

                                <ul class="mb-0 textarea-functions">
                                    <li class="type-link">
                                        <button type="button" class="type textarea-functions-icon textEditorSpecial cursor-pointer border-0 bg-transparent" title="Formatting Options"><i data-feather="type" class="feather-20"></i></button>
                                    </li>
                                    <li class="emoji-link">
                                        <div class="dropdown emoji-dropdown">
                                            <button type="button" class="dummy-button textarea-functions-icon cursor-pointer border-0 bg-transparent" title="Add emoji" id="emojiDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i data-feather="smile" class="feather-20"></i>
                                            </button>
                                            <ul class="dropdown-menu" aria-labelledby="emojiDropdown">
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😁"><img src="./images/emojis/beaming-face-with-smiling-eyes.png" alt="😁"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😀"><img src="./images/emojis/grinning-face.png" alt="😀"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="😇"><img src="./images/emojis/smiling-face-with-halo.png" alt="😇"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👉🏻"><img src="./images/emojis/backhand-index-pointing-right.png" alt="👉🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👇🏻"><img src="./images/emojis/backhand-index-pointing-down.png" alt="👇🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👈🏻"><img src="./images/emojis/backhand-index-pointing-left.png" alt="👈🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👆🏻"><img src="./images/emojis/backhand-index-pointing-up.png" alt="👆🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☝🏻"><img src="./images/emojis/index-pointing-up.png" alt="☝🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✌🏻"><img src="./images/emojis/victory-hand.png" alt="✌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👌🏻"><img src="./images/emojis/ok-hand.png" alt="👌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👍🏻"><img src="./images/emojis/thumbs-up.png" alt="👍🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👎🏻"><img src="./images/emojis/thumbs-down.png" alt="👎🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🙌🏻"><img src="./images/emojis/raising-hands.png" alt="🙌🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="👏🏻"><img src="./images/emojis/clapping-hands.png" alt="👏🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🙏🏻"><img src="./images/emojis/folded-hands.png" alt="🙏🏻"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✉️"><img src="./images/emojis/envelope.png" alt="✉️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☕"><img src="./images/emojis/hot-beverage.png" alt="☕"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🍽️"><img src="./images/emojis/fork-and-knife-with-plate.png" alt="🍽️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🌏"><img src="./images/emojis/globe-showing-asia-australia.png" alt="🌏"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="⛳"><img src="./images/emojis/flag-in-hole.png" alt="⛳"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="🎯"><img src="./images/emojis/bullseye.png" alt="🎯"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="💡"><img src="./images/emojis/light-bulb.png" alt="💡"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✅"><img src="./images/emojis/check-mark-button.png" alt="✅"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="☑️"><img src="./images/emojis/check-box-with-check.png" alt="☑️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="✔️"><img src="./images/emojis/check-mark.png" alt="✔️"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❎"><img src="./images/emojis/cross-mark-button.png" alt="❎"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❌"><img src="./images/emojis/cross-mark.png" alt="❌"></button></li>
                                                <li style="display: inline-block;"><button class="dropdown-item emoji" data-emoji="❓"><img src="./images/emojis/red-question-mark.png" alt="❓"></button></li>
                                            </ul>
                                        </div>
                                        <!-- <a class="cursor-pointer"><i data-feather="smile" class="feather-20"></i></a> -->
                                    </li>
                                    <li>
                                        <button type="button" class="textarea-functions-icon upload-file cursor-pointer border-0 bg-transparent" id="fileUploadButtton" title="Upload File"><i data-feather="upload" class="feather-20"></i></button>
                                        <input type="file" class="d-none upload-file-input" id="fileInput" multiple>
                                        <!-- <p class="file-preview"></p> -->
                                    </li>
                                    <li>
                                        <div class="line"></div>
                                    </li>
                                    <li>
                                        <a class="textarea-functions-icon disabled cursor-pointer" id="sendMessage"><img src="./images/svgs/send.svg" alt="Send"></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Chat Area End -->
        </div>
    </div>


    <!-- Forward Modal Form Code Start -->
    <div class="modal fade forwardModal" id="forwardModal" tabindex="-1" aria-labelledby="forwardModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-base">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-6 p-0">
                            <div class="modal-left">
                                <div class="fixed-content">
                                    <div class="modal-header-custom">
                                        <p class="title">Forward To...</p>
                                        <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                    </div>

                                    <div class="searchBar mt-2">
                                        <span><i data-feather="search" class="feather-20"></i></span>
                                        <input type="text" class="form-control" id="vSearchUserForward">
                                    </div>
                                </div>

                                <input type="hidden" name="iActiveMessageId" id="iActiveMessageId" value="" />
                                <input type="hidden" name="vActiveMessage" id="vActiveMessage" value="" />
                                <input type="hidden" name="vForwardDataType" id="vForwardDataType" value="" />

                                <ul class="mb-0 mt-2 list" id="forwrdModalGrpMembList">
                                </ul>

                            </div>
                        </div>
                        <div class="col-lg-6 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="list user-selected">
                                        <ul id="ForwardSelTags">
                                        </ul>
                                    </div>

                                    <div class="add-group-popup-btn-container">
                                        <button type="button" class="group-popup-btn d-none" id="submitForwardForm">Forward</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Forward Modal Form Code Ednd -->

    <!-- Group Info Modal Start -->
    <div class="modal fade groupDetails" id="groupDetails" tabindex="-1" aria-labelledby="groupDetailsLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-4 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="d-flex align-items-start">
                                        <div class="nav flex-column nav-pills" id="grouep-details" role="tablist" aria-orientation="vertical">
                                            <button class="nav-link active" id="group-basic-details" data-bs-toggle="pill" data-bs-target="#group-basic-details-pill" type="button" role="tab" aria-controls="group-basic-details-pill" aria-selected="true">Basic Details</button>
                                            <button class="nav-link" id="groupMembersTab" data-bs-toggle="pill" data-bs-target="#group-members-pill" type="button" role="tab" aria-controls="group-members-pill" aria-selected="false">Members</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 p-0">
                            <div class="modal-left">
                                <div class="tab-content" id="grouep-details">
                                    <!-- Group Basic Details Start -->
                                    <div class="tab-pane fade show active" id="group-basic-details-pill" role="tabpanel" aria-labelledby="group-basic-details" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Basic Details</p>
                                                <button type="button" class="modal-close-btn" id="groupDetailsClose"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <div class="d-flex mb-3">
                                                        <div class="group-profile-container">
                                                            <img src="images/profile/group-profile.svg" class="rounded-3" alt="Group Profile" id="vGroupInforProfile">
                                                        </div>
                                                    </div>

                                                    <p class="profile-view-title mb-3" id="vGroupInforName">Acme Corp.</p>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Created</p>
                                                        <p class="profile-view-disc mb-0" id="vGroupInfCreateDate">13 May 2024 12:52PM</p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Description</p>
                                                        <p class="profile-view-disc mb-0" id="vGroupInfoDescription">Duis aute irure dolor in
                                                            reprehenderit in voluptate velit esse cillum dolore eu
                                                            fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                                                            proident, sunt in culpa qui officia deserunt mollit anim id
                                                            ... </p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Group Admin</p>
                                                        <ul>
                                                            <li>
                                                                <div class="chat-list">
                                                                    <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="user-profile-image me-3">
                                                                                <svg role="none" viewBox="0 0 96 96">
                                                                                    <mask id="profile-image">
                                                                                        <circle fill="white" cx="48" cy="48" r="48">
                                                                                        </circle>
                                                                                        <circle fill="black" cx="86%" cy="86%" r="18">
                                                                                        </circle>
                                                                                    </mask>
                                                                                    <g mask="url(#profile-image)">
                                                                                        <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="vGroupOwnerProfile" xlink:href="images/profile/user-profile.svg">
                                                                                        </image>
                                                                                    </g>
                                                                                </svg>
                                                                                <div class="online" id="vGroupOwnerStsCls"></div>
                                                                            </div>
                                                                            <div>
                                                                                <h5 class="user-profile-name" id="vGroupOwnerName">Abhay A.
                                                                                    Achariya </h5>
                                                                                <p class="user-profile-activity" id="vGroupOwnerSts">Online
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Group Basic Details End -->

                                    <!-- Group Members Start -->
                                    <div class="tab-pane fade" id="group-members-pill" role="tabpanel" aria-labelledby="group-members" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Members</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>

                                            <div class="searchBar mt-2">
                                                <span><i data-feather="search" class="feather-20"></i></span>
                                                <input type="text" class="form-control" id="vGroupInfoSearchMember">
                                            </div>
                                        </div>

                                        <ul class="mb-0 mt-2 list" id="vGroupInfoMemeberList">
                                        </ul>
                                    </div>
                                    <!-- Group Members End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Group Info Modal End -->

    <!-- Group Info Modal Edit Start -->
    <div class="modal fade groupDetails" id="groupDetailsEdit" tabindex="-1" aria-labelledby="groupDetailsEditLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-4 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="d-flex align-items-start">
                                        <div class="nav flex-column nav-pills" id="grouep-details-edit" role="tablist" aria-orientation="vertical">
                                            <button class="nav-link active" id="vEditGrupBasicDetBtn" data-bs-toggle="pill" data-bs-target="#group-basic-details-edit-pill" type="button" role="tab" aria-controls="group-basic-details-edit-pill" aria-selected="true">Basic Details</button>
                                            <button class="nav-link" id="vGroupEditMemberList" data-bs-toggle="pill" data-bs-target="#group-members-edit-pill" type="button" role="tab" aria-controls="group-members-edit-pill" aria-selected="false">Members</button>

                                            <button class="nav-link modal-group-delete-btn" id="vGroupDeleteGroup" type="button" aria-controls="group-members-pill" aria-selected="false">Delete Group</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 p-0">
                            <div class="modal-left">
                                <div class="tab-content" id="grouep-details-edit">
                                    <!-- Group Basic Details Start -->
                                    <div class="tab-pane fade show active" id="group-basic-details-edit-pill" role="tabpanel" aria-labelledby="group-basic-details-edit" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Group Basic Details</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <p class="title">Group Picture</p>
                                                    <div class="d-flex mb-3">
                                                        <div class="group-profile-container">
                                                            <img src="images/profile/group-profile.svg" class="rounded-3" alt="Group Profile" id="vGroupEditProfile">
                                                            <a id="vEditProfilePickBtn" class="edit-icon cursor-pointer">
                                                                <i data-feather="edit-3" class="feather-20"></i>
                                                            </a>
                                                        </div>
                                                    </div>

                                                    <div class="create-group-form">
                                                        <div class="mb-3">
                                                            <label class="form-label">Group Name<span>*</span></label>
                                                            <input type="text" class="form-control" id="vEditGrupName">
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label">Description</label>
                                                            <textarea class="form-control" rows="4" id="vEditGroupDesc" maxlength="350"></textarea>
                                                            <span class="max-car-length text-end w-100 d-block pt-2" id="totalCharDisp">0/350</span>
                                                        </div>
                                                    </div>

                                                    <div class="mb-3">
                                                        <p class="profile-view-subtitle mb-2">Group Admin</p>
                                                        <ul>
                                                            <li>
                                                                <div class="chat-list">
                                                                    <label class="d-flex align-items-center justify-content-between form-check ps-0" for="flexCheckDefault2">
                                                                        <div class="d-flex align-items-center">
                                                                            <div class="user-profile-image me-3">
                                                                                <svg role="none" viewBox="0 0 96 96">
                                                                                    <mask id="profile-image">
                                                                                        <circle fill="white" cx="48" cy="48" r="48">
                                                                                        </circle>
                                                                                        <circle fill="black" cx="86%" cy="86%" r="18">
                                                                                        </circle>
                                                                                    </mask>
                                                                                    <g mask="url(#profile-image)">
                                                                                        <image x="0" y="0" height="100%" preserveAspectRatio="xMidYMid slice" width="100%" id="vEditGropOwnProfile" xlink:href="images/profile/user-profile.svg">
                                                                                        </image>
                                                                                    </g>
                                                                                </svg>
                                                                                <div class="online" id="vEditGroupOwnerStsCls"></div>
                                                                            </div>
                                                                            <div>
                                                                                <h5 class="user-profile-name" id="vEditGroupOwnerName">Abhay A.
                                                                                    Achariya </h5>
                                                                                <p class="user-profile-activity" id="vEditGroupOwnerSts">Online
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn" id="UpdateGroupBasicDetail">Save</button>
                                        </div>
                                    </div>
                                    <!-- Group Basic Details End -->

                                    <!-- Group Members Start -->
                                    <div class="tab-pane fade" id="group-members-edit-pill" role="tabpanel" aria-labelledby="group-members-edit" tabindex="0">
                                        <div class="fixed-content">
                                            <div id="editGroupModalHeader" class="create-group-popup-header position-relative modal-header-custom">
                                                <a id="EditGroupModalBackBtn" class="cursor-pointer close-new-group d-none"><i data-feather="arrow-left" class="feather-20"></i></a>
                                                <p id="editGroupHeaderTitle">Group Members</p>
                                                <a id="EditGroupModalCloseBtn" data-bs-dismiss="modal" class="close-new-group cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                                            </div>

                                            <div class="search-add pt-2">
                                                <div class="searchBar me-2">
                                                    <span><i data-feather="search" class="feather-20"></i></span>
                                                    <input type="text" class="form-control" id="vSearchEditMember">
                                                </div>
                                                <div class="new-chat">
                                                    <button id="NewUserGrpBtn"><span><i data-feather="plus" class="feather-20"></i></span></button>
                                                </div>
                                            </div>
                                        </div>

                                        <ul class="mb-0 mt-2 list" id="vEditGrpMemeberOld">
                                        </ul>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn" id="vEditGrpButtonUpd">Save</button>
                                            <button type="button" class="group-popup-btn d-none" id="vEditGrpButtonAdd">Add</button>
                                        </div>
                                    </div>
                                    <!-- Group Members End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Group Info Modal Edit End -->


    <!-- Member Required Information Modal -->
    <div class="modal fade groupMemberModal" id="groupMemberModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Attention!</p>
                        <a data-bs-dismiss="modal" id="groupMemberModalClose" class="cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">At least one member is required for the group.</h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-primary" id="groupMemberModalSubmit">Ok</button>
                        </div>
                        <!-- <div class="d-flex justify-content-center mt-3">
                            <button class="btn btn-primary" id="groupMemberModalSubmit">OK</button>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Member Required Information Modal -->

    <!-- Delete Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="groupDeleteModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Delete Confirm</p>
                        <a data-bs-dismiss="modal" id="groupDeleteModalClose" class="cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete group!</h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-danger" id="groupDeleteModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="groupDeleteModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Confirmation Modal -->

    <!-- Edit Profile Picture Modal Start -->
    <div class="modal fade groupDetails" id="editProfilePickModal" tabindex="-1" aria-labelledby="groupDetailsEditLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row gx-0">
                        <div class="col-lg-4 p-0">
                            <div class="modal-right">
                                <div class="fixed-content">
                                    <div class="d-flex align-items-start">
                                        <div class="nav flex-column nav-pills" role="tablist" aria-orientation="vertical">
                                            <button class="nav-link active" id="vUserDetailTab" data-bs-toggle="pill" data-bs-target="#user-basic-tab" type="button" role="tab" aria-controls="user-basic-tab" aria-selected="true">User Details</button>
                                            <button class="nav-link" id="vUserChangePwdTab" data-bs-toggle="pill" data-bs-target="#user-change-password" type="button" role="tab" aria-controls="user-change-password" aria-selected="false">Change Password</button>
                                            <button class="nav-link danger modal-group-delete-btn" id="vUserDeleteProfTab" data-bs-toggle="pill" data-bs-target="#user-delete-profile" type="button" role="tab" aria-controls="user-delete-profile" aria-selected="false">Delete Profile</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-8 p-0">
                            <div class="modal-left">
                                <div class="tab-content">
                                    <!-- User Details Start -->
                                    <div class="tab-pane fade show active" id="user-basic-tab" role="tabpanel" aria-labelledby="user-basic-tab" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">User Details</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <p class="title">Profile Picture</p>
                                                    <div class="d-flex mb-3">
                                                        <div class="group-profile-container">
                                                            <img src="images/profile/group-profile.svg" class="rounded-circle" alt="User Profile" id="vEditUserProfilePick">
                                                            <a id="vEditUserProfilePickBtn" class="edit-icon cursor-pointer">
                                                                <i data-feather="edit-3" class="feather-20"></i>
                                                            </a>
                                                        </div>
                                                    </div>

                                                    <div class="create-group-form">
                                                        <div class="mb-3">
                                                            <label class="form-label">User Id</label>
                                                            <div class="d-flex gap-3 position-relative">
                                                                <input type="text" class="form-control" id="vUserDispId" disabled>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="create-group-form">
                                                        <div class="mb-3" data-error="Required">
                                                            <label class="form-label">User Name<span>*</span></label>
                                                            <input type="text" class="form-control" id="vEditProfileFullName">
                                                            <span class="alert alert-danger mt-2 d-none" id="vEditProfileFullNameErr">This field is required.</span>
                                                        </div>
                                                    </div>

                                                    <div class="create-group-form">
                                                        <div class="mb-3" data-error="Required">
                                                            <label class="form-label">Email<span>*</span></label>
                                                            <div class="d-flex gap-3 position-relative">
                                                                <input type="text" class="form-control" id="vEditEmailAddrss" disabled>
                                                                <button type="button" class="btn btn-primary btn-sm d-flex align-items-center" id="changeEmailAddressBtn"><i class="feather feather-20" data-feather="edit-3"></i></button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn" id="editProfilePickModalSubmit">Save</button>
                                        </div>
                                    </div>
                                    <!-- User Details End -->

                                    <!-- User Change Password Start -->
                                    <div class="tab-pane fade show" id="user-change-password" role="tabpanel" aria-labelledby="user-change-password" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Change Password</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <div class="create-group-form">
                                                        <div class="mb-3" data-error="Required">
                                                            <label class="form-label">Old Password<span>*</span></label>
                                                            <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                                                <input type="password" class="form-control" id="vOldPassword" minlength="8" maxlength="15">
                                                                <div class="passwordView">
                                                                    <span id="ViewOldPassword"><i class="feather feather-18" data-feather="eye-off"></i></span>
                                                                </div>
                                                            </div>

                                                            <span class="alert alert-danger mt-2 d-none" id="vOldPasswordErr">This field is required.</span>
                                                        </div>
                                                    </div>
                                                    <div class="create-group-form">
                                                        <div class="mb-3" data-error="Required">
                                                            <label class="form-label">New Password<span>*</span></label>
                                                            <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                                                <input type="password" class="form-control" id="vNewPassword" minlength="8" maxlength="15">
                                                                <!-- <button id="ViewNewPassword">View</button> -->
                                                                <div class="passwordView">
                                                                    <span id="ViewNewPassword"><i class="feather feather-18" data-feather="eye-off"></i></span>
                                                                </div>
                                                            </div>

                                                            <div id="passwordErrSuggest" class="d-none mt-3">
                                                                <h6 class="validationTitle mb-2">Password requirements</h6>
                                                                <ul id="passwordErrorList">
                                                                </ul>
                                                                <!-- <li class="validation validation-complete">
                                                                        <div class="d-flex align-items-center">
                                                                            <img src="./images/svgs/validation-check.svg" alt="">
                                                                            <p class="mb-0">Password must be at least eight characters long.</p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="validation validation-pending">
                                                                        <div class="d-flex align-items-center">
                                                                            <img src="./images/svgs/validation-cross.svg" alt="">
                                                                            <p class="mb-0">Password must include at least one special character.</p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="validation validation-pending">
                                                                        <div class="d-flex align-items-center">
                                                                            <img src="./images/svgs/validation-cross.svg" alt="">
                                                                            <p class="mb-0">Password must include at least one number.</p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="validation validation-complete">
                                                                        <div class="d-flex align-items-center">
                                                                            <img src="./images/svgs/validation-check.svg" alt="">
                                                                            <p class="mb-0">Password must include at least one lowercase letter.</p>
                                                                        </div>
                                                                    </li>
                                                                    <li class="validation validation-complete">
                                                                        <div class="d-flex align-items-center">
                                                                            <img src="./images/svgs/validation-check.svg" alt="">
                                                                            <p class="mb-0">Password must include at least one uppercase letter.</p>
                                                                        </div>
                                                                    </li> -->
                                                            </div>

                                                            <!-- <span class="alert alert-danger mt-2 d-none" id="vNewPasswordErr">This field is required.</span> -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-group-popup-btn-container">
                                            <span id="editProfPassSuccesMsg" class="text-success-msg d-none">Your password has been changed successfully.</span>
                                            <button type="button" class="group-popup-btn" id="editProfChngePwd">Save</button>
                                        </div>
                                    </div>
                                    <!-- User Change Password End -->

                                    <!-- User Delete Profile Start -->
                                    <div class="tab-pane fade show" id="user-delete-profile" role="tabpanel" aria-labelledby="user-delete-profile" tabindex="0">
                                        <div class="fixed-content">
                                            <div class="modal-header-custom">
                                                <p class="title">Delete Profile</p>
                                                <button type="button" class="modal-close-btn" data-bs-dismiss="modal"><i data-feather="x" class="feather-20"></i></button>
                                            </div>
                                        </div>

                                        <div class="list">
                                            <div class="create-group-profile">
                                                <div>
                                                    <div class="create-group-form">
                                                        <div class="mb-3" data-error="Required">
                                                            <label class="form-label">Enter Password<span>*</span></label>
                                                            <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                                                <input type="password" class="form-control" id="vDeleProfVerfPwd">
                                                                <!-- <button id="ViewConfPassword">View</button> -->
                                                                <div class="passwordView">
                                                                    <span id="ViewDeletePwd"><i class="feather feather-18" data-feather="eye"></i></span>
                                                                </div>
                                                            </div>
                                                            <!-- <input type="password" class="form-control" id="vDeleProfVerfPwd">
                                                            <button type="button" id="ViewDeletePwd">View</button> -->
                                                            <span class="alert alert-danger mt-2 d-none" id="vDeleProfVerfPwdErr">This field is required.</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="add-group-popup-btn-container">
                                            <button type="button" class="group-popup-btn btn-danger" id="editDeleteProfBtn">Delete</button>
                                        </div>
                                    </div>
                                    <!-- User Delete Profile End -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Profile Picture Modal End -->

    <!-- Edit Group Profile -->
    <div class="modal fade changeProfile" id="vGroupProfilePickModal" tabindex="-1" aria-labelledby="changeProfileLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <a class="cursor-pointer" id="vBackGroupProfilePick"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p id="ImageCropperHeading">Create New Group</p>
                        <a class="cursor-pointer" id="vGroupProfilePickClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="system-default">
                        <p class="title">Custom Profile</p>
                        <ul class="mb-0">
                            <li>
                                <div class="d-flex align-items-center">
                                    <label class="cabinet profile">
                                        <figure>
                                            <img src="./images/profile/custom-group-profile.svg" class="gambar img-responsive img-thumbnail" alt="custom-group-profile" id="item-img-output">
                                        </figure>
                                        <input type="file" class="item-img file center-block" id="file_photo" name="file_photo" />
                                        <div class="add-group-popup-btn-container ms-2">
                                            <button type="button" style="pointer-events: none;" id="vChooseProfileBtn" class="group-popup-btn">Choose Profile</button>
                                        </div>
                                    </label>
                                    <div class="add-group-popup-btn-container ms-2">
                                        <button type="button" class="btn btn-danger d-none" id="deletGroupProfile">Delete Profile</button>
                                    </div>
                                </div>
                                <!-- <div style="display: flex;">
                                </div> -->
                            </li>
                        </ul>
                    </div>

                    <div class="chat-time-line">
                        <p>OR</p>
                    </div>

                    <div class="system-default">
                        <p class="title">System Default</p>
                        <ul id="vColorOptionHtml">
                        </ul>
                    </div>

                    <div class="system-default d-flex justify-content-start gap-3">
                        <button type="button" class="btn btn-primary" id="NewGroupProfilePickSubmit">Save</button>
                        <button type="button" class="btn btn-primary d-none" id="EditUserProfileSubmit">Save</button>
                        <button class="btn btn-secondary" id="vGroupProfilePickCancel">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Profile End -->

    <!-- Change Email Code Start -->
    <div class="modal fade groupMemberModal" id="changeEmailModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start" id="vEmailChangeTitle">Change Email</p>
                        <a data-bs-dismiss="modal" id="changeEmailModalClose" class="cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <div class="create-group-profile">
                            <div id="vChangeEmailForm">
                                <div class="create-group-form">
                                    <div class="mb-3" data-error="Required">
                                        <label class="form-label">Enter Password<span>*</span></label>
                                        <div class="d-flex align-items-center gap-3 position-relative passView-container">
                                            <input type="password" class="form-control" id="vEmailOldPassword">
                                            <div class="passwordView">
                                                <span id="ViewEmailOldPassrd"><i class="feather feather-18" data-feather="eye-off"></i></span>
                                            </div>
                                        </div>
                                        <!-- <button type="button" id="ViewEmailOldPassrd">View</button> -->
                                        <span class="alert alert-danger mt-2 d-none" id="vEmailOldPasswordErr">This field is required.</span>
                                    </div>
                                </div>
                                <div class="create-group-form">
                                    <div class="mb-3" data-error="Required">
                                        <label class="form-label">New Email<span>*</span></label>
                                        <input type="text" class="form-control" id="vNewEmailAddrs">
                                        <span class="alert alert-danger mt-2 d-none" id="vNewEmailAddrsErr">This field is required.</span>
                                    </div>
                                </div>

                                <span style="color:red;" class="d-none" id="vChangeEmailErrMsg"></span>
                            </div>
                            <div id="vChangeEmailOtp" class="d-none">
                                <p>Check your email address. We sent you a verification code. Enter that code below and save.</p>
                                <div class="create-group-form">
                                    <div class="mb-3" data-error="Required">
                                        <label class="form-label">Verification Code<span>*</span></label>
                                        <input type="text" class="form-control" id="vEmailChangeVerfCode">
                                        <span class="alert alert-danger mt-2 d-none" id="vEmailChangeVerfCodeErr">This field is required.</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <span id="verificationErrMsg" class="d-none" style="color: red;">Verification code is not correct!</span>

                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-primary" id="submitChangeEmail">Change</button>
                            <button class="btn btn-primary d-none" id="finalSubmitEmail">Verify</button>
                            <button class="btn btn-secondary" id="resendChangeEmail">Resend</button>
                            <button class="btn btn-secondary" id="submitChangeEmailClose">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Change Email Code End -->

    <!-- Crop Profile Start -->
    <div class="modal fade cropImagePop" id="cropImagePop" tabindex="-1" aria-labelledby="cropImagePopLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <a data-bs-dismiss="modal" class="close-new-group cursor-pointer"><i data-feather="arrow-left" class="feather-20"></i></a>
                        <p>Move & Scale Profile</p>
                        <a data-bs-dismiss="modal" class="close-new-group cursor-pointer"><i data-feather="x" class="feather-20"></i></a>
                    </div>
                    <div class="d-flex justify-content-center">
                        <div id="upload-demo" class="center-block"></div>
                    </div>
                    <div class="d-flex justify-content-center" style="padding: 12px;">
                        <div class="add-group-popup-btn-container mt-2">
                            <button type="button" id="cropImageBtn" class="group-popup-btn">Choose</button>
                        </div>
                    </div>
                    <!-- <button type="button" id="cropImageBtn" class="btn btn-primary">Crop Profile</button> -->
                </div>
            </div>
        </div>
    </div>
    <!-- Crop Profile End -->

    <!-- Delete Single Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="msgDelConfirmModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="msgDelConfirmModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete message?</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="msgDelConfirmModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="msgDelConfirmModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Single Message Confirmation Modal -->

    <!-- Delete Multiple Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="msgMultiDelConfirmModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="msgMultiDelConfirmModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete message?</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="msgMultiDelConfirmModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="msgMultiDelConfirmModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Multiple Message Confirmation Modal -->

    <!-- Delete Multiple Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="delGrpProfConfModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="delGrpProfConfModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete profile picture?</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="delGrpProfConfModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="delGrpProfConfModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Multiple Message Confirmation Modal -->

    <!-- Delete Multiple Message Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="delGroupMemeberModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="delGroupMemeberModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete member!</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="delGroupMemeberModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="delGroupMemeberModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Delete Multiple Message Confirmation Modal -->

    <!-- Clear User Chat history Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="delUserChatHist" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="delUserChatHistClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Deleting the chat from your history will be permanent. And will remove your connection with <span class="vDeleteUserNameChtConf">ABC</span>. <span class="vDeleteUserNameChtConf">ABC</span> can still view this chat.</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="delUserChatHistSubmit">Delete</button>
                            <button class="btn btn-secondary" id="delUserChatHistCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Clear User Chat history Confirmation Modal -->

    <!-- Clear Group Chat history Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="delGroupChatHist" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" id="delGroupChatHistClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Deleting the chat from your history will be permanent. The group members can still view this chat.</br></br>
                            pending replace message</h4>
                        <div class="system-default d-flex justify-content-start gap-3">
                            <button class="btn btn-danger" id="delGroupChatHistSubmit">Delete</button>
                            <button class="btn btn-secondary" id="delGroupChatHistCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Clear Group Chat history Confirmation Modal -->

    <!-- New Group Memeber Delete Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="newGroupMembDeleteConf" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" data-bs-dismiss="modal" id="newGroupMembDeleteConfClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete member?</h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-danger" id="newGroupMembDeleteConfSubmit">Delete</button>
                            <button class="btn btn-secondary" id="newGroupMembDeleteConfCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- New Group Memeber Delete Confirmation Modal -->


    <!--Profile Delete Confirmation Modal -->
    <div class="modal fade groupMemberModal" id="profileDeleteConfModal" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" data-bs-dismiss="modal" id="profileDeleteConfModalClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete profile?</h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-danger" id="profileDeleteConfModalSubmit">Delete</button>
                            <button class="btn btn-secondary" id="profileDeleteConfModalCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Profile Delete Confirmation Modal -->

    <!--Group delete for me confirmation -->
    <div class="modal fade groupMemberModal" id="grpDeleteForMeConf" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Delete Confirm</p>
                        <a class="cursor-pointer" data-bs-dismiss="modal" id="grpDeleteForMeConfClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Are you sure you want to delete group?</br></br>
                            pending replace message</h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-danger" id="grpDeleteForMeConfSubmit">Delete</button>
                            <button class="btn btn-secondary" id="grpDeleteForMeConfCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Group delete for me confirmation -->


    <!--Group delete for me confirmation -->
    <div class="modal fade groupMemberModal" id="exitGroupConf" tabindex="-1" aria-labelledby="groupMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-sm">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="create-group-popup-header position-relative">
                        <!-- <a class="close-new-group cursor-pointer"><i data-feather="arrow-left"
                                class="feather-20"></i></a> -->
                        <p class="text-start">Exit from group</p>
                        <a class="cursor-pointer" data-bs-dismiss="modal" id="exitGroupConfClose"><i data-feather="x" class="feather-20"></i></a>
                    </div>

                    <div class="groupMemberModalContainer">
                        <h4 class="title">Deleting the chat from your history will be permanent. The group members can still view this chat.
                            </br></br>
                            pending replace message
                        </h4>
                        <div class="d-flex justify-content-start mt-3 gap-3">
                            <button class="btn btn-danger" id="exitGroupConfSubmit">Exit Group</button>
                            <button class="btn btn-secondary" id="exitGroupConfCancel">Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Group delete for me confirmation -->

    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<script>window.jQuery || document.write('<script src="../js/minified/jquery-1.11.0.min.js"><\/script>')</script> -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="plugins/bootstrap/bootstrap.bundle.min.js"></script>
    <script src="https://foliotek.github.io/Croppie/croppie.js"></script>
    <script src="plugins/feather-icon/feather.min.js"></script>
    <!-- <script src="./plugins/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> -->

    <script src="plugins/socket/socket.io.min.js"></script>

    <script>
        const API_URL = "<?= $API_URL ?>";
    </script>
    <script src="js/custom2.js"></script>
    <script src="js/CustomFun.js"></script>
    <script src="js/main.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            var vMessage = document.getElementById('vMessage');

            // Ensuring autocomplete is disabled
            vMessage.setAttribute('autocomplete', 'off');

            // Ensuring spellcheck is disabled
            vMessage.setAttribute('spellcheck', 'false');

            // Add event listener to prevent suggestions
            vMessage.addEventListener('focus', function() {
                this.setAttribute('autocomplete', 'off');
                this.setAttribute('spellcheck', 'false');
            });

            vMessage.addEventListener('input', function() {
                this.setAttribute('autocomplete', 'off');
                this.setAttribute('spellcheck', 'false');
            });
        });

        // Input Disable
        $(document).ready(function() {
            $('input:disabled').after('<div class="disable-lock"><i class="feather feather-16" data-feather="lock"></i></div>');
            feather.replace();
        });

        $(window).on("load", function() {
            $("body").mCustomScrollbar({
                // theme:"minimal",
                // mouseWheelPixels: 50
            });
        });

        window.onload = function() {
    // Function to initialize and bind scroll events
    function initializeScrollable(scrollableSelector, height, width) {
        // Cache DOM Element
        var scrollable = $(scrollableSelector);

        // Keeping the Scrollable state separate
        var state = {
            pos: {
                lowest: 0,
                current: 0
            },
            offset: {
                top: [0, 0], //Old Offset, New Offset
            }
        }

        // Initialize slimScroll
        scrollable.slimScroll({
            height: height,
            width: width,
            start: 'bottom'
        });

        // Bind scroll event
        scrollable.slimScroll().bind('slimscrolling', function(e, pos) {
            // Update the Scroll Position and Offset

            // Highest Position
            state.pos.highest = pos !== state.pos.highest ?
                pos > state.pos.highest ? pos : state.pos.highest :
                state.pos.highest;

            // Update Offset State
            state.offset.top.push(pos - state.pos.lowest);
            state.offset.top.shift();

            if (state.offset.top[0] < state.offset.top[1]) {
                console.log('...Scrolling Down');
                // ... YOUR CODE ...
            } else if (state.offset.top[1] < state.offset.top[0]) {
                console.log('Scrolling Up...');
                // ... YOUR CODE ...
            } else {
                console.log('Not Scrolling');
                // ... YOUR CODE ...
            }
        });
    }

    // Initialize both scrollables
    initializeScrollable('.scrollable', 'calc(100% - 77px)', '100%');
    initializeScrollable('.scrollable2', 'calc(270px - 46px)', '100%');
};



// window.onload = function() {
//     // Function to initialize and bind scroll events
//     function initializeScrollable(scrollableSelector, maxHeight, maxWidth) {
//         // Cache DOM Element
//         var scrollable = $(scrollableSelector);

//         // Keeping the Scrollable state separate
//         var state = {
//             pos: {
//                 lowest: 0,
//                 current: 0
//             },
//             offset: {
//                 top: [0, 0], //Old Offset, New Offset
//             }
//         }

//         // Initialize slimScroll with maxHeight and maxWidth
//         scrollable.slimScroll({
//             height: 'auto',
//             width: 'auto',
//             maxHeight: maxHeight,
//             maxWidth: maxWidth,
//             start: 'top'
//         });

//         // Bind scroll event
//         scrollable.slimScroll().bind('slimscrolling', function(e, pos) {
//             // Update the Scroll Position and Offset

//             // Highest Position
//             state.pos.highest = pos !== state.pos.highest ?
//                 pos > state.pos.highest ? pos : state.pos.highest :
//                 state.pos.highest;

//             // Update Offset State
//             state.offset.top.push(pos - state.pos.lowest);
//             state.offset.top.shift();

//             if (state.offset.top[0] < state.offset.top[1]) {
//                 console.log('...Scrolling Down');
//                 // ... YOUR CODE ...
//             } else if (state.offset.top[1] < state.offset.top[0]) {
//                 console.log('Scrolling Up...');
//                 // ... YOUR CODE ...
//             } else {
//                 console.log('Not Scrolling');
//                 // ... YOUR CODE ...
//             }
//         });
//     }

//     // Initialize both scrollables with max-height and max-width
//     initializeScrollable('.scrollable', '32rem', '24rem');
//     initializeScrollable('.scrollable2', '100px', '100%');
// };



    </script>

</body>

</html>