<?php
$conn = new mysqli("localhost","admin","admin@8219","wetransfer");

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}
?>